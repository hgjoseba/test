# CV Screening SDK Examples with Azure Token Authentication

This directory contains examples showing how to use the CV Screening SDK with Azure token authentication instead of API keys.

## Examples Overview

### 1. Basic Azure Token Authentication

**File:** `example_1_azure_token_auth.py`

This example demonstrates:
- How to initialize the Azure authentication provider with service principal credentials
- How to obtain a token from Azure
- How to use the token with the CV Screening client
- Basic CV analysis with text content

### 2. Using DefaultAzureCredential

**File:** `example_2_azure_default_credentials.py`

This example demonstrates:
- How to use DefaultAzureCredential for automatic authentication
- This is useful in Azure environments like Azure VMs, Functions, or CI/CD pipelines
- CV analysis with a file path input

### 3. Advanced Token Auth with Base64 Content

**File:** `example_3_azure_token_with_base64.py`

This example demonstrates:
- A service-oriented approach with proper error handling and logging
- How to work with base64 encoded CV content
- Lazy authentication initialization
- Structured output formatting

### 4. Token Authentication with SSL Verification Disabled

**File:** `example_4_azure_token_no_ssl_verify.py`

This example demonstrates:
- How to disable SSL verification when working in corporate environments with SSL inspection
- Warning handling for insecure connections
- Proper error handling with security recommendations
- Detailed results formatting for CV analysis

### 5. Token Authentication with Corporate Proxy

**File:** `example_5_azure_token_with_proxy.py`

This example demonstrates:
- How to configure and use Azure token authentication behind a corporate proxy
- Setting up proxy environment variables
- Combining proxy settings with SSL verification options
- Advanced output formatting with status indicators
- Comprehensive error handling with troubleshooting guidance

### 6. CV Analysis Without Job Criteria

**File:** `example_6_azure_token_without_criteria.py`

This example demonstrates:
- How to analyze a CV without providing specific job criteria
- Working with unstructured response data from general CV analysis
- Advanced error handling for different response formats
- Flexible output processing for general CV insights
- Using Azure token authentication for general-purpose CV parsing

## Prerequisites

To run these examples, you'll need:

1. Azure Active Directory (AAD) service principal with:
   - Tenant ID
   - Client ID
   - Client Secret

2. Azure OpenAI Service with:
   - Endpoint URL
   - Deployed model (e.g., "gpt-4")

## Environment Variables

The examples can use these environment variables:

```
# Azure Authentication
AZURE_TENANT_ID=your-tenant-id
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret

# Azure OpenAI Service
AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com

# For proxy examples
HTTP_PROXY=http://proxy.example.com:8080
HTTPS_PROXY=http://proxy.example.com:8080
```

## Running Examples

1. Install the CV Screening SDK:
   ```
   pip install cv-screening-sdk
   ```

2. Set the required environment variables or modify the examples to use your credentials directly

3. Run an example:
   ```
   python example_1_azure_token_auth.py
   ```

## Notes on Token Authentication

Instead of using an API key directly, these examples:
1. Authenticate with Azure AD to get a token
2. Use that token as the API key when initializing the CV Screening client

This approach is more secure because:
- No long-lived API keys are needed
- Tokens expire automatically
- You can use Azure's role-based access control (RBAC)
- Authentication can be managed centrally in Azure

## Use Cases

The examples cover different use cases:

- **Job-Specific CV Analysis** (Examples 1-5): Analyze CVs against specific job criteria to assess candidate suitability
- **General CV Analysis** (Example 6): Analyze CVs without job criteria to extract general insights and candidate profiles
- **Corporate Environments** (Examples 4-5): Use the SDK in environments with proxies or SSL inspection
- **Cloud Environments** (Example 2): Use managed identities and default credentials in Azure environments

## Corporate Environment Considerations

When using this SDK in corporate environments, you may encounter additional challenges:

### SSL Verification
Some corporate environments use SSL inspection, which can interfere with HTTPS connections.
Examples 4 and 5 demonstrate how to handle this by disabling SSL verification when necessary.
**Note:** Disabling SSL verification reduces security and should only be done in controlled environments.

### Proxy Configuration
Corporate networks often require the use of a proxy server for outbound connections.
Example 5 shows how to configure proxy settings for use with the Azure SDK.

For production use, consider:
1. Consulting with your IT department for proper certificate configuration
2. Using environment variables for proxy configuration
3. Implementing proper error handling for network-related issues 