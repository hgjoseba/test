"""
Ejemplo básico de uso de CV Screening SDK Light.

Este script demuestra el uso básico del SDK para analizar un CV.
"""

import json
import os
from dotenv import load_dotenv

from cv_screening_sdk_light import CVScreeningClient
from cv_screening_sdk_light.models import JobCriteria


def main():
    # Cargar variables de entorno desde archivo .env
    load_dotenv()
    
    # Inicializar cliente con la clave API desde variable de entorno
    client = CVScreeningClient(
        api_key=os.getenv("OPENAI_API_KEY"),
        model_name="gpt-4",
        # Configuración SSL - cambiar a False si hay problemas de conexión
        connection_verify=True,
    )
    
    # Definir criterios para el puesto
    criteria = JobCriteria(
        required_skills=["Python", "Django", "SQL"],
        preferred_skills=["Docker", "AWS", "Git"],
        min_years_experience=2,
        education_level="bachelor's",
        job_title="Desarrollador Backend",
        job_description="Buscamos un desarrollador backend con experiencia en Python y Django."
    )
    
    # Texto de CV para análisis
    cv_text = """
    María González
    Desarrolladora de Software
    maria@ejemplo.com | +34 612 345 678
    
    PERFIL
    Desarrolladora con 3 años de experiencia en Python, Django y bases de datos SQL.
    
    EXPERIENCIA
    Desarrolladora Backend, Empresa Tecnológica S.L. (2021-Presente)
    - Desarrollo de APIs RESTful con Django y Django REST Framework
    - Gestión de bases de datos PostgreSQL
    - Implementación de pipelines CI/CD con GitLab
    - Despliegue de aplicaciones en AWS
    
    Desarrolladora Junior, Startup Innovadora (2020-2021)
    - Desarrollo web con Python y Flask
    - Mantenimiento de bases de datos MySQL
    
    EDUCACIÓN
    Grado en Ingeniería Informática
    Universidad Politécnica (2016-2020)
    
    HABILIDADES
    - Lenguajes: Python, JavaScript, SQL
    - Frameworks: Django, Flask
    - Herramientas: Git, Docker, AWS
    - Bases de datos: PostgreSQL, MySQL
    """
    
    try:
        # Analizar CV
        result = client.analyze_cv(cv_text, criteria)
        
        # Imprimir resultado
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main() 