"""
Example of CV screening using Azure token credentials authentication.

This example demonstrates how to initialize the CV Screening client with
Azure token-based authentication instead of API keys.
"""

import os
from src import CVScreeningClient
from src.core.types import ContentType
from src.models.criteria import JobCriteria
from src.auth.azure import AzureAuthProvider

# Azure Service Principal credentials
tenant_id = os.environ.get("AZURE_TENANT_ID", "your-tenant-id")
client_id = os.environ.get("AZURE_CLIENT_ID", "your-client-id")
client_secret = os.environ.get("AZURE_CLIENT_SECRET", "your-client-secret")
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://your-resource-name.openai.azure.com")

# Initialize the Azure authentication provider
azure_auth = AzureAuthProvider(
    tenant_id=tenant_id,
    client_id=client_id,
    client_secret=client_secret
)

# Get token from the authentication provider
token = azure_auth.get_token()

# Create the client with token as api_key
# Note: Currently, the SDK expects an API key, but we can use the token obtained from Azure Auth
client = CVScreeningClient(
    api_key=token,  # Use token as API key
    endpoint=endpoint,
    model_name="gpt-4",  # or your specific deployment name
    temperature=0.1,
)

# Example CV content as plain text
cv_content = """
JOHN DOE
Software Engineer
john.doe@example.com | (123) 456-7890 | linkedin.com/in/johndoe

SKILLS
- Programming: Python, JavaScript, Java, C++
- Frameworks: Django, React, Spring Boot
- Tools: Git, Docker, Kubernetes, CI/CD
- Databases: PostgreSQL, MongoDB

EXPERIENCE
Senior Software Engineer | ABC Tech | 2020 - Present
- Led a team of 5 developers to build a microservices architecture
- Reduced API response time by 40% through optimization
- Implemented CI/CD pipeline using GitHub Actions

Software Engineer | XYZ Solutions | 2017 - 2020
- Developed and maintained RESTful APIs using Django
- Implemented real-time data visualization using React
- Reduced database query times by 30%

EDUCATION
Master of Science in Computer Science | Stanford University | 2015-2017
Bachelor of Science in Computer Engineering | MIT | 2011-2015
"""

# Define job criteria using the JobCriteria model
criteria = JobCriteria(
    job_title="Senior Python Developer",
    job_description="We're looking for an experienced Python developer with web development skills.",
    required_skills=["Python", "Django", "REST API"],
    preferred_skills=["React", "Docker", "AWS"],
    min_years_experience=3,
    education_level="bachelor's"
)

# Analyze the CV against the job criteria
result = client.analyze_cv(
    content=cv_content,
    criteria=criteria,
    content_type=ContentType.TEXT
)

# Print the analysis results
print("CV Analysis Results:")
print(f"Overall Match: {result.get('overall_match', 'N/A')}%")

# Print skills matching details
skills_match = result.get('skills_match', {})
if skills_match:
    print("\nSkills Match:")
    
    required = skills_match.get('required_skills', {})
    if required:
        print("  Required Skills:")
        for skill, score in required.items():
            print(f"    - {skill}: {score:.2f}")
    
    preferred = skills_match.get('preferred_skills', {})
    if preferred:
        print("  Preferred Skills:")
        for skill, score in preferred.items():
            print(f"    - {skill}: {score:.2f}")
    
    missing_required = skills_match.get('missing_required', [])
    if missing_required:
        print("  Missing Required Skills:")
        for skill in missing_required:
            print(f"    - {skill}")

# Print experience and education match if available
if 'experience_match' in result:
    print(f"\nExperience Match: {result['experience_match'].get('score', 'N/A')}%")

if 'education_match' in result:
    print(f"Education Match: {result['education_match'].get('score', 'N/A')}%") 