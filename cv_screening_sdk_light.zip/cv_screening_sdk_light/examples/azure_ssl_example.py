"""
Ejemplo de uso de Azure OpenAI con distintas opciones de verificación SSL.

Este script demuestra cómo usar el proveedor de Azure OpenAI con y sin verificación SSL.
"""

import json
import os
from dotenv import load_dotenv

from cv_screening_sdk_light.providers.azure_provider import AzureOpenAIProvider


def main():
    # Cargar variables de entorno del archivo .env
    load_dotenv()
    
    # Verificar credenciales de Azure OpenAI
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        print("Error: Se requieren las variables de entorno AZURE_OPENAI_ENDPOINT y AZURE_OPENAI_API_KEY")
        return
    
    # Ejemplo 1: Con verificación SSL (default)
    try:
        print("\n=== Ejemplo 1: Azure OpenAI con verificación SSL (por defecto) ===")
        
        # Inicializar el proveedor con verificación SSL (default)
        provider_with_ssl = AzureOpenAIProvider(
            endpoint=endpoint,
            api_key=api_key,
            deployment_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            # connection_verify=True (valor por defecto)
        )
        
        print("Proveedor inicializado correctamente con verificación SSL.")
        print("Se realizará la validación de certificados SSL en todas las conexiones.")
        
        # Ejemplo de análisis
        run_analysis(provider_with_ssl)
        
    except Exception as e:
        print(f"Error con verificación SSL: {e}")
        print("\nSi experimentas errores SSL, prueba el Ejemplo 2 deshabilitando la verificación SSL.")
    
    # Ejemplo 2: Sin verificación SSL
    try:
        print("\n=== Ejemplo 2: Azure OpenAI sin verificación SSL ===")
        
        # Inicializar el proveedor sin verificación SSL
        provider_no_ssl = AzureOpenAIProvider(
            endpoint=endpoint,
            api_key=api_key,
            deployment_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            connection_verify=False,  # Deshabilitar verificación SSL
        )
        
        print("Proveedor inicializado correctamente sin verificación SSL.")
        print("ADVERTENCIA: Se ha deshabilitado la validación de certificados SSL.")
        print("Esto puede ser útil en entornos corporativos con SSL interceptado o proxies SSL.")
        
        # Ejemplo de análisis
        run_analysis(provider_no_ssl)
        
    except Exception as e:
        print(f"Error incluso sin verificación SSL: {e}")


def run_analysis(provider):
    """Ejecuta un análisis de CV de ejemplo con el proveedor proporcionado."""
    try:
        # Ejemplo de CV simple
        cv_text = """
        Ana Martínez
        Ingeniera de Software
        
        EXPERIENCIA
        - 5 años como desarrolladora backend
        - Experiencia con Python, FastAPI y SQL
        
        EDUCACIÓN
        - Ingeniería Informática, Universidad Técnica
        
        HABILIDADES
        - Python, SQL, Docker, CI/CD
        """
        
        # Criterios básicos del trabajo
        criteria = {
            "required_skills": ["Python", "SQL"],
            "preferred_skills": ["Docker", "CI/CD"],
            "min_years_experience": 3,
        }
        
        print("\nAnalizando CV con Azure OpenAI...")
        
        # Analizar CV
        result = provider.analyze_cv(cv_text, criteria)
        
        # Mostrar resultados (forma resumida para el ejemplo)
        print(f"\nAnálisis completado. Puntuación general: {result.get('overall_match', 'N/A')}")
        print("Habilidades encontradas:")
        
        skills_match = result.get('skills_match', {})
        for skill_type, skills in skills_match.items():
            if isinstance(skills, dict):
                for skill, score in skills.items():
                    print(f"  - {skill}: {score}")
        
        print("\nResumen:", result.get('summary', 'No disponible'))
        
    except Exception as e:
        print(f"Error al analizar CV: {e}")


if __name__ == "__main__":
    main() 