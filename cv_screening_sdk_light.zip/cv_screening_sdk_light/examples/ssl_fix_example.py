"""
Ejemplo de solución de problemas SSL con CV Screening SDK Light.

Este script demuestra cómo resolver problemas de certificados SSL
cuando se trabaja en entornos corporativos o detrás de proxies SSL.
"""

import json
import os
import logging
from typing import Dict, Any
from dotenv import load_dotenv

from cv_screening_sdk_light import CVScreeningClient
from cv_screening_sdk_light.models import JobCriteria


# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def ejemplo_deshabilitar_ssl():
    """Ejemplo de cómo deshabilitar la verificación SSL."""
    
    print("\n=== Ejemplo: Deshabilitar verificación SSL ===")
    
    # Cargar variables de entorno
    load_dotenv()
    
    try:
        # Inicializar cliente con verificación SSL deshabilitada
        print("Inicializando cliente con verificación SSL deshabilitada...")
        client = CVScreeningClient(
            api_key=os.getenv("OPENAI_API_KEY"),
            model_name="gpt-4",
            # Importante: Deshabilita la verificación SSL
            connection_verify=False,
        )
        
        # Definir criterios para el puesto
        criteria = JobCriteria(
            required_skills=["JavaScript", "React", "CSS"],
            preferred_skills=["TypeScript", "Next.js"],
            min_years_experience=2,
            education_level="bachelor's",
            job_title="Desarrollador Frontend",
            job_description="Buscamos un desarrollador frontend con experiencia en React."
        )
        
        # CV de ejemplo para análisis
        cv_text = """
        Juan Pérez
        Desarrollador Frontend
        juan@ejemplo.com | +34 600 123 456
        
        EXPERIENCIA
        Desarrollador Frontend, Empresa Digital (2020-Presente)
        - Desarrollo de interfaces con React y TypeScript
        - Implementación de estilos con CSS y Tailwind
        
        EDUCACIÓN
        Grado en Ingeniería Informática (2016-2020)
        
        HABILIDADES
        - JavaScript, React, CSS, HTML
        - TypeScript, Next.js
        """
        
        # Analizar CV
        print("Analizando CV con verificación SSL deshabilitada...")
        result = client.analyze_cv(cv_text, criteria)
        
        # Mostrar resultado
        print("\nRESULTADO:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("\nAnálisis completado con éxito con verificación SSL deshabilitada.")
        return True
        
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        print("No se pudo completar el análisis con verificación SSL deshabilitada.")
        return False


def explicar_soluciones_ssl():
    """Muestra información sobre las soluciones para problemas SSL."""
    
    print("\n=== SOLUCIONES PARA PROBLEMAS SSL CON CV SCREENING SDK LIGHT ===")
    print("\nSi estás trabajando en un entorno corporativo o detrás de un proxy SSL,")
    print("es posible que encuentres problemas con la verificación de certificados SSL.")
    print("\nEl SDK te ofrece una solución sencilla para estos casos:")
    print("\n1. DESHABILITAR VERIFICACIÓN SSL (para desarrollo/pruebas):")
    print("   - Configuración simple: connection_verify=False en CVScreeningClient")
    print("   - El SDK se encarga de aplicar el monkey patch a httpx y configurar OpenAI")
    print("   - NOTA: Usa esta opción solo en entornos de desarrollo, no en producción")
    print("\nPara usar esta solución en tu código:")
    print("""
    # Inicializar cliente con verificación SSL deshabilitada
    client = CVScreeningClient(
        api_key="tu-api-key",
        connection_verify=False  # Deshabilita verificación SSL
    )
    """)
    print("\nRecomendaciones:")
    print("1. Usa connection_verify=False solo si tienes problemas de conexión SSL")
    print("2. En entornos de producción, es mejor resolver los problemas de certificados")
    print("   configurando correctamente los certificados raíz en tu sistema")


def main():
    """Función principal que ejecuta los ejemplos."""
    
    # Mostrar información sobre soluciones SSL
    explicar_soluciones_ssl()
    
    # Ejecutar ejemplo de deshabilitación SSL
    print("\n\nEjecutando ejemplo de deshabilitación SSL...")
    ejemplo_deshabilitar_ssl()
    
    print("\n\nPara más información sobre la configuración del SDK, consulta la documentación.")


if __name__ == "__main__":
    main() 