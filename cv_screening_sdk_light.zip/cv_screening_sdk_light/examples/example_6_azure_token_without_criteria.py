"""
Example of CV screening using Azure token authentication without specific job criteria.

This example demonstrates how to analyze a CV using Azure token-based authentication
without providing specific job criteria, useful for general CV analysis.
"""

import os
import json
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.types import ContentType
from cv_screening_sdk.auth.azure import AzureAuthProvider
from cv_screening_sdk.core.exceptions import AuthenticationError, OpenAIError

# Azure Service Principal credentials
tenant_id = os.environ.get("AZURE_TENANT_ID", "your-tenant-id")
client_id = os.environ.get("AZURE_CLIENT_ID", "your-client-id")
client_secret = os.environ.get("AZURE_CLIENT_SECRET", "your-client-secret")
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://your-resource-name.openai.azure.com")

# Verbose mode for debugging
VERBOSE = True

def log(message):
    """Simple logging function that only prints if VERBOSE is True."""
    if VERBOSE:
        print(message)

# Initialize the Azure authentication provider
log("Initializing Azure authentication provider...")
azure_auth = AzureAuthProvider(
    tenant_id=tenant_id,
    client_id=client_id,
    client_secret=client_secret
)

try:
    # Get token from the authentication provider
    log("Obtaining authentication token from Azure...")
    token = azure_auth.get_token()
    log("Token obtained successfully")
    
    # Create the client with token as api_key
    log("Initializing CV Screening client...")
    client = CVScreeningClient(
        api_key=token,  # Use token as API key
        endpoint=endpoint,
        model_name="gpt-4",  # or your specific deployment name
        temperature=0.5,  # Higher temperature for more creative analysis without specific criteria
    )
    
    # Example CV content
    cv_content = """
    MICHAEL GARCIA
    Data Engineer
    michael.garcia@example.com | (555) 345-6789 | github.com/mgarcia

    PROFESSIONAL SUMMARY
    Experienced Data Engineer with 5 years of expertise in designing and implementing data pipelines, ETL processes, 
    and data warehousing solutions. Skilled in cloud platforms, big data technologies, and programming languages.
    Passionate about transforming raw data into actionable insights for business decision-making.

    SKILLS
    - Programming: Python, SQL, Scala, Java
    - Big Data: Hadoop, Spark, Kafka, Airflow
    - Cloud: AWS (Redshift, S3, EMR), Azure (Data Factory, Synapse)
    - Databases: PostgreSQL, MongoDB, Cassandra, Snowflake
    - Tools: Docker, Kubernetes, Git, Terraform, Jenkins
    - Data Visualization: Tableau, Power BI

    EXPERIENCE
    Lead Data Engineer | DataStream Technologies | 2020 - Present
    - Architected and implemented end-to-end data pipelines processing 5TB of daily data
    - Reduced ETL job processing time by 40% through optimization of Spark jobs
    - Migrated on-premise data warehouse to AWS Redshift, cutting operational costs by 30%
    - Led a team of 4 engineers to implement real-time data streaming architecture using Kafka
    - Created data quality monitoring framework reducing data incidents by 60%

    Data Engineer | Analytics Innovations | 2018 - 2020
    - Developed ETL processes for customer data integration from multiple sources
    - Built data models for the analytics team to support business intelligence initiatives
    - Implemented CI/CD pipeline for database schema changes and ETL code deployment
    - Collaborated with data scientists to productionize machine learning models

    Junior Software Developer | Tech Solutions Inc. | 2016 - 2018
    - Developed and maintained backend services for customer-facing applications
    - Created REST APIs for data access and integration with third-party services
    - Participated in agile development process with two-week sprint cycles

    EDUCATION
    Master of Science in Computer Science | University of California | 2014-2016
    Bachelor of Science in Information Systems | State University | 2010-2014

    CERTIFICATIONS
    - AWS Certified Data Analytics Specialty
    - Microsoft Certified: Azure Data Engineer Associate
    - Databricks Certified Associate Developer for Apache Spark
    """
    
    # Analyze the CV without providing specific criteria
    log("Analyzing CV without specific job criteria...")
    result = client.analyze_cv(
        content=cv_content,
        criteria=None,  # No specific criteria provided
        content_type=ContentType.TEXT
    )
    
    # Print the analysis results
    print("\n==================================")
    print("GENERAL CV ANALYSIS RESULTS")
    print("==================================")
    
    # Print entire result in JSON format for reference
    if VERBOSE:
        print("\nRaw Analysis Result:")
        print(json.dumps(result, indent=2))
    
    # Extract and display the key information from the CV analysis
    print("\nKey Candidate Information:")
    print("--------------------------")
    
    # Try to extract name and title from raw response if available
    raw_response = result.get('raw_response', '')
    if isinstance(raw_response, str) and 'name' in raw_response.lower():
        print(raw_response)
    else:
        # If structured data is available, use it, otherwise show general message
        print(f"Name: Michael Garcia")
        print(f"Role: Data Engineer")
    
    # Extract skills if available
    if 'skills' in result:
        print("\nIdentified Skills:")
        for category, skills in result['skills'].items():
            print(f"  {category.replace('_', ' ').title()}:")
            for skill in skills:
                print(f"    - {skill}")
    elif 'skill_summary' in result:
        print("\nSkill Summary:")
        print(result['skill_summary'])
    
    # Experience summary
    if 'experience' in result:
        print("\nExperience Summary:")
        print(result['experience'])
    elif 'experience_summary' in result:
        print("\nExperience Summary:")
        print(result['experience_summary'])
    
    # Education summary
    if 'education' in result:
        print("\nEducation:")
        print(result['education'])
    
    # Overall assessment
    if 'summary' in result:
        print("\nOverall Assessment:")
        print(result['summary'])
    
    # Career recommendations if available
    if 'career_recommendations' in result:
        print("\nCareer Recommendations:")
        for rec in result['career_recommendations']:
            print(f"  - {rec}")
    
    # Strengths and areas for improvement
    if 'strengths' in result:
        print("\nStrengths:")
        for strength in result['strengths']:
            print(f"  - {strength}")
    
    if 'areas_for_improvement' in result:
        print("\nAreas for Improvement:")
        for area in result['areas_for_improvement']:
            print(f"  - {area}")
    
except AuthenticationError as e:
    print(f"Authentication Error: {e}")
    print("Please check your Azure credentials and try again.")
    
except OpenAIError as e:
    print(f"OpenAI Error: {e}")
    print("There was an issue with the CV analysis. The service might not support analysis without criteria.")
    print("Consider providing a generic set of criteria or checking the API documentation.")
    
except Exception as e:
    print(f"Unexpected Error: {e}")
    print("An error occurred during CV analysis.")

finally:
    print("\nNote: When analyzing CVs without specific criteria, the results may vary:")
    print("- The format may be less structured than with specific job criteria")
    print("- The analysis may focus on general skill identification and experience summary")
    print("- For best results, consider providing at least minimal criteria when possible") 