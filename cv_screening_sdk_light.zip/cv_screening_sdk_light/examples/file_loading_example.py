"""
Ejemplo de carga de CV desde archivo con CV Screening SDK Light.

Este script demuestra cómo cargar y analizar CVs desde archivos.
"""

import json
import os
import sys
from dotenv import load_dotenv

from cv_screening_sdk_light import CVScreeningClient
from cv_screening_sdk_light.models import JobCriteria
from cv_screening_sdk_light.core.exceptions import DocumentParsingError


def main():
    # Verificar argumentos
    if len(sys.argv) < 2:
        print("Uso: python file_loading_example.py <ruta_al_cv>")
        print("Formatos soportados: .txt, .pdf, .docx")
        return 1
    
    # Obtener ruta del CV
    cv_path = sys.argv[1]
    
    # Verificar que el archivo existe
    if not os.path.exists(cv_path):
        print(f"Error: El archivo {cv_path} no existe.")
        return 1
    
    # Cargar variables de entorno
    load_dotenv()
    
    # Definir criterios para el puesto de Científico de Datos
    criteria = JobCriteria(
        required_skills=["Python", "Machine Learning", "SQL", "Data Analysis"],
        preferred_skills=["Deep Learning", "TensorFlow", "PyTorch", "NLP", "Cloud Computing"],
        min_years_experience=3,
        education_level="master's",
        job_title="Científico de Datos Senior",
        job_description="Buscamos un científico de datos con experiencia en machine learning y análisis de datos para desarrollar soluciones innovadoras. El candidato ideal tendrá experiencia con librerías modernas de ML y capacidad para implementar modelos en producción."
    )
    
    try:
        # Inicializar cliente
        client = CVScreeningClient(
            api_key=os.getenv("OPENAI_API_KEY"),
            model_name="gpt-4",
            temperature=0.0,  # Valor bajo para resultados más consistentes
            connection_verify=True,  # Deshabilitar si hay problemas de certificados SSL
        )
        
        print(f"Cargando CV desde: {cv_path}")
        
        # Cargar y analizar CV
        try:
            # Cargar contenido del CV
            cv_content = client.load_cv_content(cv_path)
            print(f"CV cargado correctamente ({len(cv_content)} caracteres)")
            
            # Analizar CV
            print("Analizando CV...")
            result = client.analyze_cv(cv_content, criteria)
            
            # Imprimir resultado
            print("\nRESULTADO DEL ANÁLISIS:")
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
            # Imprimir resumen
            if "overall_match" in result:
                print(f"\nCoincidencia general: {result['overall_match']}%")
            if "summary" in result:
                print(f"\nResumen: {result['summary']}")
                
            return 0
            
        except DocumentParsingError as e:
            print(f"Error al procesar el documento: {str(e)}")
            print("Para procesar PDFs y DOCXs, instale las dependencias opcionales:")
            print("pip install 'cv-screening-sdk-light[document_processing]'")
            return 1
            
    except Exception as e:
        print(f"Error inesperado: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(main()) 