"""
Advanced example of CV screening using Azure token authentication with base64 encoded content.

This example demonstrates:
1. Using Azure token-based authentication
2. Processing a CV from base64 encoded content
3. Custom handling of analysis results
"""

import os
import base64
import json
import logging
from typing import Dict, Any, Optional

from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.types import ContentType
from cv_screening_sdk.models.criteria import JobCriteria
from cv_screening_sdk.auth.azure import AzureAuthProvider
from cv_screening_sdk.core.exceptions import AuthenticationError, OpenAIError

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class CVScreeningService:
    """Service class for CV screening with Azure token authentication."""
    
    def __init__(
        self,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        endpoint: Optional[str] = None,
        model_name: str = "gpt-4",
    ):
        """
        Initialize the CV screening service.
        
        Args:
            tenant_id: Azure tenant ID (defaults to AZURE_TENANT_ID env var)
            client_id: Azure client ID (defaults to AZURE_CLIENT_ID env var)
            client_secret: Azure client secret (defaults to AZURE_CLIENT_SECRET env var)
            endpoint: Azure OpenAI endpoint (defaults to AZURE_OPENAI_ENDPOINT env var)
            model_name: OpenAI model deployment name (defaults to "gpt-4")
        """
        self.tenant_id = tenant_id or os.environ.get("AZURE_TENANT_ID")
        self.client_id = client_id or os.environ.get("AZURE_CLIENT_ID")
        self.client_secret = client_secret or os.environ.get("AZURE_CLIENT_SECRET")
        self.endpoint = endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT")
        self.model_name = model_name
        
        # Initialize Azure Auth Provider
        self.azure_auth = None
        self.client = None
        
        logger.info("CV Screening Service initialized")
    
    def _initialize_auth(self) -> None:
        """Initialize Azure authentication provider and get token."""
        try:
            # Initialize Azure Auth Provider
            logger.info("Initializing Azure authentication provider")
            self.azure_auth = AzureAuthProvider(
                tenant_id=self.tenant_id,
                client_id=self.client_id,
                client_secret=self.client_secret
            )
            
            # Get token from Azure
            token = self.azure_auth.get_token()
            logger.info("Successfully obtained authentication token from Azure")
            
            # Initialize CV Screening Client with the token
            self.client = CVScreeningClient(
                api_key=token,  # Use token as API key
                endpoint=self.endpoint,
                model_name=self.model_name,
                temperature=0.1,
            )
            logger.info(f"CV Screening client initialized with model: {self.model_name}")
            
        except AuthenticationError as e:
            logger.error(f"Authentication error: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Error initializing authentication: {str(e)}")
            raise
    
    def analyze_cv_from_base64(
        self,
        cv_base64: str,
        criteria: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyze a CV from base64 encoded content.
        
        Args:
            cv_base64: CV content encoded as base64 string
            criteria: Job criteria as dictionary
            
        Returns:
            Analysis results
            
        Raises:
            OpenAIError: If analysis fails
            AuthenticationError: If authentication fails
        """
        # Initialize authentication if not already done
        if self.client is None:
            self._initialize_auth()
        
        try:
            # Analyze CV
            logger.info("Analyzing CV from base64 content")
            result = self.client.analyze_cv(
                content=cv_base64,
                criteria=criteria,
                content_type=ContentType.BASE64
            )
            
            logger.info("CV analysis completed successfully")
            return result
            
        except OpenAIError as e:
            logger.error(f"Error analyzing CV: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}")
            raise

# Example usage
if __name__ == "__main__":
    # Sample CV content
    cv_text = """
    ALEX JOHNSON
    Full Stack Developer
    alex.johnson@example.com | (555) 987-6543 | github.com/alexj | linkedin.com/in/alexjohnson

    SKILLS
    - Frontend: React, Vue.js, Angular, HTML5, CSS3, JavaScript/TypeScript
    - Backend: Node.js, Express, Django, Flask, FastAPI
    - Database: PostgreSQL, MongoDB, Redis, Elasticsearch
    - DevOps: Docker, Kubernetes, AWS, Azure, CI/CD (GitHub Actions, Jenkins)
    - Other: GraphQL, REST API, Microservices, Serverless

    EXPERIENCE
    Lead Developer | TechSolutions Inc. | 2019 - Present
    - Led development of cloud-native microservices architecture
    - Implemented serverless functions for high-traffic components
    - Reduced infrastructure costs by 35% through architecture optimization
    - Mentored junior developers and established coding standards

    Full Stack Developer | WebInnovate | 2016 - 2019
    - Built responsive web applications with React and Node.js
    - Developed RESTful APIs consumed by mobile and web clients
    - Implemented automated testing strategy increasing code coverage to 85%

    EDUCATION
    Master of Computer Science | University of Technology | 2014-2016
    Bachelor of Software Engineering | State University | 2010-2014
    """
    
    # Convert to base64
    cv_base64 = base64.b64encode(cv_text.encode('utf-8')).decode('utf-8')
    
    # Define job criteria
    criteria = JobCriteria(
        job_title="Senior Full Stack Developer",
        job_description="We're looking for an experienced full-stack developer with cloud expertise.",
        required_skills=["React", "Node.js", "Cloud", "REST API"],
        preferred_skills=["TypeScript", "Docker", "Kubernetes", "Microservices"],
        min_years_experience=4,
        education_level="bachelor's"
    )
    
    try:
        # Create service and analyze CV
        service = CVScreeningService()
        result = service.analyze_cv_from_base64(cv_base64, criteria.to_dict())
        
        # Print results in formatted JSON
        print("\nCV Analysis Results:")
        print(json.dumps(result, indent=2))
        
        # Print simple summary
        print("\nSummary:")
        print(f"Overall Match: {result.get('overall_match', 'N/A')}%")
        
        if 'experience_match' in result:
            print(f"Experience Match: {result['experience_match'].get('score', 'N/A')}%")
        
        if 'education_match' in result:
            print(f"Education Match: {result['education_match'].get('score', 'N/A')}%")
        
        # Print recommendation or conclusion
        if 'recommendation' in result:
            print(f"\nRecommendation: {result['recommendation']}")
        
    except AuthenticationError as e:
        print(f"Authentication Error: {e}")
        print("Please check your Azure credentials and try again.")
    except OpenAIError as e:
        print(f"OpenAI Error: {e}")
        print("There was an issue with the CV analysis. Please check your inputs and try again.")
    except Exception as e:
        print(f"Unexpected Error: {e}")
        print("An unexpected error occurred. Please contact support if the issue persists.") 