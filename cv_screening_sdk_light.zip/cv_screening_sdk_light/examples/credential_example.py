"""
Ejemplo de uso de credenciales de Azure con CV Screening SDK Light.

Este script demuestra cómo utilizar diferentes tipos de credenciales
para autenticarse con Azure OpenAI, gestionando la verificación SSL.
"""

import json
import os
import logging
from typing import Dict, Any
from dotenv import load_dotenv

from cv_screening_sdk_light.providers.azure_provider import AzureOpenAIProvider
from cv_screening_sdk_light.auth.azure import AzureCredentials, AzureAuthProvider
from cv_screening_sdk_light.models import JobCriteria


# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def example_service_principal():
    """
    Ejemplo de autenticación con Service Principal (Client Secret).
    
    Este es el método más común para aplicaciones y servicios.
    """
    print("\n=== Ejemplo: Autenticación con Service Principal ===")
    
    # Cargar variables de entorno
    load_dotenv()
    
    try:
        # Inicializar proveedor Azure con credenciales
        provider = AzureOpenAIProvider(
            endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
            tenant_id=os.environ.get("AZURE_TENANT_ID"),
            client_id=os.environ.get("AZURE_CLIENT_ID"),
            client_secret=os.environ.get("AZURE_CLIENT_SECRET"),
            deployment_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            # Importante: connection_verify controla la verificación SSL
            connection_verify=True,  # Cambiar a False si hay problemas de certificados
        )
        
        # Definir criterios para el puesto
        criteria = {
            "required_skills": ["Python", "Azure", "REST API"],
            "preferred_skills": ["Docker", "Kubernetes", "CI/CD"],
            "min_years_experience": 3,
            "education_level": "bachelor's",
            "job_title": "DevOps Engineer",
            "job_description": "Buscamos un DevOps Engineer con experiencia en Azure y automatización."
        }
        
        # CV de ejemplo para análisis
        cv_text = """
        Isabel García
        DevOps Engineer
        isabel@ejemplo.com | +34 678 456 123
        
        EXPERIENCIA
        DevOps Engineer, Empresa Cloud (2020-Presente)
        - Implementación de infraestructura como código con Terraform y Azure
        - Gestión de contenedores con Docker y Kubernetes
        - Implementación de pipelines CI/CD con Azure DevOps
        
        EDUCACIÓN
        Ingeniería Informática, Universidad Politécnica (2016-2020)
        
        HABILIDADES
        - Azure, AWS, GCP
        - Docker, Kubernetes, Terraform
        - Python, Bash, PowerShell
        """
        
        # Analizar CV
        print("Analizando CV con Azure OpenAI...")
        result = provider.analyze_cv(cv_text, criteria)
        
        # Mostrar resultado
        print("\nRESULTADO:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("\nAnálisis completado con éxito usando Service Principal.")
        return True
        
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        print("No se pudo completar el análisis con Service Principal.")
        print("¿Has configurado correctamente las variables de entorno?")
        return False


def example_disable_ssl_verification():
    """
    Ejemplo deshabilitando la verificación SSL para entornos con proxies o certificados personalizados.
    """
    print("\n=== Ejemplo: Deshabilitando verificación SSL con credenciales ===")
    
    # Cargar variables de entorno
    load_dotenv()
    
    try:
        # Crear credenciales directamente para mayor control
        credentials = AzureCredentials(
            tenant_id=os.environ.get("AZURE_TENANT_ID"),
            client_id=os.environ.get("AZURE_CLIENT_ID"),
            client_secret=os.environ.get("AZURE_CLIENT_SECRET"),
            # Importante: Deshabilitar verificación SSL
            connection_verify=False
        )
        
        # Crear proveedor de autenticación
        auth_provider = AzureAuthProvider(
            tenant_id=credentials.tenant_id,
            client_id=credentials.client_id,
            client_secret=credentials.client_secret,
            connection_verify=credentials.connection_verify
        )
        
        # Obtener token manualmente (demostración)
        print("Obteniendo token de autenticación...")
        token = auth_provider.get_token()
        print(f"Token obtenido: {token[:10]}...")
        
        # También se puede obtener la credencial directamente
        credential = auth_provider.get_credential()
        print(f"Credencial obtenida: {type(credential).__name__}")
        
        print("\nLa deshabilitación de SSL ha funcionado correctamente con las credenciales.")
        return True
        
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        print("No se pudo completar el ejemplo de deshabilitación SSL.")
        return False


def explain_connection_verify():
    """Explica el uso de connection_verify con credenciales."""
    print("\n=== USO DE CONNECTION_VERIFY CON CREDENCIALES ===")
    print("\nEl parámetro connection_verify se puede usar en dos lugares:")
    
    print("\n1. EN LAS CREDENCIALES:")
    print("Afecta a la autenticación y obtención de tokens.")
    print("""
    # Crear credenciales directamente
    credentials = AzureCredentials(
        tenant_id="tu-tenant-id",
        client_id="tu-client-id",
        client_secret="tu-client-secret",
        connection_verify=False  # Deshabilitar verificación SSL para autenticación
    )
    """)
    
    print("\n2. EN EL PROVEEDOR:")
    print("Afecta a todas las comunicaciones HTTP, incluida la autenticación.")
    print("""
    # Mediante el proveedor
    provider = AzureOpenAIProvider(
        endpoint="https://tu-endpoint.openai.azure.com/",
        tenant_id="tu-tenant-id",
        client_id="tu-client-id",
        client_secret="tu-client-secret",
        connection_verify=False  # Deshabilita verificación SSL para todo
    )
    """)
    
    print("\nCuando se deshabilita, el SDK aplica un monkey patch a httpx")
    print("para forzar verify=False en todas las conexiones HTTP.")
    
    print("\nRECOMENDACIONES:")
    print("- Usar connection_verify=True en producción (valor predeterminado)")
    print("- Deshabilitar solo si hay problemas con proxies o certificados")
    print("- La deshabilitación puede representar un riesgo de seguridad")


def main():
    """Función principal para ejecutar ejemplos."""
    # Mostrar información sobre connection_verify
    explain_connection_verify()
    
    # Ejecutar ejemplo con Service Principal
    print("\n\nEjecutando ejemplo con Service Principal...")
    if all([
        os.environ.get("AZURE_OPENAI_ENDPOINT"),
        os.environ.get("AZURE_TENANT_ID"),
        os.environ.get("AZURE_CLIENT_ID"),
        os.environ.get("AZURE_CLIENT_SECRET")
    ]):
        example_service_principal()
    else:
        print("No se encontraron todas las variables de entorno necesarias.")
        print("Por favor, configura AZURE_OPENAI_ENDPOINT, AZURE_TENANT_ID, AZURE_CLIENT_ID y AZURE_CLIENT_SECRET.")
    
    # Ejecutar ejemplo deshabilitando SSL
    print("\n\nEjecutando ejemplo deshabilitando verificación SSL...")
    if all([
        os.environ.get("AZURE_TENANT_ID"),
        os.environ.get("AZURE_CLIENT_ID"),
        os.environ.get("AZURE_CLIENT_SECRET")
    ]):
        example_disable_ssl_verification()
    else:
        print("No se encontraron todas las variables de entorno necesarias para las credenciales.")
    
    print("\n\nEjemplos completados. Para más información, consulta la documentación.")


if __name__ == "__main__":
    main() 