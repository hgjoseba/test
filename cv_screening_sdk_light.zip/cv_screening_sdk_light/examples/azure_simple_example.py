"""
Ejemplo de uso simplificado de Azure OpenAI con CV Screening SDK Light.

Este script demuestra cómo usar el proveedor simplificado de Azure OpenAI.
"""

import json
import os
from dotenv import load_dotenv

from cv_screening_sdk_light.providers.azure_provider import AzureOpenAIProvider
from cv_screening_sdk_light.models import JobCriteria


def main():
    # Cargar variables de entorno del archivo .env
    load_dotenv()
    
    # Verificar credenciales de Azure OpenAI
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        print("Error: Se requieren las variables de entorno AZURE_OPENAI_ENDPOINT y AZURE_OPENAI_API_KEY")
        return
    
    try:
        # Inicializar el proveedor de Azure OpenAI simplificado
        provider = AzureOpenAIProvider(
            endpoint=endpoint,
            api_key=api_key,
            deployment_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            # Personalizar el prompt del sistema (opcional)
            system_prompt="""Eres un asistente de análisis de CVs en español.
Tu tarea es evaluar currículums contra criterios de trabajo y proporcionar una evaluación detallada.
Tu respuesta debe ser un objeto JSON con puntuación general, concordancia de habilidades y recomendaciones."""
        )
        
        # Ejemplo de CV
        cv_text = """
        María González
        Desarrolladora de Software Senior
        maria@ejemplo.com | (123) 456-7890
        
        RESUMEN
        Desarrolladora con 6 años de experiencia en Python, APIs REST y bases de datos SQL.
        Experta en automatización, testing y metodologías ágiles.
        
        EXPERIENCIA
        Desarrolladora Senior, Empresa Tecnológica S.A. (2019-Presente)
        - Desarrollé APIs RESTful con Python y FastAPI
        - Diseñé y optimicé bases de datos PostgreSQL
        - Implementé CI/CD con GitHub Actions y Docker
        
        Desarrolladora, Startup Innovadora (2017-2019)
        - Creé aplicaciones web con Django y React
        - Trabajé con bases de datos MySQL
        - Implementé pruebas unitarias y de integración
        
        EDUCACIÓN
        Ingeniería en Informática
        Universidad Tecnológica (2013-2017)
        
        HABILIDADES
        - Lenguajes: Python, JavaScript, SQL
        - Frameworks: FastAPI, Django, Flask
        - Herramientas: Git, Docker, AWS, CI/CD
        - Bases de datos: PostgreSQL, MySQL
        """
        
        # Definir criterios del trabajo
        criteria = {
            "required_skills": ["Python", "API Development", "SQL"],
            "preferred_skills": ["Docker", "AWS", "FastAPI"],
            "min_years_experience": 5,
            "education_level": "bachelor's",
            "job_title": "Desarrollador Backend Senior",
            "job_description": "Buscamos un desarrollador backend con sólidos conocimientos en Python y APIs REST."
        }
        
        # Si prefieres usar la clase JobCriteria en lugar de un diccionario:
        # criteria = JobCriteria(
        #     required_skills=["Python", "API Development", "SQL"],
        #     preferred_skills=["Docker", "AWS", "FastAPI"],
        #     min_years_experience=5,
        #     education_level="bachelor's",
        #     job_title="Desarrollador Backend Senior",
        #     job_description="Buscamos un desarrollador backend con sólidos conocimientos en Python y APIs REST."
        # ).to_dict()
        
        print("Analizando CV con Azure OpenAI (versión simplificada)...")
        
        # Analizar CV
        result = provider.analyze_cv(cv_text, criteria)
        
        # Mostrar resultados
        print("\nResultados del análisis:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
        print("\nAnálisis completado con éxito usando Azure OpenAI simplificado.")
        
    except Exception as e:
        print(f"Error: {e}")
        print("No se pudo completar el análisis con Azure OpenAI.")


if __name__ == "__main__":
    main() 