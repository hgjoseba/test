"""
Example of CV screening using Azure Default Credentials authentication.

This example demonstrates how to use DefaultAzureCredential with the CV Screening SDK,
which is useful in Azure environments like Functions, VMs, or CI/CD pipelines.
"""

import os
from src import CVScreeningClient
from src.core.types import ContentType
from src.models.criteria import JobCriteria
from src.auth.azure import AzureAuthProvider

# Get Azure OpenAI endpoint
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://your-resource-name.openai.azure.com")

# Initialize Azure Auth Provider with no parameters to use DefaultAzureCredential
# This will try different authentication methods in order:
# - EnvironmentCredential (service principal in environment variables)
# - ManagedIdentityCredential (for Azure-hosted services)
# - Visual Studio Code credential
# - Azure CLI credential
# - Azure PowerShell credential
# - Interactive browser credential (as a last resort)
azure_auth = AzureAuthProvider()

# Get token from the authentication provider
token = azure_auth.get_token()

# Create client using the obtained token
client = CVScreeningClient(
    api_key=token,  # Use token as API key
    endpoint=endpoint,
    model_name="gpt-4",  # or your specific deployment name
)

# Path to a CV file
cv_file_path = "path/to/your/resume.pdf"

# Define job criteria as a dictionary
criteria = {
    "job_title": "DevOps Engineer",
    "job_description": "Looking for a DevOps engineer with cloud experience",
    "required_skills": ["Docker", "Kubernetes", "CI/CD", "Cloud Infrastructure"],
    "preferred_skills": ["AWS", "Azure", "GCP", "Terraform"],
    "min_years_experience": 3
}

# Analyze the CV file against the job criteria
# Note: You'll need to replace the file path with a real file
try:
    result = client.analyze_cv(
        content=cv_file_path,
        criteria=criteria,
        content_type=ContentType.FILE_PATH
    )
    
    # Print analysis results
    print("CV Analysis Results:")
    print(f"Overall Match: {result.get('overall_match', 'N/A')}%")
    
    # Print skills analysis
    if 'skills_match' in result:
        skills = result['skills_match']
        print("\nSkills Analysis:")
        
        # Print required skills
        if 'required_skills' in skills:
            print("  Required Skills:")
            for skill, score in skills['required_skills'].items():
                match_level = "High" if score > 0.8 else "Medium" if score > 0.5 else "Low"
                print(f"    - {skill}: {score:.2f} ({match_level} match)")
        
        # Print preferred skills
        if 'preferred_skills' in skills:
            print("\n  Preferred Skills:")
            for skill, score in skills['preferred_skills'].items():
                match_level = "High" if score > 0.8 else "Medium" if score > 0.5 else "Low"
                print(f"    - {skill}: {score:.2f} ({match_level} match)")
        
        # Print missing skills
        if skills.get('missing_required'):
            print("\n  Missing Required Skills:")
            for skill in skills['missing_required']:
                print(f"    - {skill}")
    
    # Print summary if available
    if 'summary' in result:
        print("\nSummary:")
        print(result['summary'])
    
except Exception as e:
    print(f"Error analyzing CV: {str(e)}")
    print("Note: For this example to work, you need a valid CV file and proper Azure authentication.") 