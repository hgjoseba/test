"""
Ejemplo de uso de systemprompt personalizado con CV Screening SDK Light.

Este script demuestra cómo configurar un systemprompt personalizado para el análisis de CVs.
"""

import json
import os
from dotenv import load_dotenv

from cv_screening_sdk_light import CVScreeningClient
from cv_screening_sdk_light.models import JobCriteria


def main():
    # Cargar variables de entorno del archivo .env
    load_dotenv()
    
    # Definir un systemprompt personalizado
    custom_system_prompt = """Eres un asistente experto en evaluación de currículos en español.
Tu tarea es analizar currículums y determinar si coinciden con los criterios laborales proporcionados.

Tu respuesta debe ser un objeto JSON con la siguiente estructura:
{
    "coincidencia_general": 75,
    "coincidencia_habilidades": {
        "habilidades_requeridas": {
            "python": 0.9
        },
        "habilidades_preferidas": {
            "docker": 0.7
        },
        "requeridas_faltantes": [],
        "preferidas_faltantes": []
    },
    "coincidencia_experiencia": {
        "años_de_experiencia": 5,
        "experiencia_relevante": 0.8,
        "cumple_mínimo": true
    },
    "coincidencia_educación": {
        "tiene_educación_requerida": true,
        "detalles_educación": {
            "nivel_más_alto": "Maestría",
            "campo": "Informática"
        }
    },
    "resumen": "Breve evaluación del candidato"
}"""
    
    # Inicializar cliente con clave API del entorno y systemprompt personalizado
    client = CVScreeningClient(
        api_key=os.getenv("OPENAI_API_KEY"),
        model_name="gpt-4",                 # Especificar nombre del modelo si es necesario
        temperature=0.1,                    # Temperatura baja para resultados más consistentes
        system_prompt=custom_system_prompt  # Configurar el systemprompt personalizado
    )
    
    # Definir criterios del trabajo
    criteria = JobCriteria(
        required_skills=["Python", "Desarrollo de API", "SQL"],
        preferred_skills=["Docker", "AWS", "Git", "CI/CD"],
        min_years_experience=3,
        education_level="licenciatura",
        job_title="Desarrollador Backend Senior",
        job_description="Buscamos un Desarrollador Backend Senior con sólidos conocimientos de Python y experiencia en construcción de APIs RESTful. El candidato debe tener buen entendimiento de bases de datos SQL y estar familiarizado con contenedorización y tecnologías cloud."
    )
    
    try:
        # Analizar CV de texto
        print("Ejemplo: Analizando CV con systemprompt personalizado en español")
        
        # Texto de CV de ejemplo
        cv_text = """
        Juan Pérez
        Desarrollador de Software Senior
        email@ejemplo.com | (123) 456-7890
        
        RESUMEN
        Desarrollador de software experimentado con 5 años de experiencia en Python, SQL y desarrollo de APIs web.
        Apasionado por el código limpio, pruebas y prácticas DevOps.
        
        EXPERIENCIA
        Desarrollador Senior, Empresa Tecnológica S.A. (2020-Presente)
        - Desarrollo de APIs RESTful usando Python y Flask
        - Gestión de bases de datos PostgreSQL y optimización de consultas
        - Implementación de pipelines CI/CD usando GitHub Actions
        - Despliegue de aplicaciones en contenedores Docker a AWS ECS
        
        Desarrollador Junior, Startup Ltd. (2018-2020)
        - Construcción de aplicaciones web usando Python y Django
        - Creación y mantenimiento de bases de datos MySQL
        - Implementación de pruebas unitarias y de integración
        
        EDUCACIÓN
        Licenciatura en Ciencias de la Computación
        Universidad Tecnológica (2014-2018)
        
        HABILIDADES
        - Lenguajes de programación: Python, JavaScript, SQL
        - Frameworks: Flask, Django, FastAPI
        - Herramientas: Git, Docker, AWS, CI/CD
        - Bases de datos: PostgreSQL, MySQL
        """
        
        # Analizar CV
        result = client.analyze_cv(cv_text, criteria)
        
        # Imprimir resultado
        print(json.dumps(result, indent=2))
        
        # También se puede configurar usando variables de entorno
        print("\nNota: También puedes configurar el systemprompt usando la variable de entorno OPENAI_SYSTEM_PROMPT")
        
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main() 