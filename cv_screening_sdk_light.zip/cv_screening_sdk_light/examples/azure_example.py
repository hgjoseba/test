"""
Ejemplo de uso de Azure OpenAI con CV Screening SDK Light.

Este script demuestra cómo usar el SDK con Azure OpenAI,
configurando correctamente la verificación de conexión.
"""

import json
import os
import logging
from dotenv import load_dotenv

from cv_screening_sdk_light.providers.azure_provider import AzureOpenAIProvider
from cv_screening_sdk_light.models import JobCriteria


# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def ejemplo_azure_con_api_key():
    """Ejemplo de uso de Azure OpenAI con clave API."""
    print("\n=== Ejemplo: Azure OpenAI con API Key ===")
    
    # Cargar variables de entorno
    load_dotenv()
    
    try:
        # Inicializar proveedor de Azure OpenAI con clave API
        provider = AzureOpenAIProvider(
            endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
            api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
            deployment_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2023-05-15"),
            # Importante: Configuración de SSL
            connection_verify=True,  # Cambiar a False si hay problemas de certificados
        )
        
        # Definir criterios para el puesto
        criteria = {
            "required_skills": ["Python", "Django", "SQL"],
            "preferred_skills": ["Azure", "Docker", "Kubernetes"],
            "min_years_experience": 3,
            "education_level": "bachelor's",
            "job_title": "Desarrollador Backend Senior",
            "job_description": "Buscamos un desarrollador backend con experiencia en Python y servicios cloud."
        }
        
        # CV de ejemplo para análisis
        cv_text = """
        Ana Martínez
        Desarrolladora Backend
        ana@ejemplo.com | +34 678 123 456
        
        EXPERIENCIA
        Desarrolladora Backend, Empresa Cloud (2019-Presente)
        - Desarrollo de microservicios con Python y Django
        - Integración con servicios de Azure
        - Bases de datos SQL y NoSQL
        
        EDUCACIÓN
        Ingeniería Informática, Universidad Tecnológica (2015-2019)
        
        HABILIDADES
        - Python, Django, FastAPI
        - SQL, PostgreSQL, MongoDB
        - Docker, Azure, AWS
        """
        
        # Analizar CV
        print("Analizando CV con Azure OpenAI...")
        result = provider.analyze_cv(cv_text, criteria)
        
        # Mostrar resultado
        print("\nRESULTADO:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("\nAnálisis completado con éxito usando Azure OpenAI.")
        return True
        
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        print("No se pudo completar el análisis con Azure OpenAI.")
        return False


def ejemplo_azure_con_credenciales():
    """Ejemplo de uso de Azure OpenAI con credenciales de servicio."""
    print("\n=== Ejemplo: Azure OpenAI con Credenciales de Servicio ===")
    
    # Cargar variables de entorno
    load_dotenv()
    
    try:
        # Inicializar proveedor de Azure OpenAI con credenciales
        provider = AzureOpenAIProvider(
            endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
            # Usar credenciales en lugar de API key
            tenant_id=os.environ.get("AZURE_TENANT_ID"),
            client_id=os.environ.get("AZURE_CLIENT_ID"),
            client_secret=os.environ.get("AZURE_CLIENT_SECRET"),
            deployment_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2023-05-15"),
            # Importante: Configuración de SSL para la conexión de autenticación
            connection_verify=True,  # Cambiar a False si hay problemas de certificados
        )
        
        # Definir criterios para el puesto
        criteria = {
            "required_skills": ["Data Analysis", "Python", "SQL"],
            "preferred_skills": ["Power BI", "Tableau", "Machine Learning"],
            "min_years_experience": 2,
            "education_level": "bachelor's",
            "job_title": "Analista de Datos",
            "job_description": "Buscamos un analista de datos para trabajar con grandes conjuntos de datos."
        }
        
        # CV de ejemplo para análisis
        cv_text = """
        Carlos López
        Analista de Datos
        carlos@ejemplo.com | +34 612 987 654
        
        EXPERIENCIA
        Analista de Datos, Consultora Analítica (2020-Presente)
        - Análisis de datos para clientes de múltiples sectores
        - Creación de dashboards con Power BI y Tableau
        - Automatización de procesos ETL con Python
        
        EDUCACIÓN
        Grado en Estadística, Universidad Central (2016-2020)
        
        HABILIDADES
        - Python, R, SQL
        - Power BI, Tableau
        - Excel avanzado
        """
        
        # Analizar CV
        print("Analizando CV con Azure OpenAI (usando credenciales)...")
        result = provider.analyze_cv(cv_text, criteria)
        
        # Mostrar resultado
        print("\nRESULTADO:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        print("\nAnálisis completado con éxito usando Azure OpenAI con credenciales.")
        return True
        
    except Exception as e:
        print(f"\nERROR: {str(e)}")
        print("No se pudo completar el análisis con Azure OpenAI usando credenciales.")
        return False


def explicar_configuracion_azure():
    """Muestra información sobre las opciones de configuración de Azure OpenAI."""
    
    print("\n=== CONFIGURACIÓN DE AZURE OPENAI CON CV SCREENING SDK LIGHT ===")
    print("\nExisten dos formas principales de autenticarse con Azure OpenAI:")
    
    print("\n1. USANDO API KEY:")
    print("   - Más simple, recomendado para comenzar")
    print("   - Requiere endpoint y clave API")
    print("""
    # Ejemplo de uso con API key
    provider = AzureOpenAIProvider(
        endpoint="https://tu-recurso.openai.azure.com/",
        api_key="tu-clave-api",
        connection_verify=True  # Verificación SSL para la conexión
    )
    """)
    
    print("\n2. USANDO CREDENCIALES DE SERVICIO (App Registration):")
    print("   - Más seguro, recomendado para entornos de producción")
    print("   - Usa Azure Active Directory para autenticación")
    print("""
    # Ejemplo de uso con credenciales
    provider = AzureOpenAIProvider(
        endpoint="https://tu-recurso.openai.azure.com/",
        tenant_id="tu-tenant-id",
        client_id="tu-client-id",
        client_secret="tu-client-secret",
        connection_verify=True  # Verificación SSL para la conexión de autenticación
    )
    """)
    
    print("\nCONFIGURACIÓN DE SEGURIDAD SSL:")
    print("El parámetro connection_verify controla la verificación SSL:")
    print("  - True (por defecto): Verifica certificados SSL (más seguro)")
    print("  - False: Deshabilita verificación SSL (útil en desarrollo o con proxies corporativos)")
    print("\nEn entornos de producción, se recomienda mantener connection_verify=True")
    print("y configurar correctamente los certificados de confianza en el sistema.")


def main():
    """Función principal que ejecuta los ejemplos."""
    
    # Mostrar información de configuración
    explicar_configuracion_azure()
    
    # Ejecutar ejemplo con API key (más común)
    print("\n\nEjecutando ejemplo con API key...")
    if os.environ.get("AZURE_OPENAI_API_KEY"):
        ejemplo_azure_con_api_key()
    else:
        print("API key de Azure OpenAI no encontrada en variables de entorno.")
    
    # Ejecutar ejemplo con credenciales (si están configuradas)
    print("\n\nEjecutando ejemplo con credenciales de servicio...")
    if all([
        os.environ.get("AZURE_TENANT_ID"),
        os.environ.get("AZURE_CLIENT_ID"),
        os.environ.get("AZURE_CLIENT_SECRET")
    ]):
        ejemplo_azure_con_credenciales()
    else:
        print("Credenciales de Azure no encontradas en variables de entorno.")
    
    print("\n\nPara más información sobre la configuración de Azure OpenAI, consulta la documentación.")


if __name__ == "__main__":
    main() 