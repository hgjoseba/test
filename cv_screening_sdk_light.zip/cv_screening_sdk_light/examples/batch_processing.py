"""
Ejemplo de procesamiento por lotes con CV Screening SDK Light.

Este script demuestra cómo analizar múltiples CVs y crear un informe comparativo.
"""

import json
import os
import glob
import time
from typing import Dict, List, Any
from dotenv import load_dotenv

from cv_screening_sdk_light import CVScreeningClient
from cv_screening_sdk_light.models import JobCriteria
from cv_screening_sdk_light.core.exceptions import DocumentParsingError


def load_and_analyze_cv(client: CVScreeningClient, cv_path: str, criteria: JobCriteria) -> Dict[str, Any]:
    """
    Cargar y analizar un solo CV.
    
    Args:
        client: Cliente del SDK
        cv_path: Ruta al archivo CV
        criteria: Criterios del trabajo
        
    Returns:
        Resultado del análisis con metadatos adicionales
    """
    try:
        # Cargar CV
        cv_content = client.load_cv_content(cv_path)
        
        # Añadir un breve retraso para evitar límites de velocidad de la API
        time.sleep(0.5)
        
        # Analizar CV
        result = client.analyze_cv(cv_content, criteria)
        
        # Añadir metadatos
        result["_metadata"] = {
            "filename": os.path.basename(cv_path),
            "filepath": cv_path,
            "filesize": os.path.getsize(cv_path),
            "timestamp": time.time()
        }
        
        return result
        
    except DocumentParsingError as e:
        print(f"Error al procesar {cv_path}: {str(e)}")
        return {
            "_error": str(e),
            "_metadata": {
                "filename": os.path.basename(cv_path),
                "filepath": cv_path
            }
        }
    except Exception as e:
        print(f"Error inesperado al procesar {cv_path}: {str(e)}")
        return {
            "_error": str(e),
            "_metadata": {
                "filename": os.path.basename(cv_path),
                "filepath": cv_path
            }
        }


def generate_comparison_report(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Generar un informe comparativo de todos los candidatos.
    
    Args:
        results: Lista de resultados de análisis
        
    Returns:
        Informe comparativo
    """
    # Filtrar resultados con errores
    valid_results = [r for r in results if "_error" not in r]
    
    # Si no hay resultados válidos, devolver informe de error
    if not valid_results:
        return {"error": "No se pudieron procesar CVs válidos"}
    
    # Ordenar por coincidencia general (de mayor a menor)
    sorted_results = sorted(
        valid_results, 
        key=lambda x: x.get("overall_match", 0), 
        reverse=True
    )
    
    # Crear informe
    report = {
        "timestamp": time.time(),
        "total_candidates": len(results),
        "valid_candidates": len(valid_results),
        "top_candidates": [],
        "candidates_summary": []
    }
    
    # Añadir resumen de todos los candidatos
    for result in sorted_results:
        metadata = result.get("_metadata", {})
        report["candidates_summary"].append({
            "filename": metadata.get("filename", "unknown"),
            "overall_match": result.get("overall_match", 0),
            "summary": result.get("summary", "No hay resumen disponible")
        })
    
    # Añadir información detallada de los 3 mejores candidatos
    for i, result in enumerate(sorted_results[:3]):
        metadata = result.get("_metadata", {})
        report["top_candidates"].append({
            "rank": i + 1,
            "filename": metadata.get("filename", "unknown"),
            "overall_match": result.get("overall_match", 0),
            "skills_match": result.get("skills_match", {}),
            "experience_match": result.get("experience_match", {}),
            "education_match": result.get("education_match", {}),
            "summary": result.get("summary", "No hay resumen disponible")
        })
    
    return report


def main():
    # Cargar variables de entorno
    load_dotenv()
    
    # Directorio con CVs (modificar según sea necesario)
    cv_directory = "./cvs"
    
    # Verificar que el directorio existe
    if not os.path.exists(cv_directory):
        print(f"Error: El directorio {cv_directory} no existe.")
        print("Creando directorio para ejemplos futuros...")
        os.makedirs(cv_directory)
        print(f"Agregue archivos de CV al directorio {cv_directory} y ejecute este script nuevamente.")
        return 1
    
    # Buscar archivos CV
    cv_files = glob.glob(os.path.join(cv_directory, "*.txt"))
    cv_files.extend(glob.glob(os.path.join(cv_directory, "*.pdf")))
    cv_files.extend(glob.glob(os.path.join(cv_directory, "*.docx")))
    
    if not cv_files:
        print(f"No se encontraron archivos de CV en {cv_directory}")
        print("Formatos soportados: .txt, .pdf, .docx")
        return 1
    
    print(f"Se encontraron {len(cv_files)} archivos de CV para analizar")
    
    # Definir criterios para el puesto de Ingeniero Frontend
    criteria = JobCriteria(
        required_skills=["JavaScript", "React", "HTML", "CSS"],
        preferred_skills=["TypeScript", "Next.js", "Tailwind CSS", "Testing"],
        min_years_experience=2,
        education_level="bachelor's",
        job_title="Ingeniero Frontend",
        job_description="Buscamos un ingeniero frontend con sólida experiencia en React y conocimientos modernos de desarrollo web. El candidato ideal debe tener experiencia en la creación de interfaces de usuario atractivas y responsivas, y estar familiarizado con buenas prácticas de testing."
    )
    
    try:
        # Inicializar cliente
        client = CVScreeningClient(
            api_key=os.getenv("OPENAI_API_KEY"),
            model_name="gpt-4",
        )
        
        # Procesar todos los CVs
        print("Procesando CVs...")
        results = []
        
        for i, cv_path in enumerate(cv_files):
            print(f"[{i+1}/{len(cv_files)}] Procesando {os.path.basename(cv_path)}...")
            result = load_and_analyze_cv(client, cv_path, criteria)
            results.append(result)
        
        # Generar informe comparativo
        print("\nGenerando informe comparativo...")
        report = generate_comparison_report(results)
        
        # Guardar resultados
        output_dir = "./resultados"
        os.makedirs(output_dir, exist_ok=True)
        
        # Guardar informe comparativo
        report_path = os.path.join(output_dir, "informe_comparativo.json")
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        # Guardar resultados individuales
        for result in results:
            if "_metadata" in result:
                filename = result["_metadata"]["filename"]
                base_name = os.path.splitext(filename)[0]
                result_path = os.path.join(output_dir, f"{base_name}_resultado.json")
                with open(result_path, 'w', encoding='utf-8') as f:
                    json.dump(result, f, indent=2, ensure_ascii=False)
        
        # Imprimir resumen
        print(f"\nResultados guardados en {output_dir}")
        print(f"Informe comparativo guardado en {report_path}")
        
        # Mostrar los mejores candidatos
        print("\nMEJORES CANDIDATOS:")
        for i, candidate in enumerate(report.get("top_candidates", [])):
            print(f"{i+1}. {candidate.get('filename')} - Coincidencia: {candidate.get('overall_match')}%")
            print(f"   {candidate.get('summary')}")
            print()
        
        return 0
        
    except Exception as e:
        print(f"Error inesperado: {str(e)}")
        return 1


if __name__ == "__main__":
    main() 