"""
Document utilities for CV Screening SDK.
"""

import os
import logging
import base64
from typing import Optional, Union

from ..core.exceptions import DocumentParsingError

logger = logging.getLogger(__name__)


def load_cv_content(file_path: str) -> str:
    """
    Load CV content from a file.
    
    This helper method loads CV content from common file formats.
    For PDF and DOCX support, the optional dependencies must be installed.
    
    Args:
        file_path: Path to the CV file
    
    Returns:
        String content of the CV
    
    Raises:
        DocumentParsingError: If the file cannot be parsed
        FileNotFoundError: If the file does not exist
    """
    logger.info(f"Loading CV content from: {file_path}")
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_ext = os.path.splitext(file_path)[1].lower()
    
    # Simple text files
    if file_ext in ['.txt']:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            raise DocumentParsingError(f"Failed to read text file: {str(e)}")
    
    # PDF files require PyPDF2
    elif file_ext in ['.pdf']:
        try:
            # Import here to avoid dependency if not used
            import PyPDF2
            
            content = []
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    content.append(page.extract_text())
            
            return '\n'.join(content)
        except ImportError:
            raise DocumentParsingError(
                "PDF parsing requires PyPDF2. Install with: pip install 'cv-screening-sdk[document_processing]'"
            )
        except Exception as e:
            raise DocumentParsingError(f"Failed to parse PDF: {str(e)}")
    
    # DOCX files require python-docx
    elif file_ext in ['.docx']:
        try:
            # Import here to avoid dependency if not used
            import docx
            
            doc = docx.Document(file_path)
            content = [paragraph.text for paragraph in doc.paragraphs]
            return '\n'.join(content)
        except ImportError:
            raise DocumentParsingError(
                "DOCX parsing requires python-docx. Install with: pip install 'cv-screening-sdk[document_processing]'"
            )
        except Exception as e:
            raise DocumentParsingError(f"Failed to parse DOCX: {str(e)}")
    
    else:
        raise DocumentParsingError(f"Unsupported file format: {file_ext}")


def load_cv_from_base64(base64_content: Union[str, bytes]) -> str:
    """
    Load CV content from a base64 encoded string.
    
    This helper method decodes base64 content into text.
    
    Args:
        base64_content: Base64 encoded content as string or bytes
    
    Returns:
        String content of the CV
    
    Raises:
        DocumentParsingError: If the content cannot be decoded
    """
    logger.info("Loading CV content from base64")
    
    try:
        # Convert to bytes if it's a string
        if isinstance(base64_content, str):
            base64_bytes = base64_content.encode('utf-8')
        else:
            base64_bytes = base64_content
        
        # Decode base64
        decoded_content = base64.b64decode(base64_bytes).decode('utf-8')
        return decoded_content
    except Exception as e:
        raise DocumentParsingError(f"Failed to decode base64 content: {str(e)}")


def is_base64(content: Union[str, bytes]) -> bool:
    """
    Check if the given content is likely base64 encoded.
    
    Args:
        content: Content to check
    
    Returns:
        True if the content looks like base64, False otherwise
    """
    if isinstance(content, str):
        content = content.encode('utf-8')
    
    try:
        # Try to decode and see if it throws an error
        base64.b64decode(content)
        return True
    except Exception:
        return False 