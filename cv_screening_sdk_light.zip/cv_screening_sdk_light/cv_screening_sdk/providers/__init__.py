"""Providers for CV Screening SDK."""

from .azure_provider import AzureOpenAIProvider

__all__ = ["AzureOpenAIProvider"] 