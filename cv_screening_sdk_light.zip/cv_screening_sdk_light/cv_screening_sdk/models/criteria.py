"""
Job criteria models for CV screening.
"""

from typing import Dict, List, Optional, Union
from pydantic import BaseModel, Field


class JobCriteria(BaseModel):
    """
    Job criteria for CV screening.
    
    This model defines the requirements and preferences for a job position,
    which will be used to evaluate candidate CVs.
    """
    
    required_skills: List[str] = Field(
        default_factory=list,
        description="List of required skills for the position"
    )
    
    preferred_skills: List[str] = Field(
        default_factory=list,
        description="List of preferred skills that are a plus but not required"
    )
    
    min_years_experience: Optional[int] = Field(
        default=None,
        description="Minimum years of relevant experience required"
    )
    
    education_level: Optional[str] = Field(
        default=None,
        description="Required education level (e.g., 'bachelor's', 'master's', 'phd')"
    )
    
    job_title: Optional[str] = Field(
        default=None,
        description="Title of the job position"
    )
    
    job_description: Optional[str] = Field(
        default=None,
        description="Brief description of the job role and responsibilities"
    )
    
    def to_dict(self) -> Dict:
        """Convert the criteria to a dictionary."""
        return self.model_dump(exclude_none=True) 