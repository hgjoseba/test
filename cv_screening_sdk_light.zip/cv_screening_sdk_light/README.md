# CV Screening SDK Light

A lightweight SDK for screening CVs using Azure OpenAI Service. This is a simplified version of the full CV Screening SDK, focused on direct synchronous API calls with minimal dependencies.

## Features

- Simple synchronous API for CV analysis
- Direct integration with Azure OpenAI Service
- Raw response handling without complex processing
- Support for PDF and DOCX file formats (with optional dependencies)
- Minimal dependencies and easy installation
- Custom system prompt support for tailored CV analysis
- SSL verification control for corporate environments

## Installation

Install from PyPI:

```bash
pip install cv-screening-sdk-light
```

For PDF and DOCX support, install with optional dependencies:

```bash
pip install "cv-screening-sdk-light[document_processing]"
```

## Quick Start

```python
from cv_screening_sdk_light import CVScreeningClient
from cv_screening_sdk_light.models import JobCriteria

# Initialize client with Azure OpenAI credentials
client = CVScreeningClient(
    api_key="your-azure-openai-api-key",
    endpoint="https://your-resource.openai.azure.com/",
    model_name="gpt-4"  # Your deployment name in Azure
)

# Create job criteria
criteria = JobCriteria(
    required_skills=["python", "javascript"],
    preferred_skills=["react", "docker"],
    min_years_experience=3,
    education_level="bachelor's"
)

# Load CV from file
cv_text = client.load_cv_content("path/to/resume.pdf")

# Analyze CV
result = client.analyze_cv(cv_text, criteria)

# Print results
print(f"CV Analysis Result:")
print(result)
```

## Customizing System Prompt

You can customize the system prompt used for CV analysis:

```python
# Define a custom system prompt
custom_prompt = """You are a CV analysis expert for technical roles.
Evaluate CVs against job criteria and provide a thorough assessment.
Your response should be a JSON object with an overall match score,
skill matching details, and specific recommendations."""

# Initialize client with custom system prompt
client = CVScreeningClient(
    api_key="your-azure-openai-api-key",
    endpoint="https://your-resource.openai.azure.com/",
    model_name="gpt-4",
    system_prompt=custom_prompt
)

# Analyze with custom prompt
result = client.analyze_cv(cv_text, criteria)
```

## Using Azure OpenAI Service Directly

You can also use the Azure OpenAI provider directly:

```python
from cv_screening_sdk_light.providers.azure_provider import AzureOpenAIProvider

# Initialize the Azure OpenAI provider
provider = AzureOpenAIProvider(
    endpoint="https://your-resource.openai.azure.com/",
    api_key="your-azure-openai-api-key",
    deployment_name="gpt-4",  # Your deployment name in Azure
    system_prompt="Your custom system prompt here"  # Optional
)

# Define job criteria
criteria = {
    "required_skills": ["python", "api development"],
    "preferred_skills": ["docker", "aws"],
    "min_years_experience": 3
}

# Analyze CV
result = provider.analyze_cv(cv_content, criteria)
print(result)
```

### SSL Verification in Corporate Environments

When working behind corporate proxies or in environments with SSL inspection, you might need to disable SSL verification:

```python
# Initialize Azure OpenAI provider with SSL verification disabled
provider = AzureOpenAIProvider(
    endpoint="https://your-resource.openai.azure.com/",
    api_key="your-azure-openai-api-key",
    deployment_name="gpt-4",
    connection_verify=False  # Disable SSL verification
)
```

> **Warning**: Disabling SSL verification reduces security. Only use this option in controlled environments where you understand the risks.

## Key Differences from Full SDK

- Synchronous-only operations (no async support)
- Focus on Azure OpenAI Service
- Raw output from Azure OpenAI without complex post-processing
- Minimal dependencies for easier installation
- Simplified configuration with fewer options

## Configuration via Environment Variables

You can configure the client using environment variables:

```bash
# Azure OpenAI credentials
export AZURE_OPENAI_API_KEY=your-api-key
export AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
export AZURE_OPENAI_DEPLOYMENT=gpt-4

# Optional configuration
export OPENAI_TEMPERATURE=0.1
export OPENAI_MAX_TOKENS=2000
export OPENAI_CONNECTION_VERIFY=true
export OPENAI_SYSTEM_PROMPT="Your custom system prompt here"
```

## License

MIT 