#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
from setuptools import setup, find_packages

# Read long description from README.md
with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

# Define main dependencies
install_requires = [
    "openai==1.7.0",
    "pydantic==2.7.2",
    "python-dotenv==1.0.0",
    "requests==2.31.0",
    "azure-core>=1.26.0",
    "azure-identity>=1.12.0",
    "httpx>=0.24.0",
]

# Define optional dependencies
extras_require = {
    "document_processing": [
        "PyPDF2==3.0.1",
        "python-docx==1.1.0",
    ],
    "dev": [
        "pytest==8.3.5",
        "black==24.8.0",
        "isort==5.13.2",
        "mypy==1.9.0",
    ],
}

setup(
    name="cv-screening-sdk",
    version="0.1.0",
    description="A SDK for screening CVs using OpenAI",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="CV Screening SDK Team",
    author_email="contact@example.com",
    url="https://github.com/yourusername/cv-screening-sdk",
    packages=find_packages(include=["cv_screening_sdk", "cv_screening_sdk.*"]),
    include_package_data=True,
    zip_safe=False,
    python_requires=">=3.8",
    install_requires=install_requires,
    extras_require=extras_require,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Human Resources",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Human Resources",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Typing :: Typed",
    ],
    keywords=[
        "cv",
        "resume",
        "screening",
        "recruitment",
        "hiring",
        "ai",
        "openai",
        "nlp",
    ],
    license="MIT",
) 