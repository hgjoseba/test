# Guía de uso del parámetro `base_model` en el SDK de screening de CVs

Este documento proporciona una guía detallada sobre cómo utilizar el parámetro `base_model` en el SDK para optimizar el análisis de CVs con Azure OpenAI.

## Introducción

El parámetro `base_model` permite especificar explícitamente qué modelo base de OpenAI se está utilizando en un despliegue de Azure, independientemente del nombre del despliegue. Esto es especialmente útil en los siguientes casos:

1. Cuando el nombre del despliegue no sigue la nomenclatura estándar de OpenAI
2. Cuando se quiere forzar un comportamiento específico (proceso directo o en dos pasos)
3. Para garantizar que el SDK utilice correctamente las capacidades del modelo

## Instalación y configuración básica

```python
from src.client import CVScreeningClient
import os

# Configurar credenciales
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
api_key = os.environ.get("AZURE_OPENAI_API_KEY")

# Cliente básico sin base_model (inferirá del nombre de despliegue)
client = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="gpt-4"  # Se inferirá automáticamente como "gpt-4"
)
```

## Escenario 1: Nombre de despliegue personalizado

Cuando el despliegue tiene un nombre personalizado que no permite inferir el modelo base:

```python
# Cliente con nombre de despliegue personalizado
client = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="prod-deployment-v2",  # Nombre que no permite inferir el modelo
    base_model="gpt-4"  # Especificamos explícitamente que es GPT-4
)

# Análisis de CV
cv_content = "..."
job_criteria = {"required_skills": ["Python", "Django"]}
result = client.analyze_cv(cv_content, job_criteria)
```

## Escenario 2: Forzar un comportamiento específico

Si queremos forzar el uso del proceso en dos pasos aunque el nombre del despliegue sea estándar:

```python
# Cliente forzando comportamiento de dos pasos
client = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="gpt-4",  # Normalmente usaría proceso directo
    base_model="custom-model"  # Forzamos proceso en dos pasos
)

# Este análisis usará el proceso en dos pasos
result = client.analyze_cv(cv_content, job_criteria)
```

## Escenario 3: Análisis múltiple con modelos diferentes

Comparación entre diferentes configuraciones:

```python
# CV de ejemplo
cv_content = """
JUAN PÉREZ
Desarrollador Senior Python

EXPERIENCIA
- 7 años como desarrollador Python en Empresa ABC (2016-2023)
- 3 años como desarrollador web en XYZ Tech (2013-2016)

HABILIDADES
- Python, Django, Flask, FastAPI
- JavaScript, React
- Docker, Kubernetes
- AWS, Azure

EDUCACIÓN
- Ingeniería Informática, Universidad de Barcelona (2010-2014)
"""

# Criterios para el puesto
job_criteria = {
    "required_skills": ["Python", "Django", "API", "Docker"],
    "preferred_skills": ["AWS", "Kubernetes", "React"],
    "min_years_experience": 5,
    "education": "Ingeniería Informática o similar"
}

# Cliente 1: Inferencia automática
client1 = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="gpt-4"  # Se infiere como "gpt-4"
)
result1 = client1.analyze_cv(cv_content, job_criteria)

# Cliente 2: Base model explícito compatible
client2 = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="custom-deployment",
    base_model="gpt-4"  # Explícitamente "gpt-4"
)
result2 = client2.analyze_cv(cv_content, job_criteria)

# Cliente 3: Base model explícito no compatible
client3 = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="gpt-4",
    base_model="other-model"  # Forzar modelo no compatible
)
result3 = client3.analyze_cv(cv_content, job_criteria)

# Comparación de resultados
print(f"Cliente 1 (inferencia): {result1['overall_match']}")
print(f"Cliente 2 (explícito compatible): {result2['overall_match']}")
print(f"Cliente 3 (explícito no compatible): {result3['overall_match']}")
```

## Escenario 4: Análisis por lotes con base_model

Para procesar múltiples CVs eficientemente:

```python
# Lista de CVs
cvs = [
    "CV 1 contenido...",
    "CV 2 contenido...",
    "CV 3 contenido..."
]

# Cliente con base_model explícito
client = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="custom-deployment",
    base_model="gpt-4",  # Especificamos GPT-4 para procesamiento directo
    max_tokens=2000  # Ajustamos tokens para el batch
)

# Análisis en lotes
results = client.analyze_multiple_cvs(
    contents=cvs,
    criteria=job_criteria,
    batch_size=2  # Procesar en lotes de 2 CVs
)

# Mostrar resultados
for i, result in enumerate(results):
    print(f"CV #{i+1} - Match: {result.get('overall_match')}")
```

## Escenario 5: Esquema personalizado con base_model

Para usar un esquema JSON personalizado junto con base_model:

```python
# Esquema JSON personalizado
custom_schema = {
    "type": "object",
    "properties": {
        "candidate_score": {"type": "number", "description": "Puntuación del candidato (0-100)"},
        "skills_analysis": {"type": "object", "description": "Análisis de habilidades"},
        "recommendations": {"type": "string", "description": "Recomendaciones para el proceso"}
    },
    "required": ["candidate_score"]
}

# Cliente con base_model para garantizar compatibilidad con esquema personalizado
client = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="custom-gpt",
    base_model="gpt-4"  # Garantiza que se pueda usar el esquema personalizado
)

# Análisis con esquema personalizado
result = client.analyze_cv(
    content=cv_content,
    criteria=job_criteria,
    schema_json_ob=custom_schema
)

print(f"Puntuación: {result.get('candidate_score')}")
print(f"Recomendaciones: {result.get('recommendations')}")
```

## Conclusiones y mejores prácticas

1. **Nombres de despliegue estándar**: Si usas nombres de despliegue estándar como "gpt-4", no necesitas especificar `base_model`.

2. **Nombres personalizados**: Siempre proporciona `base_model` cuando uses nombres de despliegue personalizados.

3. **Compatibilidad con esquemas JSON**: Los modelos "gpt-4", "gpt-4-32k" y "gpt-35-turbo" soportan esquemas JSON directamente, lo que mejora la precisión del análisis.

4. **Procesamiento en dos pasos**: Los modelos no compatibles utilizarán un proceso en dos pasos con un modelo secundario (GPT-4) para formatear la respuesta.

5. **Rendimiento**: El procesamiento directo (un paso) es más rápido y eficiente que el de dos pasos.

## Diagnóstico y solución de problemas

- Si ves advertencias sobre "Could not infer base model", significa que el sistema no pudo determinar el modelo base. Especifica `base_model` explícitamente.

- Si necesitas forzar comportamientos específicos para pruebas o análisis comparativos, puedes usar `base_model` para controlar si se usa el proceso directo o en dos pasos.

- El log del sistema indicará qué proceso se está utilizando, lo que puede ayudar a diagnosticar problemas.

```python
# Ejemplo de verificación de configuración
client = CVScreeningClient(
    endpoint=endpoint,
    api_key=api_key,
    deployment_name="custom-deployment",
    base_model="gpt-4"
)

# Verificar configuración
print(f"Base model: {client.provider.base_model}")
print(f"Es capaz de JSON schema: {client.provider._is_model_schema_capable()}")
``` 