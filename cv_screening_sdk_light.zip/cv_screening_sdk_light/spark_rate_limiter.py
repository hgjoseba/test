#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Módulo para control de límites de tasa (rate limiting) en el SDK de CV Screening
para entornos distribuidos como Spark.

Este módulo proporciona clases para gestionar:
- Límites de TPM (Tokens Por Minuto)
- Límites de RPM (Requests Por Minuto)
- Estrategias de retroceso exponencial
- Sincronización entre nodos en entornos distribuidos
"""

import time
import logging
import threading
import random
import math
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any, Union, Tuple
from enum import Enum

# Configuración de logging
logger = logging.getLogger("cv_screening.rate_limiter")


class RateLimitType(Enum):
    """Tipos de límites de tasa admitidos"""
    TOKENS_PER_MINUTE = "tpm"
    REQUESTS_PER_MINUTE = "rpm"


class TokenCounter:
    """
    Clase para estimar y contar tokens consumidos en peticiones a OpenAI
    
    Esta clase proporciona métodos para:
    1. Estimar tokens antes de enviar una petición
    2. Registrar tokens realmente consumidos tras petición
    3. Hacer seguimiento del consumo de tokens por minuto
    """
    
    # Factores de estimación para diferentes modelos (tokens por carácter)
    TOKEN_ESTIMATION_FACTORS = {
        "gpt-3.5-turbo": 0.25,  # ~4 caracteres por token
        "gpt-4": 0.25,          # ~4 caracteres por token
        "gpt-4-turbo": 0.25,     # ~4 caracteres por token
        "gpt-4-32k": 0.25,      # ~4 caracteres por token
        # Añadir otros modelos según sea necesario
    }
    
    def __init__(self):
        """Inicializa el contador de tokens"""
        self.token_history = []  # [(timestamp, tokens)]
        self.lock = threading.RLock()
        
    def estimate_tokens(self, text: str, model: str = "gpt-4") -> int:
        """
        Estima el número de tokens en un texto para un modelo específico
        
        Args:
            text: Texto a analizar
            model: Modelo de OpenAI a utilizar
        
        Returns:
            Estimación del número de tokens
        """
        if not text:
            return 0
            
        factor = self.TOKEN_ESTIMATION_FACTORS.get(model, 0.25)
        return math.ceil(len(text) * factor)
    
    def record_tokens(self, tokens: int) -> None:
        """
        Registra el consumo real de tokens de una petición
        
        Args:
            tokens: Número de tokens consumidos
        """
        with self.lock:
            now = datetime.now()
            self.token_history.append((now, tokens))
            
            # Limpiar historial más antiguo que 10 minutos
            cutoff = now - timedelta(minutes=10)
            self.token_history = [(ts, tk) for ts, tk in self.token_history 
                                 if ts >= cutoff]
    
    def get_tokens_last_minute(self) -> int:
        """
        Obtiene el número total de tokens consumidos en el último minuto
        
        Returns:
            Total de tokens en el último minuto
        """
        with self.lock:
            now = datetime.now()
            cutoff = now - timedelta(minutes=1)
            
            tokens_last_minute = sum(tokens for ts, tokens in self.token_history 
                                    if ts >= cutoff)
            
            return tokens_last_minute


class RateLimiter:
    """
    Implementación de limitador de tasa para controlar TPM y RPM
    
    Esta clase proporciona:
    1. Control de peticiones por minuto
    2. Control de tokens por minuto (requiere integración con respuestas de API)
    3. Estrategias de retroceso exponencial para errores de límite de tasa
    """
    
    def __init__(
        self, 
        max_rpm: int = 100,
        max_tpm: int = 60000,
        max_concurrent: int = 5,
        base_delay: float = 0.1
    ):
        """
        Inicializa el limitador de tasa
        
        Args:
            max_rpm: Máximo de peticiones por minuto
            max_tpm: Máximo de tokens por minuto
            max_concurrent: Máximo de peticiones concurrentes
            base_delay: Retraso base para retroceso exponencial (segundos)
        """
        self.max_rpm = max_rpm
        self.max_tpm = max_tpm
        self.max_concurrent = max_concurrent
        self.base_delay = base_delay
        
        # Historial de peticiones
        self.request_history = []  # [(timestamp, request_id)]
        self.lock = threading.RLock()
        self.semaphore = threading.Semaphore(max_concurrent)
        
        # Contador de tokens
        self.token_counter = TokenCounter()
        
        logger.info(f"Limitador de tasa inicializado: {max_rpm} RPM, {max_tpm} TPM")
    
    def _wait_if_needed(self, tokens_estimate: int = 0) -> None:
        """
        Espera si es necesario para cumplir con los límites de tasa
        
        Args:
            tokens_estimate: Estimación de tokens para la petición
        """
        with self.lock:
            now = datetime.now()
            cutoff = now - timedelta(minutes=1)
            
            # Limpiar historial antiguo
            self.request_history = [(ts, req_id) for ts, req_id in self.request_history 
                                   if ts >= cutoff]
            
            # Comprobar RPM
            current_rpm = len(self.request_history)
            
            # Comprobar TPM (si se proporciona estimación)
            current_tpm = self.token_counter.get_tokens_last_minute()
            estimated_tpm = current_tpm + tokens_estimate
            
            # Determinar tiempo de espera
            wait_time = 0
            
            if current_rpm >= self.max_rpm:
                # Calcular tiempo hasta que expire la petición más antigua
                oldest = min(ts for ts, _ in self.request_history)
                time_until_oldest_expires = (oldest + timedelta(minutes=1) - now).total_seconds()
                wait_time = max(wait_time, time_until_oldest_expires)
                
            if tokens_estimate > 0 and estimated_tpm > self.max_tpm:
                # Esperar proporcionalmente al exceso de tokens
                token_wait = (estimated_tpm - self.max_tpm) / self.max_tpm * 60
                wait_time = max(wait_time, token_wait)
            
            # Añadir jitter para evitar sincronización entre nodos
            if wait_time > 0:
                jitter = random.uniform(0, 0.1)  # 0-100ms de jitter
                wait_time += jitter
                
                logger.info(f"Esperando {wait_time:.2f}s para cumplir límites de tasa (RPM: {current_rpm}/{self.max_rpm}, TPM est.: {estimated_tpm}/{self.max_tpm})")
                time.sleep(wait_time)
    
    def execute_with_rate_limit(
        self,
        func: Callable,
        *args,
        tokens_estimate: int = 0,
        max_retries: int = 3,
        **kwargs
    ) -> Any:
        """
        Ejecuta una función con control de límites de tasa
        
        Args:
            func: Función a ejecutar
            *args: Argumentos para la función
            tokens_estimate: Estimación de tokens para la petición
            max_retries: Máximo número de reintentos
            **kwargs: Argumentos con nombre para la función
            
        Returns:
            Resultado de la función
            
        Raises:
            Exception: Si se agotan los reintentos
        """
        retry_count = 0
        last_exception = None
        
        while retry_count <= max_retries:
            try:
                # Esperar si es necesario para cumplir con límites
                self._wait_if_needed(tokens_estimate)
                
                # Adquirir semáforo para limitar concurrencia
                with self.semaphore:
                    # Registrar petición
                    with self.lock:
                        request_id = id(threading.current_thread())
                        self.request_history.append((datetime.now(), request_id))
                    
                    # Ejecutar función
                    result = func(*args, **kwargs)
                    
                    # Si la respuesta contiene información de tokens, registrarlos
                    if hasattr(result, 'usage') and hasattr(result.usage, 'total_tokens'):
                        self.token_counter.record_tokens(result.usage.total_tokens)
                    elif isinstance(result, dict) and 'usage' in result and 'total_tokens' in result['usage']:
                        self.token_counter.record_tokens(result['usage']['total_tokens'])
                    elif tokens_estimate > 0:
                        # Si no hay información real, usar estimación
                        self.token_counter.record_tokens(tokens_estimate)
                    
                    return result
                    
            except Exception as e:
                last_exception = e
                retry_count += 1
                
                # Comprobar si es error de límite de tasa
                if any(error_text in str(e).lower() for error_text in 
                      ["rate limit", "too many requests", "quota exceeded"]):
                    
                    # Aplicar retroceso exponencial
                    delay = self.base_delay * (2 ** retry_count) + random.uniform(0, 0.1)
                    
                    logger.warning(f"Error de límite de tasa, reintentando en {delay:.2f}s (intento {retry_count}/{max_retries}): {str(e)}")
                    time.sleep(delay)
                else:
                    # No es error de límite de tasa, propagar
                    raise
        
        # Si llegamos aquí, se agotaron los reintentos
        logger.error(f"Se agotaron los reintentos. Último error: {str(last_exception)}")
        raise last_exception


class DistributedRateLimiter(RateLimiter):
    """
    Versión del limitador de tasa que puede coordinarse entre nodos distribuidos
    
    Esta clase extiende RateLimiter para:
    1. Escalar los límites según el número de nodos/ejecutores
    2. Opcionalmente usar un servicio externo para coordinación
    
    Nota: En un entorno completamente distribuido como Spark, se necesitaría
    un servicio externo como Redis para coordinación real. Esta implementación
    es una aproximación para uso en nodos independientes.
    """
    
    def __init__(
        self,
        max_rpm: int = 100,
        max_tpm: int = 60000,
        max_concurrent: int = 5,
        base_delay: float = 0.1,
        node_count: int = 1,
        node_id: str = None,
        coordination_service: Any = None
    ):
        """
        Inicializa el limitador de tasa distribuido
        
        Args:
            max_rpm: Máximo de peticiones por minuto (global)
            max_tpm: Máximo de tokens por minuto (global)
            max_concurrent: Máximo de peticiones concurrentes (por nodo)
            base_delay: Retraso base para retroceso exponencial
            node_count: Número de nodos/ejecutores en el cluster
            node_id: Identificador único de este nodo
            coordination_service: Opcional, servicio de coordinación (ej: cliente Redis)
        """
        # Escalar límites según número de nodos
        node_rpm = max(1, max_rpm // node_count)
        node_tpm = max(1, max_tpm // node_count)
        
        super().__init__(
            max_rpm=node_rpm,
            max_tpm=node_tpm,
            max_concurrent=max_concurrent,
            base_delay=base_delay
        )
        
        self.node_count = node_count
        self.node_id = node_id or str(random.randint(10000, 99999))
        self.coordination_service = coordination_service
        
        logger.info(f"Limitador distribuido inicializado: Nodo {self.node_id}, "
                   f"Total: {max_rpm} RPM / {max_tpm} TPM, "
                   f"Por nodo: {node_rpm} RPM / {node_tpm} TPM")
    
    def update_cluster_size(self, new_node_count: int) -> None:
        """
        Actualiza el tamaño del cluster y recalcula límites
        
        Args:
            new_node_count: Nuevo número de nodos
        """
        if new_node_count <= 0:
            raise ValueError("El número de nodos debe ser positivo")
            
        with self.lock:
            global_rpm = self.max_rpm * self.node_count
            global_tpm = self.max_tpm * self.node_count
            
            self.node_count = new_node_count
            self.max_rpm = max(1, global_rpm // new_node_count)
            self.max_tpm = max(1, global_tpm // new_node_count)
            
            logger.info(f"Límites actualizados para {new_node_count} nodos: "
                       f"{self.max_rpm} RPM, {self.max_tpm} TPM por nodo")


# Funciones de utilidad para uso en Spark

def create_rate_limiter_for_executor(
    global_rpm: int = 1000,
    global_tpm: int = 240000,
    executor_count: int = 4
) -> DistributedRateLimiter:
    """
    Crea un limitador de tasa configurado para un ejecutor de Spark.
    
    Args:
        global_rpm: RPM total para todo el cluster
        global_tpm: TPM total para todo el cluster
        executor_count: Número de ejecutores en el cluster
        
    Returns:
        Instancia de DistributedRateLimiter
    """
    # Generar ID único para este ejecutor
    import socket
    import os
    
    # Intentar obtener información única de este ejecutor
    try:
        hostname = socket.gethostname()
        pid = os.getpid()
        executor_id = f"{hostname}-{pid}"
    except:
        executor_id = str(random.randint(10000, 99999))
    
    return DistributedRateLimiter(
        max_rpm=global_rpm,
        max_tpm=global_tpm,
        max_concurrent=5,
        base_delay=0.1,
        node_count=executor_count,
        node_id=executor_id
    )


def estimate_cv_tokens(cv_content: str, prompt: Optional[str] = None) -> int:
    """
    Estima los tokens que consumirá un análisis de CV
    
    Args:
        cv_content: Contenido del CV
        prompt: Prompt adicional (instrucciones o criterios)
        
    Returns:
        Estimación de tokens
    """
    token_counter = TokenCounter()
    
    # Estimar tokens del CV
    cv_tokens = token_counter.estimate_tokens(cv_content)
    
    # Estimar tokens del prompt/criterios
    prompt_tokens = token_counter.estimate_tokens(prompt) if prompt else 0
    
    # Añadir tokens del sistema y margen de seguridad (30%)
    system_tokens = 200  # Estimación para el prompt del sistema
    margin = int((cv_tokens + prompt_tokens + system_tokens) * 0.3)
    
    total_estimate = cv_tokens + prompt_tokens + system_tokens + margin
    
    return total_estimate


def analyze_cv_with_rate_limit(
    client,
    cv_content: str,
    criteria: dict,
    rate_limiter: Optional[RateLimiter] = None,
    content_type = None,  # Suponiendo que se importa ContentType del SDK
    max_retries: int = 3
) -> dict:
    """
    Función de conveniencia para analizar un CV con control de límites de tasa
    
    Args:
        client: Instancia de CVScreeningClient
        cv_content: Contenido del CV
        criteria: Criterios del trabajo
        rate_limiter: Limitador de tasa a utilizar
        content_type: Tipo de contenido del CV
        max_retries: Máximo de reintentos
        
    Returns:
        Resultados del análisis
    """
    # Usar limitador por defecto si no se proporciona
    if rate_limiter is None:
        rate_limiter = RateLimiter()
    
    # Estimar tokens
    criteria_str = str(criteria) if criteria else ""
    tokens_estimate = estimate_cv_tokens(cv_content, criteria_str)
    
    # Ejecutar con límite de tasa
    return rate_limiter.execute_with_rate_limit(
        client.analyze_cv,
        content=cv_content,
        criteria=criteria,
        content_type=content_type,
        tokens_estimate=tokens_estimate,
        max_retries=max_retries
    ) 