#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Ejemplo de implementación del SDK de CV Screening en un cluster Spark
con control de límites de tasa (rate limiting) para TPM y RPM.

Este script muestra cómo procesar múltiples CVs en paralelo utilizando
Apache Spark y el CV Screening SDK, respetando los límites de Azure OpenAI.
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, pandas_udf
from pyspark.sql.types import StringType, StructType, StructField
import pandas as pd
import json
import time
import os
import logging
from typing import Dict, List, Iterator, Tuple

# Importar SDK de CV Screening
from src import CVScreeningClient
from src.core.types import ContentType

# Importar módulo de control de tasa
from spark_rate_limiter import (
    RateLimiter, 
    DistributedRateLimiter,
    create_rate_limiter_for_executor,
    analyze_cv_with_rate_limit
)

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger("cv_screening_spark")

# Criterios del trabajo para el análisis
JOB_CRITERIA = {
    "required_skills": ["Python", "Spark", "Data Engineering"],
    "preferred_skills": ["AWS", "Azure", "Docker", "Kubernetes"],
    "min_years_experience": 3,
    "education": "Ingeniería, Ciencias de la Computación o similar"
}

# Configuraciones de límites de API
# Estos valores deben ajustarse según tu cuota real en Azure OpenAI
GLOBAL_RPM = 600  # Peticiones por minuto para todo el cluster
GLOBAL_TPM = 240000  # Tokens por minuto para todo el cluster

def get_openai_credentials() -> Tuple[str, str]:
    """Obtiene las credenciales para Azure OpenAI"""
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        raise ValueError(
            "Debes configurar AZURE_OPENAI_ENDPOINT y AZURE_OPENAI_API_KEY"
        )
    
    return endpoint, api_key

def create_client() -> CVScreeningClient:
    """Crea y devuelve una instancia del cliente CV Screening"""
    endpoint, api_key = get_openai_credentials()
    
    return CVScreeningClient(
        endpoint=endpoint,
        api_key=api_key,
        deployment_name="gpt-4",
        temperature=0.1,
        max_tokens=2000
    )

def process_cv_batch_with_rate_limit(
    partition: Iterator[Dict], 
    executor_count: int = 4
) -> Iterator[Tuple[str, str, Dict]]:
    """
    Procesa un lote de CVs con control de límites de tasa
    
    Args:
        partition: Iterador sobre los registros de la partición
        executor_count: Número total de ejecutores en el cluster
        
    Yields:
        Tuplas de (cv_id, nombre_archivo, resultado_analisis)
    """
    # Crear cliente una vez por ejecutor
    client = create_client()
    logger.info("Cliente inicializado en el ejecutor")
    
    # Crear limitador de tasa distribuido
    rate_limiter = create_rate_limiter_for_executor(
        global_rpm=GLOBAL_RPM,
        global_tpm=GLOBAL_TPM,
        executor_count=executor_count
    )
    
    for record in partition:
        cv_id = record["cv_id"]
        filename = record["filename"]
        cv_content = record["content"]
        
        try:
            # Analizar CV con control de límites
            logger.info(f"Procesando CV ID: {cv_id}, Archivo: {filename}")
            
            result = analyze_cv_with_rate_limit(
                client=client,
                cv_content=cv_content,
                criteria=JOB_CRITERIA,
                rate_limiter=rate_limiter,
                content_type=ContentType.TEXT,
                max_retries=3
            )
            
            # Devolver resultado con metadatos
            yield (cv_id, filename, result)
            
        except Exception as e:
            logger.error(f"Error al procesar CV {cv_id}: {str(e)}")
            # Devolver error en formato json
            yield (cv_id, filename, {"error": str(e)})


def pandas_rate_limited_cv_analysis(cvs_batch: pd.Series) -> pd.Series:
    """
    UDF Pandas con control de límites de tasa
    
    Args:
        cvs_batch: Serie de pandas con contenido de CVs
        
    Returns:
        Serie de pandas con resultados
    """
    # Crear cliente una vez para toda la serie
    client = create_client()
    
    # Crear limitador de tasa 
    # Considera cada grupo de Pandas como una "partición"
    rate_limiter = RateLimiter(
        max_rpm=GLOBAL_RPM // 4,  # Asumimos 4 particiones activas
        max_tpm=GLOBAL_TPM // 4
    )
    
    results = []
    for cv in cvs_batch:
        try:
            # Usar la función de conveniencia con control de límites
            result = analyze_cv_with_rate_limit(
                client=client,
                cv_content=cv,
                criteria=JOB_CRITERIA,
                rate_limiter=rate_limiter,
                content_type=ContentType.TEXT
            )
            results.append(json.dumps(result))
        except Exception as e:
            results.append(json.dumps({"error": str(e)}))
    
    return pd.Series(results)


def broadcast_rate_limiter_config(spark, executor_count):
    """
    Transmite la configuración del limitador de tasa a todos los ejecutores
    
    Args:
        spark: SparkSession
        executor_count: Número de ejecutores
    """
    # Crear un diccionario con la configuración
    rate_config = {
        "global_rpm": GLOBAL_RPM,
        "global_tpm": GLOBAL_TPM,
        "executor_count": executor_count
    }
    
    # Convertir a JSON para broadcast
    config_json = json.dumps(rate_config)
    
    # Broadcast a todos los ejecutores
    return spark.sparkContext.broadcast(config_json)


def main():
    """Función principal"""
    logger.info("Iniciando procesamiento de CVs con Spark y control de límites de tasa")
    
    # Crear sesión Spark
    spark = (SparkSession.builder
        .appName("CV Screening Rate Limited")
        .config("spark.executor.memory", "4g")
        .config("spark.driver.memory", "2g")
        .config("spark.executor.instances", "4")  # Ajustar según tu cluster
        .getOrCreate())
    
    # Determinar número de ejecutores
    executor_count = int(spark.conf.get("spark.executor.instances", "4"))
    logger.info(f"Configurando para {executor_count} ejecutores")
    
    # Broadcast de la configuración de límites
    rate_config = broadcast_rate_limiter_config(spark, executor_count)
    
    try:
        # Cargar datos de CVs
        logger.info("Cargando datos de CVs")
        cvs_df = (spark.read
            .option("header", "true")
            .option("multiline", "true")
            .csv("s3://your-bucket/cvs_metadata.csv"))
        
        # Calcular número óptimo de particiones
        # Un buen punto de partida es: ejecutores * 2-4 tareas por ejecutor
        partition_count = executor_count * 3
        logger.info(f"Configurando para {partition_count} particiones")
        
        # Repartición para mejor distribución de carga
        cvs_df = cvs_df.repartition(partition_count)
        
        # Método 1: Usando RDD con mapPartitions y limitador de tasa
        logger.info("Procesando CVs con mapPartitions y control de límites")
        
        # Convertir a RDD
        cvs_rdd = cvs_df.rdd.map(lambda row: row.asDict())
        
        # Procesar con límites de tasa
        results_rdd = cvs_rdd.mapPartitions(
            lambda partition: process_cv_batch_with_rate_limit(
                partition, 
                executor_count=executor_count
            )
        )
        
        # Convertir resultados a DataFrame
        results_df = spark.createDataFrame(
            results_rdd,
            ["cv_id", "filename", "analysis_result"]
        )
        
        # Guardar resultados
        logger.info("Guardando resultados")
        (results_df
            .write
            .mode("overwrite")
            .parquet("s3://your-bucket/rate_limited_results/"))
        
        # Método 2: Usando Pandas UDF con control de límites
        logger.info("Procesando CVs con Pandas UDF y control de límites")
        
        # Registrar UDF
        rate_limited_analyze = pandas_udf(
            pandas_rate_limited_cv_analysis, 
            returnType=StringType()
        )
        
        # Aplicar UDF
        pandas_results_df = cvs_df.withColumn(
            "analysis_result",
            rate_limited_analyze(col("content"))
        )
        
        # Guardar resultados del método Pandas
        (pandas_results_df
            .select("cv_id", "filename", "analysis_result")
            .write
            .mode("overwrite")
            .parquet("s3://your-bucket/pandas_rate_limited_results/"))
        
        logger.info("Procesamiento completado con éxito")
        
    except Exception as e:
        logger.error(f"Error en el procesamiento: {str(e)}")
        raise
    
    finally:
        # Detener sesión Spark
        spark.stop()
        logger.info("Sesión Spark detenida")


if __name__ == "__main__":
    main() 