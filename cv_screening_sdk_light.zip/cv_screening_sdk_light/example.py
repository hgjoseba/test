"""
Example usage of CV Screening SDK Light with Azure OpenAI.

This script demonstrates how to use the CV Screening SDK Light to analyze a CV using Azure OpenAI.
"""

import json
import os
from dotenv import load_dotenv

from cv_screening_sdk_light import CVScreeningClient
from cv_screening_sdk_light.models import JobCriteria


def main():
    # Load environment variables from .env file
    load_dotenv()
    
    # Verify required environment variables
    if not os.getenv("AZURE_OPENAI_API_KEY") or not os.getenv("AZURE_OPENAI_ENDPOINT"):
        print("Error: AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT environment variables are required.")
        print("Please set these in your .env file or directly in your environment.")
        return
    
    # Initialize client with Azure OpenAI credentials
    client = CVScreeningClient(
        api_key=os.getenv("AZURE_OPENAI_API_KEY"),
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        model_name=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),  # Default to "gpt-4" if not specified
        temperature=0.1,     # Lower temperature for more consistent results
    )
    
    # Define job criteria
    criteria = JobCriteria(
        required_skills=["Python", "API Development", "SQL"],
        preferred_skills=["Docker", "AWS", "Git", "CI/CD"],
        min_years_experience=3,
        education_level="bachelor's",
        job_title="Senior Backend Developer",
        job_description="We are looking for a Senior Backend Developer with strong Python skills and experience building RESTful APIs. The candidate should have good understanding of SQL databases and be familiar with containerization and cloud technologies."
    )
    
    try:
        # Example 1: Load CV from file and analyze
        print("Example 1: Analyzing CV from file")
        # Replace with actual path to a CV file
        cv_path = "path/to/your/cv.pdf"
        
        # Check if file exists (for demonstration purposes)
        if os.path.exists(cv_path):
            # Load CV content
            cv_content = client.load_cv_content(cv_path)
            
            # Analyze CV
            result = client.analyze_cv(cv_content, criteria)
            
            # Print result
            print(json.dumps(result, indent=2))
        else:
            print(f"File not found: {cv_path}")
            print("Using example 2 with direct text input instead.")
        
        # Example 2: Analyze CV from text
        print("\nExample 2: Analyzing CV from text")
        # Sample CV text
        cv_text = """
        John Doe
        Senior Software Developer
        email@example.com | (123) 456-7890
        
        SUMMARY
        Experienced software developer with 5 years of experience in Python, SQL, and web API development.
        Passionate about clean code, testing, and DevOps practices.
        
        EXPERIENCE
        Senior Developer, Tech Company Inc. (2020-Present)
        - Developed RESTful APIs using Python and Flask
        - Managed PostgreSQL databases and optimized queries
        - Implemented CI/CD pipelines using GitHub Actions
        - Deployed applications in Docker containers to AWS ECS
        
        Junior Developer, Startup Ltd. (2018-2020)
        - Built web applications using Python and Django
        - Created and maintained MySQL databases
        - Implemented unit and integration tests
        
        EDUCATION
        Bachelor of Science in Computer Science
        University of Technology (2014-2018)
        
        SKILLS
        - Programming Languages: Python, JavaScript, SQL
        - Frameworks: Flask, Django, FastAPI
        - Tools: Git, Docker, AWS, CI/CD
        - Databases: PostgreSQL, MySQL
        """
        
        # Analyze CV
        result = client.analyze_cv(cv_text, criteria)
        
        # Print result
        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main() 