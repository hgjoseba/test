import unittest
import json
from unittest.mock import patch, MagicMock, PropertyMock

from src.providers.azure_provider import AzureOpenAIProvider
from src.core.exceptions import OpenAIError


class TestAzureOpenAIProvider(unittest.TestCase):
    """Tests for the AzureOpenAIProvider class."""
    
    def test_init_with_default_values(self):
        """Test provider initialization with default values."""
        with patch('src.providers.azure_provider.AzureOpenAI') as mock_azure_openai:
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key"
            )
            
            mock_azure_openai.assert_called_once_with(
                azure_endpoint="https://test-endpoint.com",
                api_version="2023-05-15",
                api_key="test-api-key"
            )
            
            self.assertEqual(provider.endpoint, "https://test-endpoint.com")
            self.assertEqual(provider.api_key, "test-api-key")
            self.assertEqual(provider.deployment_name, "gpt-4")
            self.assertEqual(provider.temperature, 0.1)
            self.assertIsNone(provider.max_tokens)
            self.assertIsNone(provider.system_prompt)
            self.assertTrue(provider.connection_verify)
    
    def test_init_with_custom_values(self):
        """Test provider initialization with custom values."""
        with patch('src.providers.azure_provider.AzureOpenAI') as mock_azure_openai:
            provider = AzureOpenAIProvider(
                endpoint="https://custom-endpoint.com",
                api_key="custom-api-key",
                deployment_name="gpt-35-turbo",
                api_version="2023-09-01",
                temperature=0.7,
                max_tokens=1000,
                system_prompt="Custom prompt",
                connection_verify=False
            )
            
            mock_azure_openai.assert_called_once_with(
                azure_endpoint="https://custom-endpoint.com",
                api_version="2023-09-01",
                api_key="custom-api-key"
            )
            
            self.assertEqual(provider.endpoint, "https://custom-endpoint.com")
            self.assertEqual(provider.api_key, "custom-api-key")
            self.assertEqual(provider.deployment_name, "gpt-35-turbo")
            self.assertEqual(provider.api_version, "2023-09-01")
            self.assertEqual(provider.temperature, 0.7)
            self.assertEqual(provider.max_tokens, 1000)
            self.assertEqual(provider.system_prompt, "Custom prompt")
            self.assertFalse(provider.connection_verify)
    
    def test_init_with_error(self):
        """Test provider initialization with error."""
        with patch('src.providers.azure_provider.AzureOpenAI', side_effect=Exception("Test error")):
            with self.assertRaises(OpenAIError) as context:
                AzureOpenAIProvider(
                    endpoint="https://test-endpoint.com",
                    api_key="test-api-key"
                )
            
            self.assertIn("Error initializing", str(context.exception))
            self.assertIn("Test error", str(context.exception))
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_apply_http_monkey_patch(self, mock_azure_openai):
        """Test _apply_http_monkey_patch method."""
        # Store original __init__ methods
        import httpx
        original_client_init = httpx.Client.__init__
        original_async_client_init = httpx.AsyncClient.__init__
        
        try:
            # Initialize provider with connection_verify=False
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key",
                connection_verify=False
            )
            
            # Check that the __init__ methods were patched
            self.assertNotEqual(httpx.Client.__init__, original_client_init)
            self.assertNotEqual(httpx.AsyncClient.__init__, original_async_client_init)
            
            # Clean up monkey patches
            provider.__del__()
            
            # Check that __init__ methods were restored
            self.assertEqual(httpx.Client.__init__, original_client_init)
            self.assertEqual(httpx.AsyncClient.__init__, original_async_client_init)
        finally:
            # Ensure we restore the original methods
            httpx.Client.__init__ = original_client_init
            httpx.AsyncClient.__init__ = original_async_client_init
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_get_system_prompt_default(self, mock_azure_openai):
        """Test _get_system_prompt method with default prompt."""
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        system_prompt = provider._get_system_prompt()
        
        self.assertIn("You are an expert CV screening assistant", system_prompt)
        self.assertIn("Your response should be a JSON object", system_prompt)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_get_system_prompt_custom(self, mock_azure_openai):
        """Test _get_system_prompt method with custom prompt."""
        custom_prompt = "Custom system prompt"
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            system_prompt=custom_prompt
        )
        
        system_prompt = provider._get_system_prompt()
        
        self.assertEqual(system_prompt, custom_prompt)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_get_completion(self, mock_azure_openai):
        """Test get_completion method."""
        # Set up mock response
        mock_client = MagicMock()
        mock_completion = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion
        mock_azure_openai.return_value = mock_client
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            deployment_name="test-deployment",
            temperature=0.5,
            max_tokens=100
        )
        
        # Test with default values
        messages = [
            {"role": "system", "content": "You are an assistant."},
            {"role": "user", "content": "Hello."}
        ]
        
        result = provider.get_completion(messages)
        
        # Check that API was called with correct parameters
        mock_client.chat.completions.create.assert_called_once_with(
            model="test-deployment",
            messages=messages,
            temperature=0.5,
            max_tokens=100
        )
        
        # Check result
        self.assertEqual(result, mock_completion)
        
        # Reset mock
        mock_client.chat.completions.create.reset_mock()
        
        # Test with custom values
        result = provider.get_completion(messages, temperature=0.7, max_tokens=200)
        
        # Check that API was called with custom parameters
        mock_client.chat.completions.create.assert_called_once_with(
            model="test-deployment",
            messages=messages,
            temperature=0.7,
            max_tokens=200
        )
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_get_completion_error(self, mock_azure_openai):
        """Test get_completion method with error."""
        # Set up mock to raise error
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API error")
        mock_azure_openai.return_value = mock_client
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        messages = [{"role": "user", "content": "Hello."}]
        
        with self.assertRaises(OpenAIError) as context:
            provider.get_completion(messages)
        
        self.assertIn("Error getting completion", str(context.exception))
        self.assertIn("API error", str(context.exception))
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider._get_system_prompt')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_json_response(self, mock_azure_openai, mock_get_system_prompt):
        """Test analyze_cv method with JSON response."""
        # Set up mocks
        mock_get_system_prompt.return_value = "You are an assistant."
        
        # Configurar los mocks para el método client.chat.completions.create
        chat_completions_create_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        
        # El contenido del mensaje debe ser un string JSON real, no un MagicMock
        message_mock.content = '{"match": 0.8, "skills": ["Python"]}'
        
        # Configurar la jerarquía de mocks
        choices_mock.message = message_mock
        chat_completions_create_mock.choices = [choices_mock]
        
        # Mocks para los clientes
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.return_value = chat_completions_create_mock
        client_mock.chat = chat_mock
        
        # Configurar AzureOpenAI para devolver nuestro cliente mock
        mock_azure_openai.return_value = client_mock
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        result = provider.analyze_cv(cv_content, criteria)
        
        # Verify result
        self.assertEqual(result, {"match": 0.8, "skills": ["Python"]})
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider._get_system_prompt')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_text_response(self, mock_azure_openai, mock_get_system_prompt):
        """Test analyze_cv method with text response."""
        # Set up mocks
        mock_get_system_prompt.return_value = "You are an assistant."
        
        # Configurar los mocks para el método client.chat.completions.create
        chat_completions_create_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        
        # El contenido del mensaje debe ser un string, no un MagicMock
        message_mock.content = 'This is not JSON'
        
        # Configurar la jerarquía de mocks
        choices_mock.message = message_mock
        chat_completions_create_mock.choices = [choices_mock]
        
        # Mocks para los clientes
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.return_value = chat_completions_create_mock
        client_mock.chat = chat_mock
        
        # Configurar AzureOpenAI para devolver nuestro cliente mock
        mock_azure_openai.return_value = client_mock
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        result = provider.analyze_cv(cv_content, criteria)
        
        # Verify result
        self.assertEqual(result, {"raw_response": "This is not JSON"})
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_error(self, mock_azure_openai):
        """Test analyze_cv method with error."""
        # Configurar client mock para lanzar un error
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.side_effect = Exception("Completion error")
        client_mock.chat = chat_mock
        
        # Configurar AzureOpenAI para devolver nuestro cliente mock
        mock_azure_openai.return_value = client_mock
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        with self.assertRaises(OpenAIError) as context:
            provider.analyze_cv(cv_content, criteria)
        
        self.assertIn("Error analyzing CV", str(context.exception))
        self.assertIn("Completion error", str(context.exception))
        
        # Verify chat.completions.create was called
        chat_mock.completions.create.assert_called_once()

    def test_init_with_type_error_handling(self):
        """Test provider initialization with TypeError handling."""
        with patch('src.providers.azure_provider.AzureOpenAI') as mock_azure_openai:
            # First call raises TypeError about proxies
            mock_azure_openai.side_effect = [
                TypeError("Client.__init__() got an unexpected keyword argument 'proxies'"),
                MagicMock()  # Second call succeeds
            ]
            
            # Create a provider with the mocked AzureOpenAI
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key"
            )
            
            # Verify provider was created successfully using the alternative approach
            self.assertEqual(provider.endpoint, "https://test-endpoint.com")
            self.assertEqual(provider.api_key, "test-api-key")
            self.assertEqual(provider.deployment_name, "gpt-4")
            
            # Check that AzureOpenAI was called with the expected parameters on the second attempt
            self.assertEqual(mock_azure_openai.call_count, 2)
            # We expect the second call to be with different parameters
            mock_azure_openai.assert_called_with(
                azure_endpoint="https://test-endpoint.com",
                api_version="2023-05-15",
                api_key="test-api-key",
                http_client=unittest.mock.ANY
            )

    def test_init_with_other_type_error_handling(self):
        """Test provider initialization with other TypeError handling."""
        with patch('src.providers.azure_provider.AzureOpenAI') as mock_azure_openai:
            # First call raises TypeError about something else
            mock_azure_openai.side_effect = [
                TypeError("Client.__init__() got an unexpected keyword argument 'other_param'"),
                MagicMock()  # Second call succeeds
            ]
            
            # Create a provider with the mocked AzureOpenAI
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key"
            )
            
            # Verify provider was created successfully using the alternative approach
            self.assertEqual(provider.endpoint, "https://test-endpoint.com")
            self.assertEqual(provider.api_key, "test-api-key")
            self.assertEqual(provider.deployment_name, "gpt-4")
            
            # Check that AzureOpenAI was called with the expected parameters on the second attempt
            self.assertEqual(mock_azure_openai.call_count, 2)
            # We expect the second call to use minimal parameters
            mock_azure_openai.assert_called_with(
                azure_endpoint="https://test-endpoint.com",
                api_key="test-api-key"
            )

    @patch('src.providers.azure_provider.AzureOpenAIProvider.get_completion')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_empty(self, mock_azure_openai, mock_get_completion):
        """Test analyze_multiple_cvs with empty list."""
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test with empty list
        results = provider.analyze_multiple_cvs([], {"required_skills": ["Python"]})
        
        # Verify that get_completion was not called
        mock_get_completion.assert_not_called()
        self.assertEqual(results, [])
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider._process_cv_batch')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_single_batch(self, mock_azure_openai, mock_process_batch):
        """Test analyze_multiple_cvs with single batch."""
        # Setup mock
        mock_process_batch.return_value = [{"cv_index": 0, "match": 0.8}]
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test with single CV
        cv_contents = ["CV content"]
        criteria = {"required_skills": ["Python"]}
        
        results = provider.analyze_multiple_cvs(cv_contents, criteria)
        
        # Verify that _process_cv_batch was called correctly
        mock_process_batch.assert_called_once_with(cv_contents, criteria, schema_json_ob=None)
        self.assertEqual(results, [{"cv_index": 0, "match": 0.8}])
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider._process_cv_batch')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_with_batching(self, mock_azure_openai, mock_process_batch):
        """Test analyze_multiple_cvs with batching."""
        # Setup mock
        mock_process_batch.side_effect = [
            [{"cv_index": 0, "match": 0.8}, {"cv_index": 1, "match": 0.7}],
            [{"cv_index": 2, "match": 0.9}]
        ]
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test with multiple CVs and batch_size
        cv_contents = ["CV 1", "CV 2", "CV 3"]
        criteria = {"required_skills": ["Python"]}
        
        results = provider.analyze_multiple_cvs(cv_contents, criteria, batch_size=2)
        
        # Verify that _process_cv_batch was called correctly for each batch
        self.assertEqual(mock_process_batch.call_count, 2)
        mock_process_batch.assert_any_call(["CV 1", "CV 2"], criteria, start_index=0, schema_json_ob=None)
        mock_process_batch.assert_any_call(["CV 3"], criteria, start_index=2, schema_json_ob=None)
        
        # Verify results were combined
        expected_results = [
            {"cv_index": 0, "match": 0.8},
            {"cv_index": 1, "match": 0.7},
            {"cv_index": 2, "match": 0.9}
        ]
        self.assertEqual(results, expected_results)
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider._process_cv_batch')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_with_batch_error(self, mock_azure_openai, mock_process_batch):
        """Test analyze_multiple_cvs with an error in one batch."""
        # Setup mock to raise error for the first batch but succeed for the second
        mock_process_batch.side_effect = [
            Exception("Error in first batch"),
            [{"cv_index": 2, "match": 0.9}]
        ]
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test with multiple CVs and batch_size
        cv_contents = ["CV 1", "CV 2", "CV 3"]
        criteria = {"required_skills": ["Python"]}
        
        results = provider.analyze_multiple_cvs(cv_contents, criteria, batch_size=2)
        
        # Verify that _process_cv_batch was called for both batches despite the error
        self.assertEqual(mock_process_batch.call_count, 2)
        
        # Verify results only contain the successful batch
        expected_results = [{"cv_index": 2, "match": 0.9}]
        self.assertEqual(results, expected_results)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_process_cv_batch(self, mock_azure_openai):
        """Test _process_cv_batch method."""
        # Configurar los mocks para el método client.chat.completions.create
        chat_completions_create_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        
        # El contenido del mensaje debe ser un string JSON real, no un MagicMock
        message_mock.content = '[{"cv_index": 0, "match": 0.8}]'
        
        # Configurar la jerarquía de mocks
        choices_mock.message = message_mock
        chat_completions_create_mock.choices = [choices_mock]
        
        # Mocks para los clientes
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.return_value = chat_completions_create_mock
        client_mock.chat = chat_mock
        
        # Configurar AzureOpenAI para devolver nuestro cliente mock
        mock_azure_openai.return_value = client_mock
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            max_tokens=1000
        )
        
        # Test
        cv_contents = ["CV content"]
        criteria = {"required_skills": ["Python"]}
        
        results = provider._process_cv_batch(cv_contents, criteria)
        
        # Verify that chat.completions.create was called with correct parameters
        chat_mock.completions.create.assert_called_once()
        
        # Verify results
        expected_results = [{"cv_index": 0, "match": 0.8}]
        self.assertEqual(results, expected_results)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_process_cv_batch_error(self, mock_azure_openai):
        """Test _process_cv_batch method with error handling."""
        # Configurar client mock para lanzar un error
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.side_effect = Exception("Get completion error")
        client_mock.chat = chat_mock
        
        # Configurar AzureOpenAI para devolver nuestro cliente mock
        mock_azure_openai.return_value = client_mock
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_contents = ["CV content"]
        criteria = {"required_skills": ["Python"]}
        
        # Verify that the method raises OpenAIError
        with self.assertRaises(OpenAIError) as context:
            provider._process_cv_batch(cv_contents, criteria)
        
        # Verify error message
        self.assertIn("Error processing CV batch", str(context.exception))
        self.assertIn("Get completion error", str(context.exception))
        
        # Verify chat.completions.create was called
        chat_mock.completions.create.assert_called_once()

    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_overall_error(self, mock_azure_openai):
        """Test analyze_multiple_cvs with an overall error."""
        # Setup a provider instance
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Setup a mock for process_cv_batch that will raise an exception
        with patch.object(provider, '_process_cv_batch', side_effect=Exception("Test batch error")):
            # Create test data
            cv_contents = ["CV content"]
            criteria = {"required_skills": ["Python"]}
            
            # Test error handling
            with self.assertRaises(OpenAIError) as context:
                provider.analyze_multiple_cvs(cv_contents, criteria)
            
            # Verify error message
            self.assertIn("Error analyzing multiple CVs", str(context.exception))
            self.assertIn("Test batch error", str(context.exception))

    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_infer_base_model_from_deployment_names(self, mock_azure_openai):
        """Test the correct inference of base models from different deployment names."""
        # Setup - Create a provider instance
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test exact matches
        self.assertEqual(provider._infer_base_model("gpt-4"), "gpt-4")
        self.assertEqual(provider._infer_base_model("gpt-35-turbo"), "gpt-35-turbo")
        
        # Test case insensitivity
        self.assertEqual(provider._infer_base_model("GPT-4"), "gpt-4")
        self.assertEqual(provider._infer_base_model("GPT-35-TURBO"), "gpt-35-turbo")
        
        # Test custom deployment names with model names
        self.assertEqual(provider._infer_base_model("prod-gpt-4"), "gpt-4")
        self.assertEqual(provider._infer_base_model("prod-gpt-35-turbo"), "gpt-35-turbo")
        self.assertEqual(provider._infer_base_model("gpt4-company"), "gpt-4")
        self.assertEqual(provider._infer_base_model("gpt35-turbo-test"), "gpt-35-turbo")
        
        # Test alternate formats
        self.assertEqual(provider._infer_base_model("gpt4"), "gpt-4")
        self.assertEqual(provider._infer_base_model("gpt35"), "gpt-35-turbo")
        self.assertEqual(provider._infer_base_model("gpt-3.5"), "gpt-35-turbo")
        
        # Test unrecognized models
        self.assertIsNone(provider._infer_base_model("custom-model"))
        self.assertIsNone(provider._infer_base_model("llama-70b"))
        self.assertIsNone(provider._infer_base_model("claude-2"))

    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_explicit_base_model(self, mock_azure_openai):
        """Test the behavior when base_model is explicitly provided."""
        # Create provider with explicit base_model
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            deployment_name="custom-deployment",
            base_model="gpt-4"
        )
        
        # Verify the base_model was set correctly
        self.assertEqual(provider.base_model, "gpt-4")
        
        # Check that the model is considered schema-capable since base_model is an allowed model
        self.assertTrue(provider._is_model_schema_capable())
        
        # Create provider with non-allowed base_model
        provider_non_allowed = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            deployment_name="custom-deployment",
            base_model="custom-model"
        )
        
        # Verify the base_model was set correctly
        self.assertEqual(provider_non_allowed.base_model, "custom-model")
        
        # Check that the model is not considered schema-capable
        self.assertFalse(provider_non_allowed._is_model_schema_capable())

    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_base_model_priority_over_inference(self, mock_azure_openai):
        """Test that explicit base_model takes priority over inference from deployment name."""
        # Mock infer_base_model to verify it's not called when base_model is provided
        with patch.object(AzureOpenAIProvider, '_infer_base_model', return_value="inferred-model") as mock_infer:
            # Case 1: Provide base_model - should not call _infer_base_model
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key",
                deployment_name="gpt4-deployment",
                base_model="gpt-35-turbo"  # Explicitly set to a different model than what would be inferred
            )
            
            # Verify _infer_base_model was NOT called
            mock_infer.assert_not_called()
            
            # Verify base_model is set to the explicit value, not the inferred one
            self.assertEqual(provider.base_model, "gpt-35-turbo")
            
            # Reset mock for the next test
            mock_infer.reset_mock()
            
            # Case 2: No base_model provided - should call _infer_base_model
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key",
                deployment_name="gpt4-deployment"
            )
            
            # Verify _infer_base_model was called with the deployment name
            mock_infer.assert_called_once_with("gpt4-deployment")
            
            # Verify base_model is set to the inferred value
            self.assertEqual(provider.base_model, "inferred-model")

    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_process_cv_batch_with_token_adjustment(self, mock_azure_openai):
        """Test _process_cv_batch method with token adjustment."""
        # Configurar los mocks para el método client.chat.completions.create
        chat_completions_create_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        
        # El contenido del mensaje debe ser un string JSON real, no un MagicMock
        message_mock.content = '[{"cv_index": 0, "match": 0.8}, {"cv_index": 1, "match": 0.7}, {"cv_index": 2, "match": 0.9}]'
        
        # Configurar la jerarquía de mocks
        choices_mock.message = message_mock
        chat_completions_create_mock.choices = [choices_mock]
        
        # Mocks para los clientes
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.return_value = chat_completions_create_mock
        client_mock.chat = chat_mock
        
        # Configurar AzureOpenAI para devolver nuestro cliente mock
        mock_azure_openai.return_value = client_mock
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            max_tokens=1000
        )
        
        # Test with multiple CVs to trigger token adjustment
        cv_contents = ["CV 1", "CV 2", "CV 3"]
        criteria = {"required_skills": ["Python"]}
        
        results = provider._process_cv_batch(cv_contents, criteria)
        
        # Verify results
        expected_results = [
            {"cv_index": 0, "match": 0.8},
            {"cv_index": 1, "match": 0.7},
            {"cv_index": 2, "match": 0.9}
        ]
        self.assertEqual(results, expected_results)
        
        # Verify that chat.completions.create was called with adjusted max_tokens
        chat_mock.completions.create.assert_called_once()
        call_args = chat_mock.completions.create.call_args[1]
        self.assertEqual(call_args.get('max_tokens'), 3000)  # 1000 * 3

    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_with_custom_schema(self, mock_azure_openai):
        """Test analyze_cv method with a custom JSON schema."""
        # Configurar los mocks
        chat_completions_create_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        message_mock.content = '{"match": 0.85, "custom_field": "value"}'
        choices_mock.message = message_mock
        chat_completions_create_mock.choices = [choices_mock]
        
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.return_value = chat_completions_create_mock
        client_mock.chat = chat_mock
        mock_azure_openai.return_value = client_mock
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Crear esquema personalizado
        custom_schema = {
            "type": "object",
            "properties": {
                "match": {"type": "number"},
                "custom_field": {"type": "string"}
            },
            "required": ["match", "custom_field"]
        }
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        result = provider.analyze_cv(cv_content, criteria, schema_json_ob=custom_schema)
        
        # Verificar que el método completions.create fue llamado con el esquema personalizado
        chat_mock.completions.create.assert_called_once()
        call_args = chat_mock.completions.create.call_args[1]
        self.assertIn('response_format', call_args)
        response_format = call_args.get('response_format')
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertIn('json_schema', response_format)
        self.assertEqual(response_format['json_schema']['name'], 'cvscreening')
        self.assertTrue(response_format['json_schema']['strict'])
        self.assertEqual(response_format['json_schema']['schema'], custom_schema)
        
        # Verificar resultado
        self.assertEqual(result, {"match": 0.85, "custom_field": "value"})
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_process_cv_batch_with_custom_schema(self, mock_azure_openai):
        """Test _process_cv_batch method with a custom JSON schema."""
        # Configurar los mocks
        chat_completions_create_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        message_mock.content = '[{"cv_index": 0, "match": 0.8, "custom_field": "value1"}, {"cv_index": 1, "match": 0.7, "custom_field": "value2"}]'
        choices_mock.message = message_mock
        chat_completions_create_mock.choices = [choices_mock]
        
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.return_value = chat_completions_create_mock
        client_mock.chat = chat_mock
        mock_azure_openai.return_value = client_mock
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Crear esquema personalizado
        custom_schema = {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "cv_index": {"type": "integer"},
                    "match": {"type": "number"},
                    "custom_field": {"type": "string"}
                },
                "required": ["cv_index", "match", "custom_field"]
            }
        }
        
        # Test
        cv_contents = ["CV 1", "CV 2"]
        criteria = {"required_skills": ["Python"]}
        
        results = provider._process_cv_batch(cv_contents, criteria, schema_json_ob=custom_schema)
        
        # Verificar que el método completions.create fue llamado con el esquema personalizado
        chat_mock.completions.create.assert_called_once()
        call_args = chat_mock.completions.create.call_args[1]
        self.assertIn('response_format', call_args)
        response_format = call_args.get('response_format')
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertIn('json_schema', response_format)
        self.assertEqual(response_format['json_schema']['name'], 'cvscreening')
        self.assertTrue(response_format['json_schema']['strict'])
        self.assertEqual(response_format['json_schema']['schema'], custom_schema)
        
        # Verificar resultados
        expected_results = [
            {"cv_index": 0, "match": 0.8, "custom_field": "value1"},
            {"cv_index": 1, "match": 0.7, "custom_field": "value2"}
        ]
        self.assertEqual(results, expected_results)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_with_schema_propagation(self, mock_azure_openai):
        """Test that schema_json_ob is correctly propagated to _process_cv_batch."""
        # Configurar el proveedor con un mock para _process_cv_batch
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Crear esquema personalizado
        custom_schema = {"type": "object", "properties": {"test": {"type": "string"}}}
        
        # Mock para _process_cv_batch
        with patch.object(provider, '_process_cv_batch', return_value=[{"cv_index": 0, "match": 0.8}]) as mock_process_batch:
            # Test
            cv_contents = ["CV content"]
            criteria = {"required_skills": ["Python"]}
            
            provider.analyze_multiple_cvs(cv_contents, criteria, schema_json_ob=custom_schema)
            
            # Verificar que _process_cv_batch fue llamado con el esquema personalizado
            mock_process_batch.assert_called_once_with(cv_contents, criteria, schema_json_ob=custom_schema)
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider.format_response_with_secondary_model')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_schema_propagation_to_secondary_model(self, mock_azure_openai, mock_format_response):
        """Test that schema_json_ob is correctly propagated to the secondary model processing."""
        # Configurar los mocks
        client_mock = MagicMock()
        chat_mock = MagicMock()
        
        # El completion.choices[0].message.content será un string no JSON
        completion_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        message_mock.content = "This is not JSON"
        choices_mock.message = message_mock
        completion_mock.choices = [choices_mock]
        
        chat_mock.completions.create.return_value = completion_mock
        client_mock.chat = chat_mock
        mock_azure_openai.return_value = client_mock
        
        # Configurar para que el modelo no soporte schema
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            deployment_name="custom-model",  # No en la lista de modelos permitidos
            base_model="custom-model"       # Para asegurar que _is_model_schema_capable() devuelva False
        )
        
        # Configurar el mock para format_response_with_secondary_model
        mock_format_response.return_value = {"match": 0.8}
        
        # Crear esquema personalizado
        custom_schema = {"type": "object", "properties": {"match": {"type": "number"}}}
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        provider.analyze_cv(cv_content, criteria, schema_json_ob=custom_schema)
        
        # Verificar que format_response_with_secondary_model fue llamado con el esquema personalizado
        mock_format_response.assert_called_once()
        self.assertEqual(mock_format_response.call_args[0][1], custom_schema)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_default_schema_used_when_none_provided(self, mock_azure_openai):
        """Test that the default schema is used when schema_json_ob is None."""
        # Configurar los mocks
        chat_completions_create_mock = MagicMock()
        choices_mock = MagicMock()
        message_mock = MagicMock()
        message_mock.content = '{"match": 0.8}'
        choices_mock.message = message_mock
        chat_completions_create_mock.choices = [choices_mock]
        
        client_mock = MagicMock()
        chat_mock = MagicMock()
        chat_mock.completions.create.return_value = chat_completions_create_mock
        client_mock.chat = chat_mock
        mock_azure_openai.return_value = client_mock
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        provider.analyze_cv(cv_content, criteria)  # schema_json_ob no proporcionado
        
        # Verificar que el método completions.create fue llamado con el esquema predeterminado
        chat_mock.completions.create.assert_called_once()
        call_args = chat_mock.completions.create.call_args[1]
        self.assertIn('response_format', call_args)
        response_format = call_args.get('response_format')
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertIn('json_schema', response_format)
        self.assertEqual(response_format['json_schema']['name'], 'cvscreening')
        self.assertTrue(response_format['json_schema']['strict'])
        self.assertEqual(response_format['json_schema']['schema'], provider.DEFAULT_CV_SCHEMA)


if __name__ == "__main__":
    unittest.main() 