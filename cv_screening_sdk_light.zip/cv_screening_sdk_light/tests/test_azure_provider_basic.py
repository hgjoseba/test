import unittest
import json
from unittest.mock import patch, MagicMock, PropertyMock

from cv_screening_sdk.providers.azure_provider import AzureOpenAIProvider
from cv_screening_sdk.core.exceptions import OpenAIError


class TestAzureOpenAIProvider(unittest.TestCase):
    """Tests for the AzureOpenAIProvider class."""
    
    def test_init_with_default_values(self):
        """Test provider initialization with default values."""
        with patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI') as mock_azure_openai:
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key"
            )
            
            mock_azure_openai.assert_called_once_with(
                azure_endpoint="https://test-endpoint.com",
                api_version="2023-05-15",
                api_key="test-api-key"
            )
            
            self.assertEqual(provider.endpoint, "https://test-endpoint.com")
            self.assertEqual(provider.api_key, "test-api-key")
            self.assertEqual(provider.deployment_name, "gpt-4")
            self.assertEqual(provider.temperature, 0.1)
            self.assertIsNone(provider.max_tokens)
            self.assertIsNone(provider.system_prompt)
            self.assertTrue(provider.connection_verify)
    
    def test_init_with_custom_values(self):
        """Test provider initialization with custom values."""
        with patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI') as mock_azure_openai:
            provider = AzureOpenAIProvider(
                endpoint="https://custom-endpoint.com",
                api_key="custom-api-key",
                deployment_name="gpt-35-turbo",
                api_version="2023-09-01",
                temperature=0.7,
                max_tokens=1000,
                system_prompt="Custom prompt",
                connection_verify=False
            )
            
            mock_azure_openai.assert_called_once_with(
                azure_endpoint="https://custom-endpoint.com",
                api_version="2023-09-01",
                api_key="custom-api-key"
            )
            
            self.assertEqual(provider.endpoint, "https://custom-endpoint.com")
            self.assertEqual(provider.api_key, "custom-api-key")
            self.assertEqual(provider.deployment_name, "gpt-35-turbo")
            self.assertEqual(provider.api_version, "2023-09-01")
            self.assertEqual(provider.temperature, 0.7)
            self.assertEqual(provider.max_tokens, 1000)
            self.assertEqual(provider.system_prompt, "Custom prompt")
            self.assertFalse(provider.connection_verify)
    
    def test_init_with_error(self):
        """Test provider initialization with error."""
        with patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI', side_effect=Exception("Test error")):
            with self.assertRaises(OpenAIError) as context:
                AzureOpenAIProvider(
                    endpoint="https://test-endpoint.com",
                    api_key="test-api-key"
                )
            
            self.assertIn("Error al inicializar", str(context.exception))
            self.assertIn("Test error", str(context.exception))
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_apply_http_monkey_patch(self, mock_azure_openai):
        """Test _apply_http_monkey_patch method."""
        # Store original __init__ methods
        import httpx
        original_client_init = httpx.Client.__init__
        original_async_client_init = httpx.AsyncClient.__init__
        
        try:
            # Initialize provider with connection_verify=False
            provider = AzureOpenAIProvider(
                endpoint="https://test-endpoint.com",
                api_key="test-api-key",
                connection_verify=False
            )
            
            # Check that the __init__ methods were patched
            self.assertNotEqual(httpx.Client.__init__, original_client_init)
            self.assertNotEqual(httpx.AsyncClient.__init__, original_async_client_init)
            
            # Clean up monkey patches
            provider.__del__()
            
            # Check that __init__ methods were restored
            self.assertEqual(httpx.Client.__init__, original_client_init)
            self.assertEqual(httpx.AsyncClient.__init__, original_async_client_init)
        finally:
            # Ensure we restore the original methods
            httpx.Client.__init__ = original_client_init
            httpx.AsyncClient.__init__ = original_async_client_init
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_get_system_prompt_default(self, mock_azure_openai):
        """Test _get_system_prompt method with default prompt."""
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        system_prompt = provider._get_system_prompt()
        
        self.assertIn("You are an expert CV screening assistant", system_prompt)
        self.assertIn("Your response should be a JSON object", system_prompt)
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_get_system_prompt_custom(self, mock_azure_openai):
        """Test _get_system_prompt method with custom prompt."""
        custom_prompt = "Custom system prompt"
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            system_prompt=custom_prompt
        )
        
        system_prompt = provider._get_system_prompt()
        
        self.assertEqual(system_prompt, custom_prompt)
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_get_completion(self, mock_azure_openai):
        """Test get_completion method."""
        # Set up mock response
        mock_client = MagicMock()
        mock_completion = MagicMock()
        mock_client.chat.completions.create.return_value = mock_completion
        mock_azure_openai.return_value = mock_client
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            deployment_name="test-deployment",
            temperature=0.5,
            max_tokens=100
        )
        
        # Test with default values
        messages = [
            {"role": "system", "content": "You are an assistant."},
            {"role": "user", "content": "Hello."}
        ]
        
        result = provider.get_completion(messages)
        
        # Check that API was called with correct parameters
        mock_client.chat.completions.create.assert_called_once_with(
            model="test-deployment",
            messages=messages,
            temperature=0.5,
            max_tokens=100
        )
        
        # Check result
        self.assertEqual(result, mock_completion)
        
        # Reset mock
        mock_client.chat.completions.create.reset_mock()
        
        # Test with custom values
        result = provider.get_completion(messages, temperature=0.7, max_tokens=200)
        
        # Check that API was called with custom parameters
        mock_client.chat.completions.create.assert_called_once_with(
            model="test-deployment",
            messages=messages,
            temperature=0.7,
            max_tokens=200
        )
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_get_completion_error(self, mock_azure_openai):
        """Test get_completion method with error."""
        # Set up mock to raise error
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API error")
        mock_azure_openai.return_value = mock_client
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        messages = [{"role": "user", "content": "Hello."}]
        
        with self.assertRaises(OpenAIError) as context:
            provider.get_completion(messages)
        
        self.assertIn("Error al obtener completado", str(context.exception))
        self.assertIn("API error", str(context.exception))
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAIProvider.get_completion')
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAIProvider._get_system_prompt')
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_json_response(self, mock_azure_openai, mock_get_system_prompt, mock_get_completion):
        """Test analyze_cv method with JSON response."""
        # Set up mocks
        mock_get_system_prompt.return_value = "You are an assistant."
        
        mock_message = MagicMock()
        type(mock_message).content = PropertyMock(return_value='{"match": 0.8, "skills": ["Python"]}')
        
        mock_choice = MagicMock()
        type(mock_choice).message = PropertyMock(return_value=mock_message)
        
        mock_completion = MagicMock()
        mock_completion.choices = [mock_choice]
        
        mock_get_completion.return_value = mock_completion
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        result = provider.analyze_cv(cv_content, criteria)
        
        # Verify result
        self.assertEqual(result, {"match": 0.8, "skills": ["Python"]})
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAIProvider.get_completion')
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAIProvider._get_system_prompt')
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_text_response(self, mock_azure_openai, mock_get_system_prompt, mock_get_completion):
        """Test analyze_cv method with text response."""
        # Set up mocks
        mock_get_system_prompt.return_value = "You are an assistant."
        
        mock_message = MagicMock()
        type(mock_message).content = PropertyMock(return_value='This is not JSON')
        
        mock_choice = MagicMock()
        type(mock_choice).message = PropertyMock(return_value=mock_message)
        
        mock_completion = MagicMock()
        mock_completion.choices = [mock_choice]
        
        mock_get_completion.return_value = mock_completion
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        result = provider.analyze_cv(cv_content, criteria)
        
        # Verify result
        self.assertEqual(result, {"raw_response": "This is not JSON"})
    
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAIProvider.get_completion')
    @patch('cv_screening_sdk.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_error(self, mock_azure_openai, mock_get_completion):
        """Test analyze_cv method with error."""
        # Set up mock to raise error
        mock_get_completion.side_effect = Exception("Completion error")
        
        # Create provider
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key"
        )
        
        # Test
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        with self.assertRaises(OpenAIError) as context:
            provider.analyze_cv(cv_content, criteria)
        
        self.assertIn("Error al analizar CV", str(context.exception))
        self.assertIn("Completion error", str(context.exception))


if __name__ == "__main__":
    unittest.main() 