"""
Tests para la autenticación con Azure.

Este módulo contiene pruebas para verificar el correcto funcionamiento
de las credenciales de Azure y la verificación de conexiones.
"""

import unittest
from unittest.mock import Mock, patch

from cv_screening_sdk_light.auth.azure import AzureCredentials, AzureAuthProvider
from cv_screening_sdk_light.core.exceptions import AuthenticationError


class TestAzureCredentials(unittest.TestCase):
    """Pruebas para AzureCredentials."""

    def test_init_with_all_params(self):
        """Verificar que los parámetros se asignan correctamente."""
        credentials = AzureCredentials(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=False
        )
        
        self.assertEqual(credentials.tenant_id, "test-tenant")
        self.assertEqual(credentials.client_id, "test-client")
        self.assertEqual(credentials.client_secret, "test-secret")
        self.assertEqual(credentials.connection_verify, False)
    
    def test_init_defaults(self):
        """Verificar que los valores predeterminados son correctos."""
        credentials = AzureCredentials()
        
        self.assertIsNone(credentials.tenant_id)
        self.assertIsNone(credentials.client_id)
        self.assertIsNone(credentials.client_secret)
        self.assertTrue(credentials.connection_verify)
    
    @patch("cv_screening_sdk_light.auth.azure.ClientSecretCredential")
    def test_get_credential_with_service_principal(self, mock_client_secret_credential):
        """Verificar que se crea correctamente el ClientSecretCredential."""
        # Configurar el mock
        mock_instance = Mock()
        mock_client_secret_credential.return_value = mock_instance
        
        # Crear credenciales
        credentials = AzureCredentials(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=False
        )
        
        # Obtener credencial
        result = credentials.get_credential()
        
        # Verificar que se llamó a ClientSecretCredential con los parámetros correctos
        mock_client_secret_credential.assert_called_once_with(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=False
        )
        
        # Verificar que el resultado es el mock
        self.assertEqual(result, mock_instance)
    
    @patch("cv_screening_sdk_light.auth.azure.DefaultAzureCredential")
    def test_get_credential_with_default(self, mock_default_credential):
        """Verificar que se usa DefaultAzureCredential si no hay service principal."""
        # Configurar el mock
        mock_instance = Mock()
        mock_default_credential.return_value = mock_instance
        
        # Crear credenciales sin service principal
        credentials = AzureCredentials()
        
        # Obtener credencial
        result = credentials.get_credential()
        
        # Verificar que se llamó a DefaultAzureCredential
        mock_default_credential.assert_called_once()
        
        # Verificar que el resultado es el mock
        self.assertEqual(result, mock_instance)
    
    @patch("cv_screening_sdk_light.auth.azure.ClientSecretCredential")
    def test_get_credential_exception(self, mock_client_secret_credential):
        """Verificar que se maneja correctamente una excepción al crear credenciales."""
        # Configurar el mock para lanzar una excepción
        mock_client_secret_credential.side_effect = Exception("Test error")
        
        # Crear credenciales
        credentials = AzureCredentials(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret"
        )
        
        # Verificar que se lanza AuthenticationError
        with self.assertRaises(AuthenticationError):
            credentials.get_credential()


class TestAzureAuthProvider(unittest.TestCase):
    """Pruebas para AzureAuthProvider."""
    
    def test_init_with_all_params(self):
        """Verificar que los parámetros se asignan correctamente."""
        provider = AzureAuthProvider(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=False
        )
        
        # Verificar que se creó correctamente el AzureCredentials
        self.assertEqual(provider._credentials.tenant_id, "test-tenant")
        self.assertEqual(provider._credentials.client_id, "test-client")
        self.assertEqual(provider._credentials.client_secret, "test-secret")
        self.assertEqual(provider._credentials.connection_verify, False)
        
        # Verificar que se configuró el scope correcto
        self.assertEqual(provider._scopes, ["https://cognitiveservices.azure.com/.default"])
        
        # Verificar que se creó un logger
        self.assertIsNotNone(provider.logger)
    
    @patch("cv_screening_sdk_light.auth.azure.AzureCredentials.get_credential")
    def test_get_credentials(self, mock_get_credential):
        """Verificar que get_credentials() llama a get_credential() de AzureCredentials."""
        # Configurar el mock
        mock_credential = Mock()
        mock_get_credential.return_value = mock_credential
        
        # Crear provider
        provider = AzureAuthProvider()
        
        # Llamar a get_credentials()
        result = provider.get_credentials()
        
        # Verificar que se llamó a get_credential() de AzureCredentials
        mock_get_credential.assert_called_once()
        
        # Verificar que el resultado es el mock
        self.assertEqual(result, mock_credential)
    
    @patch("cv_screening_sdk_light.auth.azure.AzureCredentials.get_credential")
    def test_get_credentials_exception(self, mock_get_credential):
        """Verificar que se maneja correctamente una excepción en get_credentials()."""
        # Configurar el mock para lanzar una excepción
        mock_get_credential.side_effect = Exception("Test error")
        
        # Crear provider
        provider = AzureAuthProvider()
        
        # Verificar que se lanza AuthenticationError
        with self.assertRaises(AuthenticationError):
            provider.get_credentials()
    
    @patch("cv_screening_sdk_light.auth.azure.AzureCredentials.get_credential")
    def test_get_token(self, mock_get_credential):
        """Verificar que get_token() obtiene un token correctamente."""
        # Configurar el mock
        mock_credential = Mock()
        mock_token = Mock()
        mock_token.token = "test-token"
        mock_credential.get_token.return_value = mock_token
        mock_get_credential.return_value = mock_credential
        
        # Crear provider
        provider = AzureAuthProvider()
        
        # Llamar a get_token()
        result = provider.get_token()
        
        # Verificar que se llamó a get_credential() de AzureCredentials
        mock_get_credential.assert_called_once()
        
        # Verificar que se llamó a get_token() del credential
        mock_credential.get_token.assert_called_once_with("https://cognitiveservices.azure.com/.default")
        
        # Verificar que el resultado es el token esperado
        self.assertEqual(result, "test-token")
    
    @patch("cv_screening_sdk_light.auth.azure.AzureCredentials.get_credential")
    def test_get_credential_method(self, mock_get_credential):
        """Verificar que get_credential() llama a get_credential() de AzureCredentials."""
        # Configurar el mock
        mock_credential = Mock()
        mock_get_credential.return_value = mock_credential
        
        # Crear provider
        provider = AzureAuthProvider()
        
        # Llamar a get_credential()
        result = provider.get_credential()
        
        # Verificar que se llamó a get_credential() de AzureCredentials
        mock_get_credential.assert_called_once()
        
        # Verificar que el resultado es el mock
        self.assertEqual(result, mock_credential)


if __name__ == "__main__":
    unittest.main() 