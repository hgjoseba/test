"""
Tests para el proveedor de Azure OpenAI.

Este módulo contiene pruebas para verificar el correcto funcionamiento
del proveedor de Azure OpenAI, incluyendo connection_verify y monkey patching.
"""

import unittest
from unittest.mock import Mock, patch

import httpx

from cv_screening_sdk_light.providers.azure_provider import AzureOpenAIProvider
from cv_screening_sdk_light.core.exceptions import OpenAIError, AuthenticationError


class TestAzureOpenAIProvider(unittest.TestCase):
    """Pruebas para AzureOpenAIProvider."""

    def setUp(self):
        """Configuración común para las pruebas."""
        self.endpoint = "https://test.openai.azure.com/"
        self.api_key = "test-api-key"
        self.deployment_name = "test-deployment"
        self.tenant_id = "test-tenant"
        self.client_id = "test-client"
        self.client_secret = "test-secret"
    
    def test_init_with_api_key(self):
        """Verificar inicialización con API key."""
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            api_key=self.api_key,
            deployment_name=self.deployment_name,
            connection_verify=True
        )
        
        self.assertEqual(provider.endpoint, self.endpoint)
        self.assertEqual(provider.api_key, self.api_key)
        self.assertEqual(provider.deployment_name, self.deployment_name)
        self.assertTrue(provider.connection_verify)
        self.assertIsNone(provider.auth_provider)
        self.assertIsNone(provider.client)
    
    def test_init_with_credentials(self):
        """Verificar inicialización con credenciales."""
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            tenant_id=self.tenant_id,
            client_id=self.client_id,
            client_secret=self.client_secret,
            connection_verify=False
        )
        
        self.assertEqual(provider.endpoint, self.endpoint)
        self.assertIsNone(provider.api_key)
        self.assertFalse(provider.connection_verify)
        self.assertIsNotNone(provider.auth_provider)
        self.assertEqual(provider.auth_provider._credentials.tenant_id, self.tenant_id)
        self.assertEqual(provider.auth_provider._credentials.client_id, self.client_id)
        self.assertEqual(provider.auth_provider._credentials.client_secret, self.client_secret)
        self.assertEqual(provider.auth_provider._credentials.connection_verify, False)
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAIProvider._apply_http_monkey_patch")
    def test_init_with_connection_verify_false(self, mock_apply_monkey_patch):
        """Verificar que se aplica el monkey patch cuando connection_verify es False."""
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            api_key=self.api_key,
            connection_verify=False
        )
        
        # Verificar que se llamó a _apply_http_monkey_patch
        mock_apply_monkey_patch.assert_called_once()
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAIProvider._apply_http_monkey_patch")
    def test_init_with_connection_verify_true(self, mock_apply_monkey_patch):
        """Verificar que no se aplica el monkey patch cuando connection_verify es True."""
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            api_key=self.api_key,
            connection_verify=True
        )
        
        # Verificar que no se llamó a _apply_http_monkey_patch
        mock_apply_monkey_patch.assert_not_called()
    
    @patch("cv_screening_sdk_light.providers.azure_provider.httpx.Client.__init__")
    def test_monkey_patch_applies_correctly(self, mock_client_init):
        """Verificar que el monkey patch aplica verify=False a httpx.Client."""
        # Guardar la función original
        original_init = httpx.Client.__init__
        
        try:
            # Crear proveedor con connection_verify=False
            provider = AzureOpenAIProvider(
                endpoint=self.endpoint,
                api_key=self.api_key,
                connection_verify=False
            )
            
            # Crear un cliente httpx
            client = httpx.Client(timeout=10)
            
            # Verificar que se llamó a init con verify=False
            # Obtenemos todos los kwargs del último call
            call_kwargs = mock_client_init.call_args[1]
            self.assertIn("verify", call_kwargs)
            self.assertFalse(call_kwargs["verify"])
            
        finally:
            # Restaurar la función original
            httpx.Client.__init__ = original_init
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAI")
    def test_get_client_with_api_key(self, mock_azure_openai):
        """Verificar que _get_client crea el cliente con API key."""
        # Configurar el mock
        mock_client = Mock()
        mock_azure_openai.return_value = mock_client
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            api_key=self.api_key,
            api_version="2023-05-15"
        )
        
        # Llamar a _get_client
        result = provider._get_client()
        
        # Verificar que se llamó a AzureOpenAI con los parámetros correctos
        mock_azure_openai.assert_called_once_with(
            azure_endpoint=self.endpoint,
            api_version="2023-05-15",
            api_key=self.api_key
        )
        
        # Verificar que el resultado es el mock
        self.assertEqual(result, mock_client)
        
        # Verificar que el cliente se guardó en el provider
        self.assertEqual(provider.client, mock_client)
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAI")
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureAuthProvider.get_token")
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureAuthProvider.get_credential")
    def test_get_client_with_credentials(self, mock_get_credential, mock_get_token, mock_azure_openai):
        """Verificar que _get_client crea el cliente con credenciales."""
        # Configurar mocks
        mock_client = Mock()
        mock_azure_openai.return_value = mock_client
        mock_credential = Mock()
        mock_get_credential.return_value = mock_credential
        mock_get_token.return_value = "test-token"
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            tenant_id=self.tenant_id,
            client_id=self.client_id,
            client_secret=self.client_secret,
            api_version="2023-05-15"
        )
        
        # Llamar a _get_client
        result = provider._get_client()
        
        # Verificar que se llamó a get_credential y get_token
        mock_get_credential.assert_called_once()
        mock_get_token.assert_called_once()
        
        # Verificar que se llamó a AzureOpenAI con los parámetros correctos
        mock_azure_openai.assert_called_once_with(
            azure_endpoint=self.endpoint,
            api_version="2023-05-15",
            azure_ad_token="test-token"
        )
        
        # Verificar que el resultado es el mock
        self.assertEqual(result, mock_client)
        
        # Verificar que el cliente se guardó en el provider
        self.assertEqual(provider.client, mock_client)
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAI")
    def test_get_client_error_no_auth(self, mock_azure_openai):
        """Verificar error cuando no hay API key ni credenciales."""
        # Crear proveedor sin API key ni credenciales
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint
        )
        
        # Verificar que se lanza OpenAIError
        with self.assertRaises(OpenAIError):
            provider._get_client()
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAI")
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureAuthProvider.get_token")
    def test_get_client_auth_error(self, mock_get_token, mock_azure_openai):
        """Verificar error cuando falla la autenticación."""
        # Configurar mock para lanzar AuthenticationError
        mock_get_token.side_effect = AuthenticationError("Test error")
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            tenant_id=self.tenant_id,
            client_id=self.client_id,
            client_secret=self.client_secret
        )
        
        # Verificar que se lanza OpenAIError
        with self.assertRaises(OpenAIError) as context:
            provider._get_client()
        
        # Verificar el mensaje de error
        self.assertIn("Authentication error", str(context.exception))
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAIProvider._get_client")
    def test_get_completion(self, mock_get_client):
        """Verificar que get_completion funciona correctamente."""
        # Configurar mocks
        mock_client = Mock()
        mock_completion = Mock()
        mock_client.chat.completions.create.return_value = mock_completion
        mock_get_client.return_value = mock_client
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            api_key=self.api_key,
            deployment_name="gpt-4",
            temperature=0.5,
            max_tokens=100
        )
        
        # Llamar a get_completion
        messages = [{"role": "user", "content": "Hello"}]
        result = provider.get_completion(messages)
        
        # Verificar que se llamó a _get_client
        mock_get_client.assert_called_once()
        
        # Verificar que se llamó a chat.completions.create con los parámetros correctos
        mock_client.chat.completions.create.assert_called_once_with(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello"}],
            temperature=0.5,
            max_tokens=100
        )
        
        # Verificar que el resultado es el mock de completion
        self.assertEqual(result, mock_completion)
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAIProvider.get_completion")
    def test_analyze_cv(self, mock_get_completion):
        """Verificar que analyze_cv funciona correctamente."""
        # Configurar mocks
        mock_completion = Mock()
        mock_completion.choices = [Mock()]
        mock_completion.choices[0].message = Mock()
        mock_completion.choices[0].message.content = '{"result": "success"}'
        mock_get_completion.return_value = mock_completion
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            api_key=self.api_key
        )
        
        # Llamar a analyze_cv
        cv_content = "Test CV content"
        criteria = {"required_skills": ["Python"]}
        result = provider.analyze_cv(cv_content, criteria)
        
        # Verificar que se llamó a get_completion con los mensajes correctos
        mock_get_completion.assert_called_once()
        call_args = mock_get_completion.call_args[0][0]
        self.assertEqual(len(call_args), 2)
        self.assertEqual(call_args[0]["role"], "system")
        self.assertEqual(call_args[1]["role"], "user")
        self.assertIn("Test CV content", call_args[1]["content"])
        self.assertIn("Python", call_args[1]["content"])
        
        # Verificar que el resultado es el JSON parseado
        self.assertEqual(result, {"result": "success"})
    
    @patch("cv_screening_sdk_light.providers.azure_provider.AzureOpenAIProvider.get_completion")
    def test_analyze_cv_invalid_json(self, mock_get_completion):
        """Verificar que analyze_cv maneja correctamente JSON inválido."""
        # Configurar mocks para devolver texto no-JSON
        mock_completion = Mock()
        mock_completion.choices = [Mock()]
        mock_completion.choices[0].message = Mock()
        mock_completion.choices[0].message.content = "This is not JSON"
        mock_get_completion.return_value = mock_completion
        
        # Crear proveedor
        provider = AzureOpenAIProvider(
            endpoint=self.endpoint,
            api_key=self.api_key
        )
        
        # Llamar a analyze_cv
        cv_content = "Test CV content"
        criteria = {"required_skills": ["Python"]}
        result = provider.analyze_cv(cv_content, criteria)
        
        # Verificar que el resultado contiene el texto en raw_response
        self.assertEqual(result, {"raw_response": "This is not JSON"})


if __name__ == "__main__":
    unittest.main() 