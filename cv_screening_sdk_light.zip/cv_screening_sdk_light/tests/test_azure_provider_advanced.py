import unittest
import json
from unittest.mock import patch, MagicMock, PropertyMock, call

from src.providers.azure_provider import AzureOpenAIProvider
from src.core.exceptions import OpenAIError


class TestAzureOpenAIProviderAdvanced(unittest.TestCase):
    """Pruebas avanzadas para la clase AzureOpenAIProvider para mejorar la cobertura."""
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_format_response_with_secondary_model_success(self, mock_azure_openai):
        """Probar format_response_with_secondary_model con respuesta exitosa."""
        # Configurar mocks
        mock_client = MagicMock()
        mock_completion = MagicMock()
        mock_message = MagicMock()
        mock_message.content = '{"score": 85, "summary": "Good match"}'
        mock_completion.choices = [MagicMock(message=mock_message)]
        mock_client.chat.completions.create.return_value = mock_completion
        mock_azure_openai.return_value = mock_client
        
        # Crear provider con secondary_client
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key",
            secondary_endpoint="https://secondary.com",
            secondary_api_key="secondary-key"
        )
        
        # Establecer el secundary_client
        provider.secondary_client = mock_client
        
        # Crear un esquema de ejemplo
        schema = {
            "type": "object",
            "properties": {
                "score": {"type": "number"},
                "summary": {"type": "string"}
            }
        }
        
        # Probar el método
        result = provider.format_response_with_secondary_model(
            "Raw response text that needs formatting",
            schema
        )
        
        # Verificar la llamada
        mock_client.chat.completions.create.assert_called_once()
        call_args = mock_client.chat.completions.create.call_args[1]
        self.assertEqual(call_args["model"], provider.SECONDARY_PROCESSING_MODEL)
        self.assertEqual(len(call_args["messages"]), 2)  # System + User
        self.assertIn("response_format", call_args)
        self.assertEqual(call_args["response_format"]["type"], "json_object")
        
        # Verificar el resultado
        self.assertEqual(result, {"score": 85, "summary": "Good match"})
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_format_response_with_secondary_model_error(self, mock_azure_openai):
        """Probar format_response_with_secondary_model cuando ocurre un error."""
        # Configurar mock para simular error
        mock_client = MagicMock()
        mock_client.chat.completions.create.side_effect = Exception("API error")
        mock_azure_openai.return_value = mock_client
        
        # Crear provider con secondary_client
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key"
        )
        provider.secondary_client = mock_client
        
        # Esquema
        schema = {"type": "object"}
        
        # Probar el método
        with self.assertRaises(OpenAIError) as context:
            provider.format_response_with_secondary_model("Raw response", schema)
        
        # Verificar mensaje de error
        self.assertIn("Error formatting response with secondary model", str(context.exception))
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_format_response_with_secondary_model_invalid_json(self, mock_azure_openai):
        """Probar format_response_with_secondary_model con respuesta de JSON inválido."""
        # Configurar mocks
        mock_client = MagicMock()
        mock_completion = MagicMock()
        mock_message = MagicMock()
        mock_message.content = 'This is not valid JSON'
        mock_completion.choices = [MagicMock(message=mock_message)]
        mock_client.chat.completions.create.return_value = mock_completion
        mock_azure_openai.return_value = mock_client
        
        # Crear provider
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key"
        )
        provider.secondary_client = mock_client
        
        # Esquema
        schema = {"type": "object"}
        
        # Probar el método
        with self.assertRaises(OpenAIError) as context:
            provider.format_response_with_secondary_model("Raw response", schema)
        
        # Verificar mensaje de error
        self.assertIn("Error parsing JSON", str(context.exception))
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_process_cv_batch_empty_batch(self, mock_azure_openai):
        """Probar _process_cv_batch con un lote vacío."""
        # Configurar mock
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Crear provider
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key"
        )
        
        # Probar con lote vacío
        result = provider._process_cv_batch([], {}, 0)
        
        # Verificar resultado
        self.assertEqual(result, [])
        mock_client.chat.completions.create.assert_not_called()
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider.get_completion')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_process_cv_batch_max_tokens_adjustment(self, mock_azure_openai, mock_get_completion):
        """Probar _process_cv_batch con ajuste de max_tokens."""
        # Configurar mocks
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Configurar mock_get_completion para devolver un diccionario simulado
        mock_completion = MagicMock()
        mock_message = MagicMock()
        mock_message.content = json.dumps([{"cv_index": 0, "match": 0.8}])
        mock_completion.choices = [MagicMock(message=mock_message)]
        mock_get_completion.return_value = mock_completion
        
        # Crear provider con max_tokens
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key",
            max_tokens=1000
        )
        
        # Contenido grande para provocar reducción
        large_content = "A" * 10000
        
        # Probar con un lote con contenido grande
        result = provider._process_cv_batch([large_content], {}, 0)
        
        # Verificar que se llamó con max_tokens reducido
        call_args = mock_get_completion.call_args[1]
        self.assertLess(call_args["max_tokens"], 1000)
    
    @patch('src.providers.azure_provider.json.loads')
    @patch('src.providers.azure_provider.AzureOpenAIProvider.get_completion')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_process_cv_batch_json_parse_error(self, mock_azure_openai, mock_get_completion, mock_json_loads):
        """Probar _process_cv_batch cuando hay un error al analizar JSON."""
        # Configurar mocks
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Configurar mock para get_completion
        mock_completion = MagicMock()
        mock_message = MagicMock()
        mock_message.content = "Not valid JSON"
        mock_completion.choices = [MagicMock(message=mock_message)]
        mock_get_completion.return_value = mock_completion
        
        # Configurar mock_json_loads para simular error
        mock_json_loads.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
        
        # Crear provider
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key"
        )
        
        # Probar con un lote simple
        with self.assertRaises(OpenAIError) as context:
            provider._process_cv_batch(["CV content"], {}, 0)
        
        # Verificar mensaje de error
        self.assertIn("Error parsing JSON", str(context.exception))
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider.format_response_with_secondary_model')
    @patch('src.providers.azure_provider.AzureOpenAIProvider.get_completion')
    @patch('src.providers.azure_provider.AzureOpenAIProvider._is_model_schema_capable')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_cv_with_schema_non_capable_model(self, mock_azure_openai, mock_is_capable, 
                                                    mock_get_completion, mock_format_response):
        """Probar analyze_cv con schema en un modelo que no es capaz."""
        # Configurar mocks
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Configurar mock para indicar que el modelo no soporta schemas
        mock_is_capable.return_value = False
        
        # Configurar mock para get_completion
        mock_completion = MagicMock()
        mock_message = MagicMock()
        mock_message.content = "Raw response"
        mock_completion.choices = [MagicMock(message=mock_message)]
        mock_get_completion.return_value = mock_completion
        
        # Configurar mock para format_response_with_secondary_model
        mock_format_response.return_value = {"score": 85}
        
        # Crear provider
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key"
        )
        
        # Probar con un schema personalizado
        schema = {"type": "object", "properties": {"score": {"type": "number"}}}
        result = provider.analyze_cv("CV content", {}, schema_json_ob=schema)
        
        # Verificar que se usó el modelo secundario para formatear
        mock_format_response.assert_called_once_with("Raw response", schema)
        self.assertEqual(result, {"score": 85})
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_empty_cv_list(self, mock_azure_openai):
        """Probar analyze_multiple_cvs con una lista vacía de CVs."""
        # Configurar mock
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Crear provider
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key"
        )
        
        # Probar con lista vacía
        result = provider.analyze_multiple_cvs([], {})
        
        # Verificar resultado
        self.assertEqual(result, [])
    
    @patch('src.providers.azure_provider.AzureOpenAIProvider._process_cv_batch')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_analyze_multiple_cvs_with_retry_on_batch_error(self, mock_azure_openai, mock_process_batch):
        """Probar analyze_multiple_cvs cuando un batch falla y se reintenta con tamaño menor."""
        # Configurar mocks
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Configurar mock para _process_cv_batch que falla en el primer intento
        # pero tiene éxito al procesar lotes más pequeños
        def side_effect(*args, **kwargs):
            contents = args[0]
            if len(contents) > 1:
                raise OpenAIError("Batch too large")
            return [{"cv_index": 0, "match": 0.8}]
        
        mock_process_batch.side_effect = side_effect
        
        # Crear provider
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key"
        )
        
        # Probar con un lote que inicialmente fallará
        contents = ["CV1", "CV2"]
        result = provider.analyze_multiple_cvs(contents, {}, batch_size=2)
        
        # Verificar llamadas y resultado
        self.assertEqual(mock_process_batch.call_count, 3)  # 1 intento original + 2 reintentos individuales
        self.assertEqual(len(result), 2)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_infer_base_model_unknown_deployment(self, mock_azure_openai):
        """Probar _infer_base_model con un nombre de deployment desconocido."""
        # Configurar mock
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Crear provider
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key",
            deployment_name="unknown-model"
        )
        
        # Llamar directamente al método
        result = provider._infer_base_model("unknown-model")
        
        # Verificar resultado
        self.assertIsNone(result)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_is_model_schema_capable_with_no_base_model(self, mock_azure_openai):
        """Probar _is_model_schema_capable cuando no hay base_model."""
        # Configurar mock
        mock_client = MagicMock()
        mock_azure_openai.return_value = mock_client
        
        # Crear provider sin base_model
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key",
            deployment_name="unknown-model"
        )
        provider.base_model = None
        
        # Llamar al método
        result = provider._is_model_schema_capable()
        
        # Verificar resultado (debería ser False por defecto)
        self.assertFalse(result)
    
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_constructor_secondary_client_setup(self, mock_azure_openai):
        """Probar la configuración del secondary_client en el constructor."""
        # Configurar mocks
        mock_client1 = MagicMock()
        mock_client2 = MagicMock()
        mock_azure_openai.side_effect = [mock_client1, mock_client2]
        
        # Crear provider con endpoints y api keys diferentes
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key",
            secondary_endpoint="https://secondary.com",
            secondary_api_key="secondary-key"
        )
        
        # Verificar que se crearon dos clientes diferentes
        self.assertEqual(mock_azure_openai.call_count, 2)
        self.assertEqual(provider.client, mock_client1)
        self.assertEqual(provider.secondary_client, mock_client2)
        
        # Verificar los parámetros en la segunda llamada
        second_call_args = mock_azure_openai.call_args_list[1][1]
        self.assertEqual(second_call_args["azure_endpoint"], "https://secondary.com")
        self.assertEqual(second_call_args["api_key"], "secondary-key")
    
    @patch('src.providers.azure_provider.httpx')
    @patch('src.providers.azure_provider.AzureOpenAI')
    def test_constructor_with_verify_false_and_typed_error(self, mock_azure_openai, mock_httpx):
        """Probar constructor cuando hay un TypeError y connection_verify=False."""
        # Primera vez lanzo error, segunda vez éxito
        mock_client = MagicMock()
        mock_azure_openai.side_effect = [
            TypeError("unexpected keyword argument 'proxies'"),
            mock_client
        ]
        
        # Mock para httpx.Client
        mock_http_client = MagicMock()
        mock_httpx.Client.return_value = mock_http_client
        
        # Crear provider con connection_verify=False
        provider = AzureOpenAIProvider(
            endpoint="https://endpoint.com",
            api_key="api-key",
            connection_verify=False
        )
        
        # Verificar que se creó httpx.Client con verify=False
        mock_httpx.Client.assert_called_once_with(verify=True)  # True porque verify=not False en el código
        
        # Verificar que se reintentó con el cliente http
        self.assertEqual(mock_azure_openai.call_count, 2)
        second_call_args = mock_azure_openai.call_args_list[1][1]
        self.assertEqual(second_call_args["http_client"], mock_http_client) 