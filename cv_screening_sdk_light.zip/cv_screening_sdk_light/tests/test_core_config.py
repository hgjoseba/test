import os
import unittest
from unittest.mock import patch

from src.core.config import Config, AzureConfig, OpenAIConfig


class TestConfig(unittest.TestCase):
    """Tests for the Config classes."""
    
    def test_azure_config_defaults(self):
        """Test AzureConfig default values."""
        config = AzureConfig()
        self.assertEqual(config.endpoint, "")
        self.assertEqual(config.api_version, "2023-05-15")
    
    def test_azure_config_custom_values(self):
        """Test AzureConfig with custom values."""
        config = AzureConfig(endpoint="https://example.azure.com", api_version="2023-08-01")
        self.assertEqual(config.endpoint, "https://example.azure.com")
        self.assertEqual(config.api_version, "2023-08-01")
    
    def test_openai_config_defaults(self):
        """Test OpenAIConfig default values."""
        config = OpenAIConfig()
        self.assertEqual(config.api_key, "")
        self.assertEqual(config.model_name, "gpt-4")
        self.assertEqual(config.temperature, 0.1)
        self.assertEqual(config.max_tokens, None)
        self.assertEqual(config.connection_verify, True)
        self.assertEqual(config.system_prompt, None)
        self.assertEqual(config.http_proxy, None)
        self.assertEqual(config.https_proxy, None)
    
    def test_openai_config_custom_values(self):
        """Test OpenAIConfig with custom values."""
        config = OpenAIConfig(
            api_key="test-key",
            model_name="gpt-3.5-turbo",
            temperature=0.7,
            max_tokens=1000,
            connection_verify=False,
            system_prompt="Test prompt",
            http_proxy="http://proxy:8080",
            https_proxy="https://proxy:8443"
        )
        
        self.assertEqual(config.api_key, "test-key")
        self.assertEqual(config.model_name, "gpt-3.5-turbo")
        self.assertEqual(config.temperature, 0.7)
        self.assertEqual(config.max_tokens, 1000)
        self.assertEqual(config.connection_verify, False)
        self.assertEqual(config.system_prompt, "Test prompt")
        self.assertEqual(config.http_proxy, "http://proxy:8080")
        self.assertEqual(config.https_proxy, "https://proxy:8443")
    
    @patch.dict(os.environ, {
        "AZURE_OPENAI_API_KEY": "env-api-key",
        "AZURE_OPENAI_DEPLOYMENT": "env-model",
        "OPENAI_TEMPERATURE": "0.5",
        "OPENAI_MAX_TOKENS": "500",
        "OPENAI_CONNECTION_VERIFY": "false",
        "OPENAI_SYSTEM_PROMPT": "env-prompt",
        "OPENAI_HTTP_PROXY": "env-http-proxy",
        "OPENAI_HTTPS_PROXY": "env-https-proxy",
        "AZURE_OPENAI_ENDPOINT": "env-endpoint",
        "AZURE_OPENAI_API_VERSION": "env-api-version",
    })
    def test_config_from_environment(self):
        """Test Config constructor using environment variables."""
        config = Config()
        
        # Test OpenAI config from env
        self.assertEqual(config.openai.api_key, "env-api-key")
        self.assertEqual(config.openai.model_name, "env-model")
        self.assertEqual(config.openai.temperature, 0.5)
        self.assertEqual(config.openai.max_tokens, 500)
        self.assertEqual(config.openai.connection_verify, False)
        self.assertEqual(config.openai.system_prompt, "env-prompt")
        self.assertEqual(config.openai.http_proxy, "env-http-proxy")
        self.assertEqual(config.openai.https_proxy, "env-https-proxy")
        
        # Test Azure config from env
        self.assertEqual(config.azure.endpoint, "env-endpoint")
        self.assertEqual(config.azure.api_version, "env-api-version")
    
    @patch.dict(os.environ, {
        "OPENAI_MAX_TOKENS": "0",  # Test the "or None" behavior
        "OPENAI_CONNECTION_VERIFY": "TRUE",  # Test case insensitivity
    })
    def test_config_edge_cases(self):
        """Test Config constructor with edge cases."""
        config = Config()
        
        # Check that max_tokens is None when env var is "0"
        self.assertIsNone(config.openai.max_tokens)
        
        # Check that connection_verify is True when env var is "TRUE"
        self.assertTrue(config.openai.connection_verify)
    
    def test_config_custom_values(self):
        """Test Config with custom values."""
        openai_config = OpenAIConfig(api_key="custom-key", model_name="custom-model")
        azure_config = AzureConfig(endpoint="custom-endpoint")
        
        config = Config(openai=openai_config, azure=azure_config)
        
        self.assertEqual(config.openai.api_key, "custom-key")
        self.assertEqual(config.openai.model_name, "custom-model")
        self.assertEqual(config.azure.endpoint, "custom-endpoint")
        self.assertEqual(config.azure.api_version, "2023-05-15")  # Default value


if __name__ == "__main__":
    unittest.main() 