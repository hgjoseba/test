import unittest
import logging
from unittest.mock import patch, MagicMock

from cv_screening_sdk.auth.azure import AzureCredentials, AzureAuthProvider
from cv_screening_sdk.core.exceptions import AuthenticationError


class TestAzureCredentials(unittest.TestCase):
    """Tests for AzureCredentials class."""
    
    @patch('cv_screening_sdk.auth.azure.ClientSecretCredential')
    def test_get_credential_service_principal(self, mock_client_secret):
        """Test get_credential with service principal credentials."""
        # Setup mock
        mock_credential = MagicMock()
        mock_client_secret.return_value = mock_credential
        
        # Create credentials
        credentials = AzureCredentials(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=True
        )
        
        # Test
        result = credentials.get_credential()
        
        # Verify
        mock_client_secret.assert_called_once_with(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=True
        )
        self.assertEqual(result, mock_credential)
    
    @patch('cv_screening_sdk.auth.azure.DefaultAzureCredential')
    def test_get_credential_default(self, mock_default_credential):
        """Test get_credential with default credentials."""
        # Setup mock
        mock_credential = MagicMock()
        mock_default_credential.return_value = mock_credential
        
        # Create credentials without tenant, client_id, and secret
        credentials = AzureCredentials()
        
        # Test
        result = credentials.get_credential()
        
        # Verify
        mock_default_credential.assert_called_once()
        self.assertEqual(result, mock_credential)
    
    @patch('cv_screening_sdk.auth.azure.ClientSecretCredential')
    def test_get_credential_error(self, mock_client_secret):
        """Test get_credential with error."""
        # Setup mock to raise error
        mock_client_secret.side_effect = Exception("Test error")
        
        # Create credentials
        credentials = AzureCredentials(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret"
        )
        
        # Test
        with self.assertRaises(AuthenticationError) as context:
            credentials.get_credential()
        
        # Verify error message
        self.assertIn("Failed to create Azure credentials", str(context.exception))
        self.assertIn("Test error", str(context.exception))


class TestAzureAuthProvider(unittest.TestCase):
    """Tests for AzureAuthProvider class."""
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_init(self, mock_credentials_class):
        """Test initialization with default values."""
        # Setup mock
        mock_credentials = MagicMock()
        mock_credentials_class.return_value = mock_credentials
        
        # Create provider
        provider = AzureAuthProvider()
        
        # Verify
        mock_credentials_class.assert_called_once_with(
            tenant_id=None,
            client_id=None,
            client_secret=None,
            connection_verify=True
        )
        self.assertEqual(provider._credentials, mock_credentials)
        self.assertEqual(provider._scopes, ["https://cognitiveservices.azure.com/.default"])
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_init_with_custom_values(self, mock_credentials_class):
        """Test initialization with custom values."""
        # Setup mock
        mock_credentials = MagicMock()
        mock_credentials_class.return_value = mock_credentials
        
        # Create logger mock
        mock_logger = MagicMock()
        
        # Create provider
        provider = AzureAuthProvider(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=False,
            logger=mock_logger
        )
        
        # Verify
        mock_credentials_class.assert_called_once_with(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=False
        )
        self.assertEqual(provider._credentials, mock_credentials)
        self.assertEqual(provider.logger, mock_logger)
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_init_error(self, mock_credentials_class):
        """Test initialization with error."""
        # Setup mock to raise error
        mock_credentials_class.side_effect = Exception("Test error")
        
        # Test
        with self.assertRaises(AuthenticationError) as context:
            AzureAuthProvider()
        
        # Verify error message
        self.assertIn("Failed to initialize Azure auth provider", str(context.exception))
        self.assertIn("Test error", str(context.exception))
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_get_credentials(self, mock_credentials_class):
        """Test get_credentials method."""
        # Setup mock
        mock_credential = MagicMock()
        mock_credentials = MagicMock()
        mock_credentials.get_credential.return_value = mock_credential
        mock_credentials_class.return_value = mock_credentials
        
        # Create provider
        provider = AzureAuthProvider()
        
        # Test
        result = provider.get_credentials()
        
        # Verify
        mock_credentials.get_credential.assert_called_once()
        self.assertEqual(result, mock_credential)
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_get_credentials_error(self, mock_credentials_class):
        """Test get_credentials method with error."""
        # Setup mock to raise error
        mock_credentials = MagicMock()
        mock_credentials.get_credential.side_effect = Exception("Test error")
        mock_credentials_class.return_value = mock_credentials
        
        # Create provider
        provider = AzureAuthProvider()
        
        # Test
        with self.assertRaises(AuthenticationError) as context:
            provider.get_credentials()
        
        # Verify error message
        self.assertIn("Failed to get Azure credentials", str(context.exception))
        self.assertIn("Test error", str(context.exception))
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_get_token(self, mock_credentials_class):
        """Test get_token method."""
        # Setup mocks
        mock_token = MagicMock()
        type(mock_token).token = "test-token"
        
        mock_credential = MagicMock()
        mock_credential.get_token.return_value = mock_token
        
        mock_credentials = MagicMock()
        mock_credentials.get_credential.return_value = mock_credential
        
        mock_credentials_class.return_value = mock_credentials
        
        # Create provider
        provider = AzureAuthProvider()
        
        # Test
        result = provider.get_token()
        
        # Verify
        mock_credentials.get_credential.assert_called_once()
        mock_credential.get_token.assert_called_once_with("https://cognitiveservices.azure.com/.default")
        self.assertEqual(result, "test-token")
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_get_token_auth_error(self, mock_credentials_class):
        """Test get_token method with authentication error."""
        from azure.core.exceptions import ClientAuthenticationError
        
        # Setup mocks
        mock_credential = MagicMock()
        mock_credential.get_token.side_effect = ClientAuthenticationError("Auth error")
        
        mock_credentials = MagicMock()
        mock_credentials.get_credential.return_value = mock_credential
        
        mock_credentials_class.return_value = mock_credentials
        
        # Create provider
        provider = AzureAuthProvider()
        
        # Test
        with self.assertRaises(AuthenticationError) as context:
            provider.get_token()
        
        # Verify error message
        self.assertIn("Failed to get authentication token", str(context.exception))
        self.assertIn("Auth error", str(context.exception))
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_get_credential(self, mock_credentials_class):
        """Test get_credential method."""
        # Setup mocks
        mock_token_credential = MagicMock()
        
        mock_credentials = MagicMock()
        mock_credentials.get_credential.return_value = mock_token_credential
        
        mock_credentials_class.return_value = mock_credentials
        
        # Create provider
        provider = AzureAuthProvider()
        
        # Test
        result = provider.get_credential()
        
        # Verify
        mock_credentials.get_credential.assert_called_once()
        self.assertEqual(result, mock_token_credential)
    
    @patch('cv_screening_sdk.auth.azure.AzureCredentials')
    def test_get_credential_error(self, mock_credentials_class):
        """Test get_credential method with error."""
        # Setup mocks
        mock_credentials = MagicMock()
        mock_credentials.get_credential.side_effect = Exception("Credential error")
        
        mock_credentials_class.return_value = mock_credentials
        
        # Create provider
        provider = AzureAuthProvider()
        
        # Test
        with self.assertRaises(AuthenticationError) as context:
            provider.get_credential()
        
        # Verify error message
        self.assertIn("Failed to get credential", str(context.exception))
        self.assertIn("Credential error", str(context.exception))


if __name__ == "__main__":
    unittest.main() 