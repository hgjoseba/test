"""
Tests for CV Screening SDK Light.

This package contains unit and integration tests for the SDK.
"""

# Common imports used in tests
import unittest
import logging
import json
from unittest.mock import patch, MagicMock, PropertyMock

# SDK core components
from src.auth.azure import AzureCredentials, AzureAuthProvider
from src.core.exceptions import AuthenticationError, OpenAIError
from src.client import CVScreeningClient
from src.core.config import Config
from src.core.types import ContentType
from src.utils.document import load_cv_content, load_cv_from_base64, is_base64

# Provider-related imports
from src.providers.azure_provider import AzureOpenAIProvider
from src.providers.azure_prompt_manager import AzurePromptManager
from src.providers.azure_response_handler import AzureResponseHandler

# Model-related imports
from src.models.criteria import JobCriteria

# Azure SDK related imports
from azure.core.credentials import TokenCredential
from azure.core.exceptions import ClientAuthenticationError
from azure.identity import ClientSecretCredential, DefaultAzureCredential

# Makes these classes easily accessible from test modules
__all__ = [
    # Core SDK components
    "AzureCredentials", 
    "AzureAuthProvider", 
    "AuthenticationError",
    "OpenAIError",
    "CVScreeningClient",
    "Config",
    "ContentType",
    "load_cv_content",
    "load_cv_from_base64",
    "is_base64",
    
    # Provider-related classes
    "AzureOpenAIProvider",
    "AzurePromptManager",
    "AzureResponseHandler",
    
    # Model-related classes
    "JobCriteria",
    
    # Azure SDK components
    "TokenCredential",
    "ClientAuthenticationError",
    "ClientSecretCredential",
    "DefaultAzureCredential",
    
    # Python standard library and testing utilities
    "unittest",
    "logging",
    "json",
    "patch",
    "MagicMock",
    "PropertyMock"
]

# Enables proper module imports 