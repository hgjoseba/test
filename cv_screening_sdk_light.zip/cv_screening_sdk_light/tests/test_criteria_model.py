import unittest

from cv_screening_sdk.models.criteria import JobCriteria


class TestJobCriteria(unittest.TestCase):
    """Tests for JobCriteria model."""
    
    def test_default_values(self):
        """Test that default values are correctly set."""
        criteria = JobCriteria()
        
        self.assertEqual(criteria.required_skills, [])
        self.assertEqual(criteria.preferred_skills, [])
        self.assertIsNone(criteria.min_years_experience)
        self.assertIsNone(criteria.education_level)
        self.assertIsNone(criteria.job_title)
        self.assertIsNone(criteria.job_description)
    
    def test_init_with_values(self):
        """Test initialization with values."""
        criteria = JobCriteria(
            required_skills=["Python", "SQL"],
            preferred_skills=["Docker", "Kubernetes"],
            min_years_experience=3,
            education_level="bachelor's",
            job_title="Data Engineer",
            job_description="Building data pipelines"
        )
        
        self.assertEqual(criteria.required_skills, ["Python", "SQL"])
        self.assertEqual(criteria.preferred_skills, ["Docker", "Kubernetes"])
        self.assertEqual(criteria.min_years_experience, 3)
        self.assertEqual(criteria.education_level, "bachelor's")
        self.assertEqual(criteria.job_title, "Data Engineer")
        self.assertEqual(criteria.job_description, "Building data pipelines")
    
    def test_to_dict_all_fields(self):
        """Test to_dict method with all fields."""
        criteria = JobCriteria(
            required_skills=["Python", "SQL"],
            preferred_skills=["Docker", "Kubernetes"],
            min_years_experience=3,
            education_level="bachelor's",
            job_title="Data Engineer",
            job_description="Building data pipelines"
        )
        
        result = criteria.to_dict()
        
        self.assertEqual(result, {
            "required_skills": ["Python", "SQL"],
            "preferred_skills": ["Docker", "Kubernetes"],
            "min_years_experience": 3,
            "education_level": "bachelor's",
            "job_title": "Data Engineer",
            "job_description": "Building data pipelines"
        })
    
    def test_to_dict_some_fields(self):
        """Test to_dict method with some fields."""
        criteria = JobCriteria(
            required_skills=["Python", "SQL"],
            preferred_skills=["Docker"]
        )
        
        result = criteria.to_dict()
        
        self.assertEqual(result, {
            "required_skills": ["Python", "SQL"],
            "preferred_skills": ["Docker"]
        })
    
    def test_to_dict_exclude_none(self):
        """Test that to_dict method excludes None values."""
        criteria = JobCriteria(
            required_skills=["Python"],
            min_years_experience=None,  # Should be excluded
            job_title="Developer"
        )
        
        result = criteria.to_dict()
        
        self.assertEqual(result, {
            "required_skills": ["Python"],
            "preferred_skills": [],
            "job_title": "Developer"
        })
        self.assertNotIn("min_years_experience", result)
        self.assertNotIn("education_level", result)
        self.assertNotIn("job_description", result)
    
    def test_model_validation(self):
        """Test model validation for list fields."""
        # Test with non-list for required_skills
        with self.assertRaises(ValueError):
            JobCriteria(required_skills="Python")  # Should be a list
        
        # Test with non-list for preferred_skills
        with self.assertRaises(ValueError):
            JobCriteria(preferred_skills="SQL")  # Should be a list
        
        # Test with non-integer for min_years_experience
        with self.assertRaises(ValueError):
            JobCriteria(min_years_experience="three")  # Should be an integer


if __name__ == "__main__":
    unittest.main() 