import unittest

from src.core.types import ContentType


class TestContentType(unittest.TestCase):
    """Tests for ContentType enum."""
    
    def test_enum_values(self):
        """Test that enum values exist."""
        self.assertTrue(hasattr(ContentType, "TEXT"))
        self.assertTrue(hasattr(ContentType, "BASE64"))
        self.assertTrue(hasattr(ContentType, "FILE_PATH"))
    
    def test_from_string_valid(self):
        """Test from_string method with valid inputs."""
        self.assertEqual(ContentType.from_string("text"), ContentType.TEXT)
        self.assertEqual(ContentType.from_string("TEXT"), ContentType.TEXT)
        self.assertEqual(ContentType.from_string("base64"), ContentType.BASE64)
        self.assertEqual(ContentType.from_string("BASE64"), ContentType.BASE64)
        self.assertEqual(ContentType.from_string("file"), ContentType.FILE_PATH)
        self.assertEqual(ContentType.from_string("FILE"), ContentType.FILE_PATH)
        self.assertEqual(ContentType.from_string("file_path"), ContentType.FILE_PATH)
        self.assertEqual(ContentType.from_string("FILE_PATH"), ContentType.FILE_PATH)
    
    def test_from_string_invalid(self):
        """Test from_string method with invalid inputs."""
        with self.assertRaises(ValueError) as context:
            ContentType.from_string("invalid_type")
        
        # Check error message contains valid types
        error_message = str(context.exception)
        self.assertIn("Invalid content type", error_message)
        self.assertIn("text", error_message)
        self.assertIn("base64", error_message)
        self.assertIn("file", error_message)
        self.assertIn("file_path", error_message)
    
    def test_enum_uniqueness(self):
        """Test that enum values are unique."""
        self.assertNotEqual(ContentType.TEXT, ContentType.BASE64)
        self.assertNotEqual(ContentType.TEXT, ContentType.FILE_PATH)
        self.assertNotEqual(ContentType.BASE64, ContentType.FILE_PATH)


if __name__ == "__main__":
    unittest.main() 