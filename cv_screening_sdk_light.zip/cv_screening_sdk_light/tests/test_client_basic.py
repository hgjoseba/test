import unittest
import io
import base64
from unittest.mock import patch, MagicMock

from cv_screening_sdk.client import CVScreeningClient
from cv_screening_sdk.core.exceptions import ConfigurationError, OpenAIError
from cv_screening_sdk.core.types import ContentType
from cv_screening_sdk.models.criteria import JobCriteria


class TestCVScreeningClient(unittest.TestCase):
    """Test basic functionality of the CVScreeningClient class."""

    @patch('cv_screening_sdk.client.AzureOpenAIProvider')
    def setUp(self, mock_provider_class):
        """Set up test environment."""
        self.mock_provider = MagicMock()
        mock_provider_class.return_value = self.mock_provider
        
        # Mock environment variables for testing
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.com'
        }):
            self.client = CVScreeningClient()
    
    def test_init_with_default_values(self):
        """Test client initialization with default values."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.com'
        }):
            client = CVScreeningClient()
            
            # Check that the config has been set correctly
            self.assertEqual(client.config.openai.api_key, 'test-api-key')
            self.assertEqual(client.config.azure.endpoint, 'https://test-endpoint.com')
            self.assertEqual(client.config.openai.model_name, 'gpt-4')
            self.assertEqual(client.config.openai.temperature, 0.1)
    
    def test_init_with_custom_values(self):
        """Test client initialization with custom values."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'env-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://env-endpoint.com'
        }):
            client = CVScreeningClient(
                api_key='custom-api-key',
                endpoint='https://custom-endpoint.com',
                model_name='gpt-3.5-turbo',
                temperature=0.7,
                max_tokens=1000,
                connection_verify=False,
                system_prompt='Custom prompt'
            )
            
            # Check that the config has been set correctly with custom values
            self.assertEqual(client.config.openai.api_key, 'custom-api-key')
            self.assertEqual(client.config.azure.endpoint, 'https://custom-endpoint.com')
            self.assertEqual(client.config.openai.model_name, 'gpt-3.5-turbo')
            self.assertEqual(client.config.openai.temperature, 0.7)
            self.assertEqual(client.config.openai.max_tokens, 1000)
            self.assertEqual(client.config.openai.connection_verify, False)
            self.assertEqual(client.config.openai.system_prompt, 'Custom prompt')
    
    def test_init_missing_api_key(self):
        """Test initialization with missing API key."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': '',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.com'
        }):
            with self.assertRaises(ConfigurationError) as context:
                CVScreeningClient()
            
            self.assertIn('API key is required', str(context.exception))
    
    def test_init_missing_endpoint(self):
        """Test initialization with missing endpoint."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': ''
        }):
            with self.assertRaises(ConfigurationError) as context:
                CVScreeningClient()
            
            self.assertIn('endpoint is required', str(context.exception))
    
    def test_process_criteria_none(self):
        """Test _process_criteria with None."""
        result = self.client._process_criteria(None)
        self.assertEqual(result, {})
    
    def test_process_criteria_job_criteria(self):
        """Test _process_criteria with JobCriteria object."""
        criteria = JobCriteria(
            required_skills=["Python", "SQL"],
            preferred_skills=["Docker"],
            min_years_experience=3
        )
        
        result = self.client._process_criteria(criteria)
        
        self.assertEqual(result, {
            "required_skills": ["Python", "SQL"],
            "preferred_skills": ["Docker"],
            "min_years_experience": 3
        })
    
    def test_process_criteria_string(self):
        """Test _process_criteria with string."""
        criteria = "Looking for a Python developer"
        
        result = self.client._process_criteria(criteria)
        
        self.assertEqual(result, {"prompt": "Looking for a Python developer"})
    
    def test_process_criteria_dict(self):
        """Test _process_criteria with dictionary."""
        criteria = {"skills": ["Python"], "experience": 3}
        
        result = self.client._process_criteria(criteria)
        
        self.assertEqual(result, {"skills": ["Python"], "experience": 3})
    
    def test_process_criteria_invalid_type(self):
        """Test _process_criteria with invalid type."""
        with self.assertRaises(TypeError) as context:
            self.client._process_criteria(123)
        
        self.assertIn('Unsupported criteria type', str(context.exception))
    
    def test_analyze_cv_text(self):
        """Test analyze_cv with text content."""
        # Setup mock
        self.mock_provider.analyze_cv.return_value = {"match": 0.8}
        
        # Test
        result = self.client.analyze_cv(
            "This is a CV content",
            {"required_skills": ["Python"]},
            ContentType.TEXT
        )
        
        # Verify
        self.mock_provider.analyze_cv.assert_called_once_with(
            "This is a CV content",
            {"required_skills": ["Python"]}
        )
        self.assertEqual(result, {"match": 0.8})
    
    def test_analyze_cv_base64(self):
        """Test analyze_cv with base64 content."""
        # Create base64 content
        cv_text = "This is a CV content"
        cv_base64 = base64.b64encode(cv_text.encode('utf-8')).decode('utf-8')
        
        # Setup mock
        self.mock_provider.analyze_cv.return_value = {"match": 0.9}
        
        # Test
        result = self.client.analyze_cv(
            cv_base64,
            {"required_skills": ["Python"]},
            ContentType.BASE64
        )
        
        # Verify
        self.mock_provider.analyze_cv.assert_called_once_with(
            cv_text,
            {"required_skills": ["Python"]}
        )
        self.assertEqual(result, {"match": 0.9})
    
    @patch('cv_screening_sdk.client.load_cv_content')
    def test_analyze_cv_file_path(self, mock_load_cv_content):
        """Test analyze_cv with file path."""
        # Setup mock
        mock_load_cv_content.return_value = "CV content from file"
        self.mock_provider.analyze_cv.return_value = {"match": 0.7}
        
        # Test
        result = self.client.analyze_cv(
            "path/to/cv.pdf",
            {"required_skills": ["Python"]},
            ContentType.FILE_PATH
        )
        
        # Verify
        mock_load_cv_content.assert_called_once_with("path/to/cv.pdf")
        self.mock_provider.analyze_cv.assert_called_once_with(
            "CV content from file",
            {"required_skills": ["Python"]}
        )
        self.assertEqual(result, {"match": 0.7})
    
    def test_analyze_cv_bytes(self):
        """Test analyze_cv with bytes content."""
        # Setup
        cv_bytes = b"This is a CV content"
        self.mock_provider.analyze_cv.return_value = {"match": 0.75}
        
        # Test
        result = self.client.analyze_cv(
            cv_bytes,
            {"required_skills": ["Python"]},
            ContentType.TEXT
        )
        
        # Verify
        self.mock_provider.analyze_cv.assert_called_once_with(
            "This is a CV content",
            {"required_skills": ["Python"]}
        )
        self.assertEqual(result, {"match": 0.75})
    
    def test_analyze_cv_provider_error(self):
        """Test analyze_cv when provider raises an error."""
        # Setup
        self.mock_provider.analyze_cv.side_effect = Exception("Provider error")
        
        # Test
        with self.assertRaises(OpenAIError) as context:
            self.client.analyze_cv(
                "This is a CV content",
                {"required_skills": ["Python"]},
                ContentType.TEXT
            )
        
        # Verify
        self.assertIn("Failed to analyze CV", str(context.exception))
        self.assertIn("Provider error", str(context.exception))
    
    @patch('cv_screening_sdk.client.load_cv_content')
    def test_load_cv_content_file_path(self, mock_load_cv_content):
        """Test load_cv_content with file path."""
        # Setup
        mock_load_cv_content.return_value = "CV content from file"
        
        # Test
        result = CVScreeningClient.load_cv_content(
            "path/to/cv.pdf",
            ContentType.FILE_PATH
        )
        
        # Verify
        mock_load_cv_content.assert_called_once_with("path/to/cv.pdf")
        self.assertEqual(result, "CV content from file")
    
    @patch('cv_screening_sdk.client.load_cv_from_base64')
    def test_load_cv_content_base64(self, mock_load_cv_from_base64):
        """Test load_cv_content with base64."""
        # Setup
        mock_load_cv_from_base64.return_value = "Decoded CV content"
        
        # Test
        result = CVScreeningClient.load_cv_content(
            "base64content",
            ContentType.BASE64
        )
        
        # Verify
        mock_load_cv_from_base64.assert_called_once_with("base64content")
        self.assertEqual(result, "Decoded CV content")
    
    def test_load_cv_content_text_string(self):
        """Test load_cv_content with text string."""
        # Test
        result = CVScreeningClient.load_cv_content(
            "This is a CV content",
            ContentType.TEXT
        )
        
        # Verify
        self.assertEqual(result, "This is a CV content")
    
    def test_load_cv_content_text_bytes(self):
        """Test load_cv_content with text bytes."""
        # Test
        result = CVScreeningClient.load_cv_content(
            b"This is a CV content",
            ContentType.TEXT
        )
        
        # Verify
        self.assertEqual(result, "This is a CV content")


if __name__ == "__main__":
    unittest.main() 