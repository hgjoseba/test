import unittest

from cv_screening_sdk.core.exceptions import (
    SDKError,
    ConfigurationError,
    OpenAIError,
    DocumentParsingError,
    ValidationError,
    AuthenticationError
)


class TestExceptions(unittest.TestCase):
    """Tests for exceptions module."""
    
    def test_sdk_error(self):
        """Test SDKError exception."""
        error = SDKError("Test error message")
        self.assertEqual(str(error), "Test error message")
        self.assertIsInstance(error, Exception)
    
    def test_configuration_error(self):
        """Test ConfigurationError exception."""
        error = ConfigurationError("Configuration error message")
        self.assertEqual(str(error), "Configuration error message")
        self.assertIsInstance(error, SDKError)
        self.assertIsInstance(error, Exception)
    
    def test_openai_error(self):
        """Test OpenAIError exception."""
        error = OpenAIError("OpenAI error message")
        self.assertEqual(str(error), "OpenAI error message")
        self.assertIsInstance(error, SDKError)
        self.assertIsInstance(error, Exception)
    
    def test_document_parsing_error(self):
        """Test DocumentParsingError exception."""
        error = DocumentParsingError("Document parsing error message")
        self.assertEqual(str(error), "Document parsing error message")
        self.assertIsInstance(error, SDKError)
        self.assertIsInstance(error, Exception)
    
    def test_validation_error(self):
        """Test ValidationError exception."""
        error = ValidationError("Validation error message")
        self.assertEqual(str(error), "Validation error message")
        self.assertIsInstance(error, SDKError)
        self.assertIsInstance(error, Exception)
    
    def test_authentication_error(self):
        """Test AuthenticationError exception."""
        error = AuthenticationError("Authentication error message")
        self.assertEqual(str(error), "Authentication error message")
        self.assertIsInstance(error, SDKError)
        self.assertIsInstance(error, Exception)
    
    def test_exception_hierarchy(self):
        """Test exception hierarchy."""
        # All custom exceptions should inherit from SDKError
        self.assertTrue(issubclass(ConfigurationError, SDKError))
        self.assertTrue(issubclass(OpenAIError, SDKError))
        self.assertTrue(issubclass(DocumentParsingError, SDKError))
        self.assertTrue(issubclass(ValidationError, SDKError))
        self.assertTrue(issubclass(AuthenticationError, SDKError))
        
        # And SDKError should inherit from Exception
        self.assertTrue(issubclass(SDKError, Exception))


if __name__ == "__main__":
    unittest.main() 