import os
import base64
import unittest
import sys
from unittest.mock import patch, mock_open, MagicMock

from src.utils.document import (
    load_cv_content,
    load_cv_from_base64,
    is_base64,
    _check_pdf_dependency,
    _check_docx_dependency
)
from src.core.exceptions import DocumentParsingError


class TestDocumentUtils(unittest.TestCase):
    """Tests for document utilities."""
    
    def setUp(self):
        """Reset dependency check status before each test."""
        # Access private module variables to reset for testing
        from src.utils import document
        document._DEPENDENCIES_CHECKED = {
            "pdf": False,
            "docx": False
        }
        document._HAS_PDF_DEPENDENCY = False
        document._HAS_DOCX_DEPENDENCY = False
    
    @patch('os.path.exists')
    def test_load_cv_content_file_not_found(self, mock_exists):
        """Test load_cv_content with non-existent file."""
        mock_exists.return_value = False
        
        with self.assertRaises(FileNotFoundError):
            load_cv_content("nonexistent_file.txt")
    
    @patch('os.path.exists')
    @patch('src.utils.document._safe_open')
    def test_load_cv_content_txt(self, mock_safe_open, mock_exists):
        """Test load_cv_content with a text file."""
        mock_exists.return_value = True
        mock_file = MagicMock()
        mock_file.read.return_value = "CV content text"
        mock_context = MagicMock()
        mock_context.__enter__.return_value = mock_file
        mock_safe_open.return_value = mock_context
        
        result = load_cv_content("test_cv.txt")
        
        mock_safe_open.assert_called_once_with("test_cv.txt", 'r', encoding='utf-8')
        self.assertEqual(result, "CV content text")
    
    @patch('os.path.exists')
    @patch('src.utils.document._safe_open')
    def test_load_cv_content_txt_with_error(self, mock_safe_open, mock_exists):
        """Test load_cv_content with a text file that raises an error."""
        mock_exists.return_value = True
        mock_safe_open.side_effect = Exception("Mock file error")
        
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_content("test_cv.txt")
        
        self.assertIn("Failed to read text file", str(context.exception))
        self.assertIn("Mock file error", str(context.exception))
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    def test_load_cv_content_unsupported_format(self, mock_splitext, mock_exists):
        """Test load_cv_content with an unsupported file format."""
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".unsupported")
        
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_content("test_cv.unsupported")
        
        self.assertIn("Unsupported file format", str(context.exception))
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    @patch('src.utils.document._check_pdf_dependency')
    def test_load_cv_content_pdf_missing_dependency(self, mock_check_dependency, mock_splitext, mock_exists):
        """Test load_cv_content with a PDF file when pypdf is not installed."""
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".pdf")
        mock_check_dependency.return_value = False
        
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_content("test_cv.pdf")
        
        self.assertIn("PDF parsing requires pypdf", str(context.exception))
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    @patch('src.utils.document._check_pdf_dependency')
    def test_load_cv_content_pdf(self, mock_check_dependency, mock_splitext, mock_exists):
        """Test load_cv_content with a PDF file."""
        # Skip this test if pypdf is not installed
        try:
            import pypdf
        except ImportError:
            self.skipTest("pypdf is not installed")
            
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".pdf")
        mock_check_dependency.return_value = True
        
        # Create mock for pypdf
        mock_page1 = MagicMock()
        mock_page1.extract_text.return_value = "Page 1 content"
        mock_page2 = MagicMock()
        mock_page2.extract_text.return_value = "Page 2 content"
        
        mock_reader = MagicMock()
        mock_reader.pages = [mock_page1, mock_page2]
        
        with patch('pypdf.PdfReader', return_value=mock_reader):
            with patch('src.utils.document._safe_open', mock_open()):
                result = load_cv_content("test_cv.pdf")
                
        self.assertEqual(result, "Page 1 content\nPage 2 content")
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    @patch('src.utils.document._check_pdf_dependency')
    def test_load_cv_content_pdf_empty_pages(self, mock_check_dependency, mock_splitext, mock_exists):
        """Test load_cv_content with a PDF file that has empty pages."""
        # Skip this test if pypdf is not installed
        try:
            import pypdf
        except ImportError:
            self.skipTest("pypdf is not installed")
            
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".pdf")
        mock_check_dependency.return_value = True
        
        # Create mock for pypdf with empty pages
        mock_page1 = MagicMock()
        mock_page1.extract_text.return_value = ""  # Empty page
        mock_page2 = MagicMock()
        mock_page2.extract_text.return_value = "Page 2 content"
        mock_page3 = MagicMock()
        mock_page3.extract_text.return_value = None  # None content
        
        mock_reader = MagicMock()
        mock_reader.pages = [mock_page1, mock_page2, mock_page3]
        
        with patch('pypdf.PdfReader', return_value=mock_reader):
            with patch('src.utils.document._safe_open', mock_open()):
                result = load_cv_content("test_cv.pdf")
                
        # Only Page 2 should be included
        self.assertEqual(result, "Page 2 content")
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    @patch('src.utils.document._check_docx_dependency')
    def test_load_cv_content_docx_missing_dependency(self, mock_check_dependency, mock_splitext, mock_exists):
        """Test load_cv_content with a DOCX file when python-docx is not installed."""
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".docx")
        mock_check_dependency.return_value = False
        
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_content("test_cv.docx")
        
        self.assertIn("DOCX parsing requires python-docx", str(context.exception))
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    @patch('src.utils.document._check_docx_dependency')
    def test_load_cv_content_docx(self, mock_check_dependency, mock_splitext, mock_exists):
        """Test load_cv_content with a DOCX file."""
        # Skip this test if docx is not installed
        try:
            import docx
        except ImportError:
            self.skipTest("python-docx is not installed")
            
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".docx")
        mock_check_dependency.return_value = True
        
        # Mock paragraphs
        mock_para1 = MagicMock()
        mock_para1.text = "Paragraph 1"
        mock_para2 = MagicMock()
        mock_para2.text = "Paragraph 2"
        mock_para3 = MagicMock()
        mock_para3.text = "  "  # Empty paragraph that should be skipped
        
        # Mock table cells
        mock_cell_para = MagicMock()
        mock_cell_para.text = "Table cell content"
        mock_cell = MagicMock()
        mock_cell.paragraphs = [mock_cell_para]
        mock_row = MagicMock()
        mock_row.cells = [mock_cell]
        mock_table = MagicMock()
        mock_table.rows = [mock_row]
        
        # Mock document
        mock_doc = MagicMock()
        mock_doc.paragraphs = [mock_para1, mock_para2, mock_para3]
        mock_doc.tables = [mock_table]
        
        with patch('docx.Document', return_value=mock_doc):
            result = load_cv_content("test_cv.docx")
        
        expected_content = "Paragraph 1\nParagraph 2\nTable cell content"
        self.assertEqual(result, expected_content)
    
    def test_load_cv_from_base64_string(self):
        """Test load_cv_from_base64 with a base64 string."""
        # Create a base64 encoded string
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8')).decode('utf-8')
        
        result = load_cv_from_base64(encoded)
        
        self.assertEqual(result, original_text)
    
    def test_load_cv_from_base64_bytes(self):
        """Test load_cv_from_base64 with base64 bytes."""
        # Create base64 encoded bytes
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8'))
        
        result = load_cv_from_base64(encoded)
        
        self.assertEqual(result, original_text)
    
    def test_load_cv_from_base64_error(self):
        """Test load_cv_from_base64 with invalid base64."""
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_from_base64("invalid base64 !@#$")
        
        self.assertIn("Invalid base64 format", str(context.exception))
    
    def test_load_cv_from_base64_empty(self):
        """Test load_cv_from_base64 with empty input."""
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_from_base64("")
        
        self.assertIn("Empty base64 content provided", str(context.exception))
    
    def test_is_base64_valid_string(self):
        """Test is_base64 with valid base64 string."""
        # Create a base64 encoded string
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8')).decode('utf-8')
        
        result = is_base64(encoded)
        
        self.assertTrue(result)
    
    def test_is_base64_valid_bytes(self):
        """Test is_base64 with valid base64 bytes."""
        # Create base64 encoded bytes
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8'))
        
        result = is_base64(encoded)
        
        self.assertTrue(result)
    
    def test_is_base64_invalid(self):
        """Test is_base64 with invalid base64."""
        result = is_base64("invalid base64 !@#$")
        
        self.assertFalse(result)
    
    def test_is_base64_empty(self):
        """Test is_base64 with empty input."""
        self.assertFalse(is_base64(""))
        self.assertFalse(is_base64(b""))


if __name__ == "__main__":
    unittest.main() 