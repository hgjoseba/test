import os
import base64
import unittest
import sys
from unittest.mock import patch, mock_open, MagicMock

from cv_screening_sdk.utils.document import (
    load_cv_content,
    load_cv_from_base64,
    is_base64
)
from cv_screening_sdk.core.exceptions import DocumentParsingError


class TestDocumentUtils(unittest.TestCase):
    """Tests for document utilities."""
    
    @patch('os.path.exists')
    def test_load_cv_content_file_not_found(self, mock_exists):
        """Test load_cv_content with non-existent file."""
        mock_exists.return_value = False
        
        with self.assertRaises(FileNotFoundError):
            load_cv_content("nonexistent_file.txt")
    
    @patch('os.path.exists')
    @patch('builtins.open', new_callable=mock_open, read_data="CV content text")
    def test_load_cv_content_txt(self, mock_file, mock_exists):
        """Test load_cv_content with a text file."""
        mock_exists.return_value = True
        
        result = load_cv_content("test_cv.txt")
        
        mock_file.assert_called_once_with("test_cv.txt", 'r', encoding='utf-8')
        self.assertEqual(result, "CV content text")
    
    @patch('os.path.exists')
    @patch('builtins.open', new_callable=mock_open, read_data="CV content text")
    def test_load_cv_content_txt_with_error(self, mock_file, mock_exists):
        """Test load_cv_content with a text file that raises an error."""
        mock_exists.return_value = True
        mock_file.side_effect = Exception("Mock file error")
        
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_content("test_cv.txt")
        
        self.assertIn("Failed to read text file", str(context.exception))
        self.assertIn("Mock file error", str(context.exception))
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    def test_load_cv_content_unsupported_format(self, mock_splitext, mock_exists):
        """Test load_cv_content with an unsupported file format."""
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".unsupported")
        
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_content("test_cv.unsupported")
        
        self.assertIn("Unsupported file format", str(context.exception))
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    def test_load_cv_content_pdf(self, mock_splitext, mock_exists):
        """Test load_cv_content with a PDF file."""
        # Skip this test if PyPDF2 is not installed
        try:
            import PyPDF2
        except ImportError:
            self.skipTest("PyPDF2 is not installed")
            
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".pdf")
        
        # Create mock for PyPDF2
        mock_page1 = MagicMock()
        mock_page1.extract_text.return_value = "Page 1 content"
        mock_page2 = MagicMock()
        mock_page2.extract_text.return_value = "Page 2 content"
        
        mock_reader = MagicMock()
        mock_reader.pages = [mock_page1, mock_page2]
        
        with patch('PyPDF2.PdfReader', return_value=mock_reader):
            with patch('builtins.open', mock_open()):
                result = load_cv_content("test_cv.pdf")
                
        self.assertEqual(result, "Page 1 content\nPage 2 content")
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    def test_load_cv_content_pdf_import_error(self, mock_splitext, mock_exists):
        """Test load_cv_content with a PDF file when PyPDF2 is not installed."""
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".pdf")
        
        # Simulate ImportError
        with patch.dict('sys.modules', {'PyPDF2': None}):
            with patch('builtins.__import__', side_effect=ImportError()):
                with self.assertRaises(DocumentParsingError) as context:
                    load_cv_content("test_cv.pdf")
        
        self.assertIn("PDF parsing requires PyPDF2", str(context.exception))
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    def test_load_cv_content_docx(self, mock_splitext, mock_exists):
        """Test load_cv_content with a DOCX file."""
        # Skip this test if docx is not installed
        try:
            import docx
        except ImportError:
            self.skipTest("python-docx is not installed")
            
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".docx")
        
        # Mock paragraphs
        mock_para1 = MagicMock()
        mock_para1.text = "Paragraph 1"
        mock_para2 = MagicMock()
        mock_para2.text = "Paragraph 2"
        
        # Mock document
        mock_doc = MagicMock()
        mock_doc.paragraphs = [mock_para1, mock_para2]
        
        with patch('docx.Document', return_value=mock_doc):
            result = load_cv_content("test_cv.docx")
            
        self.assertEqual(result, "Paragraph 1\nParagraph 2")
    
    @patch('os.path.exists')
    @patch('os.path.splitext')
    def test_load_cv_content_docx_import_error(self, mock_splitext, mock_exists):
        """Test load_cv_content with a DOCX file when python-docx is not installed."""
        mock_exists.return_value = True
        mock_splitext.return_value = ("test_cv", ".docx")
        
        # Simulate ImportError
        with patch.dict('sys.modules', {'docx': None}):
            with patch('builtins.__import__', side_effect=ImportError()):
                with self.assertRaises(DocumentParsingError) as context:
                    load_cv_content("test_cv.docx")
        
        self.assertIn("DOCX parsing requires python-docx", str(context.exception))
    
    def test_load_cv_from_base64_string(self):
        """Test load_cv_from_base64 with a base64 string."""
        # Create a base64 encoded string
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8')).decode('utf-8')
        
        result = load_cv_from_base64(encoded)
        
        self.assertEqual(result, original_text)
    
    def test_load_cv_from_base64_bytes(self):
        """Test load_cv_from_base64 with base64 bytes."""
        # Create base64 encoded bytes
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8'))
        
        result = load_cv_from_base64(encoded)
        
        self.assertEqual(result, original_text)
    
    def test_load_cv_from_base64_error(self):
        """Test load_cv_from_base64 with invalid base64."""
        with self.assertRaises(DocumentParsingError) as context:
            load_cv_from_base64("invalid base64 !@#$")
        
        self.assertIn("Failed to decode base64 content", str(context.exception))
    
    def test_is_base64_valid_string(self):
        """Test is_base64 with valid base64 string."""
        # Create a base64 encoded string
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8')).decode('utf-8')
        
        result = is_base64(encoded)
        
        self.assertTrue(result)
    
    def test_is_base64_valid_bytes(self):
        """Test is_base64 with valid base64 bytes."""
        # Create base64 encoded bytes
        original_text = "This is a CV content"
        encoded = base64.b64encode(original_text.encode('utf-8'))
        
        result = is_base64(encoded)
        
        self.assertTrue(result)
    
    def test_is_base64_invalid(self):
        """Test is_base64 with invalid base64."""
        result = is_base64("invalid base64 !@#$")
        
        self.assertFalse(result)


if __name__ == "__main__":
    unittest.main() 