# Tests para CV Screening SDK

Este directorio contiene los tests unitarios para el SDK de CV Screening. El objetivo es mantener una cobertura de código de al menos el 80%.

## Estructura de los tests

Los archivos de test están organizados para corresponder con la estructura del SDK:

- `test_core_config.py` - Tests para la configuración
- `test_core_exceptions.py` - Tests para las excepciones
- `test_core_types.py` - Tests para los tipos de datos
- `test_document_utils.py` - Tests para las utilidades de documentos
- `test_criteria_model.py` - Tests para el modelo de criterios
- `test_cli.py` - Tests para la interfaz de línea de comandos
- `test_client.py` - Tests para el cliente principal
- `test_azure_provider.py` - Tests para el proveedor de Azure
- `test_azure_auth.py` - Tests para la autenticación de Azure

## Ejecutar los tests

Hay varias formas de ejecutar los tests:

### Usando el script de cobertura

La manera más sencilla es utilizar el script `run_tests.py` que se encuentra en la raíz del proyecto:

```bash
python run_tests.py
```

Este script ejecutará todos los tests y generará un informe de cobertura en la terminal y en formato HTML en el directorio `coverage_report/`.

### Usando pytest directamente

También puedes ejecutar los tests directamente con pytest:

```bash
# Ejecutar todos los tests
pytest tests/

# Ejecutar un archivo de test específico
pytest tests/test_core_config.py

# Ejecutar con cobertura
pytest --cov=cv_screening_sdk tests/
```

### Ejecutar tests individuales

Para ejecutar un test específico:

```bash
# Ejecutar una clase de test específica
pytest tests/test_core_config.py::TestConfig

# Ejecutar un método de test específico
pytest tests/test_core_config.py::TestConfig::test_azure_config_defaults
```

## Meta de cobertura

La meta de cobertura para este proyecto es de al menos el 80%. Esto significa que al menos el 80% de las líneas de código deben ser ejecutadas por los tests.

Para verificar la cobertura actual, ejecuta:

```bash
pytest --cov=cv_screening_sdk tests/
```

## Agregar nuevos tests

Al implementar nuevas funcionalidades en el SDK, asegúrate de agregar los tests correspondientes para mantener la cobertura por encima del 80%.

Sigue los patrones existentes en los archivos de test actuales para mantener la consistencia. 