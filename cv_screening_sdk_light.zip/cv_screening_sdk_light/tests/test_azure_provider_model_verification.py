"""
Tests for the model verification functionality in the Azure provider.
"""

import json
import unittest
from unittest.mock import patch, MagicMock

from src.providers.azure_provider import AzureOpenAIProvider


class TestAzureProviderModelVerification(unittest.TestCase):
    """
    Tests for the model verification and JSON formatting functionality.
    """

    def setUp(self):
        """Initial setup for the tests."""
        self.mock_response = MagicMock()
        self.mock_response.choices = [MagicMock()]
        self.mock_response.choices[0].message = MagicMock()
        
        # Simulated data
        self.cv_content = "Software Engineer with 5 years of experience in Python and Django."
        self.job_criteria = {"required_skills": ["Python", "Django"], "preferred_skills": ["Docker"]}

    @patch("src.providers.azure_provider.AzureOpenAI")
    def test_allowed_model_uses_response_format(self, mock_azure_openai):
        """Verifies that response_format is used for allowed models in a single call."""
        # Configure the mock
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = self.mock_response
        self.mock_response.choices[0].message.content = json.dumps({
            "overall_match": 85,
            "skills_match": {"required_skills": {"Python": 0.9, "Django": 0.8}}
        })
        mock_azure_openai.return_value = mock_client
        
        # Create the provider with an allowed model
        provider = AzureOpenAIProvider(
            endpoint="https://example.com",
            api_key="test-key",
            deployment_name="gpt-4",  # Allowed model
        )
        
        # Analyze CV
        result = provider.analyze_cv(self.cv_content, self.job_criteria)
        
        # Verify that the chat.completions.create call was made with response_format
        args, kwargs = mock_client.chat.completions.create.call_args
        self.assertIn('response_format', kwargs)
        self.assertEqual(kwargs['response_format'], {"type": "json_schema", "json_schema": {"name": "cvscreening", "strict": True, "schema": provider.DEFAULT_CV_SCHEMA}})
        
        # Verify that the result is as expected
        self.assertEqual(result["overall_match"], 85)

    @patch("src.providers.azure_provider.AzureOpenAI")
    def test_non_allowed_model_uses_two_step_processing(self, mock_azure_openai):
        """Verifies that non-allowed models use a two-step process."""
        # Configure the mock for two calls
        mock_client = MagicMock()
        
        # Create two different responses
        initial_response = MagicMock()
        initial_response.choices = [MagicMock()]
        initial_response.choices[0].message = MagicMock()
        initial_response.choices[0].message.content = "The candidate has good experience in Python and Django."
        
        formatted_response = MagicMock()
        formatted_response.choices = [MagicMock()]
        formatted_response.choices[0].message = MagicMock()
        formatted_response.choices[0].message.content = json.dumps({
            "overall_match": 85,
            "skills_match": {"required_skills": {"Python": 0.9, "Django": 0.8}}
        })
        
        # Return different responses for different calls
        mock_client.chat.completions.create.side_effect = [
            initial_response,    # First call (get_completion)
            formatted_response   # Second call (format_response_with_secondary_model)
        ]
        
        mock_azure_openai.return_value = mock_client
        
        # Create the provider with a NON-allowed model
        provider = AzureOpenAIProvider(
            endpoint="https://example.com",
            api_key="test-key",
            deployment_name="custom-model",  # NON-allowed model
        )
        
        # Analyze CV
        result = provider.analyze_cv(self.cv_content, self.job_criteria)
        
        # Verify that chat.completions.create was called twice
        self.assertEqual(mock_client.chat.completions.create.call_count, 2)
        
        # First call should be without response_format
        args, kwargs = mock_client.chat.completions.create.call_args_list[0]
        self.assertNotIn('response_format', kwargs)
        
        # Second call should be with response_format (secondary model)
        args, kwargs = mock_client.chat.completions.create.call_args_list[1]
        self.assertIn('response_format', kwargs)
        response_format = kwargs['response_format']
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertIn('json_schema', response_format)
        self.assertEqual(response_format['json_schema']['name'], 'cvscreening')
        self.assertTrue(response_format['json_schema']['strict'])
        
        # Verify that the result is as expected
        self.assertEqual(result["overall_match"], 85)

    @patch("src.providers.azure_provider.AzureOpenAI")
    def test_base_model_overrides_deployment_capabilities(self, mock_azure_openai):
        """Verifies that base_model overrides the deployment name for determining capabilities."""
        # Configure the mock for different scenarios
        mock_client = MagicMock()
        
        # Single response for direct approach
        direct_response = MagicMock()
        direct_response.choices = [MagicMock()]
        direct_response.choices[0].message = MagicMock()
        direct_response.choices[0].message.content = json.dumps({
            "overall_match": 90,
            "skills_match": {"required_skills": {"Python": 0.95, "Django": 0.85}}
        })
        
        # Two-step responses
        first_step = MagicMock()
        first_step.choices = [MagicMock()]
        first_step.choices[0].message = MagicMock()
        first_step.choices[0].message.content = "The candidate has excellent experience in Python and Django."
        
        second_step = MagicMock()
        second_step.choices = [MagicMock()]
        second_step.choices[0].message = MagicMock()
        second_step.choices[0].message.content = json.dumps({
            "overall_match": 90,
            "skills_match": {"required_skills": {"Python": 0.95, "Django": 0.85}}
        })
        
        # Set up for different test cases
        mock_client.chat.completions.create.return_value = direct_response
        mock_azure_openai.return_value = mock_client
        
        # CASE 1: Custom deployment name but with an allowed base_model
        # This should use the direct approach with response_format
        provider1 = AzureOpenAIProvider(
            endpoint="https://example.com",
            api_key="test-key",
            deployment_name="custom-deployment",  # Non-standard name
            base_model="gpt-4"  # But base model is allowed
        )
        
        # Reset the mock for clean testing
        mock_client.chat.completions.create.reset_mock()
        mock_client.chat.completions.create.return_value = direct_response
        
        # Test analyze_cv with this configuration
        result1 = provider1.analyze_cv(self.cv_content, self.job_criteria)
        
        # Should use direct approach (single call with response_format)
        self.assertEqual(mock_client.chat.completions.create.call_count, 1)
        args, kwargs = mock_client.chat.completions.create.call_args
        self.assertIn('response_format', kwargs)
        response_format = kwargs['response_format']
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertIn('json_schema', response_format)
        self.assertEqual(response_format['json_schema']['name'], 'cvscreening')
        self.assertTrue(response_format['json_schema']['strict'])
        self.assertEqual(result1["overall_match"], 90)
        
        # CASE 2: Allowed model name but with non-allowed base_model
        # This should use the two-step approach
        # Configure two-step responses
        mock_client.chat.completions.create.reset_mock()
        mock_client.chat.completions.create.side_effect = [first_step, second_step]
        
        provider2 = AzureOpenAIProvider(
            endpoint="https://example.com",
            api_key="test-key",
            deployment_name="gpt-4",  # Standard allowed name
            base_model="custom-model"  # But base model is not allowed
        )
        
        # Test analyze_cv
        result2 = provider2.analyze_cv(self.cv_content, self.job_criteria)
        
        # Should use two-step approach (two calls)
        self.assertEqual(mock_client.chat.completions.create.call_count, 2)
        
        # First call should be without response_format
        args, kwargs = mock_client.chat.completions.create.call_args_list[0]
        self.assertNotIn('response_format', kwargs)
        
        # Second call should be with response_format (secondary model)
        args, kwargs = mock_client.chat.completions.create.call_args_list[1]
        self.assertIn('response_format', kwargs)
        response_format = kwargs['response_format']
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertIn('json_schema', response_format)
        self.assertEqual(response_format['json_schema']['name'], 'cvscreening')
        self.assertTrue(response_format['json_schema']['strict'])
        
        # Verify the result
        self.assertEqual(result2["overall_match"], 90)

    @patch("src.providers.azure_provider.AzureOpenAI")
    def test_batch_processing_with_non_allowed_model(self, mock_azure_openai):
        """Verifies that batch processing also uses two-step process for non-allowed models."""
        # Configure mock for two calls
        mock_client = MagicMock()
        
        # Initial response (text)
        initial_response = MagicMock()
        initial_response.choices = [MagicMock()]
        initial_response.choices[0].message = MagicMock()
        initial_response.choices[0].message.content = """
        CV #1: Good candidate with Python experience
        CV #2: Limited experience, doesn't meet requirements
        """
        
        # Formatted response (JSON)
        formatted_response = MagicMock()
        formatted_response.choices = [MagicMock()]
        formatted_response.choices[0].message = MagicMock()
        formatted_response.choices[0].message.content = json.dumps([
            {
                "cv_index": 0,
                "overall_match": 85,
                "skills_match": {"required_skills": {"Python": 0.9, "Django": 0.8}}
            },
            {
                "cv_index": 1,
                "overall_match": 45,
                "skills_match": {"required_skills": {"Python": 0.4, "Django": 0.2}}
            }
        ])
        
        # Return different responses for different calls
        mock_client.chat.completions.create.side_effect = [
            initial_response,    # First call (get_completion)
            formatted_response   # Second call (format_response_with_secondary_model)
        ]
        
        mock_azure_openai.return_value = mock_client
        
        # Create the provider with a NON-allowed model
        provider = AzureOpenAIProvider(
            endpoint="https://example.com",
            api_key="test-key",
            deployment_name="custom-model",  # NON-allowed model
        )
        
        # List of CVs to process in batch
        cv_contents = [
            "Software Engineer with 5 years of experience in Python and Django.",
            "Recent graduate with basic programming knowledge."
        ]
        
        # Process the batch
        results = provider._process_cv_batch(cv_contents, self.job_criteria)
        
        # Verify that chat.completions.create was called twice
        self.assertEqual(mock_client.chat.completions.create.call_count, 2)
        
        # First call should be without response_format
        args, kwargs = mock_client.chat.completions.create.call_args_list[0]
        self.assertNotIn('response_format', kwargs)
        
        # Second call should be with response_format (secondary model)
        args, kwargs = mock_client.chat.completions.create.call_args_list[1]
        self.assertIn('response_format', kwargs)
        response_format = kwargs['response_format']
        self.assertEqual(response_format['type'], 'json_schema')
        self.assertIn('json_schema', response_format)
        self.assertEqual(response_format['json_schema']['name'], 'cvscreening')
        self.assertTrue(response_format['json_schema']['strict'])
        
        # Verify that there are results for both CVs
        self.assertEqual(len(results), 2)
        
        # Verify that the indices are correct
        self.assertEqual(results[0]["cv_index"], 0)
        self.assertEqual(results[1]["cv_index"], 1)
        
        # Verify the match scores
        self.assertEqual(results[0]["overall_match"], 85)
        self.assertEqual(results[1]["overall_match"], 45)


if __name__ == "__main__":
    unittest.main() 