"""
Tests for the AzureResponseHandler class.
"""
import unittest
import json
from unittest.mock import patch, MagicMock

from src.providers.azure_response_handler import AzureResponseHandler


class TestAzureResponseHandler(unittest.TestCase):
    """Tests for the AzureResponseHandler class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.handler = AzureResponseHandler()
    
    def test_init(self):
        """Test initialization."""
        self.assertIsNotNone(self.handler.logger)
    
    def test_process_single_response_valid_json(self):
        """Test process_single_response with valid JSON."""
        response_text = '{"overall_match": 80, "skills": ["Python", "SQL"]}'
        result = self.handler.process_single_response(response_text)
        
        expected = {
            "overall_match": 80,
            "skills": ["Python", "SQL"]
        }
        self.assertEqual(result, expected)
    
    def test_process_single_response_invalid_json(self):
        """Test process_single_response with invalid JSON."""
        response_text = "This is not JSON"
        result = self.handler.process_single_response(response_text)
        
        expected = {"raw_response": "This is not JSON"}
        self.assertEqual(result, expected)
    
    def test_process_batch_response_list(self):
        """Test process_batch_response with list response."""
        response_text = '''[
            {"cv_index": 0, "overall_match": 80},
            {"cv_index": 1, "overall_match": 60}
        ]'''
        result = self.handler.process_batch_response(response_text, start_index=0)
        
        expected = [
            {"cv_index": 0, "overall_match": 80},
            {"cv_index": 1, "overall_match": 60}
        ]
        self.assertEqual(result, expected)
    
    def test_process_batch_response_dict_with_results(self):
        """Test process_batch_response with dict containing results key."""
        response_text = '''{"results": [
            {"cv_index": 0, "overall_match": 80},
            {"cv_index": 1, "overall_match": 60}
        ]}'''
        result = self.handler.process_batch_response(response_text, start_index=0)
        
        expected = [
            {"cv_index": 0, "overall_match": 80},
            {"cv_index": 1, "overall_match": 60}
        ]
        self.assertEqual(result, expected)
    
    def test_process_batch_response_dict_without_results(self):
        """Test process_batch_response with dict without results key."""
        response_text = '''{"overall_match": 80, "skills": ["Python", "SQL"]}'''
        result = self.handler.process_batch_response(response_text, start_index=0)
        
        expected = [
            {"overall_match": 80, "skills": ["Python", "SQL"]}
        ]
        self.assertEqual(result, expected)
    
    def test_process_batch_response_invalid_json(self):
        """Test process_batch_response with invalid JSON."""
        response_text = "This is not JSON"
        result = self.handler.process_batch_response(response_text, start_index=0)
        
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["raw_response"], "This is not JSON")
        self.assertIn("error", result[0])
    
    def test_adjust_cv_indices(self):
        """Test _adjust_cv_indices."""
        results = [
            {"cv_index": 0, "overall_match": 80},
            {"cv_index": 1, "overall_match": 60},
            {"cv_index": 2, "overall_match": 90}
        ]
        
        # Test with start_index=0 (no change expected)
        start_index = 0
        original_results = results.copy()
        self.handler._adjust_cv_indices(results, start_index)
        self.assertEqual(results, original_results)
        
        # Test with start_index=10
        start_index = 10
        expected = [
            {"cv_index": 10, "overall_match": 80},
            {"cv_index": 11, "overall_match": 60},
            {"cv_index": 12, "overall_match": 90}
        ]
        results = original_results.copy()
        self.handler._adjust_cv_indices(results, start_index)
        self.assertEqual(results, expected)


if __name__ == "__main__":
    unittest.main() 