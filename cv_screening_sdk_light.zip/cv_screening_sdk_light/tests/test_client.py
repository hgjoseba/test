"""
Tests para el cliente principal.

Este módulo contiene pruebas para verificar el correcto funcionamiento
del cliente principal, incluyendo el parámetro connection_verify.
"""

import unittest
from unittest.mock import Mock, patch

from cv_screening_sdk_light.client import CVScreeningClient
from cv_screening_sdk_light.core.exceptions import ConfigurationError, OpenAIError


class TestCVScreeningClient(unittest.TestCase):
    """Pruebas para CVScreeningClient."""

    def test_init_with_api_key(self):
        """Verificar inicialización con API key y endpoint."""
        client = CVScreeningClient(
            api_key="test-api-key",
            endpoint="https://test-endpoint.openai.azure.com/",
            model_name="gpt-4",
            temperature=0.5,
            max_tokens=100,
            connection_verify=True
        )
        
        self.assertEqual(client.config.openai.api_key, "test-api-key")
        self.assertEqual(client.config.azure.endpoint, "https://test-endpoint.openai.azure.com/")
        self.assertEqual(client.config.openai.model_name, "gpt-4")
        self.assertEqual(client.config.openai.temperature, 0.5)
        self.assertEqual(client.config.openai.max_tokens, 100)
        self.assertEqual(client.config.openai.connection_verify, True)
    
    def test_init_defaults(self):
        """Verificar valores predeterminados."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-env-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-env-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
            
            self.assertEqual(client.config.openai.api_key, "test-env-key")
            self.assertEqual(client.config.azure.endpoint, "https://test-env-endpoint.openai.azure.com/")
            self.assertEqual(client.config.openai.model_name, "gpt-4")
            self.assertEqual(client.config.openai.temperature, 0.1)
            self.assertIsNone(client.config.openai.max_tokens)
            self.assertTrue(client.config.openai.connection_verify)
    
    def test_init_no_api_key(self):
        """Verificar error cuando no hay API key."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': '',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.openai.azure.com/'
        }):
            with self.assertRaises(ConfigurationError):
                CVScreeningClient()
    
    def test_init_no_endpoint(self):
        """Verificar error cuando no hay endpoint."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': ''
        }):
            with self.assertRaises(ConfigurationError):
                CVScreeningClient()
    
    @patch("cv_screening_sdk_light.client.AzureOpenAIProvider")
    def test_init_connection_verify(self, mock_provider_class):
        """Verificar que connection_verify se pasa al proveedor."""
        # Configurar el mock
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        # Crear cliente con connection_verify=False
        client = CVScreeningClient(
            api_key="test-api-key",
            endpoint="https://test-endpoint.openai.azure.com/",
            connection_verify=False
        )
        
        # Verificar que se llamó al proveedor con connection_verify=False
        mock_provider_class.assert_called_once()
        call_kwargs = mock_provider_class.call_args[1]
        self.assertIn("connection_verify", call_kwargs)
        self.assertFalse(call_kwargs["connection_verify"])
    
    @patch("cv_screening_sdk_light.client.AzureOpenAIProvider")
    def test_analyze_cv(self, mock_provider_class):
        """Verificar que analyze_cv llama al método del proveedor."""
        # Configurar mocks
        mock_provider = Mock()
        mock_provider.analyze_cv.return_value = {"result": "success"}
        mock_provider_class.return_value = mock_provider
        
        # Crear cliente
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
        
        # Llamar a analyze_cv
        result = client.analyze_cv("Test CV content", {"required_skills": ["Python"]})
        
        # Verificar que se llamó a analyze_cv del proveedor
        mock_provider.analyze_cv.assert_called_once_with(
            "Test CV content", 
            {"required_skills": ["Python"]}
        )
        
        # Verificar el resultado
        self.assertEqual(result, {"result": "success"})
    
    @patch("cv_screening_sdk_light.client.AzureOpenAIProvider")
    def test_analyze_cv_error(self, mock_provider_class):
        """Verificar manejo de errores en analyze_cv."""
        # Configurar mock para lanzar excepción
        mock_provider = Mock()
        mock_provider.analyze_cv.side_effect = Exception("Test error")
        mock_provider_class.return_value = mock_provider
        
        # Crear cliente
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
        
        # Verificar que se lanza OpenAIError
        with self.assertRaises(OpenAIError):
            client.analyze_cv("Test CV content", {})
    
    def test_process_criteria_dict(self):
        """Verificar procesamiento de criterios como diccionario."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
        
        criteria = {"required_skills": ["Python"]}
        result = client._process_criteria(criteria)
        
        self.assertEqual(result, criteria)
    
    def test_process_criteria_string(self):
        """Verificar procesamiento de criterios como string."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
        
        criteria = "Test criteria"
        result = client._process_criteria(criteria)
        
        self.assertEqual(result, {"prompt": "Test criteria"})
    
    def test_process_criteria_object(self):
        """Verificar procesamiento de criterios como objeto JobCriteria."""
        # Crear un mock manualmente que imite JobCriteria
        mock_criteria = Mock()
        mock_criteria.to_dict.return_value = {"required_skills": ["Python"]}
        
        # Crear cliente
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-env-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
        
        # Parchear isinstance para que devuelva True cuando se compara con JobCriteria
        original_isinstance = isinstance
        
        def patched_isinstance(obj, classinfo):
            if obj is mock_criteria and str(classinfo) == "<class 'cv_screening_sdk_light.models.criteria.JobCriteria'>":
                return True
            return original_isinstance(obj, classinfo)
        
        # Aplicar el patch
        with patch('builtins.isinstance', patched_isinstance):
            # Procesar criterios
            result = client._process_criteria(mock_criteria)
            
            # Verificar que se llamó a to_dict()
            mock_criteria.to_dict.assert_called_once()
            
            # Verificar el resultado
            self.assertEqual(result, {"required_skills": ["Python"]})
    
    def test_process_criteria_none(self):
        """Verificar procesamiento de criterios None."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
        
        result = client._process_criteria(None)
        
        self.assertEqual(result, {})
    
    def test_process_criteria_invalid(self):
        """Verificar error con tipo de criterios inválido."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.openai.azure.com/'
        }):
            client = CVScreeningClient()
        
        with self.assertRaises(TypeError):
            client._process_criteria(123)  # Entero no es un tipo válido
    
    @patch("cv_screening_sdk_light.client.load_cv_content")
    def test_load_cv_content(self, mock_load_cv_content):
        """Verificar que load_cv_content llama a la función correcta."""
        # Configurar mock
        mock_load_cv_content.return_value = "CV content"
        
        # Llamar al método estático
        result = CVScreeningClient.load_cv_content("test.pdf")
        
        # Verificar que se llamó a la función correcta
        mock_load_cv_content.assert_called_once_with("test.pdf")
        
        # Verificar el resultado
        self.assertEqual(result, "CV content")


if __name__ == "__main__":
    unittest.main() 