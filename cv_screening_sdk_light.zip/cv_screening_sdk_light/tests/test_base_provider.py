import unittest
from abc import ABC
from typing import Any, Dict, List, Optional

from src.providers.base_provider import BaseLLMProvider


class TestBaseLLMProvider(unittest.TestCase):
    """Pruebas para la clase abstracta BaseLLMProvider."""
    
    def test_base_provider_is_abstract(self):
        """Probar que BaseLLMProvider es una clase abstracta."""
        # Verificar que BaseLLMProvider es una subclase de ABC
        self.assertTrue(issubclass(BaseLLMProvider, ABC))
    
    def test_base_provider_abstract_methods(self):
        """Probar que BaseLLMProvider tiene los métodos abstractos requeridos."""
        # Verificar que analyze_cv es un método abstracto
        self.assertTrue(hasattr(BaseLLMProvider, 'analyze_cv'))
        
        # Verificar que analyze_multiple_cvs es un método abstracto
        self.assertTrue(hasattr(BaseLLMProvider, 'analyze_multiple_cvs'))
    
    def test_cannot_instantiate_base_provider(self):
        """Probar que no se puede instanciar BaseLLMProvider directamente."""
        with self.assertRaises(TypeError):
            BaseLLMProvider()
    
    def test_concrete_implementation_requirements(self):
        """Probar que una implementación concreta debe implementar todos los métodos abstractos."""
        # Definir una clase que hereda de BaseLLMProvider pero no implementa los métodos
        class IncompleteProvider(BaseLLMProvider):
            pass
        
        # Verificar que no se puede instanciar
        with self.assertRaises(TypeError):
            IncompleteProvider()
        
        # Definir una clase que implementa solo un método
        class PartialProvider(BaseLLMProvider):
            def analyze_cv(self, content: str, criteria: Dict[str, Any], 
                          schema_json_ob: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
                return {}
        
        # Verificar que aún no se puede instanciar
        with self.assertRaises(TypeError):
            PartialProvider()
        
        # Definir una clase que implementa todos los métodos requeridos
        class CompleteProvider(BaseLLMProvider):
            def analyze_cv(self, content: str, criteria: Dict[str, Any],
                          schema_json_ob: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
                return {}
            
            def analyze_multiple_cvs(self, contents: List[str], criteria: Dict[str, Any],
                                    batch_size: Optional[int] = None,
                                    schema_json_ob: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
                return []
        
        # Verificar que ahora sí se puede instanciar
        try:
            provider = CompleteProvider()
            self.assertIsInstance(provider, BaseLLMProvider)
        except TypeError:
            self.fail("CompleteProvider no se pudo instanciar a pesar de implementar todos los métodos abstractos")
    
    def test_method_signatures(self):
        """Probar que los métodos abstractos tienen las firmas correctas."""
        # Crear una implementación mínima para probar
        class MinimalProvider(BaseLLMProvider):
            def analyze_cv(self, content: str, criteria: Dict[str, Any],
                          schema_json_ob: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
                return {"result": "ok"}
            
            def analyze_multiple_cvs(self, contents: List[str], criteria: Dict[str, Any],
                                    batch_size: Optional[int] = None,
                                    schema_json_ob: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
                return [{"result": "ok"} for _ in contents]
        
        provider = MinimalProvider()
        
        # Probar analyze_cv
        result = provider.analyze_cv("content", {"skill": "Python"})
        self.assertEqual(result, {"result": "ok"})
        
        # Probar analyze_cv con schema_json_ob
        result = provider.analyze_cv("content", {"skill": "Python"}, {"type": "object"})
        self.assertEqual(result, {"result": "ok"})
        
        # Probar analyze_multiple_cvs
        result = provider.analyze_multiple_cvs(["content1", "content2"], {"skill": "Python"})
        self.assertEqual(result, [{"result": "ok"}, {"result": "ok"}])
        
        # Probar analyze_multiple_cvs con batch_size
        result = provider.analyze_multiple_cvs(["content1", "content2"], {"skill": "Python"}, batch_size=1)
        self.assertEqual(result, [{"result": "ok"}, {"result": "ok"}])
        
        # Probar analyze_multiple_cvs con schema_json_ob
        result = provider.analyze_multiple_cvs(
            ["content1"], {"skill": "Python"}, schema_json_ob={"type": "object"}
        )
        self.assertEqual(result, [{"result": "ok"}]) 