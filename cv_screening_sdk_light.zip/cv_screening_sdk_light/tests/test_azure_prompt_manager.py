"""
Tests for the AzurePromptManager class.
"""
import unittest
import json
from unittest.mock import patch

from src.providers.azure_prompt_manager import AzurePromptManager


class TestAzurePromptManager(unittest.TestCase):
    """Tests for the AzurePromptManager class."""
    
    def test_init_default(self):
        """Test initialization with default values."""
        manager = AzurePromptManager()
        self.assertIsNone(manager.system_prompt)
    
    def test_init_custom(self):
        """Test initialization with custom system prompt."""
        custom_prompt = "Custom system prompt"
        manager = AzurePromptManager(system_prompt=custom_prompt)
        self.assertEqual(manager.system_prompt, custom_prompt)
    
    def test_get_system_prompt_default(self):
        """Test get_system_prompt with default prompt."""
        manager = AzurePromptManager()
        prompt = manager.get_system_prompt()
        
        self.assertIn("You are an expert CV screening assistant", prompt)
        self.assertIn("Your response should be a JSON object", prompt)
        self.assertIn("overall_match", prompt)
    
    def test_get_system_prompt_custom(self):
        """Test get_system_prompt with custom prompt."""
        custom_prompt = "Custom system prompt"
        manager = AzurePromptManager(system_prompt=custom_prompt)
        prompt = manager.get_system_prompt()
        
        self.assertEqual(prompt, custom_prompt)
    
    def test_get_system_prompt_for_multiple_cvs_default(self):
        """Test get_system_prompt_for_multiple_cvs with default prompt."""
        manager = AzurePromptManager()
        prompt = manager.get_system_prompt_for_multiple_cvs(3)
        
        self.assertIn("You are an expert CV screening assistant", prompt)
        self.assertIn("Your response should be a JSON array with 3 objects", prompt)
        self.assertIn("cv_index", prompt)
    
    def test_get_system_prompt_for_multiple_cvs_custom(self):
        """Test get_system_prompt_for_multiple_cvs with custom prompt."""
        custom_prompt = "Custom system prompt"
        manager = AzurePromptManager(system_prompt=custom_prompt)
        prompt = manager.get_system_prompt_for_multiple_cvs(5)
        
        self.assertEqual(prompt, custom_prompt)
    
    def test_build_screening_prompt(self):
        """Test build_screening_prompt."""
        manager = AzurePromptManager()
        
        cv_content = "Experience: Python, SQL"
        criteria = {"required_skills": ["Python"]}
        
        prompt = manager.build_screening_prompt(cv_content, criteria)
        
        self.assertIn("CV Content:", prompt)
        self.assertIn(cv_content, prompt)
        self.assertIn("Job Criteria:", prompt)
        self.assertIn(json.dumps(criteria, indent=2), prompt)
    
    def test_build_multiple_screening_prompt(self):
        """Test build_multiple_screening_prompt."""
        manager = AzurePromptManager()
        
        cv_contents = ["CV 1", "CV 2", "CV 3"]
        criteria = {"required_skills": ["Python"]}
        
        # Test with default start_index
        prompt = manager.build_multiple_screening_prompt(cv_contents, criteria)
        
        self.assertIn("Please analyze the following 3 CVs", prompt)
        self.assertIn("CV #1 (index 0)", prompt)
        self.assertIn("CV #2 (index 1)", prompt)
        self.assertIn("CV #3 (index 2)", prompt)
        self.assertIn("CV 1", prompt)
        self.assertIn("CV 2", prompt)
        self.assertIn("CV 3", prompt)
        
        # Test with custom start_index
        prompt = manager.build_multiple_screening_prompt(cv_contents, criteria, start_index=10)
        
        self.assertIn("CV #11 (index 10)", prompt)
        self.assertIn("CV #12 (index 11)", prompt)
        self.assertIn("CV #13 (index 12)", prompt)
        self.assertIn("starting from 10", prompt)


if __name__ == "__main__":
    unittest.main() 