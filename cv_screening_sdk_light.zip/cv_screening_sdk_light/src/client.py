"""
Main client for CV screening operations.

This module provides the main entry point for the CV Screening SDK,
handling CV analysis with a simplified interface.
"""

import logging
import os
import base64
from typing import Any, Dict, List, Optional, Union, Tuple

from .core.config import Config
from .core.exceptions import ConfigurationError, OpenAIError, ValidationError
from .core.types import ContentType
from .models.criteria import JobCriteria
from .providers.azure_provider import AzureOpenAIProvider
from .providers.base_provider import BaseLLMProvider
from .utils.document import load_cv_content, load_cv_from_base64

logger = logging.getLogger(__name__)


class CVScreeningClient:
    """
    Client for CV screening using Azure OpenAI.
    
    This is the main client class for interacting with the CV Screening SDK.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        api_key: str = None,
        deployment_name: str = "gpt-4",
        api_version: str = "2023-05-15",
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None,
        connection_verify: bool = True,
        secondary_endpoint: Optional[str] = None,
        secondary_api_key: Optional[str] = None,
        base_model: Optional[str] = None,
        custom_provider: Optional[BaseLLMProvider] = None,
    ) -> None:
        """
        Initialize the CV screening client.

        Args:
            endpoint: The Azure OpenAI endpoint URL (default: from AZURE_OPENAI_ENDPOINT env).
            api_key: The API key for Azure OpenAI (default: from AZURE_OPENAI_API_KEY env).
            deployment_name: The deployment name to use (default: "gpt-4").
            api_version: The API version to use (default: "2023-05-15").
            temperature: The temperature to use for generations (default: 0.1).
            max_tokens: The maximum number of tokens to generate (optional).
            system_prompt: A custom system prompt to use (optional).
            connection_verify: Whether to verify SSL connections (default: True).
            secondary_endpoint: Optional different endpoint for secondary processing model.
            secondary_api_key: Optional different API key for secondary processing model.
            base_model: The base model name of the deployment (e.g., "gpt-4", "gpt-35-turbo").
                       Used to determine capabilities instead of inferring from deployment name.
            custom_provider: Custom LLM provider to use instead of AzureOpenAI (optional).
        """
        self.logger = logging.getLogger(__name__)

        if custom_provider:
            self.provider = custom_provider
        else:
            # Use provided values or look for environment variables
            endpoint = endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT")
            api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")

            if not endpoint or not api_key:
                raise ValueError(
                    "AzureOpenAI endpoint and API key must be provided either through "
                    "parameters or environment variables."
                )

            self.provider = AzureOpenAIProvider(
                endpoint=endpoint,
                api_key=api_key,
                deployment_name=deployment_name,
                api_version=api_version,
                temperature=temperature,
                max_tokens=max_tokens,
                system_prompt=system_prompt,
                connection_verify=connection_verify,
                secondary_endpoint=secondary_endpoint,
                secondary_api_key=secondary_api_key,
                base_model=base_model,
            )
            
            self.logger.info("CV Screening SDK client initialized with Azure OpenAI")
    
    def analyze_cv(
        self,
        content: Union[str, bytes],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        content_type: ContentType = ContentType.TEXT,
        schema_json_ob: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Analyze a CV against given criteria.
        
        This is the main method for CV screening. It analyzes a single CV
        against the provided criteria and returns the raw analysis results.
        
        Args:
            content: CV content as text, base64 or file path
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            content_type: Type of content provided (default: ContentType.TEXT)
            schema_json_ob: Optional JSON schema to use for response formatting. If not provided, 
                   the default schema will be used.
        
        Returns:
            Raw analysis results from Azure OpenAI
        
        Raises:
            OpenAIError: If the analysis fails
        """
        self.logger.info(f"Starting CV analysis with content type: {content_type.name}")
        
        # Process content based on its type
        if content_type == ContentType.BASE64:
            try:
                # Convert to bytes if it's a string
                if isinstance(content, str):
                    content_bytes = content.encode('utf-8')
                else:
                    content_bytes = content
                
                # Decode base64
                decoded_content = base64.b64decode(content_bytes).decode('utf-8')
                content = decoded_content
                self.logger.info("Successfully decoded base64 content")
            except Exception as e:
                self.logger.error(f"Failed to decode base64 content: {str(e)}")
                raise OpenAIError(f"Failed to decode base64 content: {str(e)}") from e
        elif content_type == ContentType.FILE_PATH:
            if not isinstance(content, str):
                raise OpenAIError("File path must be a string")
            try:
                content = load_cv_content(content)
                self.logger.info(f"Successfully loaded content from file: {content}")
            except Exception as e:
                self.logger.error(f"Failed to load content from file: {str(e)}")
                raise OpenAIError(f"Failed to load content from file: {str(e)}") from e
        elif isinstance(content, bytes):
            # For text content that's in bytes, decode to string
            try:
                content = content.decode('utf-8')
            except Exception as e:
                self.logger.error(f"Failed to decode bytes content as UTF-8: {str(e)}")
                raise OpenAIError(f"Failed to decode bytes content: {str(e)}") from e
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        try:
            # Analyze with Azure OpenAI
            result = self.provider.analyze_cv(content, criteria_dict, schema_json_ob=schema_json_ob)
            
            self.logger.info("CV analysis completed")
            return result
        except Exception as e:
            self.logger.error(f"Failed to analyze CV: {str(e)}")
            raise OpenAIError(f"Failed to analyze CV: {str(e)}") from e
    
    def analyze_multiple_cvs(
        self,
        contents: List[Union[str, bytes]],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        content_type: ContentType = ContentType.TEXT,
        batch_size: Optional[int] = None,
        schema_json_ob: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Analyze multiple CVs against given criteria.
        
        This method analyzes multiple CVs at once against the provided criteria
        and returns a list of analysis results.
        
        Args:
            contents: List of CV contents as text, base64 or file paths
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            content_type: Type of content provided (default: ContentType.TEXT)
            batch_size: Batch size for processing CVs. If not provided,
                       all CVs will be processed in a single batch.
            schema_json_ob: Optional JSON schema to use for response formatting. If not provided, 
                   the default schema will be used.
        
        Returns:
            List of raw analysis results from Azure OpenAI
        
        Raises:
            OpenAIError: If the analysis fails
        """
        self.logger.info(f"Starting multiple CV analysis with content type: {content_type.name}")
        
        # Process each CV content based on its type
        processed_contents = []
        for cv_content in contents:
            if content_type == ContentType.BASE64:
                try:
                    # Convert to bytes if it's a string
                    if isinstance(cv_content, str):
                        content_bytes = cv_content.encode('utf-8')
                    else:
                        content_bytes = cv_content
                    
                    # Decode base64
                    decoded_content = base64.b64decode(content_bytes).decode('utf-8')
                    processed_contents.append(decoded_content)
                except Exception as e:
                    self.logger.error(f"Failed to decode base64 content: {str(e)}")
                    raise OpenAIError(f"Failed to decode base64 content: {str(e)}") from e
            elif content_type == ContentType.FILE_PATH:
                if not isinstance(cv_content, str):
                    raise OpenAIError("File path must be a string")
                try:
                    processed_contents.append(load_cv_content(cv_content))
                except Exception as e:
                    self.logger.error(f"Failed to load content from file: {str(e)}")
                    raise OpenAIError(f"Failed to load content from file: {str(e)}") from e
            elif isinstance(cv_content, bytes):
                # For text content that's in bytes, decode to string
                try:
                    processed_contents.append(cv_content.decode('utf-8'))
                except Exception as e:
                    self.logger.error(f"Failed to decode bytes content as UTF-8: {str(e)}")
                    raise OpenAIError(f"Failed to decode bytes content: {str(e)}") from e
            else:
                # Assume it's already text content
                processed_contents.append(cv_content)
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        try:
            # Analyze with Azure OpenAI
            results = self.provider.analyze_multiple_cvs(
                contents=processed_contents,
                criteria=criteria_dict,
                batch_size=batch_size,
                schema_json_ob=schema_json_ob
            )
            
            self.logger.info(f"Multiple CV analysis completed for {len(contents)} CVs")
            return results
        except Exception as e:
            self.logger.error(f"Failed to analyze multiple CVs: {str(e)}")
            raise OpenAIError(f"Failed to analyze multiple CVs: {str(e)}") from e
    
    def _process_criteria(
        self,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> Dict[str, Any]:
        """
        Process criteria to a dictionary format.
        
        Args:
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
        
        Returns:
            Criteria as dictionary
        """
        if criteria is None:
            return {}
        
        if isinstance(criteria, JobCriteria):
            return criteria.to_dict()
        
        if isinstance(criteria, str):
            return {"prompt": criteria}
        
        if isinstance(criteria, dict):
            return criteria
        
        raise TypeError(f"Unsupported criteria type: {type(criteria)}")
    
    # Expose utility method directly
    @staticmethod
    def load_cv_content(file_path_or_content: Union[str, bytes], content_type: ContentType = ContentType.FILE_PATH) -> str:
        """
        Load CV content from a file or decode from base64.
        
        This is a convenience method that handles different types of content.
        
        Args:
            file_path_or_content: Path to the CV file or content (plain text or base64)
            content_type: Type of content provided (default: ContentType.FILE_PATH)
        
        Returns:
            String content of the CV
        
        Raises:
            DocumentParsingError: If the file cannot be parsed or base64 cannot be decoded
            FileNotFoundError: If the file does not exist
        """
        # Process based on content type
        if content_type == ContentType.FILE_PATH:
            # Load from file
            if not isinstance(file_path_or_content, str):
                raise DocumentParsingError("File path must be a string")
            
            return load_cv_content(file_path_or_content)
            
        elif content_type == ContentType.BASE64:
            # Decode base64
            try:
                return load_cv_from_base64(file_path_or_content)
            except Exception as e:
                raise DocumentParsingError(f"Failed to decode base64 content: {str(e)}")
        
        else: # ContentType.TEXT
            # Return as is (assuming it's already text content)
            if isinstance(file_path_or_content, bytes):
                try:
                    return file_path_or_content.decode('utf-8')
                except Exception as e:
                    raise DocumentParsingError(f"Failed to decode content as UTF-8: {str(e)}")
            
            return file_path_or_content 