"""
Main client for CV screening operations.

This module provides the main entry point for the CV Screening SDK,
handling CV analysis with a simplified interface.
"""

import logging
import os
import base64
from typing import Any, Dict, List, Optional, Union

from .core.config import Config
from .core.exceptions import ConfigurationError, OpenAIError, ValidationError
from .core.types import ContentType
from .models.criteria import JobCriteria
from .providers.azure_provider import AzureOpenAIProvider
from .utils.document import load_cv_content, load_cv_from_base64

logger = logging.getLogger(__name__)


class CVScreeningClient:
    """
    Client for CV screening using Azure OpenAI.
    
    This is the main client class for interacting with the CV Screening SDK.
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        endpoint: Optional[str] = None,
        model_name: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        connection_verify: Optional[bool] = None,
        system_prompt: Optional[str] = None,
    ):
        """
        Initialize the client.
        
        Args:
            api_key: Azure OpenAI API key (defaults to AZURE_OPENAI_API_KEY environment variable)
            endpoint: Azure OpenAI endpoint (defaults to AZURE_OPENAI_ENDPOINT environment variable)
            model_name: Model deployment name (defaults to AZURE_OPENAI_DEPLOYMENT or "gpt-4")
            temperature: Sampling temperature (defaults to OPENAI_TEMPERATURE or 0.1)
            max_tokens: Maximum tokens to generate (defaults to OPENAI_MAX_TOKENS or None)
            connection_verify: Whether to verify SSL connections (defaults to OPENAI_CONNECTION_VERIFY or True)
            system_prompt: Custom system prompt to use (defaults to OPENAI_SYSTEM_PROMPT or None)
        
        Raises:
            ConfigurationError: If the configuration is invalid
        """
        try:
            # Create config with defaults from environment variables
            self.config = Config()
            
            # Override config with provided values
            if api_key:
                self.config.openai.api_key = api_key
            if endpoint:
                self.config.azure.endpoint = endpoint
            if model_name:
                self.config.openai.model_name = model_name
            if temperature is not None:
                self.config.openai.temperature = temperature
            if max_tokens is not None:
                self.config.openai.max_tokens = max_tokens
            if connection_verify is not None:
                self.config.openai.connection_verify = connection_verify
            if system_prompt is not None:
                self.config.openai.system_prompt = system_prompt
            
            # Validate API key and endpoint
            if not self.config.openai.api_key:
                self.config.openai.api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")
                if not self.config.openai.api_key:
                    raise ConfigurationError(
                        "Azure OpenAI API key is required. Provide it as a parameter or set the AZURE_OPENAI_API_KEY environment variable."
                    )
            
            if not self.config.azure.endpoint:
                self.config.azure.endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
                if not self.config.azure.endpoint:
                    raise ConfigurationError(
                        "Azure OpenAI endpoint is required. Provide it as a parameter or set the AZURE_OPENAI_ENDPOINT environment variable."
                    )
            
            # Initialize provider
            self.provider = AzureOpenAIProvider(
                endpoint=self.config.azure.endpoint,
                api_key=self.config.openai.api_key,
                deployment_name=self.config.openai.model_name,
                temperature=self.config.openai.temperature,
                max_tokens=self.config.openai.max_tokens,
                connection_verify=self.config.openai.connection_verify,
                system_prompt=self.config.openai.system_prompt,
            )
            
            self.logger = logging.getLogger(__name__)
            self.logger.info("CV Screening SDK client initialized with Azure OpenAI")
        except Exception as e:
            logger.error(f"Failed to initialize client: {str(e)}")
            raise ConfigurationError(f"Failed to initialize client: {str(e)}") from e
    
    def analyze_cv(
        self,
        content: Union[str, bytes],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        content_type: ContentType = ContentType.TEXT,
    ) -> Dict[str, Any]:
        """
        Analyze a CV against given criteria.
        
        This is the main method for CV screening. It analyzes a single CV
        against the provided criteria and returns the raw analysis results.
        
        Args:
            content: CV content as text, base64 or file path
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            content_type: Type of content provided (default: ContentType.TEXT)
        
        Returns:
            Raw analysis results from Azure OpenAI
        
        Raises:
            OpenAIError: If the analysis fails
        """
        self.logger.info(f"Starting CV analysis with content type: {content_type.name}")
        
        # Process content based on its type
        if content_type == ContentType.BASE64:
            try:
                # Convert to bytes if it's a string
                if isinstance(content, str):
                    content_bytes = content.encode('utf-8')
                else:
                    content_bytes = content
                
                # Decode base64
                decoded_content = base64.b64decode(content_bytes).decode('utf-8')
                content = decoded_content
                self.logger.info("Successfully decoded base64 content")
            except Exception as e:
                self.logger.error(f"Failed to decode base64 content: {str(e)}")
                raise OpenAIError(f"Failed to decode base64 content: {str(e)}") from e
        elif content_type == ContentType.FILE_PATH:
            if not isinstance(content, str):
                raise OpenAIError("File path must be a string")
            try:
                content = load_cv_content(content)
                self.logger.info(f"Successfully loaded content from file: {content}")
            except Exception as e:
                self.logger.error(f"Failed to load content from file: {str(e)}")
                raise OpenAIError(f"Failed to load content from file: {str(e)}") from e
        elif isinstance(content, bytes):
            # For text content that's in bytes, decode to string
            try:
                content = content.decode('utf-8')
            except Exception as e:
                self.logger.error(f"Failed to decode bytes content as UTF-8: {str(e)}")
                raise OpenAIError(f"Failed to decode bytes content: {str(e)}") from e
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        try:
            # Analyze with Azure OpenAI
            result = self.provider.analyze_cv(content, criteria_dict)
            
            self.logger.info("CV analysis completed")
            return result
        except Exception as e:
            self.logger.error(f"Failed to analyze CV: {str(e)}")
            raise OpenAIError(f"Failed to analyze CV: {str(e)}") from e
    
    def _process_criteria(
        self,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> Dict[str, Any]:
        """
        Process criteria to a dictionary format.
        
        Args:
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
        
        Returns:
            Criteria as dictionary
        """
        if criteria is None:
            return {}
        
        if isinstance(criteria, JobCriteria):
            return criteria.to_dict()
        
        if isinstance(criteria, str):
            return {"prompt": criteria}
        
        if isinstance(criteria, dict):
            return criteria
        
        raise TypeError(f"Unsupported criteria type: {type(criteria)}")
    
    # Expose utility method directly
    @staticmethod
    def load_cv_content(file_path_or_content: Union[str, bytes], content_type: ContentType = ContentType.FILE_PATH) -> str:
        """
        Load CV content from a file or decode from base64.
        
        This is a convenience method that handles different types of content.
        
        Args:
            file_path_or_content: Path to the CV file or content (plain text or base64)
            content_type: Type of content provided (default: ContentType.FILE_PATH)
        
        Returns:
            String content of the CV
        
        Raises:
            DocumentParsingError: If the file cannot be parsed or base64 cannot be decoded
            FileNotFoundError: If the file does not exist
        """
        # Process based on content type
        if content_type == ContentType.FILE_PATH:
            # Load from file
            if not isinstance(file_path_or_content, str):
                raise DocumentParsingError("File path must be a string")
            
            return load_cv_content(file_path_or_content)
            
        elif content_type == ContentType.BASE64:
            # Decode base64
            try:
                return load_cv_from_base64(file_path_or_content)
            except Exception as e:
                raise DocumentParsingError(f"Failed to decode base64 content: {str(e)}")
        
        else: # ContentType.TEXT
            # Return as is (assuming it's already text content)
            if isinstance(file_path_or_content, bytes):
                try:
                    return file_path_or_content.decode('utf-8')
                except Exception as e:
                    raise DocumentParsingError(f"Failed to decode content as UTF-8: {str(e)}")
            
            return file_path_or_content 