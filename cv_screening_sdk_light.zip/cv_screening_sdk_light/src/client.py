"""
Main client for CV screening operations.

This module provides the main entry point for the CV Screening SDK,
handling CV analysis with a simplified interface.
"""

import logging
import os
import base64
from typing import Any, Dict, List, Optional, Union, Tuple

from .core.config import Config
from .core.exceptions import ConfigurationError, OpenAIError, ValidationError, DocumentParsingError
from .core.types import ContentType
from .models.criteria import JobCriteria
from .providers.azure_provider import AzureOpenAIProvider
from .providers.base_provider import BaseLLMProvider
from .utils.document import load_cv_content, load_cv_from_base64
from .utils.rate_limiting import RateLimiter, estimate_cv_tokens

logger = logging.getLogger(__name__)


class CVScreeningClient:
    """
    Client for CV screening using Azure OpenAI.
    
    This is the main client class for interacting with the CV Screening SDK.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        api_key: str = None,
        deployment_name: str = "gpt-4",
        api_version: str = "2023-05-15",
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None,
        connection_verify: bool = True,
        secondary_endpoint: Optional[str] = None,
        secondary_api_key: Optional[str] = None,
        base_model: Optional[str] = None,
        custom_provider: Optional[BaseLLMProvider] = None,
        rate_limiter: Optional[RateLimiter] = None,
        max_rpm: int = 100,
        max_tpm: int = 60000,
    ) -> None:
        """
        Initialize the CV screening client.

        Args:
            endpoint: The Azure OpenAI endpoint URL (default: from AZURE_OPENAI_ENDPOINT env).
            api_key: The API key for Azure OpenAI (default: from AZURE_OPENAI_API_KEY env).
            deployment_name: The deployment name to use (default: "gpt-4").
            api_version: The API version to use (default: "2023-05-15").
            temperature: The temperature to use for generations (default: 0.1).
            max_tokens: The maximum number of tokens to generate (optional).
            system_prompt: A custom system prompt to use (optional).
            connection_verify: Whether to verify SSL connections (default: True).
            secondary_endpoint: Optional different endpoint for secondary processing model.
            secondary_api_key: Optional different API key for secondary processing model.
            base_model: The base model name of the deployment (e.g., "gpt-4", "gpt-35-turbo").
                       Used to determine capabilities instead of inferring from deployment name.
            custom_provider: Custom LLM provider to use instead of AzureOpenAI (optional).
            rate_limiter: Optional custom rate limiter instance to use for rate limiting.
            max_rpm: Maximum requests per minute when using the default rate limiter (default: 100).
            max_tpm: Maximum tokens per minute when using the default rate limiter (default: 60000).
        """
        self.logger = logging.getLogger(__name__)

        # Configurar el limitador de tasa
        self.rate_limiter = rate_limiter or RateLimiter(max_rpm=max_rpm, max_tpm=max_tpm)
        self.logger.info(f"Rate limiter configured: {max_rpm} RPM, {max_tpm} TPM")

        if custom_provider:
            self.provider = custom_provider
        else:
            # Use provided values or look for environment variables
            endpoint = endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT")
            api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")

            if not endpoint or not api_key:
                raise ValueError(
                    "AzureOpenAI endpoint and API key must be provided either through "
                    "parameters or environment variables."
                )

            self.provider = AzureOpenAIProvider(
                endpoint=endpoint,
                api_key=api_key,
                deployment_name=deployment_name,
                api_version=api_version,
                temperature=temperature,
                max_tokens=max_tokens,
                system_prompt=system_prompt,
                connection_verify=connection_verify,
                secondary_endpoint=secondary_endpoint,
                secondary_api_key=secondary_api_key,
                base_model=base_model,
            )
            
            self.logger.info("CV Screening SDK client initialized with Azure OpenAI")
    
    def analyze_cv(
        self,
        content: Union[str, bytes],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        content_type: ContentType = ContentType.TEXT,
        schema_json_ob: Optional[Dict[str, Any]] = None,
        use_rate_limiting: bool = True,
        max_retries: int = 3,
    ) -> Dict[str, Any]:
        """
        Analyze a CV against given criteria.
        
        This is the main method for CV screening. It analyzes a single CV
        against the provided criteria and returns the raw analysis results.
        
        Args:
            content: CV content as text, base64 or file path
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            content_type: Type of content provided (default: ContentType.TEXT)
            schema_json_ob: Optional JSON schema to use for response formatting. If not provided, 
                   the default schema will be used.
            use_rate_limiting: Whether to apply rate limiting (default: True)
            max_retries: Maximum number of retries for rate limit errors (default: 3)
        
        Returns:
            Raw analysis results from Azure OpenAI
        
        Raises:
            OpenAIError: If the analysis fails
        """
        self.logger.info(f"Starting CV analysis with content type: {content_type.name}")
        
        # Process content based on its type
        if content_type == ContentType.BASE64:
            try:
                # Convert to bytes if it's a string
                if isinstance(content, str):
                    content_bytes = content.encode('utf-8')
                else:
                    content_bytes = content
                
                # Decode base64
                decoded_content = base64.b64decode(content_bytes).decode('utf-8')
                content = decoded_content
                self.logger.info("Successfully decoded base64 content")
            except Exception as e:
                self.logger.error(f"Failed to decode base64 content: {str(e)}")
                raise OpenAIError(f"Failed to decode base64 content: {str(e)}") from e
        elif content_type == ContentType.FILE_PATH:
            if not isinstance(content, str):
                raise OpenAIError("File path must be a string")
            try:
                content = load_cv_content(content)
                self.logger.info(f"Successfully loaded content from file: {content}")
            except Exception as e:
                self.logger.error(f"Failed to load content from file: {str(e)}")
                raise OpenAIError(f"Failed to load content from file: {str(e)}") from e
        elif isinstance(content, bytes):
            # For text content that's in bytes, decode to string
            try:
                content = content.decode('utf-8')
            except Exception as e:
                self.logger.error(f"Failed to decode bytes content as UTF-8: {str(e)}")
                raise OpenAIError(f"Failed to decode bytes content: {str(e)}") from e
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        try:
            if not use_rate_limiting:
                # Analyze directly without rate limiting
                result = self.provider.analyze_cv(content, criteria_dict, schema_json_ob=schema_json_ob)
            else:
                # Estimar tokens para rate limiting
                criteria_str = str(criteria_dict) if criteria_dict else ""
                base_model = getattr(self.provider, "base_model", "gpt-4")
                tokens_estimate = estimate_cv_tokens(content, criteria_str, model=base_model)
                
                # Usar rate limiting
                self.logger.info(f"Analyzing CV with rate limiting. Estimated tokens: {tokens_estimate}")
                result = self.rate_limiter.execute_with_rate_limit(
                    self.provider.analyze_cv,
                    content, 
                    criteria_dict, 
                    schema_json_ob=schema_json_ob,
                    tokens_estimate=tokens_estimate,
                    max_retries=max_retries
                )
            
            self.logger.info("CV analysis completed")
            return result
        except Exception as e:
            self.logger.error(f"Failed to analyze CV: {str(e)}")
            raise OpenAIError(f"Failed to analyze CV: {str(e)}") from e
    
    def analyze_multiple_cvs(
        self,
        contents: List[Union[str, bytes]],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        content_type: ContentType = ContentType.TEXT,
        batch_size: Optional[int] = None,
        schema_json_ob: Optional[Dict[str, Any]] = None,
        use_rate_limiting: bool = True,
        max_retries: int = 3,
    ) -> List[Dict[str, Any]]:
        """
        Analyze multiple CVs against given criteria.
        
        This method analyzes multiple CVs at once against the provided criteria
        and returns a list of analysis results.
        
        Args:
            contents: List of CV contents as text, base64 or file paths
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            content_type: Type of content provided (default: ContentType.TEXT)
            batch_size: Batch size for processing CVs. If not provided,
                       all CVs will be processed in a single batch.
            schema_json_ob: Optional JSON schema to use for response formatting. If not provided, 
                   the default schema will be used.
            use_rate_limiting: Whether to apply rate limiting (default: True)
            max_retries: Maximum number of retries for rate limit errors (default: 3)
        
        Returns:
            List of raw analysis results from Azure OpenAI
        
        Raises:
            OpenAIError: If the analysis fails
        """
        self.logger.info(f"Starting multiple CV analysis with content type: {content_type.name}")
        
        # Process each CV
        processed_contents = []
        for content in contents:
            if content_type == ContentType.BASE64:
                try:
                    if isinstance(content, str):
                        content_bytes = content.encode('utf-8')
                    else:
                        content_bytes = content
                    
                    decoded_content = base64.b64decode(content_bytes).decode('utf-8')
                    processed_contents.append(decoded_content)
                except Exception as e:
                    self.logger.error(f"Failed to decode base64 content: {str(e)}")
                    raise OpenAIError(f"Failed to decode base64 content: {str(e)}") from e
            elif content_type == ContentType.FILE_PATH:
                if not isinstance(content, str):
                    raise OpenAIError("File path must be a string")
                try:
                    processed_content = load_cv_content(content)
                    processed_contents.append(processed_content)
                except Exception as e:
                    self.logger.error(f"Failed to load content from file {content}: {str(e)}")
                    raise OpenAIError(f"Failed to load content from file: {str(e)}") from e
            elif isinstance(content, bytes):
                try:
                    decoded_content = content.decode('utf-8')
                    processed_contents.append(decoded_content)
                except Exception as e:
                    self.logger.error(f"Failed to decode bytes content as UTF-8: {str(e)}")
                    raise OpenAIError(f"Failed to decode bytes content: {str(e)}") from e
            else:
                processed_contents.append(content)
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        # Determine batch size
        if batch_size is None or batch_size <= 0:
            batch_size = len(processed_contents)
        
        # Process CVs in batches
        results = []
        for i in range(0, len(processed_contents), batch_size):
            batch = processed_contents[i:i+batch_size]
            
            try:
                for content in batch:
                    if use_rate_limiting:
                        # Con rate limiting
                        criteria_str = str(criteria_dict) if criteria_dict else ""
                        base_model = getattr(self.provider, "base_model", "gpt-4")
                        tokens_estimate = estimate_cv_tokens(content, criteria_str, model=base_model)
                        
                        result = self.rate_limiter.execute_with_rate_limit(
                            self.provider.analyze_cv,
                            content, 
                            criteria_dict, 
                            schema_json_ob=schema_json_ob,
                            tokens_estimate=tokens_estimate,
                            max_retries=max_retries
                        )
                    else:
                        # Sin rate limiting
                        result = self.provider.analyze_cv(content, criteria_dict, schema_json_ob=schema_json_ob)
                    
                    results.append(result)
            except Exception as e:
                self.logger.error(f"Failed to analyze batch of CVs: {str(e)}")
                raise OpenAIError(f"Failed to analyze batch of CVs: {str(e)}") from e
        
        self.logger.info(f"Multiple CV analysis completed. Processed {len(results)} CVs.")
        return results
    
    def _process_criteria(
        self,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> Dict[str, Any]:
        """
        Process and validate the criteria object.
        
        Args:
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            
        Returns:
            Processed criteria as dictionary
        """
        if criteria is None:
            return {}
        
        if isinstance(criteria, dict):
            # If it's already a dictionary, use it directly
            return criteria
        elif isinstance(criteria, JobCriteria):
            # If it's a JobCriteria object, convert to dictionary
            return criteria.model_dump()
        elif isinstance(criteria, str):
            # If it's a string, use it as a prompt
            return {"prompt": criteria}
        else:
            raise ValueError(f"Invalid criteria type: {type(criteria)}. Expected dict, JobCriteria, or str.")
    
    @staticmethod
    def load_cv_content(file_path_or_content: Union[str, bytes], content_type: ContentType = ContentType.FILE_PATH) -> str:
        """
        Load CV content from a file path, base64 string, or content bytes.
        
        This is a convenience method that handles different content types.
        
        Args:
            file_path_or_content: File path, base64 string, or content bytes
            content_type: Type of content provided (default: ContentType.FILE_PATH)
            
        Returns:
            The loaded CV content as a string
            
        Raises:
            OpenAIError: If loading fails
        """
        try:
            if content_type == ContentType.FILE_PATH:
                return load_cv_content(file_path_or_content)
            elif content_type == ContentType.BASE64:
                return load_cv_from_base64(file_path_or_content)
            elif content_type == ContentType.TEXT:
                if isinstance(file_path_or_content, bytes):
                    return file_path_or_content.decode('utf-8')
                return file_path_or_content
            else:
                raise ValueError(f"Unknown content type: {content_type}")
        except Exception as e:
            raise OpenAIError(f"Failed to load CV content: {str(e)}") from e 