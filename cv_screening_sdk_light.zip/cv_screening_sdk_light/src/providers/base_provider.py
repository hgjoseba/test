"""
Base provider interface for CV Screening SDK.

This module defines the base interface that all LLM providers must implement.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class BaseLLMProvider(ABC):
    """
    Base abstract class for LLM providers.
    
    All LLM providers used with the CV Screening SDK should inherit from this class
    and implement its abstract methods.
    """
    
    @abstractmethod
    def analyze_cv(
        self, 
        content: str, 
        criteria: Dict[str, Any],
        schema_json_ob: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Analyze a CV against job criteria.
        
        Args:
            content: CV content to analyze.
            criteria: Job criteria to evaluate the CV against.
            schema_json_ob: Optional JSON schema to use for response formatting.
            
        Returns:
            A dictionary containing the CV analysis.
        """
        pass
    
    @abstractmethod
    def analyze_multiple_cvs(
        self,
        contents: List[str],
        criteria: Dict[str, Any],
        batch_size: Optional[int] = None,
        schema_json_ob: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Analyze multiple CVs against job criteria.
        
        Args:
            contents: List of CV contents to analyze.
            criteria: Job criteria to evaluate CVs against.
            batch_size: Batch size for processing CVs.
            schema_json_ob: Optional JSON schema to use for response formatting.
            
        Returns:
            A list of dictionaries containing CV analyses.
        """
        pass 