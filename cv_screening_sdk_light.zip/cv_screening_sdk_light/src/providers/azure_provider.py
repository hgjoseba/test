"""
Azure OpenAI provider simplificado para CV Screening SDK.

Este módulo proporciona integración con Azure OpenAI de manera simplificada.
"""

import json
import logging
import functools
from typing import Any, Dict, List, Optional

from openai import AzureOpenAI
import httpx

from ..core.exceptions import OpenAIError


class AzureOpenAIProvider:
    """
    Proveedor simplificado para integración con Azure OpenAI.
    
    Esta clase gestiona la comunicación con Azure OpenAI API.
    """
    
    def __init__(
        self,
        endpoint: str,
        api_key: str,
        deployment_name: str = "gpt-4",
        api_version: str = "2023-05-15",
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None,
        connection_verify: bool = True,
    ) -> None:
        """
        Inicializa el proveedor de Azure OpenAI.
        
        Args:
            endpoint: URL del endpoint de Azure OpenAI
            api_key: Clave API de Azure OpenAI
            deployment_name: Nombre del deployment a usar (modelo)
            api_version: Versión de la API de Azure OpenAI
            temperature: Temperatura de muestreo (0-1)
            max_tokens: Máximo de tokens a generar
            system_prompt: Prompt de sistema personalizado
            connection_verify: Si se debe verificar las conexiones SSL (default: True)
        
        Raises:
            OpenAIError: Si falla la inicialización
        """
        self.endpoint = endpoint
        self.api_key = api_key
        self.api_version = api_version
        self.deployment_name = deployment_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.system_prompt = system_prompt
        self.connection_verify = connection_verify
        self.logger = logging.getLogger(__name__)
        
        try:
            # Aplicar monkey patch si es necesario
            if not self.connection_verify:
                self._apply_http_monkey_patch()
                
            # Inicializar cliente de OpenAI
            self.client = AzureOpenAI(
                azure_endpoint=self.endpoint,
                api_version=self.api_version,
                api_key=self.api_key,
            )
            self.logger.info(f"Proveedor Azure OpenAI inicializado con deployment: {deployment_name}")
        except Exception as e:
            self.logger.error(f"Error al inicializar el proveedor de Azure OpenAI: {str(e)}")
            raise OpenAIError(f"Error al inicializar el proveedor de Azure OpenAI: {str(e)}") from e
    
    def _apply_http_monkey_patch(self) -> None:
        """
        Aplica monkey patch para deshabilitar la verificación SSL en httpx.
        
        Esto fuerza a todos los clientes httpx a usar verify=False para la verificación SSL.
        """
        try:
            self.logger.warning("Aplicando monkey patch al cliente httpx para deshabilitar la verificación SSL")
            
            # Guardar httpx.Client.__init__ original
            self._original_client_init = httpx.Client.__init__
            
            # Definir nuevo __init__ que siempre establece verify=False
            @functools.wraps(httpx.Client.__init__)
            def new_init(client_self, *args, **kwargs):
                # Asegurar que no hay parámetros inválidos
                if "proxies" in kwargs:
                    del kwargs["proxies"]
                
                # Establecer verificación SSL a False
                kwargs["verify"] = False
                
                # Llamar al inicializador original
                self._original_client_init(client_self, *args, **kwargs)
            
            # Aplicar monkey patch
            httpx.Client.__init__ = new_init
            
            # También patchear AsyncClient si se usa
            self._original_async_client_init = httpx.AsyncClient.__init__
            
            @functools.wraps(httpx.AsyncClient.__init__)
            def new_async_init(client_self, *args, **kwargs):
                # Asegurar que no hay parámetros inválidos
                if "proxies" in kwargs:
                    del kwargs["proxies"]
                
                # Establecer verificación SSL a False
                kwargs["verify"] = False
                
                # Llamar al inicializador original
                self._original_async_client_init(client_self, *args, **kwargs)
            
            httpx.AsyncClient.__init__ = new_async_init
            
            self.logger.warning("Monkey patch de cliente HTTP aplicado: verificación SSL deshabilitada")
        except Exception as e:
            self.logger.error(f"Error al aplicar monkey patch HTTP: {str(e)}")
    
    def __del__(self):
        """Limpia los monkey patches cuando la instancia es destruida."""
        try:
            # Restaurar httpx.Client.__init__ original si lo parcheamos
            if hasattr(self, "_original_client_init") and httpx.Client.__init__ != self._original_client_init:
                httpx.Client.__init__ = self._original_client_init
                
            # Restaurar httpx.AsyncClient.__init__ original si lo parcheamos
            if hasattr(self, "_original_async_client_init") and httpx.AsyncClient.__init__ != self._original_async_client_init:
                httpx.AsyncClient.__init__ = self._original_async_client_init
        except Exception:
            pass  # Ignorar errores durante la limpieza
    
    def get_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Obtiene completado desde Azure OpenAI.
        
        Args:
            messages: Lista de mensajes en la conversación
            temperature: Temperatura alternativa (opcional)
            max_tokens: Máximo de tokens alternativo (opcional)
        
        Returns:
            Respuesta cruda del completado
        
        Raises:
            OpenAIError: Si falla la llamada a la API
        """
        try:
            # Usar valores predeterminados si no se especifican
            temp = temperature if temperature is not None else self.temperature
            tokens = max_tokens if max_tokens is not None else self.max_tokens
            
            # Llamar a la API de Azure OpenAI
            completion = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=messages,
                temperature=temp,
                max_tokens=tokens,
            )
            
            # Devolver respuesta cruda
            return completion
        except Exception as e:
            self.logger.error(f"Error al obtener completado: {str(e)}")
            raise OpenAIError(f"Error al obtener completado: {str(e)}") from e
    
    def analyze_cv(
        self,
        content: str,
        criteria: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Analiza un CV contra criterios laborales.
        
        Args:
            content: Contenido del CV como texto
            criteria: Criterios laborales como diccionario
        
        Returns:
            Respuesta de análisis cruda de Azure OpenAI
        
        Raises:
            OpenAIError: Si falla el análisis
        """
        try:
            # Construir mensajes
            messages = [
                {"role": "system", "content": self._get_system_prompt()},
                {
                    "role": "user",
                    "content": self._build_screening_prompt(content, criteria),
                },
            ]
            
            # Obtener completado
            completion = self.get_completion(messages)
            
            # Extraer contenido de la respuesta
            response_text = completion.choices[0].message.content
            
            # Intentar analizar como JSON si es posible
            try:
                return json.loads(response_text)
            except json.JSONDecodeError:
                # Devolver como texto si no es JSON válido
                return {"raw_response": response_text}
        except Exception as e:
            self.logger.error(f"Error al analizar CV: {str(e)}")
            raise OpenAIError(f"Error al analizar CV: {str(e)}") from e
    
    def _get_system_prompt(self) -> str:
        """
        Obtiene el prompt de sistema para el análisis de CV.
        
        Returns:
            Prompt de sistema
        """
        # Usar prompt personalizado si se proporciona
        if self.system_prompt:
            return self.system_prompt
            
        # Usar prompt predeterminado
        return """You are an expert CV screening assistant. Your task is to analyze CVs and determine if they match the given job criteria.

Your response should be a JSON object with the following structure:
{
    "overall_match": 75,
    "skills_match": {
        "required_skills": {
            "python": 0.9
        },
        "preferred_skills": {
            "docker": 0.7
        },
        "missing_required": [],
        "missing_preferred": []
    },
    "experience_match": {
        "years_of_experience": 5,
        "relevant_experience": 0.8,
        "meets_minimum": true
    },
    "education_match": {
        "has_required_education": true,
        "education_details": {
            "highest_level": "Master's",
            "field": "Computer Science"
        }
    },
    "summary": "Brief evaluation of the candidate"
}"""
    
    def _build_screening_prompt(self, content: str, criteria: Dict[str, Any]) -> str:
        """
        Construye el prompt de análisis.
        
        Args:
            content: Contenido del CV
            criteria: Criterios laborales
        
        Returns:
            Prompt de análisis
        """
        return f"""Please analyze the following CV against the job criteria.

CV Content:
{content}

Job Criteria:
{json.dumps(criteria, indent=2)}

Provide your analysis in JSON format.""" 