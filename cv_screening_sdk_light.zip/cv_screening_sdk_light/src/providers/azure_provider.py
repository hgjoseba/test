"""
Azure OpenAI provider simplified for CV Screening SDK.

This module provides simplified integration with Azure OpenAI.
"""

import logging
import functools
from typing import Any, Dict, List, Optional, Union

from openai import AzureOpenAI
import httpx

from ..core.exceptions import OpenAIError
from .azure_prompt_manager import AzurePromptManager
from .azure_response_handler import AzureResponseHandler


class AzureOpenAIProvider:
    """
    Simplified provider for Azure OpenAI integration.

    This class manages communication with Azure OpenAI API.
    """

    def __init__(
        self,
        endpoint: str,
        api_key: str,
        deployment_name: str = "gpt-4",
        api_version: str = "2023-05-15",
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
        system_prompt: Optional[str] = None,
        connection_verify: bool = True,
    ) -> None:
        """
        Initialize the Azure OpenAI provider.

        Args:
            endpoint: The Azure OpenAI endpoint URL.
            api_key: The API key for Azure OpenAI.
            deployment_name: The deployment name to use (default: "gpt-4").
            api_version: The API version to use (default: "2023-05-15").
            temperature: The temperature to use for generations (default: 0.1).
            max_tokens: The maximum number of tokens to generate (optional).
            system_prompt: A custom system prompt to use (optional).
            connection_verify: Whether to verify SSL connections (default: True).
        """
        self.endpoint = endpoint
        self.api_key = api_key
        self.api_version = api_version
        self.deployment_name = deployment_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.system_prompt = system_prompt
        self.connection_verify = connection_verify
        self.logger = logging.getLogger(__name__)
        self.prompt_manager = AzurePromptManager(system_prompt)
        self.response_handler = AzureResponseHandler()

        try:
            if not self.connection_verify:
                self._apply_http_monkey_patch()

            # Initialize AzureOpenAI client with only the necessary parameters
            # to avoid compatibility issues with different OpenAI SDK versions
            try:
                self.client = AzureOpenAI(
                    azure_endpoint=self.endpoint,
                    api_version=self.api_version,
                    api_key=self.api_key,
                )
                self.logger.info(f"Azure OpenAI provider initialized with deployment: {deployment_name}")
            except TypeError as te:
                # Handle case where AzureOpenAI init signature has changed
                if "unexpected keyword argument" in str(te):
                    self.logger.warning(f"Adapting to OpenAI SDK API changes: {str(te)}")
                    
                    # Try alternative initialization approaches based on the error
                    if "proxies" in str(te):
                        import httpx
                        # Create a custom httpx client with verify=False if needed
                        http_client = httpx.Client(verify=not self.connection_verify)
                        
                        self.client = AzureOpenAI(
                            azure_endpoint=self.endpoint,
                            api_version=self.api_version,
                            api_key=self.api_key,
                            http_client=http_client,
                        )
                    else:
                        # If other parameter issues, try minimal initialization
                        self.client = AzureOpenAI(
                            azure_endpoint=self.endpoint,
                            api_key=self.api_key,
                        )
                    
                    self.logger.info(f"Azure OpenAI provider initialized with alternative configuration for deployment: {deployment_name}")
                else:
                    raise
        except Exception as e:
            self.logger.error(f"Error initializing Azure OpenAI provider: {str(e)}")
            raise OpenAIError(f"Error initializing Azure OpenAI provider: {str(e)}") from e

    def _get_system_prompt(self) -> str:
        """
        Get the system prompt for compatibility with tests.
        
        Returns:
            The system prompt from the prompt manager.
        """
        return self.prompt_manager.get_system_prompt()

    def _apply_http_monkey_patch(self) -> None:
        """
        Apply monkey patch to disable SSL verification in httpx.
        """
        try:
            self.logger.warning("Applying monkey patch to httpx client to disable SSL verification")

            def patch_client_init(original_init):
                @functools.wraps(original_init)
                def new_init(client_self, *args, **kwargs):
                    # Remove proxies parameter as it's not supported in the current version
                    if "proxies" in kwargs:
                        del kwargs["proxies"]
                    kwargs["verify"] = False
                    original_init(client_self, *args, **kwargs)
                return new_init

            self._original_client_init = httpx.Client.__init__
            httpx.Client.__init__ = patch_client_init(self._original_client_init)

            self._original_async_client_init = httpx.AsyncClient.__init__
            httpx.AsyncClient.__init__ = patch_client_init(self._original_async_client_init)

            self.logger.warning("HTTP client monkey patch applied: SSL verification disabled")
        except Exception as e:
            self.logger.error(f"Error applying HTTP monkey patch: {str(e)}")

    def __del__(self):
        """Clean up monkey patches when the instance is destroyed."""
        try:
            if hasattr(self, "_original_client_init") and httpx.Client.__init__ != self._original_client_init:
                httpx.Client.__init__ = self._original_client_init

            if hasattr(self, "_original_async_client_init") and httpx.AsyncClient.__init__ != self._original_async_client_init:
                httpx.AsyncClient.__init__ = self._original_async_client_init
        except Exception:
            pass

    def get_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Get completion from Azure OpenAI.
        """
        try:
            temp = temperature or self.temperature
            tokens = max_tokens or self.max_tokens

            completion = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=messages,
                temperature=temp,
                max_tokens=tokens,
            )
            return completion
        except Exception as e:
            self.logger.error(f"Error getting completion: {str(e)}")
            raise OpenAIError(f"Error getting completion: {str(e)}") from e

    def analyze_cv(self, content: str, criteria: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze a CV against job criteria.
        """
        try:
            messages = [
                {"role": "system", "content": self.prompt_manager.get_system_prompt()},
                {"role": "user", "content": self.prompt_manager.build_screening_prompt(content, criteria)},
            ]
            completion = self.get_completion(messages)
            response_text = completion.choices[0].message.content
            return self.response_handler.process_single_response(response_text)
        except Exception as e:
            self.logger.error(f"Error analyzing CV: {str(e)}")
            raise OpenAIError(f"Error analyzing CV: {str(e)}") from e

    def analyze_multiple_cvs(
        self,
        contents: List[str],
        criteria: Dict[str, Any],
        batch_size: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Analyze multiple CVs against job criteria in a single LLM call.
        
        This method analyzes multiple CVs against the given job criteria.
        If a batch size is provided, the CVs will be processed in batches
        of that size to avoid exceeding token limits.
        
        Args:
            contents: List of CV contents to analyze.
            criteria: Job criteria to evaluate CVs against.
            batch_size: Batch size for processing CVs. If not provided,
                       all CVs will be processed in a single batch.
                        
        Returns:
            A list of results where each element is a dictionary containing
            the analysis for a corresponding CV.
            
        Raises:
            OpenAIError: If an error occurs during analysis.
        """
        try:
            if not contents:
                self.logger.info("No CVs provided for analysis")
                return []
           
            if batch_size is None:
                self.logger.info(f"Processing {len(contents)} CVs in a single batch")
                return self._process_cv_batch(contents, criteria)

            if len(contents) > batch_size:
                self.logger.info(f"Processing {len(contents)} CVs in batches of {batch_size}")
                results = []
                for i in range(0, len(contents), batch_size):
                    batch = contents[i:i + batch_size]
                    self.logger.info(f"Processing batch {i // batch_size + 1}: CVs {i+1} to {min(i + batch_size, len(contents))}")
                    try:
                        batch_results = self._process_cv_batch(batch, criteria, start_index=i)
                        results.extend(batch_results)
                    except Exception as e:
                        self.logger.error(f"Error processing batch {i // batch_size + 1}: {str(e)}")
                        # Continue with the next batch if possible
                        continue
                return results
            else:
                return self._process_cv_batch(contents, criteria)
        except Exception as e:
            self.logger.error(f"Error analyzing multiple CVs: {str(e)}")
            raise OpenAIError(f"Error analyzing multiple CVs: {str(e)}") from e

    def _process_cv_batch(
        self,
        contents: List[str],
        criteria: Dict[str, Any],
        start_index: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Process a batch of CVs in a single LLM call.
        
        Args:
            contents: List of CV contents in the batch.
            criteria: Job criteria to evaluate CVs against.
            start_index: Starting index for the CVs in this batch.
            
        Returns:
            A list of results where each element is a dictionary containing
            the analysis for a corresponding CV.
            
        Raises:
            OpenAIError: If an error occurs during batch processing.
        """
        try:
            messages = [
                {"role": "system", "content": self.prompt_manager.get_system_prompt_for_multiple_cvs(len(contents))},
                {"role": "user", "content": self.prompt_manager.build_multiple_screening_prompt(contents, criteria, start_index)},
            ]

            # Adjust token limit based on the number of CVs
            max_tokens_override = None
            if len(contents) > 2 and self.max_tokens:
                max_tokens_override = self.max_tokens * len(contents)
                self.logger.info(f"Adjusting token limit to {max_tokens_override} for {len(contents)} CVs")
            
            completion = self.get_completion(messages, max_tokens=max_tokens_override)
            response_text = completion.choices[0].message.content
            return self.response_handler.process_batch_response(response_text, start_index)
        except Exception as e:
            self.logger.error(f"Error processing CV batch: {str(e)}")
            raise OpenAIError(f"Error processing CV batch: {str(e)}") from e