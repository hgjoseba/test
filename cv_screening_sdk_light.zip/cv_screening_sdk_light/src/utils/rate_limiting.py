#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Module for rate limiting control in the CV Screening SDK.
Provides classes and functions to manage TPM (Tokens Per Minute) and RPM
(Requests Per Minute) in sequential and distributed environments.
"""

import time
import logging
import threading
import random
import math
import functools
import backoff  # Importamos la librería backoff de PyPI
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any, Union, Tuple, Type, Set
from enum import Enum

# Logging configuration
logger = logging.getLogger("cv_screening.rate_limiter")

# Configurar el logger para backoff
backoff_logger = logging.getLogger('backoff')
backoff_logger.addHandler(logging.StreamHandler())
backoff_logger.setLevel(logging.INFO)


class RateLimitType(Enum):
    """Supported rate limit types"""
    TOKENS_PER_MINUTE = "tpm"
    REQUESTS_PER_MINUTE = "rpm"


class TokenCounter:
    """
    Class to estimate and count tokens consumed in OpenAI requests
    
    This class provides methods to:
    1. Estimate tokens before sending a request
    2. Record actually consumed tokens after a request
    3. Track token consumption per minute
    """
    
    # Estimation factors for different models (tokens per character)
    # Standard factor is 0.25 (about 4 characters per token)
    TOKEN_ESTIMATION_FACTORS = {
        "gpt-3.5-turbo": 0.25,
        "gpt-4": 0.25,
        "gpt-4-turbo": 0.25,
        "gpt-4-32k": 0.25,
        "gpt-35-turbo": 0.25,
        # Default factor for any other model
        "_default": 0.22  # Slightly more conservative for unknown models
    }
    
    def __init__(self):
        """Initialize the token counter"""
        self.token_history = []  # [(timestamp, tokens)]
        self.lock = threading.RLock()
        
    def estimate_tokens(self, text: str, model: str = "gpt-4") -> int:
        """
        Estimate the number of tokens in a text for a specific model
        
        Args:
            text: Text to analyze
            model: OpenAI model to use
        
        Returns:
            Estimated number of tokens
        """
        if not text:
            return 0
            
        # Normalize model name
        model_lower = model.lower()
        
        # Get factor for this model or use the default
        factor = self.TOKEN_ESTIMATION_FACTORS.get(model_lower)
        
        # If model not found, check for similar models or use default
        if factor is None:
            # Check if it contains a known model name
            for known_model in self.TOKEN_ESTIMATION_FACTORS:
                if known_model != '_default' and known_model in model_lower:
                    factor = self.TOKEN_ESTIMATION_FACTORS[known_model]
                    logger.info(f"Using token estimation factor from similar model '{known_model}' for '{model}'")
                    break
            
            # If still not found, use the default factor
            if factor is None:
                factor = self.TOKEN_ESTIMATION_FACTORS["_default"]
                logger.info(f"Using default token estimation factor for model '{model}'")
        
        return math.ceil(len(text) * factor)
    
    def record_tokens(self, tokens: int) -> None:
        """
        Record the actual token consumption of a request
        
        Args:
            tokens: Number of tokens consumed
        """
        with self.lock:
            now = datetime.now()
            self.token_history.append((now, tokens))
            
            # Clean history older than 10 minutes
            cutoff = now - timedelta(minutes=10)
            self.token_history = [(ts, tk) for ts, tk in self.token_history 
                                 if ts >= cutoff]
    
    def get_tokens_last_minute(self) -> int:
        """
        Get the total number of tokens consumed in the last minute
        
        Returns:
            Total tokens in the last minute
        """
        with self.lock:
            now = datetime.now()
            cutoff = now - timedelta(minutes=1)
            
            tokens_last_minute = sum(tokens for ts, tokens in self.token_history 
                                    if ts >= cutoff)
            
            return tokens_last_minute


class RateLimiter:
    """
    Rate limiter implementation to control TPM and RPM
    
    This class provides:
    1. Control of requests per minute
    2. Control of tokens per minute (requires integration with API responses)
    3. Exponential backoff strategies for rate limit errors
    """
    
    def __init__(
        self, 
        max_rpm: int = 100,
        max_tpm: int = 60000,
        max_concurrent: int = 5,
        base_delay: float = 0.1
    ):
        """
        Initialize the rate limiter
        
        Args:
            max_rpm: Maximum requests per minute
            max_tpm: Maximum tokens per minute
            max_concurrent: Maximum concurrent requests
            base_delay: Base delay for exponential backoff (seconds)
        """
        self.max_rpm = max_rpm
        self.max_tpm = max_tpm
        self.max_concurrent = max_concurrent
        self.base_delay = base_delay
        
        # Request history
        self.request_history = []  # [(timestamp, request_id)]
        self.lock = threading.RLock()
        self.semaphore = threading.Semaphore(max_concurrent)
        
        # Token counter
        self.token_counter = TokenCounter()
        
        logger.info(f"Rate limiter initialized: {max_rpm} RPM, {max_tpm} TPM")
    
    def _wait_if_needed(self, tokens_estimate: int = 0) -> None:
        """
        Wait if necessary to comply with rate limits
        
        Args:
            tokens_estimate: Token estimation for the request
        """
        with self.lock:
            now = datetime.now()
            cutoff = now - timedelta(minutes=1)
            
            # Clean old history
            self.request_history = [(ts, req_id) for ts, req_id in self.request_history 
                                   if ts >= cutoff]
            
            # Check RPM
            current_rpm = len(self.request_history)
            
            # Check TPM (if estimation is provided)
            current_tpm = self.token_counter.get_tokens_last_minute()
            estimated_tpm = current_tpm + tokens_estimate
            
            # Determine wait time
            wait_time = 0
            
            if current_rpm >= self.max_rpm:
                # Calculate time until the oldest request expires
                oldest = min(ts for ts, _ in self.request_history)
                time_until_oldest_expires = (oldest + timedelta(minutes=1) - now).total_seconds()
                wait_time = max(wait_time, time_until_oldest_expires)
                
            if tokens_estimate > 0 and estimated_tpm > self.max_tpm:
                # Wait proportionally to the token excess
                token_wait = (estimated_tpm - self.max_tpm) / self.max_tpm * 60
                wait_time = max(wait_time, token_wait)
            
            # Add jitter to avoid synchronization between nodes
            if wait_time > 0:
                jitter = random.uniform(0, 0.1)  # 0-100ms of jitter
                wait_time += jitter
                
                logger.info(f"Waiting {wait_time:.2f}s to comply with rate limits (RPM: {current_rpm}/{self.max_rpm}, TPM est.: {estimated_tpm}/{self.max_tpm})")
                time.sleep(wait_time)
    
    def execute_with_rate_limit(
        self,
        func: Callable,
        *args,
        tokens_estimate: int = 0,
        max_retries: int = 3,
        **kwargs
    ) -> Any:
        """
        Execute a function with rate limit control
        
        Args:
            func: Function to execute
            *args: Arguments for the function
            tokens_estimate: Token estimation for the request
            max_retries: Maximum number of retries
            **kwargs: Keyword arguments for the function
            
        Returns:
            Function result
            
        Raises:
            Exception: If retries are exhausted
        """
        retry_count = 0
        last_exception = None
        
        while retry_count <= max_retries:
            try:
                # Wait if necessary to comply with limits
                self._wait_if_needed(tokens_estimate)
                
                # Acquire semaphore to limit concurrency
                with self.semaphore:
                    # Register request
                    with self.lock:
                        request_id = id(threading.current_thread())
                        self.request_history.append((datetime.now(), request_id))
                    
                    # Execute function
                    result = func(*args, **kwargs)
                    
                    # If the response contains token information, record it
                    if hasattr(result, 'usage') and hasattr(result.usage, 'total_tokens'):
                        self.token_counter.record_tokens(result.usage.total_tokens)
                    elif isinstance(result, dict) and 'usage' in result and 'total_tokens' in result['usage']:
                        self.token_counter.record_tokens(result['usage']['total_tokens'])
                    elif tokens_estimate > 0:
                        # If there's no real information, use the estimation
                        self.token_counter.record_tokens(tokens_estimate)
                    
                    return result
                    
            except Exception as e:
                last_exception = e
                retry_count += 1
                
                # Check if it's a rate limit error
                if any(error_text in str(e).lower() for error_text in 
                      ["rate limit", "too many requests", "quota exceeded"]):
                    
                    # Apply exponential backoff
                    delay = self.base_delay * (2 ** retry_count) + random.uniform(0, 0.1)
                    
                    logger.warning(f"Rate limit error, retrying in {delay:.2f}s (attempt {retry_count}/{max_retries}): {str(e)}")
                    time.sleep(delay)
                else:
                    # Not a rate limit error, propagate
                    raise
        
        # If we get here, retries are exhausted
        logger.error(f"Retries exhausted. Last error: {str(last_exception)}")
        raise last_exception


class DistributedRateLimiter(RateLimiter):
    """
    Distributed version of the rate limiter that can coordinate between distributed nodes
    
    This class extends RateLimiter to:
    1. Scale limits according to the number of nodes/executors
    2. Optionally use an external service for coordination
    
    Note: In a fully distributed environment like Spark, an external service
    like Redis would be needed for real coordination. This implementation is
    an approximation for use on independent nodes.
    """
    
    def __init__(
        self,
        max_rpm: int = 100,
        max_tpm: int = 60000,
        max_concurrent: int = 5,
        base_delay: float = 0.1,
        node_count: int = 1,
        node_id: str = None,
        coordination_service: Any = None
    ):
        """
        Initialize the distributed rate limiter
        
        Args:
            max_rpm: Maximum requests per minute (global)
            max_tpm: Maximum tokens per minute (global)
            max_concurrent: Maximum concurrent requests (per node)
            base_delay: Base delay for exponential backoff
            node_count: Number of nodes/executors in the cluster
            node_id: Unique identifier for this node
            coordination_service: Optional coordination service (e.g.: Redis client)
        """
        # Scale limits according to node count
        node_rpm = max(1, max_rpm // node_count)
        node_tpm = max(1, max_tpm // node_count)
        
        super().__init__(
            max_rpm=node_rpm,
            max_tpm=node_tpm,
            max_concurrent=max_concurrent,
            base_delay=base_delay
        )
        
        self.node_count = node_count
        self.node_id = node_id or str(random.randint(10000, 99999))
        self.coordination_service = coordination_service
        
        logger.info(f"Distributed rate limiter initialized: Node {self.node_id}, "
                   f"Total: {max_rpm} RPM / {max_tpm} TPM, "
                   f"Per node: {node_rpm} RPM / {node_tpm} TPM")
    
    def update_cluster_size(self, new_node_count: int) -> None:
        """
        Update the cluster size and recalculate limits
        
        Args:
            new_node_count: New number of nodes
        """
        if new_node_count <= 0:
            raise ValueError("Node count must be positive")
            
        with self.lock:
            global_rpm = self.max_rpm * self.node_count
            global_tpm = self.max_tpm * self.node_count
            
            self.node_count = new_node_count
            self.max_rpm = max(1, global_rpm // new_node_count)
            self.max_tpm = max(1, global_tpm // new_node_count)
            
            logger.info(f"Limits updated for {new_node_count} nodes: "
                       f"{self.max_rpm} RPM, {self.max_tpm} TPM per node")


# Backoff decorator for exception handling

def backoff(
    max_retries: int = 3,
    exceptions: Union[Type[Exception], Set[Type[Exception]]] = Exception,
    base_delay: float = 0.1,
    max_delay: float = 60.0,
    jitter: bool = True
) -> Callable:
    """
    Decorator that implements exponential backoff retry logic for functions that may fail.
    
    This is a wrapper around the PyPI 'backoff' library that maintains compatibility with
    existing code while providing more powerful functionality.
    
    Args:
        max_retries: Maximum number of retries before giving up.
        exceptions: Exception or set of exceptions that trigger a retry.
        base_delay: Initial delay between retries in seconds.
        max_delay: Maximum delay between retries in seconds.
        jitter: Whether to add randomness to the delay time.
        
    Returns:
        Decorated function with retry logic.
        
    Example:
        @backoff(max_retries=5, exceptions={ConnectionError, TimeoutError})
        def fetch_data():
            # This function will automatically retry up to 5 times
            # with exponential backoff if it raises ConnectionError or TimeoutError
            ...
    """
    # If exceptions is a single exception type, convert to a set
    if isinstance(exceptions, type) and issubclass(exceptions, Exception):
        exceptions = {exceptions}
        
    # Convert our parameters to backoff library parameters
    jitter_func = backoff.full_jitter if jitter else None
    max_tries = max_retries + 1  # backoff counts the initial attempt

    # Return the backoff.on_exception decorator with our parameters
    return backoff.on_exception(
        wait_gen=backoff.expo,
        exception=tuple(exceptions),
        max_tries=max_tries,
        factor=base_delay,
        max_value=max_delay,
        jitter=jitter_func,
        logger=logger
    )


def backoff_on_predicate(
    max_retries: int = 3,
    predicate: Callable[[Any], bool] = lambda x: x is None,
    base_delay: float = 0.1,
    max_delay: float = 60.0,
    jitter: bool = True
) -> Callable:
    """
    Decorator that implements exponential backoff retry logic based on function return value.
    
    This decorator will retry a function call if the predicate function returns True when
    called with the decorated function's return value.
    
    Args:
        max_retries: Maximum number of retries before giving up.
        predicate: A function that takes the return value of the decorated function and returns
                  True if a retry should be performed. Default is to retry on None.
        base_delay: Initial delay between retries in seconds.
        max_delay: Maximum delay between retries in seconds.
        jitter: Whether to add randomness to the delay time.
        
    Returns:
        Decorated function with retry logic.
        
    Example:
        @backoff_on_predicate(max_retries=5, predicate=lambda x: not x.get('success', False))
        def fetch_data():
            # This function will retry up to 5 times if it returns a dict without 'success': True
            ...
    """
    # Convert our parameters to backoff library parameters
    jitter_func = backoff.full_jitter if jitter else None
    max_tries = max_retries + 1  # backoff counts the initial attempt
    
    # Return the backoff.on_predicate decorator with our parameters
    return backoff.on_predicate(
        wait_gen=backoff.expo,
        predicate=predicate,
        max_tries=max_tries,
        factor=base_delay,
        max_value=max_delay,
        jitter=jitter_func,
        logger=logger
    )


# Utility functions for parallel processing

def estimate_cv_tokens(cv_content: str, prompt: Optional[str] = None, model: str = "gpt-4") -> int:
    """
    Estimate the tokens that a CV analysis will consume
    
    Args:
        cv_content: CV content
        prompt: Additional prompt (instructions or criteria)
        model: Model to use
        
    Returns:
        Token estimation
    """
    token_counter = TokenCounter()
    
    # Estimate CV tokens
    cv_tokens = token_counter.estimate_tokens(cv_content, model)
    
    # Estimate prompt/criteria tokens
    prompt_tokens = token_counter.estimate_tokens(prompt, model) if prompt else 0
    
    # Add system tokens and safety margin (30%)
    system_tokens = 200  # Estimation for the system prompt
    margin = int((cv_tokens + prompt_tokens + system_tokens) * 0.3)
    
    total_estimate = cv_tokens + prompt_tokens + system_tokens + margin
    
    return total_estimate


# Advanced example of backoff usage
def example_advanced_backoff():
    """
    Advanced example of how to use the backoff library directly for more complex retry scenarios.
    This is not used in the SDK but provided as reference for users who want to implement
    custom retry logic.
    
    The SDK's backoff function is a simplified wrapper around these capabilities.
    """
    # Example 1: Predicate-based backoff (retry based on return value)
    @backoff.on_predicate(
        backoff.expo,
        predicate=lambda x: x is None or x.get('status') != 'success',
        max_tries=5,
        jitter=backoff.full_jitter
    )
    def retry_until_success():
        # This will retry if the function returns None or doesn't return {'status': 'success'}
        pass
    
    # Example 2: Combining exception and predicate backoff
    @backoff.on_exception(
        backoff.expo,
        (ConnectionError, TimeoutError),
        max_tries=3
    )
    @backoff.on_predicate(
        backoff.expo,
        predicate=lambda x: not x.get('success', False),
        max_tries=3
    )
    def retry_with_multiple_conditions():
        # This will retry for both exceptions and unsuccessful responses
        pass
    
    # Example 3: Custom backoff handler
    def on_backoff(details):
        logger.warning(
            f"Backing off {details['wait']:0.1f} seconds after {details['tries']} tries "
            f"calling function {details['target'].__name__} with args {details['args']} "
            f"and kwargs {details['kwargs']}"
        )
    
    @backoff.on_exception(
        backoff.expo,
        Exception,
        on_backoff=on_backoff,
        max_tries=5
    )
    def function_with_custom_handler():
        # This will use a custom handler for backoff events
        pass
    
    # Example 4: Custom giveup condition
    def give_up_if_unauthorized(e):
        # Don't retry on 401 Unauthorized errors
        return hasattr(e, 'status_code') and e.status_code == 401
    
    @backoff.on_exception(
        backoff.expo,
        Exception,
        giveup=give_up_if_unauthorized,
        max_tries=5
    )
    def function_with_custom_giveup():
        # This will not retry on 401 errors
        pass


# Helper functions for distributed environments

def create_rate_limiter_for_distributed(
    global_rpm: int = 1000,
    global_tpm: int = 240000,
    node_count: int = 4,
    node_id: Optional[str] = None
) -> DistributedRateLimiter:
    """
    Create a rate limiter for use in distributed environments.
    
    Args:
        global_rpm: Total RPM for the whole system
        global_tpm: Total TPM for the whole system
        node_count: Number of nodes/executors
        node_id: Unique identifier for this node
        
    Returns:
        DistributedRateLimiter instance
    """
    if node_id is None:
        # Generate a unique ID for this node
        try:
            import socket
            import os
            hostname = socket.gethostname()
            pid = os.getpid()
            node_id = f"{hostname}-{pid}"
        except:
            node_id = str(random.randint(10000, 99999))
    
    return DistributedRateLimiter(
        max_rpm=global_rpm,
        max_tpm=global_tpm,
        max_concurrent=5,
        base_delay=0.1,
        node_count=node_count,
        node_id=node_id
    ) 