"""
Parallel processing utilities for CV Screening SDK.

This module provides utilities for parallel processing of CVs
in batch mode, allowing efficient use of worker resources.
"""

import logging
import concurrent.futures
from typing import List, Dict, Any, Union, Optional, Callable
import math

from ..core.types import ContentType
from ..client import CVScreeningClient

logger = logging.getLogger(__name__)

def process_partition(
    client: CVScreeningClient,
    cvs_partition: List[Union[str, bytes]],
    criteria: Any = None,
    content_type: ContentType = ContentType.TEXT,
    schema_json_ob: Optional[Dict[str, Any]] = None,
    use_rate_limiting: bool = True,
    max_retries: int = 3,
    max_workers: int = None,
    batch_size: int = 5,
    timeout: Optional[float] = None,
    on_success: Optional[Callable[[Dict[str, Any]], None]] = None,
    on_error: Optional[Callable[[Exception, Union[str, bytes]], None]] = None
) -> List[Dict[str, Any]]:
    """
    Process a partition of CVs in parallel using threads.
    
    This function analyzes multiple CVs concurrently using a ThreadPoolExecutor,
    which allows more efficient use of worker resources by running multiple
    CV analysis tasks in parallel. Each thread processes a batch of CVs using
    analyze_multiple_cvs.
    
    Args:
        client: The CVScreeningClient instance to use for analysis
        cvs_partition: List of CV contents to analyze
        criteria: Job criteria for CV analysis
        content_type: Type of content provided (default: ContentType.TEXT)
        schema_json_ob: Optional JSON schema for response formatting
        use_rate_limiting: Whether to apply rate limiting (default: True)
        max_retries: Maximum number of retries for rate limit errors (default: 3)
        max_workers: Maximum number of worker threads (default: None, which uses CPU count)
        batch_size: Number of CVs to process in each thread (default: 5)
        timeout: Maximum time to wait for all tasks to complete (in seconds, None for no timeout)
        on_success: Optional callback function to call with each successful result
        on_error: Optional callback function to call with each error
    
    Returns:
        List of analysis results from processed CVs
        
    Example:
        ```python
        client = CVScreeningClient(...)
        cvs = [cv1, cv2, cv3, ..., cv20]
        criteria = {"skills": ["Python", "Machine Learning"]}
        
        # Process CVs in parallel with 4 worker threads, 5 CVs per thread
        results = process_partition(client, cvs, criteria, max_workers=4, batch_size=5)
        ```
    """
    results = []
    errors = []
    
    # Divide CVs into batches
    cv_batches = []
    cv_indices = []
    
    for i in range(0, len(cvs_partition), batch_size):
        end = min(i + batch_size, len(cvs_partition))
        batch = cvs_partition[i:end]
        indices = list(range(i, end))
        
        cv_batches.append(batch)
        cv_indices.append(indices)
    
    logger.info(f"Dividing {len(cvs_partition)} CVs into {len(cv_batches)} analysis batches")
    
    def analyze_cv_batch(batch, indices):
        """Process a batch of CVs and handle results/errors"""
        try:
            # Use analyze_multiple_cvs to process the entire batch
            batch_results = client.analyze_multiple_cvs(
                contents=batch,
                criteria=criteria,
                content_type=content_type,
                schema_json_ob=schema_json_ob,
                use_rate_limiting=use_rate_limiting,
                max_retries=max_retries,
                batch_size=None  # Process the entire batch as a single group
            )
            
            # Add original indices to the results
            for i, result in enumerate(batch_results):
                original_index = indices[i]
                result["_original_index"] = original_index
                
                # Execute callback if it exists
                if on_success:
                    try:
                        on_success(result)
                    except Exception as callback_error:
                        logger.error(f"Error in success callback: {str(callback_error)}")
            
            return batch_results
            
        except Exception as e:
            logger.error(f"Error processing CV batch {indices}: {str(e)}")
            
            # Generate error results for the entire batch
            error_results = []
            for i, cv in enumerate(batch):
                original_index = indices[i]
                
                # Execute error callback if it exists
                if on_error:
                    try:
                        on_error(e, cv)
                    except Exception as callback_error:
                        logger.error(f"Error in error callback: {str(callback_error)}")
                
                # Create error object
                error_result = {
                    "error": str(e),
                    "_original_index": original_index,
                    "_error": True
                }
                error_results.append(error_result)
            
            return error_results
    
    # Use ThreadPoolExecutor to process batches in parallel
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all tasks
        future_to_batch = {
            executor.submit(analyze_cv_batch, batch, indices): indices
            for batch, indices in zip(cv_batches, cv_indices)
        }
        
        # Process results as they complete
        for future in concurrent.futures.as_completed(future_to_batch, timeout=timeout):
            try:
                batch_results = future.result()
                results.extend(batch_results)
            except Exception as e:
                batch_indices = future_to_batch[future]
                logger.error(f"Exception in task for batch {batch_indices}: {str(e)}")
                
                # Create error objects for all CVs in this batch
                for idx in batch_indices:
                    error_result = {
                        "error": str(e),
                        "_original_index": idx,
                        "_error": True
                    }
                    results.append(error_result)
                    errors.append((idx, e))
    
    # Sort results to maintain original order
    results.sort(key=lambda x: x["_original_index"])
    
    # Log summary
    success_count = len(results) - len(errors)
    logger.info(f"Parallel processing completed: {success_count} successful, {len(errors)} failed")
    
    return results 