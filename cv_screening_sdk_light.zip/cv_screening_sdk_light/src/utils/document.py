"""
Document utilities for CV Screening SDK.
"""

import os
import logging
import base64
from typing import Optional, Union, List
from contextlib import contextmanager

from ..core.exceptions import DocumentParsingError

logger = logging.getLogger(__name__)

# Flag to check dependencies only once
_DEPENDENCIES_CHECKED = {
    "pdf": False,
    "docx": False
}

# Results of dependency checks
_HAS_PDF_DEPENDENCY = False
_HAS_DOCX_DEPENDENCY = False


def _check_pdf_dependency() -> bool:
    """Check if pypdf dependency is available."""
    global _HAS_PDF_DEPENDENCY, _DEPENDENCIES_CHECKED
    
    if not _DEPENDENCIES_CHECKED["pdf"]:
        try:
            import pypdf
            _HAS_PDF_DEPENDENCY = True
        except ImportError:
            _HAS_PDF_DEPENDENCY = False
        _DEPENDENCIES_CHECKED["pdf"] = True
    
    return _HAS_PDF_DEPENDENCY


def _check_docx_dependency() -> bool:
    """Check if python-docx dependency is available."""
    global _HAS_DOCX_DEPENDENCY, _DEPENDENCIES_CHECKED
    
    if not _DEPENDENCIES_CHECKED["docx"]:
        try:
            import docx
            _HAS_DOCX_DEPENDENCY = True
        except ImportError:
            _HAS_DOCX_DEPENDENCY = False
        _DEPENDENCIES_CHECKED["docx"] = True
    
    return _HAS_DOCX_DEPENDENCY


@contextmanager
def _safe_open(file_path: str, mode: str = 'r', encoding: Optional[str] = 'utf-8'):
    """Safely open a file and ensure it's closed properly."""
    f = None
    try:
        if 'b' in mode:
            f = open(file_path, mode)
        else:
            f = open(file_path, mode, encoding=encoding)
        yield f
    finally:
        if f is not None:
            f.close()


def load_cv_content(file_path: str) -> str:
    """
    Load CV content from a file.
    
    This helper method loads CV content from common file formats.
    For PDF and DOCX support, the optional dependencies must be installed.
    
    Args:
        file_path: Path to the CV file
    
    Returns:
        String content of the CV
    
    Raises:
        DocumentParsingError: If the file cannot be parsed
        FileNotFoundError: If the file does not exist
    """
    logger.info(f"Loading CV content from: {file_path}")
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    file_ext = os.path.splitext(file_path)[1].lower()
    
    # Simple text files
    if file_ext in ['.txt']:
        try:
            with _safe_open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except UnicodeDecodeError as e:
            raise DocumentParsingError(f"Failed to decode text file (encoding issue): {str(e)}")
        except Exception as e:
            raise DocumentParsingError(f"Failed to read text file: {str(e)}")
    
    # PDF files require pypdf
    elif file_ext in ['.pdf']:
        if not _check_pdf_dependency():
            raise DocumentParsingError(
                "PDF parsing requires pypdf. Install with: pip install 'cv-screening-sdk[document_processing]'"
            )
        
        try:
            import pypdf
            content = []
            
            with _safe_open(file_path, 'rb') as f:
                pdf_reader = pypdf.PdfReader(f)
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    extracted_text = page.extract_text()
                    if extracted_text:  # Only add non-empty pages
                        content.append(extracted_text)
            
            if not content:
                logger.warning(f"PDF file {file_path} appears to be empty or unreadable.")
            
            return '\n'.join(content)
        except pypdf.errors.PdfReadError as e:
            raise DocumentParsingError(f"Failed to parse PDF (file may be corrupted): {str(e)}")
        except Exception as e:
            raise DocumentParsingError(f"Failed to parse PDF: {str(e)}")
    
    # DOCX files require python-docx
    elif file_ext in ['.docx']:
        if not _check_docx_dependency():
            raise DocumentParsingError(
                "DOCX parsing requires python-docx. Install with: pip install 'cv-screening-sdk[document_processing]'"
            )
        
        try:
            import docx
            
            doc = docx.Document(file_path)
            content: List[str] = []
            
            # Extract paragraphs
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():  # Skip empty paragraphs
                    content.append(paragraph.text)
            
            # Also extract text from tables if present
            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        for paragraph in cell.paragraphs:
                            if paragraph.text.strip():
                                content.append(paragraph.text)
            
            if not content:
                logger.warning(f"DOCX file {file_path} appears to be empty.")
            
            return '\n'.join(content)
        except Exception as e:
            raise DocumentParsingError(f"Failed to parse DOCX: {str(e)}")
    
    else:
        raise DocumentParsingError(f"Unsupported file format: {file_ext}")


def load_cv_from_base64(base64_content: Union[str, bytes]) -> str:
    """
    Load CV content from a base64 encoded string.
    
    This helper method decodes base64 content into text.
    
    Args:
        base64_content: Base64 encoded content as string or bytes
    
    Returns:
        String content of the CV
    
    Raises:
        DocumentParsingError: If the content cannot be decoded
    """
    logger.info("Loading CV content from base64")
    
    if not base64_content:
        raise DocumentParsingError("Empty base64 content provided")
    
    try:
        # Convert to bytes if it's a string
        if isinstance(base64_content, str):
            base64_bytes = base64_content.encode('utf-8')
        else:
            base64_bytes = base64_content
        
        # Decode base64
        try:
            decoded_bytes = base64.b64decode(base64_bytes, validate=True)
        except Exception as e:
            raise DocumentParsingError(f"Invalid base64 format: {str(e)}")
        
        # Try to decode as UTF-8, fallback to latin-1 if that fails
        try:
            decoded_content = decoded_bytes.decode('utf-8')
        except UnicodeDecodeError:
            try:
                decoded_content = decoded_bytes.decode('latin-1')
                logger.warning("Base64 content could not be decoded as UTF-8, fell back to latin-1")
            except UnicodeDecodeError as e:
                raise DocumentParsingError(f"Failed to decode content after base64 decoding: {str(e)}")
        
        return decoded_content
    except DocumentParsingError:
        raise  # Re-raise DocumentParsingError
    except Exception as e:
        raise DocumentParsingError(f"Failed to decode base64 content: {str(e)}")


def is_base64(content: Union[str, bytes]) -> bool:
    """
    Check if the given content is likely base64 encoded.
    
    Args:
        content: Content to check
    
    Returns:
        True if the content looks like base64, False otherwise
    """
    if not content:
        return False
    
    if isinstance(content, str):
        # Quick check for characters that aren't in base64
        invalid_chars = set(content) - set('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=')
        if invalid_chars:
            return False
        
        content = content.encode('utf-8')
    
    try:
        # Try to decode with validate=True to ensure proper padding
        base64.b64decode(content, validate=True)
        return True
    except Exception:
        return False 