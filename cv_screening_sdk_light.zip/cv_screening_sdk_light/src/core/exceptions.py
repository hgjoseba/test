"""
Exceptions for CV Screening SDK.
"""


class SDKError(Exception):
    """Base exception for CV Screening SDK."""
    pass


class ConfigurationError(SDKError):
    """Error in configuration."""
    pass


class OpenAIError(SDKError):
    """Error when using OpenAI API."""
    pass


class RateLimitError(OpenAIError):
    """Error when API rate limits are exceeded."""
    pass


class DocumentParsingError(SDKError):
    """Error when parsing documents."""
    pass


class ValidationError(SDKError):
    """Error when validating input data."""
    pass


class AuthenticationError(SDKError):
    """Error in authentication process."""
    pass 