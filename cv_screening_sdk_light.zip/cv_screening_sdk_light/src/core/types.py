"""
Types definitions for CV Screening SDK.
"""

from enum import Enum, auto


class ContentType(Enum):
    """Enum to represent different content types for CV data."""
    TEXT = auto()         # Plain text content
    BASE64 = auto()       # Base64 encoded content
    FILE_PATH = auto()    # Path to a file on disk
    
    @classmethod
    def from_string(cls, value: str) -> 'ContentType':
        """
        Convert string to ContentType enum.
        
        Args:
            value: String representation of content type
            
        Returns:
            ContentType enum value
            
        Raises:
            ValueError: If value is not a valid content type
        """
        mapping = {
            'text': cls.TEXT,
            'base64': cls.BASE64,
            'file': cls.FILE_PATH,
            'file_path': cls.FILE_PATH,
        }
        
        value_lower = value.lower()
        if value_lower in mapping:
            return mapping[value_lower]
        
        raise ValueError(f"Invalid content type: '{value}'. Valid types are: {', '.join(mapping.keys())}") 