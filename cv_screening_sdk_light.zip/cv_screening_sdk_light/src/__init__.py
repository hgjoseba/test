"""
CV Screening SDK

A SDK for screening CVs using OpenAI API.
Rate limiting functionality now uses the backoff library from PyPI.
"""

from .client import CVScreeningClient
from .utils.rate_limiting import (
    RateLimiter, DistributedRateLimiter, TokenCounter, 
    backoff, backoff_on_predicate
)
from .utils.parallel import process_partition

__version__ = "0.1.0"
__all__ = [
    "CVScreeningClient",
    "RateLimiter",
    "DistributedRateLimiter",
    "TokenCounter",
    "backoff",
    "backoff_on_predicate",
    "process_partition"
] 