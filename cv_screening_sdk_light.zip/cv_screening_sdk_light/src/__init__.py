"""
CV Screening SDK

A SDK for screening CVs using OpenAI API.
"""

from .client import CVScreeningClient

__version__ = "0.1.0"
__all__ = ["CVScreeningClient"] 