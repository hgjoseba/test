"""
Utilities for CV Screening SDK Light.
"""

from .document import load_cv_content

__all__ = ["load_cv_content"] 