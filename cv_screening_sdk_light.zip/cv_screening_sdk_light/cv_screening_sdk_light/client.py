"""
Main client for CV screening operations.

This module provides the main entry point for the CV Screening SDK Light,
handling CV analysis with a simplified interface.
"""

import logging
import os
from typing import Any, Dict, List, Optional, Union

from .core.config import Config
from .core.exceptions import ConfigurationError, OpenAIError, ValidationError
from .models.criteria import JobCriteria
from .providers.azure_provider import AzureOpenAIProvider
from .utils.document import load_cv_content

logger = logging.getLogger(__name__)


class CVScreeningClient:
    """
    Client for CV screening using Azure OpenAI.
    
    This is the main client class for interacting with the CV Screening SDK Light.
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        endpoint: Optional[str] = None,
        model_name: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        connection_verify: Optional[bool] = None,
        system_prompt: Optional[str] = None,
    ):
        """
        Initialize the client.
        
        Args:
            api_key: Azure OpenAI API key (defaults to AZURE_OPENAI_API_KEY environment variable)
            endpoint: Azure OpenAI endpoint (defaults to AZURE_OPENAI_ENDPOINT environment variable)
            model_name: Model deployment name (defaults to AZURE_OPENAI_DEPLOYMENT or "gpt-4")
            temperature: Sampling temperature (defaults to OPENAI_TEMPERATURE or 0.1)
            max_tokens: Maximum tokens to generate (defaults to OPENAI_MAX_TOKENS or None)
            connection_verify: Whether to verify SSL connections (defaults to OPENAI_CONNECTION_VERIFY or True)
            system_prompt: Custom system prompt to use (defaults to OPENAI_SYSTEM_PROMPT or None)
        
        Raises:
            ConfigurationError: If the configuration is invalid
        """
        try:
            # Create config with defaults from environment variables
            self.config = Config()
            
            # Override config with provided values
            if api_key:
                self.config.openai.api_key = api_key
            if endpoint:
                self.config.azure.endpoint = endpoint
            if model_name:
                self.config.openai.model_name = model_name
            if temperature is not None:
                self.config.openai.temperature = temperature
            if max_tokens is not None:
                self.config.openai.max_tokens = max_tokens
            if connection_verify is not None:
                self.config.openai.connection_verify = connection_verify
            if system_prompt is not None:
                self.config.openai.system_prompt = system_prompt
            
            # Validate API key and endpoint
            if not self.config.openai.api_key:
                self.config.openai.api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")
                if not self.config.openai.api_key:
                    raise ConfigurationError(
                        "Azure OpenAI API key is required. Provide it as a parameter or set the AZURE_OPENAI_API_KEY environment variable."
                    )
            
            if not self.config.azure.endpoint:
                self.config.azure.endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
                if not self.config.azure.endpoint:
                    raise ConfigurationError(
                        "Azure OpenAI endpoint is required. Provide it as a parameter or set the AZURE_OPENAI_ENDPOINT environment variable."
                    )
            
            # Initialize provider
            self.provider = AzureOpenAIProvider(
                endpoint=self.config.azure.endpoint,
                api_key=self.config.openai.api_key,
                deployment_name=self.config.openai.model_name,
                temperature=self.config.openai.temperature,
                max_tokens=self.config.openai.max_tokens,
                connection_verify=self.config.openai.connection_verify,
                system_prompt=self.config.openai.system_prompt,
            )
            
            self.logger = logging.getLogger(__name__)
            self.logger.info("CV Screening SDK Light client initialized with Azure OpenAI")
        except Exception as e:
            logger.error(f"Failed to initialize client: {str(e)}")
            raise ConfigurationError(f"Failed to initialize client: {str(e)}") from e
    
    def analyze_cv(
        self,
        content: str,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> Dict[str, Any]:
        """
        Analyze a CV against given criteria.
        
        This is the main method for CV screening. It analyzes a single CV
        against the provided criteria and returns the raw analysis results.
        
        Args:
            content: CV content as text
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
        
        Returns:
            Raw analysis results from Azure OpenAI
        
        Raises:
            OpenAIError: If the analysis fails
        """
        self.logger.info("Starting CV analysis")
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        try:
            # Analyze with Azure OpenAI
            result = self.provider.analyze_cv(content, criteria_dict)
            
            self.logger.info("CV analysis completed")
            return result
        except Exception as e:
            self.logger.error(f"Failed to analyze CV: {str(e)}")
            raise OpenAIError(f"Failed to analyze CV: {str(e)}") from e
    
    def _process_criteria(
        self,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> Dict[str, Any]:
        """
        Process criteria to a dictionary format.
        
        Args:
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
        
        Returns:
            Criteria as dictionary
        """
        if criteria is None:
            return {}
        
        if isinstance(criteria, JobCriteria):
            return criteria.to_dict()
        
        if isinstance(criteria, str):
            return {"prompt": criteria}
        
        if isinstance(criteria, dict):
            return criteria
        
        raise TypeError(f"Unsupported criteria type: {type(criteria)}")
    
    # Expose utility method directly
    @staticmethod
    def load_cv_content(file_path: str) -> str:
        """
        Load CV content from a file.
        
        This is a convenience method that delegates to the utility function.
        
        Args:
            file_path: Path to the CV file
        
        Returns:
            String content of the CV
        
        Raises:
            DocumentParsingError: If the file cannot be parsed
            FileNotFoundError: If the file does not exist
        """
        return load_cv_content(file_path) 