"""
Models for CV Screening SDK Light.
"""

from .criteria import JobCriteria

__all__ = ["JobCriteria"] 