"""
Exceptions for CV Screening SDK Light.
"""


class SDKLightError(Exception):
    """Base exception for CV Screening SDK Light."""
    pass


class ConfigurationError(SDKLightError):
    """Error in configuration."""
    pass


class OpenAIError(SDKLightError):
    """Error when using OpenAI API."""
    pass


class DocumentParsingError(SDKLightError):
    """Error when parsing documents."""
    pass


class ValidationError(SDKLightError):
    """Error when validating input data."""
    pass


class AuthenticationError(SDKLightError):
    """Error in authentication process."""
    pass 