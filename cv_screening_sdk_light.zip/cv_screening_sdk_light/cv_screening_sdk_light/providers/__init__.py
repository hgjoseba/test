"""
Providers for CV Screening SDK Light.

This package provides provider implementations for different services.
"""

from .azure_provider import AzureOpenAIProvider

__all__ = ["AzureOpenAIProvider"] 