"""
Command-line interface for CV Screening SDK Light.
"""

import argparse
import json
import os
import sys
from typing import Dict, Any

from .client import CVScreeningClient
from .models.criteria import JobCriteria
from .core.exceptions import SDKLightError


def load_criteria_from_file(file_path: str) -> Dict[str, Any]:
    """
    Load job criteria from a JSON file.
    
    Args:
        file_path: Path to JSON file with criteria
    
    Returns:
        Criteria dictionary
    
    Raises:
        FileNotFoundError: If file does not exist
        JSONDecodeError: If file is not valid JSON
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(description="CV Screening SDK Light CLI")
    
    parser.add_argument("cv_file", help="Path to CV file (PDF, DOCX, or TXT)")
    parser.add_argument(
        "--criteria", "-c", 
        help="Path to JSON file with job criteria"
    )
    parser.add_argument(
        "--api-key", "-k",
        help="OpenAI API key (defaults to OPENAI_API_KEY environment variable)"
    )
    parser.add_argument(
        "--model", "-m",
        help="OpenAI model name (defaults to OPENAI_MODEL_NAME or gpt-4)"
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file for results (defaults to stdout)"
    )
    parser.add_argument(
        "--pretty", "-p", action="store_true",
        help="Pretty-print JSON output"
    )
    
    args = parser.parse_args()
    
    try:
        # Load criteria if provided
        criteria = None
        if args.criteria:
            criteria = load_criteria_from_file(args.criteria)
        
        # Initialize client
        client = CVScreeningClient(
            api_key=args.api_key,
            model_name=args.model
        )
        
        # Load CV content
        cv_content = client.load_cv_content(args.cv_file)
        
        # Analyze CV
        result = client.analyze_cv(cv_content, criteria)
        
        # Format output
        indent = 2 if args.pretty else None
        output = json.dumps(result, indent=indent)
        
        # Write output
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(output)
            print(f"Results written to {args.output}")
        else:
            print(output)
        
        return 0
    
    except SDKLightError as e:
        print(f"Error: {str(e)}", file=sys.stderr)
        return 1
    except FileNotFoundError as e:
        print(f"File not found: {str(e)}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as e:
        print(f"Invalid JSON: {str(e)}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected error: {str(e)}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main()) 