# Control de TPMs y RPMs para el SDK de CV Screening en Spark

Este documento explica la implementación del control de TPMs (Tokens Por Minuto) y RPMs (Requests Por Minuto) en entornos distribuidos Spark para el CV Screening SDK.

## Índice
1. [Conceptos básicos](#conceptos-básicos)
2. [Implementación en Spark](#implementación-en-spark)
3. [Configuraciones recomendadas](#configuraciones-recomendadas)
4. [Ejemplos de uso](#ejemplos-de-uso)
5. [Monitoreo y ajuste](#monitoreo-y-ajuste)

## Conceptos básicos

### ¿Qué son TPM y RPM?

- **TPM (Tokens Por Minuto)**: Límite de tokens que se pueden procesar por minuto en los modelos de Azure OpenAI. Cada modelo tiene un límite de TPM específico según el tipo de suscripción.
- **RPM (Requests Por Minuto)**: Límite de peticiones que se pueden hacer a la API por minuto.

### Importancia del control de límites

En entornos distribuidos como Spark, es crucial controlar estos límites porque:

1. **Evitar errores de limitación de tasa**: Si se exceden los límites, Azure OpenAI devuelve errores 429 (Too Many Requests).
2. **Optimizar recursos**: Un control adecuado permite aprovechar al máximo la cuota disponible sin desperdiciarla.
3. **Costos controlados**: Ayuda a predecir y controlar los costos asociados al uso de la API.

### Desafíos en entornos distribuidos

El principal desafío en Spark es que el procesamiento ocurre en paralelo en múltiples ejecutores, lo que complica:

1. **Coordinación**: Los ejecutores no comparten estado naturalmente.
2. **Distribución equitativa**: Necesitamos dividir los límites entre los ejecutores.
3. **Gestión de fallos**: Los reinicios de ejecutores pueden romper el seguimiento de límites.

## Implementación en Spark

Nuestra solución se basa en tres componentes principales:

### 1. Contador de tokens

La clase `TokenCounter` estima y registra el uso de tokens:

```python
class TokenCounter:
    def estimate_tokens(self, text: str, model: str = "gpt-4") -> int:
        # Estima tokens antes de enviar la petición
        
    def record_tokens(self, tokens: int) -> None:
        # Registra tokens consumidos después de la petición
        
    def get_tokens_last_minute(self) -> int:
        # Devuelve el total de tokens del último minuto
```

### 2. Limitador de tasa

La clase `RateLimiter` implementa el control de límites local:

```python
class RateLimiter:
    def __init__(self, max_rpm: int = 100, max_tpm: int = 60000):
        # Inicializa con límites
        
    def _wait_if_needed(self, tokens_estimate: int = 0) -> None:
        # Espera si es necesario para cumplir límites
        
    def execute_with_rate_limit(self, func, *args, **kwargs) -> Any:
        # Ejecuta función con control de límites y reintentos
```

### 3. Limitador distribuido

La clase `DistributedRateLimiter` adapta los límites para entornos distribuidos:

```python
class DistributedRateLimiter(RateLimiter):
    def __init__(self, max_rpm, max_tpm, node_count):
        # Divide límites entre ejecutores
        node_rpm = max_rpm // node_count
        node_tpm = max_tpm // node_count
        super().__init__(max_rpm=node_rpm, max_tpm=node_tpm)
```

## Configuraciones recomendadas

### Límites por modelo

| Modelo | TPM típico | RPM recomendado |
|--------|------------|-----------------|
| gpt-4  | 80,000     | 500             |
| gpt-4-turbo | 120,000 | 600           |
| gpt-35-turbo | 240,000 | 1,000        |

### Cálculo de recursos

Para distribuir los límites correctamente, es importante:

1. **Conocer el total de ejecutores**: `spark.executor.instances`
2. **Dividir los límites**: TPM global ÷ Número de ejecutores
3. **Añadir un margen de seguridad**: Reducir ~10% para compensar imprecisiones

### Factores que afectan el rendimiento

- **Tamaño del CV**: Los CVs más grandes consumen más tokens
- **Complejidad de los criterios**: Criterios detallados aumentan el consumo
- **Número de campos a analizar**: Más campos = más tokens
- **Latencia de red**: Afecta el tiempo entre peticiones

## Ejemplos de uso

### Uso básico

```python
from spark_rate_limiter import RateLimiter

# Crear limitador de tasa
rate_limiter = RateLimiter(max_rpm=100, max_tpm=60000)

# Ejecutar con control de límites
result = rate_limiter.execute_with_rate_limit(
    client.analyze_cv,
    content=cv_content,
    criteria=job_criteria
)
```

### Uso en mapPartitions

```python
def process_partition(partition):
    # Crear limitador distribuido
    rate_limiter = create_rate_limiter_for_executor(
        global_rpm=600,
        global_tpm=240000,
        executor_count=4  # Ajustar según configuración
    )
    
    # Procesar cada CV
    for record in partition:
        result = analyze_cv_with_rate_limit(
            client, record["content"], criteria,
            rate_limiter=rate_limiter
        )
        yield (record["id"], result)

# En el código principal
results = df.rdd.mapPartitions(process_partition)
```

### Uso con Pandas UDF

```python
@pandas_udf(StringType())
def analyze_cvs(cvs: pd.Series) -> pd.Series:
    # Crear limitador de tasa para este batch
    rate_limiter = RateLimiter(max_rpm=100, max_tpm=60000)
    
    results = []
    for cv in cvs:
        result = analyze_cv_with_rate_limit(
            client, cv, criteria, rate_limiter=rate_limiter
        )
        results.append(json.dumps(result))
    
    return pd.Series(results)
```

## Monitoreo y ajuste

### Métricas clave a monitorear

1. **Tasa de errores 429**: Indica que los límites son insuficientes
2. **Tiempo de espera**: Muestra si los ejecutores están esperando demasiado
3. **Utilización de cuota**: Controla si estamos aprovechando toda la capacidad
4. **Latencia promedio**: Ayuda a optimizar el tiempo entre peticiones

### Ajustes recomendados

- **Si recibes errores 429**: Reduce los límites por ejecutor
- **Si el tiempo de espera es alto**: Aumenta los límites o añade ejecutores
- **Si el rendimiento es bajo**: Considera paralelizar más aumentando particiones
- **Si hay desbalance entre ejecutores**: Mejora la distribución de datos con repartition

### Ejemplos de logging

```python
# En el limitador de tasa
logger.info(f"Esperando {wait_time:.2f}s para cumplir límites (RPM: {current_rpm}/{max_rpm}, TPM: {current_tpm}/{max_tpm})")

# Después de cada petición
logger.info(f"CV {cv_id} procesado. Tokens: {result.usage.total_tokens}, Tiempo: {elapsed_time:.2f}s")
```

## Optimización avanzada

### Coordinación entre ejecutores

Para una coordinación más precisa, se puede utilizar un servicio externo como Redis:

```python
class RedisRateLimiter(DistributedRateLimiter):
    def __init__(self, redis_client, key_prefix, ...):
        # Inicializa con cliente Redis
        
    def _wait_if_needed(self, tokens_estimate):
        # Usa Redis para coordinación global
        with self.redis_client.pipeline() as pipe:
            # Implementa algoritmo de límite distribuido
```

### Estimación dinámica de tokens

Para mejorar la precisión de la estimación:

```python
def adaptive_token_estimation(cv, history):
    # Estima basado en longitud y estructura
    base_estimate = len(cv) * 0.25
    
    # Ajusta según histórico
    if history:
        ratio = sum(actual/estimate for estimate, actual in history) / len(history)
        return base_estimate * ratio
    
    return base_estimate
```

### Optimización de batches

Agrupar CVs similares puede mejorar el rendimiento:

```python
def optimize_batches(cvs_df):
    # Calcular tamaño aproximado
    df_with_size = cvs_df.withColumn(
        "estimated_size", 
        udf(lambda x: len(x), IntegerType())(col("content"))
    )
    
    # Ordenar y redistribuir para balance
    return df_with_size.orderBy("estimated_size").repartition(num_partitions)
```

## Conclusión

La implementación de control de TPM y RPM es esencial para productivizar el SDK de CV Screening en Spark. Nuestra solución proporciona:

1. **Control preciso**: Gestión de límites tanto de tokens como de peticiones
2. **Escalabilidad**: Adaptación a entornos distribuidos con múltiples ejecutores
3. **Robustez**: Manejo de errores y reintentos con retroceso exponencial
4. **Monitorización**: Capacidad para seguir y ajustar el rendimiento

Usando estas herramientas, puedes procesar grandes volúmenes de CVs de manera eficiente y confiable, maximizando el rendimiento mientras respetas los límites de la API de Azure OpenAI. 