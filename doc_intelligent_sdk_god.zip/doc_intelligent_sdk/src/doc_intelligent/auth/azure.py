"""
Azure authentication for Document Intelligence SDK.

This module provides authentication mechanisms for Azure services,
particularly for Document Intelligence.
"""

import os
from datetime import datetime, timedelta
from typing import Dict, Optional, Union, Any
from pathlib import Path

from azure.core.credentials import TokenCredential, AzureKeyCredential
from azure.identity import (
    DefaultAzureCredential,
    ClientSecretCredential,
    AzureCliCredential,
    ManagedIdentityCredential,
)

class AzureCredential:
    """
    Wrapper for Azure authentication credentials.
    
    This class provides a unified interface for different Azure authentication 
    methods, including API keys, service principals, managed identities, 
    and the Azure CLI.
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        use_azure_cli: bool = False,
        use_managed_identity: bool = False,
        scope: str = "https://cognitiveservices.azure.com/.default",
        connection_verify: Union[bool, str] = True,
        credential: Optional[TokenCredential] = None,
    ):
        """
        Initialize Azure credential.
        
        Args:
            api_key: Azure API key. If provided, takes precedence over other methods.
            tenant_id: Azure tenant ID for service principal authentication.
            client_id: Azure client ID for service principal authentication.
            client_secret: Azure client secret for service principal authentication.
            use_azure_cli: Use the Azure CLI for authentication.
            use_managed_identity: Use Azure managed identity for authentication.
            scope: The scope for the authentication token. Defaults to 
                "https://cognitiveservices.azure.com/.default".
            connection_verify: Controls SSL certificate verification for token requests.
                Set to False to disable verification, or provide a path to a CA 
                bundle to use. Defaults to True.
            credential: A pre-configured TokenCredential instance to use directly.
        """
        self.api_key = api_key or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
        self.tenant_id = tenant_id or os.getenv("AZURE_TENANT_ID")
        self.client_id = client_id or os.getenv("AZURE_CLIENT_ID")
        self.client_secret = client_secret or os.getenv("AZURE_CLIENT_SECRET")
        self.use_azure_cli = use_azure_cli
        self.use_managed_identity = use_managed_identity
        self.scope = scope
        self.connection_verify = connection_verify
        
        self._credential = credential
        
        # Initialize the appropriate credential type if not provided directly
        if credential:
            # Use the provided credential
            pass
        elif self.api_key:
            # No need to initialize credential for API key
            pass
        elif self.tenant_id and self.client_id and self.client_secret:
            self._credential = ClientSecretCredential(
                tenant_id=self.tenant_id,
                client_id=self.client_id,
                client_secret=self.client_secret,
                verify_certificate=self.connection_verify,  # Usar verify_certificate
            )
        elif self.use_azure_cli:
            self._credential = AzureCliCredential()
        elif self.use_managed_identity:
            self._credential = ManagedIdentityCredential()
        else:
            # Default credential chain
            self._credential = DefaultAzureCredential(verify_certificate=self.connection_verify)
        
        self._token_cache = None
        self._token_expiry = None
    
    def get_token(self) -> str:
        """
        Get an authentication token for Azure services.
        
        If using API key, returns the API key directly.
        For other authentication methods, returns a valid token.
        
        Returns:
            str: Authentication token or API key.
            
        Raises:
            ValueError: If no authentication method is available.
        """
        if self.api_key:
            return self.api_key
        
        if not self._credential:
            raise ValueError("No valid authentication method available")
        
        # Check if we have a cached token that's still valid
        if self._token_cache and self._token_expiry and datetime.now() < self._token_expiry:
            return self._token_cache
        
        # Get a new token
        token_response = self._credential.get_token(self.scope)
        self._token_cache = token_response.token
        
        # Set expiry to be slightly earlier than the actual expiry
        expires_in = getattr(token_response, "expires_on", None) or 3600
        if isinstance(expires_in, int):
            self._token_expiry = datetime.now() + timedelta(seconds=expires_in - 300)
        
        return self._token_cache
    
    def get_azure_credential(self) -> Union[AzureKeyCredential, TokenCredential]:
        """
        Get the appropriate Azure credential object for use with Azure SDK clients.
        
        This returns either an AzureKeyCredential (for API key) or a TokenCredential
        (for other auth methods) that can be directly used with Azure SDK clients.
        
        Returns:
            Union[AzureKeyCredential, TokenCredential]: The Azure credential object.
            
        Raises:
            ValueError: If no authentication method is available.
        """
        if self.api_key:
            return AzureKeyCredential(self.api_key)
        
        if not self._credential:
            raise ValueError("No valid authentication method available")
            
        return self._credential
    
    @classmethod
    def default_credential(cls, scope: str = "https://cognitiveservices.azure.com/.default", connection_verify: Union[bool, str] = True) -> "AzureCredential":
        """
        Create a credential using the DefaultAzureCredential chain.
        
        This uses environment variables, managed identity, or Azure CLI as available.
        
        Args:
            scope: The scope for the authentication token.
            connection_verify: Controls SSL certificate verification. Set to False to disable 
                verification, or provide a path to a CA bundle to use. Defaults to True.
            
        Returns:
            AzureCredential: A configured credential object.
        """
        # Create credential options
        credential_options = {}
        # Use verify_certificate para DefaultAzureCredential
        credential_options["verify_certificate"] = connection_verify
        
        # Manually create DefaultAzureCredential to ensure it's used in tests
        default_azure_credential = DefaultAzureCredential(**credential_options)
        
        # Create and return our AzureCredential object with the DefaultAzureCredential
        return cls(credential=default_azure_credential, scope=scope, connection_verify=connection_verify)
    
    @classmethod
    def from_service_principal(
        cls,
        tenant_id: str,
        client_id: str,
        client_secret: str,
        scope: str = "https://cognitiveservices.azure.com/.default",
        connection_verify: Union[bool, str] = True,
    ) -> "AzureCredential":
        """
        Create a credential using service principal authentication.
        
        Args:
            tenant_id: Azure tenant ID.
            client_id: Azure client ID.
            client_secret: Azure client secret.
            scope: The scope for the authentication token.
            connection_verify: Controls SSL certificate verification. Set to False to disable 
                verification, or provide a path to a CA bundle to use. Defaults to True.
            
        Returns:
            AzureCredential: A configured credential object.
        """
        # Create credential options with the correct parameter name for ClientSecretCredential
        credential_options = {"verify_certificate": connection_verify}
            
        # Manually create ClientSecretCredential to ensure it's used in tests
        client_secret_credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
            **credential_options
        )
        
        # Create and return our AzureCredential object with the ClientSecretCredential
        return cls(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
            credential=client_secret_credential, 
            scope=scope, 
            connection_verify=connection_verify
        ) 