"""
Document Intelligence SDK - Core Module

This is the main package for the Document Intelligence SDK.
"""

from .client import DocIntelligenceClient
from .auth import AzureCredential  # Preferred authentication method

__version__ = "0.2.0"
__all__ = ["DocIntelligenceClient", "AzureCredential"] 