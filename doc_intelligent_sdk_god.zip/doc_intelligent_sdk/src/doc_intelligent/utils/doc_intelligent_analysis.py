"""
Document analysis utilities using AzureDocumentProvider.

This module provides utility functions for document analysis
using the AzureDocumentProvider class, offering a similar interface
to document_analysis.py but with the advantages of the structured SDK:
- analyze_document: Analyzes a document from a file path
- analyze_document_from_base64: Analyzes a document directly from a base64 string
- analyze_multiple_base64_documents: Analyzes multiple base64 documents at once
"""

import os
import base64
from typing import Optional, Tuple, Dict, List, Any, Union
from pathlib import Path

from ..providers.azure import AzureDocumentProvider
from ..auth import AzureCredential
from .logging import get_logger

logger = get_logger(__name__)

def analyze_document(
    file_path: Union[str, Path], 
    upload_mode: str = "multipart",
    model_id: str = "prebuilt-read",
    poll_interval: int = 5, 
    timeout: int = 300,
    credential = None,
    verify_ssl: Optional[bool] = True
) -> Tuple[Optional[str], Optional[str]]:
    """
    Analyze a document using AzureDocumentProvider.
    
    This function offers the same interface as document_analysis.py,
    but implements the analysis using the AzureDocumentProvider class.
    
    Args:
        file_path: Path to the document file to analyze
        upload_mode: "multipart" or "base64" for document upload
        model_id: ID of the model to use (default: "prebuilt-read")
        poll_interval: Interval (in seconds) between polling requests
        timeout: Maximum time (in seconds) to wait for the result
        credential: Optional AzureCredential instance. If None, a default one will be created
        verify_ssl: Verify SSL certificates. Default: True
        
    Returns:
        Tuple[Optional[str], Optional[str]]: Extracted content and job_id
    """
    # Read required environment variables
    private_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    public_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
    
    if not all([private_endpoint, public_endpoint]):
        logger.error("Missing required environment variables.")
        return None, None
    
    # Create credential if not provided
    azure_credential = credential or AzureCredential.default_credential()
    
    # Create AzureDocumentProvider instance
    provider = AzureDocumentProvider(
        endpoint=private_endpoint,
        public_endpoint=public_endpoint,
        credential=azure_credential,
        connection_verify=verify_ssl
    )
    
    try:
        # If the mode is base64, first read the file and encode it
        if upload_mode == "base64":
            file_path = Path(file_path)
            with open(file_path, "rb") as f:
                file_content = f.read()
            
            base64_string = base64.b64encode(file_content).decode("utf-8")
            content_type = provider._get_content_type(Path(file_path))
            
            # Use analyze_document_from_base64
            response = provider.analyze_document_from_base64(
                base64_string=base64_string,
                content_type=content_type,
                model_id=model_id,
                poll_interval=poll_interval,
                timeout=timeout,
                verify_ssl=verify_ssl
            )
        else:
            # Use analyze_document with multipart mode
            response = provider.analyze_document(
                file_path=file_path,
                model_id=model_id,
                poll_interval=poll_interval,
                timeout=timeout
            )
        
        # If we have a response, extract content and job_id
        if response and response.status == "succeeded":
            # Try to get the text content
            content = response.get_text() if hasattr(response, "get_text") else None
            
            # If get_text is not available or returns None, look in result
            if content is None and response.result and "content" in response.result:
                content = response.result["content"]
                
            return content, response.document_id
            
        return None, getattr(response, "document_id", None)
        
    except Exception as e:
        logger.error(f"Error analyzing document: {str(e)}")
        return None, None

def analyze_document_from_base64(
    base64_string: str,
    content_type: str = "application/pdf",
    model_id: str = "prebuilt-read",
    poll_interval: int = 5,
    timeout: int = 300,
    credential = None,
    verify_ssl: Optional[bool] = True
) -> Tuple[Optional[str], Optional[str]]:
    """
    Analyze a document directly from a base64 string.
    
    This function offers the same interface as document_analysis.py,
    but implements the analysis using the AzureDocumentProvider class.
    
    Args:
        base64_string: String with the base64-encoded document
        content_type: Content type of the document (default: "application/pdf")
        model_id: ID of the model to use (default: "prebuilt-read")
        poll_interval: Interval (in seconds) between polling requests
        timeout: Maximum time (in seconds) to wait for the result
        credential: Optional AzureCredential instance. If None, a default one will be created
        verify_ssl: Verify SSL certificates. Default: True
        
    Returns:
        Tuple[Optional[str], Optional[str]]: Extracted content and job_id
    """
    # Read required environment variables
    private_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    public_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
    
    if not all([private_endpoint, public_endpoint]):
        logger.error("Missing required environment variables.")
        return None, None
    
    # Create credential if not provided
    azure_credential = credential or AzureCredential.default_credential()
    
    # Create AzureDocumentProvider instance
    provider = AzureDocumentProvider(
        endpoint=private_endpoint,
        public_endpoint=public_endpoint,
        credential=azure_credential,
        connection_verify=verify_ssl
    )
    
    try:
        # Use analyze_document_from_base64
        response = provider.analyze_document_from_base64(
            base64_string=base64_string,
            content_type=content_type,
            model_id=model_id,
            poll_interval=poll_interval,
            timeout=timeout,
            verify_ssl=verify_ssl
        )
        
        # If we have a response, extract content and job_id
        if response and response.status == "succeeded":
            # Try to get the text content
            content = response.get_text() if hasattr(response, "get_text") else None
            
            # If get_text is not available or returns None, look in result
            if content is None and response.result and "content" in response.result:
                content = response.result["content"]
                
            return content, response.document_id
            
        return None, getattr(response, "document_id", None)
        
    except Exception as e:
        logger.error(f"Error analyzing base64 document: {str(e)}")
        return None, None

def analyze_multiple_base64_documents(
    documents: List[Dict[str, str]], 
    model_id: str = "prebuilt-read",
    credential = None, 
    verify_ssl: Optional[bool] = True, 
    **kwargs
) -> Dict[str, Optional[str]]:
    """
    Analyze multiple base64-encoded documents and return a dictionary with the results.
    
    This function offers the same interface as document_analysis.py,
    but implements the analysis using the AzureDocumentProvider class.
    
    Args:
        documents: List of dictionaries with 'base64_string' and optionally 'content_type'
        model_id: ID of the model to use (default: "prebuilt-read")
        credential: Optional AzureCredential instance. If None, a default one will be created
        verify_ssl: Verify SSL certificates. Default: True
        **kwargs: Additional arguments to pass to analyze_document_from_base64
        
    Returns:
        Dict[str, Optional[str]]: Dictionary with indices and extracted content
    """
    results = {}
    
    # Read required environment variables
    private_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    public_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
    
    if not all([private_endpoint, public_endpoint]):
        logger.error("Missing required environment variables.")
        return {f"doc_{i}": None for i in range(len(documents))}
    
    # Create credential if not provided
    azure_credential = credential or AzureCredential.default_credential()
    
    # Create AzureDocumentProvider instance
    provider = AzureDocumentProvider(
        endpoint=private_endpoint,
        public_endpoint=public_endpoint,
        credential=azure_credential,
        connection_verify=verify_ssl
    )
    
    # Prepare documents for the required provider format
    formatted_docs = []
    for doc in documents:
        formatted_docs.append({
            'content': doc.get('base64_string'),
            'contentType': doc.get('content_type', 'application/pdf')
        })
    
    try:
        # Use analyze_documents_batch_from_base64
        responses = provider.analyze_documents_batch_from_base64(
            documents=formatted_docs,
            model_id=model_id,
            **kwargs
        )
        
        # Process responses
        for i, response in enumerate(responses):
            if response and response.status == "succeeded":
                # Try to get the text content
                content = response.get_text() if hasattr(response, "get_text") else None
                
                # If get_text is not available or returns None, look in result
                if content is None and response.result and "content" in response.result:
                    content = response.result["content"]
                    
                results[f"doc_{i}"] = content
            else:
                results[f"doc_{i}"] = None
    
    except Exception as e:
        logger.error(f"Error analyzing documents in batch: {str(e)}")
        results = {f"doc_{i}": None for i in range(len(documents))}
    
    return results 