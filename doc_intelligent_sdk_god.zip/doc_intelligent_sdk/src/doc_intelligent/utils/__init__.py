"""
Utility modules for the Document Intelligence SDK (OCR version).

This package contains various utility modules used throughout the SDK
for authentication, error handling, logging, and other common functions.
"""

# Import logging utilities
from .logging import get_logger

# Import authentication utilities
from ..auth import AzureCredential  # Preferred authentication method

# Import document analysis utilities
from .document_analysis import (
    analyze_document, 
    analyze_document_from_base64, 
    analyze_base64_document,
    analyze_multiple_base64_documents
)

__all__ = [
    "get_logger",
    "AzureCredential",  # Preferred authentication method
    "analyze_base64_document",
    "analyze_multiple_base64_documents",
    "analyze_document",
    "analyze_document_from_base64"
]