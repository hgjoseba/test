"""
Tests for logging utilities in the doc_intelligent.utils.logging module.
"""

import unittest
import logging
import os
from unittest.mock import patch, MagicMock

from doc_intelligent.utils.logging import get_logger


class TestLogging(unittest.TestCase):
    """Test cases for logging utilities."""
    
    def setUp(self):
        """Set up test environment before each test."""
        # Eliminar todos los loggers existentes para evitar interferencias
        logging.Logger.manager.loggerDict.clear()
        root = logging.getLogger()
        if root.handlers:
            for handler in root.handlers:
                root.removeHandler(handler)
    
    def test_get_logger_with_default_level(self):
        """Test get_logger with default log level."""
        logger = get_logger("test_logger")
        
        self.assertEqual(logger.name, "test_logger")
        self.assertEqual(logger.level, logging.INFO)
        self.assertEqual(len(logger.handlers), 1)
        self.assertIsInstance(logger.handlers[0], logging.StreamHandler)
    
    @patch.dict(os.environ, {"DOC_INTELLIGENCE_LOG_LEVEL": "DEBUG"})
    def test_get_logger_with_env_level(self):
        """Test get_logger with environment variable log level."""
        logger = get_logger("test_env_logger")
        
        self.assertEqual(logger.name, "test_env_logger")
        self.assertEqual(logger.level, logging.DEBUG)
        self.assertEqual(len(logger.handlers), 1)
    
    def test_get_logger_with_custom_level(self):
        """Test get_logger with custom log level."""
        logger = get_logger("test_custom_logger", level=logging.WARNING)
        
        self.assertEqual(logger.name, "test_custom_logger")
        self.assertEqual(logger.level, logging.WARNING)
        self.assertEqual(len(logger.handlers), 1)
        handler = logger.handlers[0]
        self.assertEqual(handler.level, logging.WARNING)
    
    @patch.dict(os.environ, {"DOC_INTELLIGENCE_LOG_LEVEL": "INVALID"})
    def test_get_logger_with_invalid_env_level(self):
        """Test get_logger with invalid environment variable log level."""
        logger = get_logger("test_invalid_logger")
        
        # Debería usar INFO como nivel predeterminado si el nivel es inválido
        self.assertEqual(logger.level, logging.INFO)
    
    def test_get_logger_reuse_existing(self):
        """Test get_logger reuses existing logger."""
        # Crear un logger dos veces con el mismo nombre
        logger1 = get_logger("test_reuse_logger")
        
        # Agregar un handler ficticio adicional para verificar si se mantiene
        mock_handler = MagicMock(spec=logging.Handler)
        logger1.addHandler(mock_handler)
        
        # Obtener el mismo logger nuevamente
        logger2 = get_logger("test_reuse_logger")
        
        # Verificar que es el mismo objeto y mantiene todos los handlers
        self.assertIs(logger1, logger2)
        self.assertEqual(len(logger2.handlers), 2)  # El original más el mock
    
    def test_logger_formatter(self):
        """Test logger formatter configuration."""
        logger = get_logger("test_formatter")
        handler = logger.handlers[0]
        formatter = handler.formatter
        
        # Verificar que el formato del formatter es el esperado
        expected_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        self.assertEqual(formatter._fmt, expected_format)


if __name__ == "__main__":
    unittest.main() 