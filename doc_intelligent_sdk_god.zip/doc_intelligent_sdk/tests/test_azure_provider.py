"""
Tests for the Azure Document Intelligence Provider.
"""

import unittest
from unittest.mock import patch, MagicMock, mock_open
import json
import os
from pathlib import Path

from doc_intelligent.providers.azure import AzureDocumentProvider
from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.utils.errors import DocumentIntelligenceError, ModelNotFoundError, ServiceError
from doc_intelligent.providers.base import DocumentProvider


# Crear una clase concreta para las pruebas que implementa los métodos abstractos
class ConcreteAzureDocumentProvider(AzureDocumentProvider):
    """Implementación concreta de AzureDocumentProvider para pruebas."""
    
    def analyze_documents_batch(self, *args, **kwargs):
        """Implementación del método abstracto."""
        return {}
    
    def analyze_documents_batch_from_base64(self, *args, **kwargs):
        """Implementación del método abstracto."""
        return {}
    
    def list_models(self, *args, **kwargs):
        """Implementación del método abstracto."""
        return []


class TestAzureDocumentProvider(unittest.TestCase):
    """Test cases for the AzureDocumentProvider class."""

    def setUp(self):
        """Set up test environment before each test."""
        self.endpoint = "https://test-endpoint.cognitiveservices.azure.com/"
        self.public_endpoint = "https://public-endpoint.cognitiveservices.azure.com/"
        self.api_key = "test-api-key"
        self.api_version = "2024-11-30"  # Actualizado a la versión actual
        
        # Guardar las variables de entorno originales
        self.original_env = os.environ.copy()
        
        self.provider = ConcreteAzureDocumentProvider(
            endpoint=self.endpoint,
            api_key=self.api_key,
            api_version=self.api_version,
            public_endpoint=self.public_endpoint
        )
    
    def tearDown(self):
        """Restaurar variables de entorno después de cada prueba."""
        os.environ.clear()
        os.environ.update(self.original_env)

    def test_init_with_api_key(self):
        """Test initialization with API key."""
        provider = ConcreteAzureDocumentProvider(
            endpoint=self.endpoint,
            api_key=self.api_key
        )
        self.assertEqual(provider.endpoint, self.endpoint)
        self.assertEqual(provider.api_key, self.api_key)
        self.assertEqual(provider.api_version, "2024-11-30")  # Actualizado a la versión actual

    def test_init_with_missing_endpoint(self):
        """Test initialization with missing endpoint."""
        # Asegurarse de que la variable de entorno no esté establecida
        if "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT" in os.environ:
            del os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"]
            
        with self.assertRaises(ValueError):
            ConcreteAzureDocumentProvider(
                api_key=self.api_key
            )

    @patch("doc_intelligent.providers.azure.DefaultAzureCredential")
    def test_init_with_missing_auth(self, mock_default_credential):
        """Test initialization with missing authentication."""
        # Asegurar que no hay variables de entorno que interfieran
        if "AZURE_DOCUMENT_INTELLIGENCE_KEY" in os.environ:
            del os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"]
        
        # Configurar el mock para devolver una credencial falsa
        mock_credential = MagicMock()
        mock_default_credential.return_value = mock_credential
        
        # En la implementación actual, si no se proporciona api_key, 
        # se debe intentar usar DefaultAzureCredential
        provider = ConcreteAzureDocumentProvider(
            endpoint=self.endpoint
        )
        
        # Ahora api_key debe ser None y credential debe contener la credencial
        self.assertIsNone(provider.api_key)
        self.assertIsNotNone(provider.credential)

    def test_get_headers_with_api_key(self):
        """Test _get_headers method with API key."""
        headers = self.provider._get_headers()
        self.assertEqual(headers, {"Ocp-Apim-Subscription-Key": self.api_key})

    def test_get_headers_with_credential(self):
        """Test _get_headers method with credential."""
        # Set up mock credential that returns a string token instead of an object
        mock_credential = MagicMock()
        mock_token = "mock-token"  # Usamos directamente un string en lugar de un objeto token
        mock_credential.get_token.return_value = mock_token

        # Create provider with mock credential but without API key
        provider = ConcreteAzureDocumentProvider(
            endpoint=self.endpoint,
            credential=mock_credential,
            api_key=None,  # Importante: asegurarse de que el api_key es None para que use el credential
            public_endpoint=self.public_endpoint
        )

        headers = provider._get_headers()
        self.assertEqual(headers, {"Authorization": f"Bearer {mock_token}"})
        mock_credential.get_token.assert_called_once()

    def test_get_content_type(self):
        """Test _get_content_type method."""
        # Test PDF content type
        pdf_path = Path("test_document.pdf")
        self.assertEqual(self.provider._get_content_type(pdf_path), "application/pdf")

        # Test DOCX content type
        docx_path = Path("test_document.docx")
        self.assertEqual(
            self.provider._get_content_type(docx_path),
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

        # Test fallback content type
        txt_path = Path("test_document.txt")
        self.assertEqual(self.provider._get_content_type(txt_path), "application/octet-stream")

    @patch("requests.post")
    @patch("requests.get")
    @patch("pathlib.Path.exists", return_value=True)
    def test_analyze_document_success(self, mock_path_exists, mock_get, mock_post):
        """Test analyze_document method with successful response."""
        # Setup mock responses
        mock_post_response = MagicMock()
        mock_post_response.status_code = 202
        mock_post_response.headers = {"Operation-Location": f"{self.endpoint}operations/123"}
        mock_post.return_value = mock_post_response

        mock_get_response = MagicMock()
        mock_get_response.status_code = 200
        mock_get_response.json.return_value = {
            "status": "succeeded",
            "createdDateTime": "2023-01-01T00:00:00Z",
            "lastUpdatedDateTime": "2023-01-01T00:01:00Z",
            "analyzeResult": {
                "apiVersion": "2023-07-31",
                "modelId": "prebuilt-document",
                "content": "Sample document content",
                "pages": [],
                "tables": [],
                "paragraphs": []
            }
        }
        mock_get.return_value = mock_get_response

        # Call the method with mocked file open
        with patch("builtins.open", mock_open(read_data=b"file content")):
            response = self.provider.analyze_document(
                file_path="test_document.pdf",
                model_id="prebuilt-document",
                locale="en"
            )

        # Verify post request was made correctly
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], f"{self.endpoint}documentModels/prebuilt-document:analyze?api-version={self.api_version}")
        self.assertEqual(kwargs["headers"], {"Ocp-Apim-Subscription-Key": self.api_key})
        self.assertIn("files", kwargs)
        self.assertIn("data", kwargs)
        self.assertEqual(kwargs["data"]["locale"], "en")

        # Verify get request was made correctly for polling
        mock_get.assert_called_with(
            f"{self.endpoint}operations/123",
            headers={"Ocp-Apim-Subscription-Key": self.api_key},
            timeout=30,
            verify=True
        )

        # Verify response object
        self.assertIsInstance(response, DocumentAnalysisResponse)
        self.assertEqual(response.status, "succeeded")
        self.assertEqual(response.model_id, "prebuilt-document")

    @patch("requests.post")
    @patch("pathlib.Path.exists", return_value=True)
    def test_analyze_document_request_error(self, mock_path_exists, mock_post):
        """Test analyze_document method with request error."""
        mock_post.side_effect = Exception("Connection error")

        # Call the method with mocked file open
        with patch("builtins.open", mock_open(read_data=b"file content")):
            with self.assertRaises(DocumentIntelligenceError):
                self.provider.analyze_document(
                    file_path="test_document.pdf",
                    model_id="prebuilt-document"
                )

    @patch("requests.post")
    @patch("pathlib.Path.exists", return_value=True)
    def test_analyze_document_service_error(self, mock_path_exists, mock_post):
        """Test analyze_document method with service error."""
        # Setup mock response with error status code
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.text = json.dumps({
            "error": {
                "code": "InvalidRequest",
                "message": "The request is invalid."
            }
        })
        mock_post.return_value = mock_response

        # Call the method with mocked file open
        with patch("builtins.open", mock_open(read_data=b"file content")):
            with self.assertRaises(ServiceError):
                self.provider.analyze_document(
                    file_path="test_document.pdf",
                    model_id="prebuilt-document"
                )

    @patch("requests.post")
    @patch("pathlib.Path.exists", return_value=True)
    def test_analyze_document_model_not_found(self, mock_path_exists, mock_post):
        """Test analyze_document method with model not found error."""
        # Setup mock response with 404 status code
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.text = json.dumps({
            "error": {
                "code": "ModelNotFound",
                "message": "Model 'nonexistent-model' not found."
            }
        })
        mock_post.return_value = mock_response

        # Call the method with mocked file open
        with patch("builtins.open", mock_open(read_data=b"file content")):
            with self.assertRaises(ModelNotFoundError):
                self.provider.analyze_document(
                    file_path="test_document.pdf",
                    model_id="nonexistent-model"
                )

    @patch("requests.post")
    @patch("requests.get")
    def test_analyze_document_from_base64(self, mock_get, mock_post):
        """Test analyze_document_from_base64 method."""
        # Setup mock responses
        mock_post_response = MagicMock()
        mock_post_response.status_code = 202
        mock_post_response.headers = {"Operation-Location": f"{self.endpoint}operations/123"}
        mock_post.return_value = mock_post_response

        mock_get_response = MagicMock()
        mock_get_response.status_code = 200
        mock_get_response.json.return_value = {
            "status": "succeeded",
            "analyzeResult": {
                "apiVersion": "2023-07-31",
                "modelId": "prebuilt-document",
                "content": "Base64 document content",
                "pages": [],
                "tables": [],
                "paragraphs": []
            }
        }
        mock_get.return_value = mock_get_response

        # Call the method
        response = self.provider.analyze_document_from_base64(
            base64_string="base64_encoded_data",
            content_type="application/pdf",
            model_id="prebuilt-document",
            locale="es"
        )

        # Verificar que la respuesta es correcta
        self.assertIsInstance(response, DocumentAnalysisResponse)
        self.assertEqual(response.status, "succeeded")
        self.assertEqual(response.model_id, "prebuilt-document")


if __name__ == "__main__":
    unittest.main()