"""
Unit tests for the Response models.

This module contains comprehensive test cases for the DocumentAnalysisResponse class,
which handles the responses from the document analysis service.
"""

import unittest
from unittest.mock import MagicMock, patch
from datetime import datetime

from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.models.document import (
    AnalyzedDocument,
    DocumentStatus,
    TextPage,
    TextLine,
    UnitType
)


class TestDocumentAnalysisResponse(unittest.TestCase):
    """Test cases for the DocumentAnalysisResponse class."""

    def test_basic_initialization(self):
        """Test basic initialization with minimal parameters."""
        response = DocumentAnalysisResponse(
            status="running",
            result=None
        )
        self.assertEqual(response.status, "running")
        self.assertIsNone(response.result)

    def test_full_initialization(self):
        """Test initialization with complete result data."""
        result = {
            "modelId": "test-model",
            "content": "Test content",
            "contentType": "application/pdf",
            "fileName": "test.pdf",
            "language": "en-US",
            "pages": [
                {
                    "pageNumber": 1,
                    "width": 8.5,
                    "height": 11.0,
                    "unit": "inch",
                    "lines": [
                        {
                            "content": "Test line",
                            "confidence": 0.95,
                            "span": {"offset": 0, "length": 9}
                        }
                    ]
                }
            ]
        }
        response = DocumentAnalysisResponse(
            status="succeeded",
            result=result
        )
        self.assertEqual(response.status, "succeeded")
        self.assertEqual(response.result["modelId"], "test-model")
        self.assertEqual(response.result["content"], "Test content")
        self.assertEqual(response.result["contentType"], "application/pdf")

    def test_get_analyzed_document_success(self):
        """Test get_analyzed_document method with successful result."""
        result = {
            "modelId": "test-model",
            "content": "Test content",
            "contentType": "application/pdf",
            "fileName": "test.pdf",
            "language": "en-US",
            "pages": [
                {
                    "pageNumber": 1,
                    "width": 8.5,
                    "height": 11.0,
                    "unit": "inch",
                    "lines": [
                        {
                            "content": "Test line",
                            "confidence": 0.95,
                            "span": {"offset": 0, "length": 9}
                        }
                    ]
                }
            ]
        }
        response = DocumentAnalysisResponse(
            status="succeeded",
            result=result
        )
        
        document = response.get_analyzed_document()
        self.assertIsInstance(document, AnalyzedDocument)
        self.assertEqual(document.model_id, "test-model")
        self.assertEqual(document.content, "Test content")
        self.assertEqual(document.content_type, "application/pdf")
        self.assertEqual(document.file_name, "test.pdf")
        self.assertEqual(document.language, "en-US")
        self.assertEqual(document.status, DocumentStatus.SUCCEEDED)
        self.assertEqual(len(document.pages), 1)
        self.assertEqual(document.pages[0].unit, UnitType.INCH)

    def test_get_analyzed_document_running(self):
        """Test get_analyzed_document method with running status."""
        response = DocumentAnalysisResponse(
            status="running",
            result=None
        )
        document = response.get_analyzed_document()
        self.assertIsInstance(document, AnalyzedDocument)
        self.assertEqual(document.status, DocumentStatus.RUNNING)
        self.assertEqual(document.model_id, "unknown")

    def test_get_analyzed_document_failed(self):
        """Test get_analyzed_document method with failed status."""
        response = DocumentAnalysisResponse(
            status="failed",
            result={
                "errors": [
                    {
                        "code": "InvalidRequest",
                        "message": "Invalid request parameters"
                    }
                ]
            }
        )
        document = response.get_analyzed_document()
        self.assertIsInstance(document, AnalyzedDocument)
        self.assertEqual(document.status, DocumentStatus.FAILED)
        self.assertEqual(document.model_id, "unknown")

    def test_get_analyzed_document_cached(self):
        """Test that get_analyzed_document method caches the result."""
        result = {
            "modelId": "test-model",
            "content": "Test content",
            "contentType": "application/pdf"
        }
        response = DocumentAnalysisResponse(
            status="succeeded",
            result=result
        )
        
        document1 = response.get_analyzed_document()
        document2 = response.get_analyzed_document()
        self.assertIs(document1, document2)

    def test_get_text_with_content(self):
        """Test get_text method with available content."""
        response = DocumentAnalysisResponse(
            status="succeeded",
            result={
                "modelId": "test-model",
                "content": "Test content"
            }
        )
        self.assertEqual(response.get_text(), "Test content")

    def test_get_text_with_pages(self):
        """Test get_text method with page content."""
        result = {
            "modelId": "test-model",
            "content": "",
            "pages": [
                {
                    "pageNumber": 1,
                    "width": 8.5,
                    "height": 11.0,
                    "unit": "inch",
                    "lines": [
                        {"content": "Line 1"},
                        {"content": "Line 2"}
                    ]
                }
            ]
        }
        response = DocumentAnalysisResponse(
            status="succeeded",
            result=result
        )
        self.assertEqual(response.get_text(), "Line 1\nLine 2")

    def test_get_text_failed(self):
        """Test get_text method with failed status."""
        response = DocumentAnalysisResponse(
            status="failed",
            result=None
        )
        self.assertEqual(response.get_text(), "")

    def test_get_errors_with_errors(self):
        """Test get_errors method with error information."""
        errors = [
            {
                "code": "InvalidRequest",
                "message": "Invalid request parameters"
            },
            {
                "code": "AuthenticationFailed",
                "message": "Authentication failed"
            }
        ]
        response = DocumentAnalysisResponse(
            status="failed",
            result={"errors": errors}
        )
        
        result_errors = response.get_errors()
        self.assertEqual(len(result_errors), 2)
        self.assertEqual(result_errors[0]["code"], "InvalidRequest")
        self.assertEqual(result_errors[1]["code"], "AuthenticationFailed")

    def test_get_errors_without_errors(self):
        """Test get_errors method without error information."""
        response = DocumentAnalysisResponse(
            status="succeeded",
            result={"modelId": "test-model"}
        )
        self.assertEqual(response.get_errors(), [])

    def test_from_azure_result_success(self):
        """Test from_azure_result method with successful result."""
        mock_result = MagicMock()
        mock_result.status = "succeeded"
        mock_result.analyze_result = MagicMock()
        mock_result.analyze_result.model_id = "test-model"
        mock_result.analyze_result.content = "Test content"
        mock_result.content_type = "application/pdf"
        mock_result.file_name = "test.pdf"
        mock_result.analyze_result.language = "en-US"
        mock_result.analyze_result.pages = []

        response = DocumentAnalysisResponse.from_azure_result(mock_result)
        self.assertEqual(response.status, "succeeded")
        self.assertEqual(response.result["modelId"], "test-model")
        self.assertEqual(response.result["content"], "Test content")
        self.assertEqual(response.result["contentType"], "application/pdf")
        self.assertEqual(response.result["fileName"], "test.pdf")
        self.assertEqual(response.result["language"], "en-US")
        self.assertEqual(response.result["pages"], [])

    def test_from_azure_result_running(self):
        """Test from_azure_result method with running status."""
        # Usar un diccionario en lugar de un mock para evitar problemas de tipo
        mock_dict = {
            "status": "running",
            "model_id": "test-model",
            "analyze_result": None
        }

        response = DocumentAnalysisResponse.from_azure_result(mock_dict)
        self.assertEqual(response.status, "running")
        self.assertIsNone(response.result)

    def test_from_azure_result_with_errors(self):
        """Test from_azure_result method with error information."""
        mock_result = MagicMock()
        mock_result.status = "failed"
        mock_result.model_id = "test-model"
        mock_result.errors = [
            {
                "code": "InvalidRequest",
                "message": "Invalid request parameters"
            }
        ]

        print(f"Type of model_id: {type(mock_result.model_id)}, Value: {mock_result.model_id}")
        
        mock_dict = {
            "status": "failed",
            "model_id": "test-model",
            "errors": [{"code": "InvalidRequest", "message": "Invalid request parameters"}]
        }

        response = DocumentAnalysisResponse.from_azure_result(mock_dict)
        self.assertEqual(response.status, "failed")
        self.assertEqual(len(response.errors), 1)
        self.assertEqual(response.errors[0]["code"], "InvalidRequest")

    def test_validate_status_valid_values(self):
        """Test validate_status method with all valid status values."""
        valid_statuses = ['succeeded', 'failed', 'running', 'not_started']
        for status in valid_statuses:
            try:
                DocumentAnalysisResponse.validate_status(status)
            except ValueError:
                self.fail(f"validate_status raised ValueError unexpectedly for status '{status}'")

    def test_validate_status_invalid_value(self):
        """Test validate_status method with an invalid status value."""
        with self.assertRaises(ValueError) as context:
            DocumentAnalysisResponse.validate_status('invalid_status')
        self.assertIn("Invalid status value", str(context.exception))

    def test_validate_status_none_value(self):
        """Test validate_status method with None value."""
        with self.assertRaises(ValueError) as context:
            DocumentAnalysisResponse.validate_status(None)
        self.assertIn("Status cannot be None", str(context.exception))

    def test_validate_status_wrong_type(self):
        """Test validate_status method with wrong type."""
        with self.assertRaises(ValueError) as context:
            DocumentAnalysisResponse.validate_status(123)
        self.assertIn("Status must be a string", str(context.exception))

    def test_status_property_validation(self):
        """Test that status property validates values on assignment."""
        response = DocumentAnalysisResponse(status="running", result=None)
        
        # Test valid status change
        response.status = "succeeded"
        self.assertEqual(response.status, "succeeded")
        
        # Test invalid status change
        with self.assertRaises(ValueError):
            response.status = "invalid_status"


if __name__ == "__main__":
    unittest.main() 