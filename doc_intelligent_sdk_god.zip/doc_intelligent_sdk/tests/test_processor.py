import os
import pytest
from pathlib import Path
from doc_intelligent.core.processor import DocumentProcessor
from doc_intelligent.utils.errors import DocumentTypeError

@pytest.fixture
def processor():
    """Create a DocumentProcessor instance."""
    return DocumentProcessor()

@pytest.fixture
def temp_dir(tmp_path):
    """Create a temporary directory for test files."""
    return tmp_path

@pytest.fixture
def sample_pdf(temp_dir):
    """Create a sample PDF file."""
    file_path = temp_dir / "test.pdf"
    with open(file_path, "wb") as f:
        f.write(b"%PDF-1.4\n%Test PDF content")
    return file_path

@pytest.fixture
def sample_docx(temp_dir):
    """Create a sample DOCX file."""
    file_path = temp_dir / "test.docx"
    with open(file_path, "wb") as f:
        f.write(b"PK\x03\x04\x14\x00\x00\x00\x00\x00")  # Minimal DOCX header
    return file_path

def test_processor_initialization():
    """Test DocumentProcessor initialization."""
    processor = DocumentProcessor()
    assert isinstance(processor, DocumentProcessor)
    assert ".pdf" in processor.SUPPORTED_EXTENSIONS
    assert ".docx" in processor.SUPPORTED_EXTENSIONS

def test_validate_document_pdf(processor, sample_pdf):
    """Test validating a PDF document."""
    validated_path = processor.validate_document(sample_pdf)
    assert validated_path == sample_pdf
    assert validated_path.suffix == ".pdf"

def test_validate_document_docx(processor, sample_docx):
    """Test validating a DOCX document."""
    validated_path = processor.validate_document(sample_docx)
    assert validated_path == sample_docx
    assert validated_path.suffix == ".docx"

def test_validate_document_not_found(processor, temp_dir):
    """Test validating a non-existent document."""
    non_existent_file = temp_dir / "non_existent.pdf"
    with pytest.raises(FileNotFoundError):
        processor.validate_document(non_existent_file)

def test_validate_document_unsupported_type(processor, temp_dir):
    """Test validating a document with unsupported type."""
    unsupported_file = temp_dir / "test.txt"
    with open(unsupported_file, "w") as f:
        f.write("test content")
    
    with pytest.raises(DocumentTypeError):
        processor.validate_document(unsupported_file)

def test_get_content_type_pdf(processor, sample_pdf):
    """Test getting content type for PDF."""
    content_type = processor.get_content_type(sample_pdf)
    assert content_type == "application/pdf"

def test_get_content_type_docx(processor, sample_docx):
    """Test getting content type for DOCX."""
    content_type = processor.get_content_type(sample_docx)
    assert content_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

def test_get_content_type_unknown(processor, temp_dir):
    """Test getting content type for unknown file type."""
    unknown_file = temp_dir / "test.unknown"
    content_type = processor.get_content_type(unknown_file)
    assert content_type == "application/octet-stream"

def test_prepare_document_pdf(processor, sample_pdf):
    """Test preparing a PDF document."""
    doc_data = processor.prepare_document(sample_pdf)
    
    assert doc_data["file_name"] == "test.pdf"
    assert doc_data["content_type"] == "application/pdf"
    assert isinstance(doc_data["content"], bytes)
    assert doc_data["size_bytes"] > 0
    assert doc_data["content"].startswith(b"%PDF")

def test_prepare_document_docx(processor, sample_docx):
    """Test preparing a DOCX document."""
    doc_data = processor.prepare_document(sample_docx)
    
    assert doc_data["file_name"] == "test.docx"
    assert doc_data["content_type"] == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    assert isinstance(doc_data["content"], bytes)
    assert doc_data["size_bytes"] > 0
    assert doc_data["content"].startswith(b"PK") 