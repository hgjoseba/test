#!/usr/bin/env python
"""
Ejemplo directo de análisis de documentos usando Azure Document Intelligence.

Este ejemplo utiliza la función analyze_document que implementa exactamente el
mismo flujo de trabajo que el ejemplo original, incluyendo:
- Configuración NO_PROXY para endpoints privados
- Autenticación con Service Principal 
- Manejo de análisis en dos fases (carga y polling)
- Soporte para multipart/form-data y base64

Demuestra tres métodos de análisis: 
- multipart/form-data desde archivo
- base64 desde archivo 
- base64 directo (string base64 preexistente)
"""

import os
import sys
import time
import base64
from doc_intelligent.utils import analyze_document, analyze_document_from_base64

# Verificar variables de entorno necesarias
REQUIRED_ENV = [
    "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT",   # Endpoint privado 
    "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT", # Endpoint público
]

def check_env_vars():
    """Verifica que las variables de entorno necesarias estén configuradas."""
    missing = [var for var in REQUIRED_ENV if not os.environ.get(var)]
    if missing:
        print(f"❌ Error: Faltan variables de entorno requeridas: {', '.join(missing)}")
        print("\nConfigura estas variables antes de ejecutar el ejemplo:")
        print("export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://tu-endpoint-privado.cognitiveservices.azure.com/")
        print("export AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT=https://eastus.api.cognitive.microsoft.com/")
        return False
    return True

def main():
    print("\n=== Ejemplo de análisis directo de documentos ===")
    
    # Verificar variables de entorno
    if not check_env_vars():
        return 1
    
    # Mostrar configuración actual
    private_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    public_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
    print(f"\nEndpoint privado: {private_endpoint}")
    print(f"Endpoint público: {public_endpoint}")
    
    # Menú para seleccionar método de análisis
    print("\nSelecciona el método de análisis:")
    print("1. Analizar archivo con multipart/form-data (recomendado para archivos locales)")
    print("2. Analizar archivo con base64 (mayor overhead pero útil para datos ya en memoria)")
    print("3. Analizar string base64 directamente (para strings codificados preexistentes)")
    print("4. Comparar métodos 1 y 2")
    
    option = input("\nSelección (1-4): ")
    
    # Para opciones 1, 2 y 4 necesitamos un archivo
    if option in ["1", "2", "4"]:
        file_path = input("\nIngresa la ruta al archivo PDF para analizar: ")
        if not os.path.exists(file_path):
            print(f"❌ Error: El archivo {file_path} no existe")
            return 1
    
    # Para la opción 3, necesitamos un string base64
    base64_string = None
    if option == "3":
        print("\nSelecciona cómo proporcionar el string base64:")
        print("1. Ingresar ruta de archivo (lo convertiremos a base64)")
        print("2. Ingresar ruta de archivo .b64 (string base64 guardado en archivo)")
        
        b64_option = input("\nSelección (1-2): ")
        
        if b64_option == "1":
            file_path = input("\nIngresa la ruta al archivo para convertir a base64: ")
            if not os.path.exists(file_path):
                print(f"❌ Error: El archivo {file_path} no existe")
                return 1
                
            try:
                with open(file_path, "rb") as f:
                    file_bytes = f.read()
                base64_string = base64.b64encode(file_bytes).decode("utf-8")
                print(f"✅ Archivo convertido a base64 ({len(base64_string)} caracteres)")
            except Exception as e:
                print(f"❌ Error al convertir el archivo a base64: {e}")
                return 1
                
        elif b64_option == "2":
            b64_file = input("\nIngresa la ruta al archivo .b64 que contiene el string base64: ")
            if not os.path.exists(b64_file):
                print(f"❌ Error: El archivo {b64_file} no existe")
                return 1
                
            try:
                with open(b64_file, "r") as f:
                    base64_string = f.read().strip()
                print(f"✅ String base64 cargado desde archivo ({len(base64_string)} caracteres)")
            except Exception as e:
                print(f"❌ Error al leer el archivo base64: {e}")
                return 1
        else:
            print("❌ Opción no válida")
            return 1
    
    # Analizar con multipart
    if option in ["1", "4"]:
        print("\n=== Análisis usando multipart/form-data ===")
        start_time = time.time()
        content_multipart, job_id = analyze_document(
            file_path=file_path,
            upload_mode="multipart",
            poll_interval=5,
            timeout=300
        )
        multipart_time = time.time() - start_time
        
        if content_multipart:
            print(f"✅ Análisis multipart completado en {multipart_time:.2f} segundos")
            print(f"Job ID: {job_id}")
            print(f"Texto extraído ({len(content_multipart)} caracteres)")
            print(f"\nPrimeros 200 caracteres:")
            print("-" * 50)
            print(content_multipart[:200] + "...")
            print("-" * 50)
        else:
            print(f"❌ Error en el análisis multipart. Job ID: {job_id}")
    
    # Analizar con base64 desde archivo
    if option in ["2", "4"]:
        print("\n=== Análisis usando base64 (desde archivo) ===")
        start_time = time.time()
        content_base64, job_id = analyze_document(
            file_path=file_path,
            upload_mode="base64",
            poll_interval=5,
            timeout=300
        )
        base64_time = time.time() - start_time
        
        if content_base64:
            print(f"✅ Análisis base64 completado en {base64_time:.2f} segundos")
            print(f"Job ID: {job_id}")
            print(f"Texto extraído ({len(content_base64)} caracteres)")
            print(f"\nPrimeros 200 caracteres:")
            print("-" * 50)
            print(content_base64[:200] + "...")
            print("-" * 50)
        else:
            print(f"❌ Error en el análisis base64. Job ID: {job_id}")
    
    # Analizar con base64 directo (string base64 preexistente)
    if option == "3" and base64_string:
        print("\n=== Análisis usando string base64 directo ===")
        start_time = time.time()
        
        # Determinamos el tipo de contenido
        content_type = "application/pdf"  # valor por defecto
        content_type_input = input("\nIngresa el tipo de contenido (por defecto: application/pdf): ")
        if content_type_input.strip():
            content_type = content_type_input
        
        content, job_id = analyze_document_from_base64(
            base64_string=base64_string,
            content_type=content_type,
            poll_interval=5,
            timeout=300
        )
        direct_base64_time = time.time() - start_time
        
        if content:
            print(f"✅ Análisis directo de base64 completado en {direct_base64_time:.2f} segundos")
            print(f"Job ID: {job_id}")
            print(f"Texto extraído ({len(content)} caracteres)")
            print(f"\nPrimeros 200 caracteres:")
            print("-" * 50)
            print(content[:200] + "...")
            print("-" * 50)
        else:
            print(f"❌ Error en el análisis directo de base64. Job ID: {job_id}")
    
    # Comparar resultados
    if option == "4" and content_multipart and content_base64:
        print("\n=== Comparación de métodos ===")
        print(f"Tiempo multipart: {multipart_time:.2f} segundos")
        print(f"Tiempo base64:    {base64_time:.2f} segundos")
        print(f"Diferencia:       {base64_time - multipart_time:.2f} segundos")
        
        same_content = content_multipart == content_base64
        print(f"¿Contenido idéntico? {'✅ Sí' if same_content else '❌ No'}")
        
        if not same_content:
            print("Hay diferencias entre los contenidos extraídos.")
    
    # Guardar el resultado
    content_to_save = None
    if option == "1" and content_multipart:
        content_to_save = content_multipart
    elif option == "2" and content_base64:
        content_to_save = content_base64
    elif option == "3" and content:
        content_to_save = content
    elif option == "4" and content_multipart:
        content_to_save = content_multipart
    
    if content_to_save:
        save = input("\n¿Guardar el texto extraído en un archivo? (s/n): ")
        
        if save.lower() == "s":
            # Determinar nombre de archivo para guardar
            output_file = None
            if 'file_path' in locals():
                output_file = os.path.splitext(file_path)[0] + "_extracted.txt"
            else:
                output_file = input("\nIngresa el nombre del archivo de salida: ")
                
            try:
                with open(output_file, "w", encoding="utf-8") as f:
                    f.write(content_to_save)
                print(f"✅ Texto guardado en: {output_file}")
            except Exception as e:
                print(f"❌ Error al guardar el archivo: {e}")
    
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nOperación cancelada por el usuario.")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        sys.exit(1) 