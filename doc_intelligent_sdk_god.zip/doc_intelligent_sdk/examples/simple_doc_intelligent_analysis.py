#!/usr/bin/env python3
"""
Ejemplo básico del uso de doc_intelligent_analysis.py con Service Principal

Este script muestra un ejemplo sencillo de cómo utilizar las funciones
en doc_intelligent_analysis.py para analizar un documento PDF utilizando
autenticación por Service Principal.

Requisitos:
1. Configurar las variables de entorno:
   - AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT
   - AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT
   - AZURE_TENANT_ID
   - AZURE_CLIENT_ID
   - AZURE_CLIENT_SECRET
2. Tener un archivo PDF para analizar

Uso:
    python examples/simple_doc_intelligent_analysis.py <ruta_al_pdf>
"""

import os
import sys
import time
from pathlib import Path

# Importar módulos necesarios
from doc_intelligent.utils.doc_intelligent_analysis import analyze_document
from doc_intelligent.auth import AzureCredential


def setup_environment():
    """Verificar y configurar el entorno necesario para el análisis de documentos."""
    # Variables requeridas
    required_vars = {
        "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT": "El endpoint privado de Azure Document Intelligence",
        "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT": "El endpoint público de Azure Document Intelligence",
        "AZURE_TENANT_ID": "ID del tenant de Azure (Directory ID)",
        "AZURE_CLIENT_ID": "ID del cliente (Application ID)",
        "AZURE_CLIENT_SECRET": "Secret del cliente"
    }
    
    # Verificar variables de entorno
    missing_vars = []
    for var, description in required_vars.items():
        if not os.environ.get(var):
            missing_vars.append(f"  - {var}: {description}")
    
    # Si faltan variables, solicitarlas
    if missing_vars:
        print("Faltan las siguientes variables de entorno necesarias:")
        for var in missing_vars:
            print(var)
        
        print("\n¿Desea configurar estas variables ahora? (s/n)")
        if input().lower() != 's':
            print("No se pueden configurar las credenciales. Saliendo...")
            return False
        
        # Configurar variables faltantes
        for var, description in required_vars.items():
            if not os.environ.get(var):
                value = input(f"Ingrese {var} ({description}): ").strip()
                os.environ[var] = value
    
    return True


def get_pdf_path():
    """Obtener la ruta al archivo PDF a analizar."""
    # Verificar si se proporcionó un argumento
    if len(sys.argv) > 1:
        pdf_path = Path(sys.argv[1])
        if pdf_path.exists() and pdf_path.is_file():
            return pdf_path
        else:
            print(f"Error: No se encontró el archivo {pdf_path}")
    
    # Si no hay argumento o el archivo no existe, solicitar ruta
    while True:
        path_str = input("Introduzca la ruta a un archivo PDF: ").strip()
        if not path_str:
            print("Operación cancelada.")
            return None
            
        pdf_path = Path(path_str)
        if pdf_path.exists() and pdf_path.is_file():
            return pdf_path
        else:
            print(f"Error: No se encontró el archivo {pdf_path}")


def create_service_principal_credential():
    """Crear credencial de Service Principal para la autenticación."""
    try:
        # Obtener valores de las variables de entorno
        tenant_id = os.environ.get("AZURE_TENANT_ID")
        client_id = os.environ.get("AZURE_CLIENT_ID")
        client_secret = os.environ.get("AZURE_CLIENT_SECRET")
        
        # Crear la credencial
        credential = AzureCredential.from_service_principal(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        return credential
    except Exception as e:
        print(f"Error al crear la credencial: {str(e)}")
        return None


def analyze_pdf_document(pdf_path, credential):
    """Analizar un documento PDF y extraer su contenido."""
    start_time = time.time()
    
    try:
        # Llamar a la función analyze_document
        content, document_id = analyze_document(
            file_path=pdf_path,
            upload_mode="multipart",  # Usar el modo multipart que es más eficiente
            model_id="prebuilt-read",  # Modelo para extraer texto
            credential=credential,
            poll_interval=5,  # Intervalo para verificar el estado del análisis
            timeout=300       # Tiempo máximo de espera (5 minutos)
        )
        
        elapsed_time = time.time() - start_time
        
        if content:
            print("\n=== Análisis completado con éxito ===")
            print(f"Tiempo total: {elapsed_time:.2f} segundos")
            print(f"ID del documento: {document_id}")
            print(f"Longitud del contenido extraído: {len(content)} caracteres")
            
            # Mostrar una vista previa del contenido
            preview_length = min(300, len(content))
            print(f"\nVista previa del contenido (primeros {preview_length} caracteres):")
            print("-" * 50)
            print(content[:preview_length] + "..." if len(content) > preview_length else content)
            print("-" * 50)
            
            # Ofrecer guardar el resultado
            should_save = input("\n¿Desea guardar el contenido extraído en un archivo? (s/n): ").lower() == 's'
            if should_save:
                output_path = pdf_path.with_suffix('.txt')
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Contenido guardado en: {output_path}")
                
            return True
        else:
            print("\n=== Error en el análisis ===")
            print(f"No se pudo extraer contenido del documento. ID de documento: {document_id}")
            return False
            
    except Exception as e:
        print(f"Error durante el análisis del documento: {str(e)}")
        return False


def main():
    """Función principal que ejecuta el ejemplo."""
    print("=== Ejemplo de Análisis de Documentos con Service Principal ===\n")
    
    # Verificar y configurar el entorno
    if not setup_environment():
        return
    
    # Obtener la ruta al PDF
    pdf_path = get_pdf_path()
    if not pdf_path:
        return
    
    # Crear credencial
    print("\nCreando credencial con Service Principal...")
    credential = create_service_principal_credential()
    if not credential:
        return
    
    # Analizar el documento
    print(f"\nAnalizando documento: {pdf_path}")
    print("Por favor espere, esto puede tomar unos minutos...")
    analyze_pdf_document(pdf_path, credential)


if __name__ == "__main__":
    main() 