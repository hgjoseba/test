#!/usr/bin/env python3
"""
Análisis avanzado de documentos con autenticación Service Principal

Este script proporciona una herramienta completa para analizar documentos
utilizando Azure Document Intelligence a través del módulo doc_intelligent_analysis.py.

Características:
- Análisis de documentos en formato nativo
- Análisis de documentos en formato base64
- Procesamiento por lotes de múltiples documentos
- Autenticación segura con Service Principal
- Guardado automático de resultados

Requisitos:
1. Configurar las variables de entorno:
   - AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT
   - AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT
   - AZURE_TENANT_ID
   - AZURE_CLIENT_ID
   - AZURE_CLIENT_SECRET
2. Tener archivos para analizar (PDF, DOCX, imágenes, etc.)

Uso:
    python examples/combined_doc_analysis.py [opciones]

Opciones:
    --file <ruta>         : Analizar un archivo individual
    --dir <directorio>    : Analizar todos los documentos en un directorio
    --base64              : Utilizar el modo base64 (por defecto: multipart)
    --batch               : Procesar archivos en lote (solo con --dir y --base64)
    --output <directorio> : Directorio para guardar resultados
    --model <modelo_id>   : Modelo a utilizar (default: prebuilt-read)
    --help                : Mostrar esta ayuda
"""

import os
import sys
import base64
import time
import argparse
import json
from pathlib import Path
from typing import List, Dict, Tuple, Optional, Any

# Importar módulos necesarios
from doc_intelligent.utils.doc_intelligent_analysis import (
    analyze_document,
    analyze_document_from_base64,
    analyze_multiple_base64_documents
)
from doc_intelligent.auth import AzureCredential


def parse_arguments():
    """Analizar los argumentos de línea de comandos."""
    parser = argparse.ArgumentParser(
        description="Herramienta de análisis de documentos con Azure Document Intelligence"
    )
    
    parser.add_argument("--file", type=str, help="Ruta a un archivo individual para analizar")
    parser.add_argument("--dir", type=str, help="Directorio con documentos para analizar")
    parser.add_argument("--base64", action="store_true", help="Utilizar el modo base64 (por defecto: multipart)")
    parser.add_argument("--batch", action="store_true", help="Procesar archivos en lote (solo con --dir y --base64)")
    parser.add_argument("--output", type=str, help="Directorio para guardar resultados", default="resultados")
    parser.add_argument("--model", type=str, help="Modelo a utilizar", default="prebuilt-read")
    
    args = parser.parse_args()
    
    # Verificar argumentos
    if not args.file and not args.dir:
        parser.print_help()
        print("\nError: Debe especificar --file o --dir")
        sys.exit(1)
    
    if args.batch and not (args.dir and args.base64):
        print("Error: La opción --batch solo puede usarse con --dir y --base64")
        sys.exit(1)
    
    return args


def setup_environment():
    """Verificar y configurar el entorno necesario para el análisis de documentos."""
    # Variables requeridas
    required_vars = {
        "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT": "El endpoint privado de Azure Document Intelligence",
        "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT": "El endpoint público de Azure Document Intelligence",
        "AZURE_TENANT_ID": "ID del tenant de Azure (Directory ID)",
        "AZURE_CLIENT_ID": "ID del cliente (Application ID)",
        "AZURE_CLIENT_SECRET": "Secret del cliente"
    }
    
    # Verificar variables de entorno
    missing_vars = []
    for var, description in required_vars.items():
        if not os.environ.get(var):
            missing_vars.append(f"  - {var}: {description}")
    
    # Si faltan variables, solicitarlas
    if missing_vars:
        print("Faltan las siguientes variables de entorno necesarias:")
        for var in missing_vars:
            print(var)
        
        print("\n¿Desea configurar estas variables ahora? (s/n)")
        if input().lower() != 's':
            print("No se pueden configurar las credenciales. Saliendo...")
            return False
        
        # Configurar variables faltantes
        for var, description in required_vars.items():
            if not os.environ.get(var):
                value = input(f"Ingrese {var} ({description}): ").strip()
                os.environ[var] = value
    
    return True


def create_service_principal_credential():
    """Crear credencial de Service Principal para la autenticación."""
    try:
        # Obtener valores de las variables de entorno
        tenant_id = os.environ.get("AZURE_TENANT_ID")
        client_id = os.environ.get("AZURE_CLIENT_ID")
        client_secret = os.environ.get("AZURE_CLIENT_SECRET")
        
        # Crear la credencial
        credential = AzureCredential.from_service_principal(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        print("Credencial de Service Principal creada correctamente.")
        return credential
    except Exception as e:
        print(f"Error al crear la credencial: {str(e)}")
        return None


def get_content_type(file_path):
    """Determinar el tipo de contenido basado en la extensión del archivo."""
    extension = file_path.suffix.lower()
    content_types = {
        '.pdf': 'application/pdf',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.doc': 'application/msword',
        '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '.xls': 'application/vnd.ms-excel',
        '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        '.ppt': 'application/vnd.ms-powerpoint',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.tiff': 'image/tiff',
        '.tif': 'image/tiff'
    }
    
    return content_types.get(extension, 'application/octet-stream')


def convert_to_base64(file_path):
    """Convertir un archivo a base64."""
    try:
        with open(file_path, 'rb') as file:
            file_content = file.read()
        
        base64_string = base64.b64encode(file_content).decode('utf-8')
        content_type = get_content_type(file_path)
        
        return base64_string, content_type
    except Exception as e:
        print(f"Error al convertir el archivo {file_path} a base64: {str(e)}")
        return None, None


def analyze_single_document(file_path, credential, args):
    """Analizar un único documento utilizando el modo especificado."""
    start_time = time.time()
    print(f"Analizando archivo: {file_path}")
    
    try:
        if args.base64:
            # Modo base64
            base64_string, content_type = convert_to_base64(file_path)
            if not base64_string:
                return None, None
                
            print(f"Archivo convertido a base64. Tamaño: {len(base64_string) / 1024:.2f} KB")
            print(f"Tipo de contenido: {content_type}")
            
            content, document_id = analyze_document_from_base64(
                base64_string=base64_string,
                content_type=content_type,
                model_id=args.model,
                credential=credential,
                poll_interval=5,
                timeout=300
            )
        else:
            # Modo multipart
            content, document_id = analyze_document(
                file_path=file_path,
                upload_mode="multipart",
                model_id=args.model,
                credential=credential,
                poll_interval=5,
                timeout=300
            )
        
        elapsed_time = time.time() - start_time
        
        if content:
            print(f"  ✓ Análisis completado en {elapsed_time:.2f} segundos. ID: {document_id}")
            return content, document_id
        else:
            print(f"  ✗ No se pudo extraer contenido. ID: {document_id}, Tiempo: {elapsed_time:.2f}s")
            return None, document_id
            
    except Exception as e:
        print(f"  ✗ Error durante el análisis: {str(e)}")
        return None, None


def analyze_directory(directory_path, credential, args):
    """Analizar todos los documentos en un directorio."""
    # Crear directorio de resultados si no existe
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Obtener los archivos a procesar
    supported_extensions = ['.pdf', '.docx', '.doc', '.jpg', '.jpeg', '.png', '.tiff', '.tif']
    files_to_process = []
    
    for ext in supported_extensions:
        files_to_process.extend(list(directory_path.glob(f"*{ext}")))
    
    if not files_to_process:
        print(f"No se encontraron documentos compatibles en {directory_path}")
        return
    
    print(f"Se encontraron {len(files_to_process)} documentos para analizar.")
    
    # Procesar archivos en batch si se solicitó
    if args.batch and args.base64:
        return analyze_batch(files_to_process, credential, args)
    
    # Procesar archivos individualmente
    results = {}
    
    for file_path in files_to_process:
        content, document_id = analyze_single_document(file_path, credential, args)
        
        if content:
            # Guardar contenido en un archivo
            result_file = output_dir / f"{file_path.stem}.txt"
            with open(result_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Guardar información en resultados
            results[str(file_path)] = {
                "document_id": document_id,
                "status": "success",
                "result_file": str(result_file)
            }
        else:
            results[str(file_path)] = {
                "document_id": document_id,
                "status": "failed"
            }
    
    # Guardar resumen de resultados
    summary_file = output_dir / "resumen.json"
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f"\nResumen de resultados guardado en: {summary_file}")
    
    # Mostrar estadísticas
    successful = sum(1 for v in results.values() if v["status"] == "success")
    print(f"Procesados: {len(results)} archivos, Exitosos: {successful}, Fallidos: {len(results) - successful}")
    

def analyze_batch(files, credential, args):
    """Procesar múltiples documentos en un lote usando base64."""
    if not files:
        return
    
    print("Preparando documentos para procesamiento en lote...")
    
    # Convertir todos los archivos a base64
    documents = []
    file_map = {}  # Para mantener el mapeo entre índices y archivos
    
    for idx, file_path in enumerate(files):
        base64_string, content_type = convert_to_base64(file_path)
        if base64_string:
            documents.append({
                "base64_string": base64_string,
                "content_type": content_type
            })
            file_map[f"doc_{idx}"] = str(file_path)
    
    if not documents:
        print("No se pudieron preparar documentos para procesamiento en lote.")
        return
    
    print(f"Procesando {len(documents)} documentos en lote...")
    start_time = time.time()
    
    # Analizar documentos en lote
    try:
        results = analyze_multiple_base64_documents(
            documents=documents,
            model_id=args.model,
            credential=credential,
            verify_ssl=True,
            poll_interval=5,
            timeout=900  # tiempo de espera más largo para lotes
        )
        
        elapsed_time = time.time() - start_time
        print(f"Lote procesado en {elapsed_time:.2f} segundos.")
        
        # Crear directorio de resultados si no existe
        output_dir = Path(args.output)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Procesar resultados
        batch_results = {}
        successful = 0
        
        for key, content in results.items():
            file_path = file_map.get(key)
            if not file_path:
                continue
                
            if content:
                # Guardar contenido en un archivo
                result_file = output_dir / f"{Path(file_path).stem}.txt"
                with open(result_file, 'w', encoding='utf-8') as f:
                    f.write(content)
                
                batch_results[file_path] = {
                    "status": "success",
                    "result_file": str(result_file)
                }
                successful += 1
            else:
                batch_results[file_path] = {
                    "status": "failed"
                }
        
        # Guardar resumen de resultados
        summary_file = output_dir / "resumen_lote.json"
        with open(summary_file, 'w', encoding='utf-8') as f:
            json.dump(batch_results, f, indent=2, ensure_ascii=False)
        
        print(f"\nResumen de resultados por lote guardado en: {summary_file}")
        print(f"Procesados: {len(batch_results)} archivos, Exitosos: {successful}, Fallidos: {len(batch_results) - successful}")
        
    except Exception as e:
        print(f"Error en el procesamiento por lotes: {str(e)}")


def main():
    """Función principal del programa."""
    print("=== Análisis de Documentos con Azure Document Intelligence ===\n")
    
    # Analizar argumentos
    args = parse_arguments()
    
    # Verificar y configurar el entorno
    if not setup_environment():
        return 1
    
    # Crear credencial
    credential = create_service_principal_credential()
    if not credential:
        return 1
    
    # Procesar según las opciones
    if args.file:
        file_path = Path(args.file)
        if not file_path.exists() or not file_path.is_file():
            print(f"Error: No se encontró el archivo {file_path}")
            return 1
        
        # Crear directorio de resultados si no existe
        output_dir = Path(args.output)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Analizar archivo individual
        content, document_id = analyze_single_document(file_path, credential, args)
        
        if content:
            # Guardar contenido en un archivo
            result_file = output_dir / f"{file_path.stem}.txt"
            with open(result_file, 'w', encoding='utf-8') as f:
                f.write(content)
            
            print(f"\nResultado guardado en: {result_file}")
            
            # Mostrar una vista previa del contenido
            preview_length = min(300, len(content))
            print(f"\nVista previa del contenido (primeros {preview_length} caracteres):")
            print("-" * 50)
            print(content[:preview_length] + "..." if len(content) > preview_length else content)
            print("-" * 50)
    
    elif args.dir:
        dir_path = Path(args.dir)
        if not dir_path.exists() or not dir_path.is_dir():
            print(f"Error: No se encontró el directorio {dir_path}")
            return 1
        
        # Analizar directorio
        analyze_directory(dir_path, credential, args)
    
    print("\n¡Proceso completado!")
    return 0


if __name__ == "__main__":
    sys.exit(main()) 