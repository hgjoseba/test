#!/usr/bin/env python
"""
Ejemplo de Azure Document Intelligence que combina:
1. Autenticación mediante Service Principal
2. Configuración automática de NO_PROXY para endpoints privados
3. Análisis de documentos PDF convertidos a base64

Ideal para entornos empresariales donde los documentos se transmiten como base64 
a través de APIs o servicios web, manteniendo la seguridad de Service Principal.
"""

import os
import base64
import time
from doc_intelligent import DocIntelligenceClient
from doc_intelligent.providers import AzureDocumentProvider

def leer_archivo_como_base64(ruta_archivo):
    """Lee un archivo y lo devuelve como string base64."""
    try:
        with open(ruta_archivo, "rb") as archivo:
            bytes_archivo = archivo.read()
            return base64.b64encode(bytes_archivo).decode("utf-8")
    except Exception as e:
        print(f"Error al leer el archivo: {e}")
        return None

def mostrar_configuracion_proxy():
    """Muestra la configuración actual de proxy del sistema."""
    print("\n=== Configuración de proxy del sistema ===")
    print(f"NO_PROXY: {os.environ.get('NO_PROXY', 'No definido')}")
    print(f"HTTP_PROXY: {os.environ.get('HTTP_PROXY', 'No definido')}")
    print(f"HTTPS_PROXY: {os.environ.get('HTTPS_PROXY', 'No definido')}")

def main():
    print("=== Ejemplo de análisis de documento base64 con Azure Document Intelligence ===")
    print("Este ejemplo demuestra:")
    print("1. Autenticación con Azure AD mediante Service Principal")
    print("2. Configuración automática de NO_PROXY para endpoints privados")
    print("3. Análisis de documentos PDF convertidos a formato base64")
    
    # 1. CONFIGURACIÓN DE CREDENCIALES Y ENDPOINTS
    print("\n=== Configurando credenciales y endpoints ===")
    
    # Información del Service Principal (idealmente desde variables de entorno)
    tenant_id = os.environ.get("AZURE_TENANT_ID", "your_tenant_id")
    client_id = os.environ.get("AZURE_CLIENT_ID", "your_client_id")
    client_secret = os.environ.get("AZURE_CLIENT_SECRET", "your_client_secret")
    
    # Endpoints para escenarios empresariales
    private_endpoint = os.environ.get(
        "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", 
        "https://your-private-endpoint.cognitiveservices.azure.com/"
    )
    public_endpoint = os.environ.get(
        "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT",
        "https://eastus.api.cognitive.microsoft.com/"
    )
    
    # Mostrar configuración inicial de proxy
    print("Estado inicial de la configuración de proxy:")
    mostrar_configuracion_proxy()
    
    # 2. INICIALIZAR PROVEEDOR DE AZURE USANDO EL MÉTODO from_service_principal
    print("\n=== Creando proveedor con método from_service_principal ===")
    print("Este método simplifica la creación del proveedor con credenciales de Service Principal")
    
    # Usar el método from_service_principal proporcionado por el SDK
    provider = AzureDocumentProvider.from_service_principal(
        tenant_id=tenant_id,                 # Azure AD tenant ID
        client_id=client_id,                 # Application (client) ID
        client_secret=client_secret,         # Client secret 
        endpoint=private_endpoint,           # Endpoint privado
        public_endpoint=public_endpoint      # Endpoint público (para reemplazo URLs)
    )
    
    print("✓ Proveedor de Azure inicializado con Service Principal")
    
    # Verificar que el SDK ha configurado NO_PROXY automáticamente
    print("\nVerificando configuración de NO_PROXY después de inicializar el SDK:")
    mostrar_configuracion_proxy()
    
    # Verificar que el dominio del endpoint privado está en NO_PROXY
    private_domain = private_endpoint.replace("https://", "").split("/")[0]
    no_proxy = os.environ.get("NO_PROXY", "")
    if private_domain in no_proxy:
        print(f"✓ El dominio privado '{private_domain}' fue añadido a NO_PROXY correctamente")
    else:
        print(f"⚠️ El dominio privado '{private_domain}' no está en NO_PROXY")
    
    # 3. INICIALIZAR EL SDK
    doc_intelligence = DocIntelligenceClient(provider=provider)
    print("✓ SDK Document Intelligence inicializado")
    
    # 4. CONVERTIR DOCUMENTO PDF A BASE64
    print("\n=== Convirtiendo documento PDF a base64 ===")
    ruta_pdf = "samples/invoice.pdf"  # Cambiar a la ruta de tu archivo PDF
    print(f"Leyendo archivo: {ruta_pdf}")
    
    # Verificar que el archivo existe
    if not os.path.exists(ruta_pdf):
        print(f"⚠️ El archivo {ruta_pdf} no existe.")
        print("Creando directorio de samples para futuras pruebas...")
        os.makedirs("samples", exist_ok=True)
        return
    
    # Convertir a base64
    inicio_conversion = time.time()
    base64_data = leer_archivo_como_base64(ruta_pdf)
    if not base64_data:
        print("❌ Error al convertir archivo a base64")
        return
    
    fin_conversion = time.time()
    tamano_base64 = len(base64_data)
    print(f"✓ Conversión completada en {fin_conversion - inicio_conversion:.2f} segundos")
    print(f"  Tamaño de datos base64: {tamano_base64/1024:.2f} KB")
    
    # Mostrar primeros y últimos caracteres del base64 para verificación
    print(f"  Vista previa: {base64_data[:50]}...{base64_data[-50:]}")
    
    # 5. ANALIZAR DOCUMENTO DESDE BASE64
    print("\n=== Analizando documento desde datos base64 ===")
    try:
        # El tipo de contenido para PDF
        content_type = "application/pdf"
        
        # Modelo a utilizar (por ejemplo, para facturas)
        model_id = "prebuilt-invoice"  # O prebuilt-document, prebuilt-layout, etc.
        
        print(f"Enviando solicitud con modelo: {model_id}")
        print(f"Tipo de contenido: {content_type}")
        
        # Iniciar tiempo para medir rendimiento
        inicio_analisis = time.time()
        
        # Realizar el análisis usando base64
        respuesta = doc_intelligence.analyze_document_from_base64(
            base64_string=base64_data,
            content_type=content_type,
            model_id=model_id,
            locale="en",
            # Parámetros adicionales
            poll_interval=5  # Intervalo de polling en segundos
        )
        
        # Calcular tiempo total
        fin_analisis = time.time()
        tiempo_total = fin_analisis - inicio_analisis
        
        # 6. PROCESAR RESULTADOS
        print(f"\n✓ Análisis completado en {tiempo_total:.2f} segundos")
        print(f"Estado: {respuesta.status}")
        print(f"Páginas procesadas: {len(respuesta.pages)}")
        print(f"Campos detectados: {len(respuesta.fields)}")
        
        # Mostrar algunos campos importantes del documento
        if model_id == "prebuilt-invoice":
            campos_importantes = ["InvoiceId", "InvoiceDate", "DueDate", "VendorName", "CustomerName", "InvoiceTotal"]
            print("\nInformación extraída de la factura:")
            for campo in campos_importantes:
                if campo in respuesta.fields:
                    valor = respuesta.fields[campo].value
                    confianza = respuesta.fields[campo].confidence
                    print(f"  {campo}: {valor} (confianza: {confianza:.2f})")
        
        # Extraer texto general de las primeras páginas (limitado por brevedad)
        print("\nExtracto de texto del documento:")
        for pagina in respuesta.pages[:1]:  # Solo mostrar la primera página
            texto = pagina.text[:200]  # Limitar a 200 caracteres
            print(f"  Página {pagina.page_number}: {texto}...")
        
    except Exception as e:
        print(f"\n❌ Error durante el análisis: {e}")
        print("Nota: Para ejecutar este ejemplo correctamente, necesitas:")
        print("1. Credenciales válidas de Azure (Service Principal)")
        print("2. Un documento PDF real en la ruta especificada")
        print("3. Acceso a un recurso Azure Document Intelligence")
    
 

if __name__ == "__main__":
    # Guardar configuración original de NO_PROXY
    original_no_proxy = os.environ.get("NO_PROXY", "")
    
    try:
        main()
    finally:
        # Restaurar la configuración original
        if original_no_proxy:
            os.environ["NO_PROXY"] = original_no_proxy
        elif "NO_PROXY" in os.environ:
            del os.environ["NO_PROXY"]
        
        print("\n=== Configuración de proxy restaurada a valores originales ===")
        print(f"NO_PROXY: {os.environ.get('NO_PROXY', 'No definido')}") 