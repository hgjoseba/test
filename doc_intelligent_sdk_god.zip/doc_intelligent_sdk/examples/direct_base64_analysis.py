#!/usr/bin/env python3
"""
Ejemplo directo del uso de analyze_document_from_base64 con Service Principal

Este ejemplo muestra específicamente cómo:
1. Leer un documento local (PDF, DOC o DOCX)
2. Convertirlo a formato base64
3. Enviarlo para análisis usando analyze_document_from_base64
4. Recibir y mostrar el resultado del análisis

Requisitos:
- Tener configuradas las variables de entorno de Azure
- Tener un documento para analizar (Solo formatos PDF, DOC o DOCX)

Uso:
    python examples/direct_base64_analysis.py <ruta_del_archivo>

Si no se proporciona una ruta, se solicitará interactivamente.
"""

import os
import sys
import base64
import time
from pathlib import Path

# Importar la función específica para análisis desde base64
from doc_intelligent.utils.doc_intelligent_analysis import analyze_document_from_base64
from doc_intelligent.auth import AzureCredential


# Función para configurar las variables de entorno necesarias
def setup_environment():
    """Verificar y configurar las variables de entorno necesarias."""
    # Endpoints requeridos (siempre necesarios)
    endpoint_vars = {
        "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT": "Endpoint privado de Azure Document Intelligence",
        "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT": "Endpoint público de Azure Document Intelligence"
    }
    
    # Variables requeridas para Service Principal
    service_principal_vars = {
        "AZURE_TENANT_ID": "ID del tenant de Azure (Directory ID)",
        "AZURE_CLIENT_ID": "ID del cliente (Application ID)",
        "AZURE_CLIENT_SECRET": "Secret del cliente"
    }
    
    # Verificar endpoints
    missing_endpoints = [var for var, desc in endpoint_vars.items() if not os.environ.get(var)]
    if missing_endpoints:
        print("Faltan las siguientes variables de entorno necesarias:")
        for var in missing_endpoints:
            print(f"  - {var}: {endpoint_vars[var]}")
            value = input(f"    Ingrese el valor para {var}: ").strip()
            if value:
                os.environ[var] = value
            else:
                print(f"No se proporcionó un valor para {var}. No se puede continuar.")
                return False
    
    # Verificar credenciales de Service Principal
    missing_sp_vars = [var for var, desc in service_principal_vars.items() if not os.environ.get(var)]
    if missing_sp_vars:
        print("\nFaltan las siguientes variables para Service Principal:")
        for var in missing_sp_vars:
            print(f"  - {var}: {service_principal_vars[var]}")
            value = input(f"    Ingrese el valor para {var}: ").strip()
            if value:
                os.environ[var] = value
            else:
                print(f"No se proporcionó un valor para {var}. No se puede continuar.")
                return False
    
    print("\nConfiguraciones cargadas correctamente para Service Principal.")
    return True


# Función para obtener la ruta del archivo a analizar
def get_file_path():
    """Obtener la ruta del archivo a analizar desde los argumentos o interactivamente."""
    # Verificar si se proporcionó un archivo como argumento
    if len(sys.argv) > 1:
        file_path = Path(sys.argv[1])
        if file_path.exists() and file_path.is_file():
            return file_path
        print(f"El archivo {file_path} no existe o no es válido.")
    
    # Solicitar la ruta interactivamente
    while True:
        file_path_str = input("Ingrese la ruta completa al archivo que desea analizar: ").strip()
        if not file_path_str:
            print("Operación cancelada.")
            return None
        
        file_path = Path(file_path_str)
        if file_path.exists() and file_path.is_file():
            return file_path
        
        print(f"El archivo {file_path} no existe o no es válido. Intente nuevamente.")


# Función para determinar el tipo de contenido basado en la extensión del archivo
def get_content_type(file_path):
    """Determinar el tipo de contenido MIME basado en la extensión del archivo."""
    extension = file_path.suffix.lower()
    content_types = {
        # Documentos aceptados
        '.pdf': 'application/pdf',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.doc': 'application/msword',
    }
    
    # Verificar si la extensión es compatible
    if extension not in content_types:
        print(f"Error: El tipo de archivo {extension} no es compatible.")
        print("Solo se aceptan archivos PDF, DOC o DOCX.")
        print("Se utilizará 'application/octet-stream' como tipo predeterminado, pero el análisis podría fallar.")
        return "application/octet-stream"
    
    return content_types[extension]


# Función principal para leer el archivo y convertirlo a base64
def file_to_base64(file_path):
    """
    Lee un archivo local y lo convierte a formato base64.
    
    Args:
        file_path (Path): Ruta al archivo local
        
    Returns:
        tuple: (string base64, tipo de contenido)
    """
    try:
        print(f"Leyendo archivo: {file_path}")
        
        # Determinar el tipo de contenido
        content_type = get_content_type(file_path)
        
        # Abrir y leer el archivo en modo binario
        with open(file_path, 'rb') as file:
            file_bytes = file.read()
        
        # Convertir a base64
        base64_string = base64.b64encode(file_bytes).decode('utf-8')
        
        file_size_kb = len(file_bytes) / 1024
        base64_size_kb = len(base64_string) / 1024
        
        print(f"Archivo leído correctamente:")
        print(f"  - Tamaño original: {file_size_kb:.2f} KB")
        print(f"  - Tamaño en base64: {base64_size_kb:.2f} KB")
        print(f"  - Tipo de contenido: {content_type}")
        
        return base64_string, content_type
    
    except Exception as e:
        print(f"Error al leer y convertir el archivo: {str(e)}")
        return None, None


# Función para crear la credencial de servicio principal
def create_credential():
    """Crear credencial de Service Principal para Azure Document Intelligence."""
    try:
        tenant_id = os.environ.get("AZURE_TENANT_ID")
        client_id = os.environ.get("AZURE_CLIENT_ID")
        client_secret = os.environ.get("AZURE_CLIENT_SECRET")
        
        # Verificar que tengamos las variables necesarias para Service Principal
        if not all([tenant_id, client_id, client_secret]):
            print("Error: Faltan credenciales para Service Principal.")
            print("Se requieren AZURE_TENANT_ID, AZURE_CLIENT_ID y AZURE_CLIENT_SECRET.")
            return None
        
        print("Creando credencial ClientSecretCredential para Service Principal...")
        
        # Importar directamente ClientSecretCredential de azure.identity
        from azure.identity import ClientSecretCredential
        
        # Crear ClientSecretCredential directamente
        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        print("Credencial de Service Principal creada correctamente")
        return credential
    
    except Exception as e:
        print(f"Error al crear la credencial: {str(e)}")
        return None


# Función principal
def main():
    """Función principal del ejemplo."""
    print("=== Análisis de documento con base64 ===\n")
    
    # Verificar y configurar el entorno
    if not setup_environment():
        return 1
    
    # Obtener la ruta del archivo
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
    else:
        file_path = input("\nPor favor, ingrese la ruta completa al documento (solo se aceptan formatos PDF, DOC o DOCX): ")

    # Verificar si el archivo existe
    if not os.path.isfile(file_path):
        print(f"Error: El archivo '{file_path}' no existe.")
        return
    
    # Convertir archivo a base64
    base64_string, content_type = file_to_base64(file_path)
    if not base64_string:
        return 1
    
    # Crear credencial
    credential = create_credential()
    if not credential:
        return 1
    
    # Realizar el análisis
    print("\nAnalizando documento con Azure Document Intelligence...")
    print("Esto puede tomar unos momentos...")
    
    start_time = time.time()
    
    try:
        # Usamos Service Principal para la autenticación
        print("Usando Service Principal para la solicitud...")
        
        # Pasamos el objeto credential de Service Principal
        response = analyze_document_from_base64(
            base64_string=base64_string,
            content_type=content_type,
            model_id="prebuilt-read",
            credential=credential,  
            poll_interval=5,
            timeout=300
        )
        
        elapsed_time = time.time() - start_time
        
        # Desempaquetar la respuesta
        if isinstance(response, tuple) and len(response) == 2:
            content, document_id = response
        else:
            # Si la respuesta no es una tupla como se esperaba
            content = response
            document_id = None
        
        # Intentar extraer información de resultado si es un objeto DocumentAnalysisResponse
        if hasattr(response, 'result') and hasattr(response, 'status'):
            # Es probablemente un objeto DocumentAnalysisResponse
            content = response.get_text() if hasattr(response, 'get_text') else ""
            
            # Buscar document_id en varias ubicaciones posibles
            if not document_id:
                # Intento 1: Buscar directamente en el objeto
                document_id = getattr(response, 'id', None) or getattr(response, 'job_id', None)
                
                # Intento 2: Buscar en el resultado
                if not document_id and response.result:
                    if hasattr(response.result, 'id'):
                        document_id = response.result.id
                    elif isinstance(response.result, dict):
                        document_id = (response.result.get('id') or 
                                     response.result.get('documentId') or 
                                     response.result.get('document_id') or 
                                     response.result.get('jobId') or 
                                     response.result.get('job_id'))
                
                # Intento 3: Buscar en los metadatos o propiedades adicionales
                if not document_id and hasattr(response, 'metadata'):
                    document_id = (getattr(response.metadata, 'id', None) or 
                                 getattr(response.metadata, 'document_id', None))
        
        # Manejar caso donde document_id es None o está en un formato diferente
        document_id_str = document_id if document_id else "No disponible"
        
        if content:
            print(f"\n✅ Análisis completado con éxito en {elapsed_time:.2f} segundos")
            print(f"ID del documento: {document_id_str}")
            print(f"Contenido extraído ({len(content)} caracteres)")
            
            # Mostrar vista previa
            preview_length = min(300, len(content))
            print("\n--- Vista previa del contenido ---")
            print(content[:preview_length] + ("..." if len(content) > preview_length else ""))
            print("--------------------------------")
            
            # Guardar resultado
            save = input("\n¿Desea guardar el contenido extraído? (s/n): ").lower() == 's'
            if save:
                output_path = file_path.with_suffix('.txt')
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Contenido guardado en: {output_path}")
            
            return 0
        else:
            print(f"\n❌ No se pudo extraer contenido del documento (ID: {document_id_str})")
            print(f"Tiempo transcurrido: {elapsed_time:.2f} segundos")
            return 1
    
    except Exception as e:
        print(f"\n❌ Error durante el análisis: {str(e)}")
        print("\nRecomendación: verificar que las credenciales son correctas y tienen permisos adecuados")
        print("También asegúrese de que el formato del documento sea compatible con Azure Document Intelligence")
        return 1


if __name__ == "__main__":
    sys.exit(main()) 