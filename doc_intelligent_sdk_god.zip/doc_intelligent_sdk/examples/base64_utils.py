#!/usr/bin/env python
"""
Utilidades para trabajar con strings base64 para Document Intelligence.

Este script proporciona funciones útiles para:
1. Convertir archivos a strings base64
2. Guardar strings base64 en archivos
3. Cargar strings base64 desde archivos
4. Ver información sobre strings base64

Estas utilidades son útiles como complemento del ejemplo 'base64_analysis_example.py'
para preparar y manejar strings base64 antes del análisis.
"""

import os
import sys
import base64
import argparse
from pathlib import Path

def file_to_base64(file_path):
    """
    Convierte un archivo a un string base64.
    
    Args:
        file_path: Ruta al archivo a convertir
        
    Returns:
        str: String base64 o None si hay error
    """
    try:
        with open(file_path, "rb") as f:
            file_bytes = f.read()
        b64_string = base64.b64encode(file_bytes).decode("utf-8")
        return b64_string
    except Exception as e:
        print(f"❌ Error al convertir el archivo a base64: {e}")
        return None

def save_base64_to_file(b64_string, output_file):
    """
    Guarda un string base64 en un archivo.
    
    Args:
        b64_string: String base64 a guardar
        output_file: Ruta del archivo donde guardar
        
    Returns:
        bool: True si se guardó correctamente, False en caso contrario
    """
    try:
        with open(output_file, "w") as f:
            f.write(b64_string)
        return True
    except Exception as e:
        print(f"❌ Error al guardar el string base64: {e}")
        return False

def load_base64_from_file(file_path):
    """
    Carga un string base64 desde un archivo.
    
    Args:
        file_path: Ruta al archivo que contiene el string base64
        
    Returns:
        str: String base64 o None si hay error
    """
    try:
        with open(file_path, "r") as f:
            b64_string = f.read().strip()
        return b64_string
    except Exception as e:
        print(f"❌ Error al cargar el string base64: {e}")
        return None

def get_base64_info(b64_string):
    """
    Obtiene información sobre un string base64.
    
    Args:
        b64_string: String base64 a analizar
        
    Returns:
        dict: Diccionario con información del string base64
    """
    info = {
        "length": len(b64_string),
        "size_kb": len(b64_string) / 1024,
        "size_mb": len(b64_string) / (1024 * 1024),
        "estimated_original_size_kb": (len(b64_string) * 3/4) / 1024,  # Aproximado
        "is_valid": all(c in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" for c in b64_string)
    }
    return info

def decode_base64_sample(b64_string, max_bytes=50):
    """
    Decodifica y muestra una muestra del contenido base64.
    Útil para verificar que el string base64 es válido.
    
    Args:
        b64_string: String base64 a decodificar parcialmente
        max_bytes: Máximo número de bytes a mostrar
        
    Returns:
        bytes: Muestra de los primeros bytes del contenido
    """
    try:
        # Tomar solo los primeros caracteres para decodificar
        sample_length = min(len(b64_string), 100)  # Tomar solo una pequeña muestra
        sample = b64_string[:sample_length]
        
        # Decodificar la muestra
        decoded = base64.b64decode(sample)
        
        # Limitar la cantidad de bytes a mostrar
        return decoded[:max_bytes]
    except Exception as e:
        print(f"❌ Error al decodificar el string base64: {e}")
        return None

def main():
    parser = argparse.ArgumentParser(description="Utilidades para trabajar con strings base64")
    parser.add_argument("--convert", "-c", help="Convertir archivo a base64")
    parser.add_argument("--save", "-s", help="Guardar string base64 en archivo")
    parser.add_argument("--load", "-l", help="Cargar string base64 desde archivo")
    parser.add_argument("--output", "-o", help="Archivo de salida")
    parser.add_argument("--info", "-i", action="store_true", help="Mostrar información del string base64")
    parser.add_argument("--sample", action="store_true", help="Mostrar muestra del contenido decodificado")
    
    args = parser.parse_args()
    
    # Variable para almacenar el string base64
    b64_string = None
    
    # Convertir archivo a base64
    if args.convert:
        if not os.path.exists(args.convert):
            print(f"❌ Error: El archivo {args.convert} no existe")
            return 1
            
        print(f"\n=== Convirtiendo archivo a base64 ===")
        print(f"Archivo: {args.convert}")
        
        b64_string = file_to_base64(args.convert)
        if b64_string:
            print(f"✅ Archivo convertido a base64 ({len(b64_string)} caracteres)")
            
            # Si se especificó un archivo de salida, guardar el string base64
            if args.output:
                if save_base64_to_file(b64_string, args.output):
                    print(f"✅ String base64 guardado en: {args.output}")
        else:
            return 1
    
    # Cargar string base64 desde archivo
    elif args.load:
        if not os.path.exists(args.load):
            print(f"❌ Error: El archivo {args.load} no existe")
            return 1
            
        print(f"\n=== Cargando string base64 desde archivo ===")
        print(f"Archivo: {args.load}")
        
        b64_string = load_base64_from_file(args.load)
        if b64_string:
            print(f"✅ String base64 cargado ({len(b64_string)} caracteres)")
        else:
            return 1
    
    # Mostrar información del string base64
    if args.info and b64_string:
        info = get_base64_info(b64_string)
        
        print(f"\n=== Información del string base64 ===")
        print(f"Longitud: {info['length']} caracteres")
        print(f"Tamaño: {info['size_kb']:.2f} KB ({info['size_mb']:.4f} MB)")
        print(f"Tamaño original estimado: {info['estimated_original_size_kb']:.2f} KB")
        print(f"¿Es válido? {'✅ Sí' if info['is_valid'] else '❌ No'}")
    
    # Mostrar muestra del contenido decodificado
    if args.sample and b64_string:
        sample = decode_base64_sample(b64_string)
        
        if sample:
            print(f"\n=== Muestra del contenido decodificado ===")
            try:
                # Intentar decodificar como texto
                print(f"Como texto: {sample[:30].decode('utf-8', errors='replace')}...")
            except:
                pass
                
            print(f"Como bytes: {sample[:30]}")
            
            # Detectar posible tipo de archivo
            if sample.startswith(b'%PDF'):
                print("✅ Tipo de archivo detectado: PDF")
            elif sample.startswith(b'\xff\xd8\xff'):
                print("✅ Tipo de archivo detectado: JPEG")
            elif sample.startswith(b'PK\x03\x04'):
                print("✅ Tipo de archivo detectado: ZIP/DOCX/XLSX")
            elif sample.startswith(b'GIF8'):
                print("✅ Tipo de archivo detectado: GIF")
            elif sample.startswith(b'\x89PNG'):
                print("✅ Tipo de archivo detectado: PNG")
            else:
                print("❓ Tipo de archivo no reconocido")
    
    # Si no se especificó ninguna acción
    if not any([args.convert, args.load, args.output, args.info, args.sample]):
        parser.print_help()
    
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nOperación cancelada por el usuario.")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        sys.exit(1) 