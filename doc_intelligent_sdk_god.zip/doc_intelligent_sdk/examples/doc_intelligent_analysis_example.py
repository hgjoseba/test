#!/usr/bin/env python3
"""
Ejemplo de uso del nuevo módulo doc_intelligent_analysis.py con autenticación de Service Principal

Este script muestra un ejemplo de cómo utilizar las nuevas funciones basadas en AzureDocumentProvider
en comparación con las funciones originales de document_analysis.py, utilizando autenticación segura
a través de Service Principal de Azure.

Para ejecutar este ejemplo:
1. Configure las variables de entorno para los endpoints:
   - AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT
   - AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT
2. Configure las variables de entorno para Service Principal:
   - AZURE_TENANT_ID
   - AZURE_CLIENT_ID
   - AZURE_CLIENT_SECRET
3. Tenga un archivo PDF de prueba
4. Execute: python examples/doc_intelligent_analysis_example.py

Si no tiene las variables de entorno configuradas, el script le guiará a través del
proceso de configuración interactiva.
"""

import os
import base64
import time
from pathlib import Path

# Importar el módulo original
from doc_intelligent.utils.document_analysis import (
    analyze_document as analyze_document_original,
    analyze_document_from_base64 as analyze_document_from_base64_original,
    analyze_multiple_base64_documents as analyze_multiple_base64_documents_original
)

# Importar el nuevo módulo basado en AzureDocumentProvider
from doc_intelligent.utils.doc_intelligent_analysis import (
    analyze_document as analyze_document_new,
    analyze_document_from_base64 as analyze_document_from_base64_new,
    analyze_multiple_base64_documents as analyze_multiple_base64_documents_new
)

# Importar la clase de autenticación
from doc_intelligent.auth import AzureCredential

def get_test_pdf_path():
    """Obtener la ruta a un archivo PDF de prueba."""
    # Probar diferentes ubicaciones para el archivo de prueba
    possible_paths = [
        Path(__file__).parent / "test_document.pdf",  # En el directorio actual
        Path(__file__).parent / "samples" / "test_document.pdf",  # En el subdirectorio samples
        Path.home() / "Downloads" / "test_document.pdf"  # En la carpeta de descargas del usuario
    ]
    
    # Buscar un PDF en las ubicaciones posibles
    for path in possible_paths:
        if path.exists() and path.is_file():
            print(f"Usando archivo de prueba: {path}")
            return path
    
    # Si no se encuentra ningún archivo, ofrecer opciones al usuario
    print("No se encontró un archivo PDF de prueba predeterminado.")
    print("Por favor, elija una opción:")
    print("1. Proporcionar la ruta a un archivo PDF existente")
    print("2. Utilizar un archivo de muestra en el directorio 'samples' (si está disponible)")
    print("3. Cancelar")
    
    option = input("Opción (1-3): ")
    
    if option == "1":
        # Solicitar ruta personalizada
        custom_path = input("Introduzca la ruta completa a un archivo PDF: ")
        custom_path = Path(custom_path.strip())
        if custom_path.exists() and custom_path.is_file():
            return custom_path
        else:
            print(f"Error: No se encontró el archivo en {custom_path}")
            return None
    
    elif option == "2":
        # Buscar archivos PDF en el directorio samples
        samples_dir = Path(__file__).parent / "samples"
        if samples_dir.exists() and samples_dir.is_dir():
            pdf_files = list(samples_dir.glob("*.pdf"))
            if pdf_files:
                print(f"Usando el primer PDF encontrado: {pdf_files[0]}")
                return pdf_files[0]
            else:
                print(f"No se encontraron archivos PDF en {samples_dir}")
                return None
        else:
            print(f"El directorio 'samples' no existe.")
            return None
    
    print("Operación cancelada. No se puede continuar sin un archivo PDF.")
    return None

def setup_test_credentials():
    """Configurar credenciales temporales para pruebas si no están disponibles en el entorno."""
    # Priorizar la configuración del Service Principal
    print("\n=== Configuración de credenciales de Service Principal ===")
    print("Se recomienda utilizar la autenticación por Service Principal para entornos de producción.")
    print("Para obtener estas credenciales, necesita registrar una aplicación en Azure Active Directory.")
    
    # Intentar configurar automáticamente los endpoints si están en otras variables de entorno conocidas
    try_auto_config_endpoints()
    
    # Configuración de Service Principal
    print("\nEjemplo de Tenant ID: 12345678-1234-1234-1234-123456789012")
    tenant_id = input("Ingrese su Azure Tenant ID: ").strip()
    
    print("\nEjemplo de Client ID: 87654321-4321-4321-4321-210987654321")
    client_id = input("Ingrese su Azure Client ID: ").strip()
    
    print("\nEjemplo de Client Secret: abcdef12345~_SomEsEcrEtVaLuE")
    client_secret = input("Ingrese su Azure Client Secret: ").strip()
    
    if tenant_id and client_id and client_secret:
        os.environ["AZURE_TENANT_ID"] = tenant_id
        os.environ["AZURE_CLIENT_ID"] = client_id
        os.environ["AZURE_CLIENT_SECRET"] = client_secret
        print("\nCredenciales de Service Principal configuradas correctamente.")
        return True
    
    print("\nNo se proporcionaron todas las credenciales de Service Principal requeridas.")
    return False

def try_auto_config_endpoints():
    """Intenta configurar los endpoints automáticamente si están disponibles en otras variables."""
    # Lista de posibles variables de entorno para el endpoint privado
    private_endpoint_vars = [
        "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT",  # Principal - mantener
        "AZURE_FORM_RECOGNIZER_ENDPOINT"         # Nombre antiguo del servicio - mantener
    ]
    
    # Lista de posibles variables de entorno para el endpoint público
    public_endpoint_vars = [
        "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"  # Principal - mantener
    ]
    
    # Verificar si ya están configurados los endpoints requeridos
    if os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT") and os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"):
        return
    
    # Buscar un endpoint privado en las variables alternativas
    for var in private_endpoint_vars:
        endpoint = os.environ.get(var)
        if endpoint and not os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"):
            os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = endpoint
            print(f"Endpoint privado configurado automáticamente de {var}.")
            break
    
    # Buscar un endpoint público en las variables alternativas
    for var in public_endpoint_vars:
        endpoint = os.environ.get(var)
        if endpoint and not os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"):
            os.environ["AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"] = endpoint
            print(f"Endpoint público configurado automáticamente de {var}.")
            break
    
    # Si no se encontró un endpoint público pero hay uno privado, usar el mismo para ambos
    if os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT") and not os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"):
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"] = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        print("Endpoint público configurado para usar el mismo valor que el endpoint privado.")

def check_environment():
    """Verificar que las variables de entorno necesarias estén configuradas."""
    # Variables de endpoint requeridas
    endpoint_vars = [
        "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT",
        "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"
    ]
    
    # Variables para autenticación con Service Principal
    service_principal_vars = [
        "AZURE_TENANT_ID", 
        "AZURE_CLIENT_ID", 
        "AZURE_CLIENT_SECRET"
    ]
    
    # Intentar configurar automáticamente los endpoints si están en otras variables de entorno
    try_auto_config_endpoints()
    
    # Verificar endpoints
    missing_endpoints = [var for var in endpoint_vars if not os.environ.get(var)]
    if missing_endpoints:
        print(f"Error: Faltan las siguientes variables de entorno para endpoints: {', '.join(missing_endpoints)}")
        print("Por favor, configure los endpoints:")
        
        # Solicitar endpoints al usuario
        for var in missing_endpoints:
            endpoint = input(f"Ingrese el valor para {var}: ").strip()
            if endpoint:
                os.environ[var] = endpoint
            else:
                print(f"No se proporcionó un valor para {var}")
                return False
    
    # Verificar si están configuradas las credenciales de Service Principal
    missing_sp_vars = [var for var in service_principal_vars if not os.environ.get(var)]
    if missing_sp_vars:
        print("No se encontraron credenciales de Service Principal completas.")
        print(f"Faltan las siguientes variables: {', '.join(missing_sp_vars)}")
        print("\nSe solicitarán las credenciales de Service Principal...")
        if not setup_test_credentials():
            return False
    else:
        print("Credenciales de Service Principal encontradas en las variables de entorno.")
    
    return True

def time_function(func, *args, **kwargs):
    """Medir el tiempo de ejecución de una función."""
    start_time = time.time()
    result = func(*args, **kwargs)
    end_time = time.time()
    return result, end_time - start_time

def compare_approaches():
    """Comparar los dos enfoques para analizar documentos."""
    if not check_environment():
        return
    
    pdf_path = get_test_pdf_path()
    if not pdf_path:
        return
    
    # Crear un objeto de credencial que se utilizará en todas las pruebas
    credential = None
    try:
        # Crear las credenciales con Service Principal
        tenant_id = os.environ.get("AZURE_TENANT_ID")
        client_id = os.environ.get("AZURE_CLIENT_ID")
        client_secret = os.environ.get("AZURE_CLIENT_SECRET")
        
        credential = AzureCredential.from_service_principal(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        print("Usando autenticación con Service Principal.")
        print("Credenciales configuradas correctamente.")
    except Exception as e:
        print(f"Error al configurar las credenciales: {str(e)}")
        return
    
    print("\n=== Comparación de enfoques para analizar documentos ===\n")
    
    # 1. Analizar documento con multipart/form-data
    print("1. Analizar documento con multipart/form-data:")
    
    print("\nEnfoque original:")
    result_orig, time_orig = time_function(
        analyze_document_original, 
        pdf_path, 
        upload_mode="multipart"
    )
    print(f"  - Tiempo: {time_orig:.2f} segundos")
    print(f"  - Resultado exitoso: {result_orig[0] is not None}")
    
    print("\nEnfoque nuevo (con AzureDocumentProvider):")
    result_new, time_new = time_function(
        analyze_document_new, 
        pdf_path, 
        upload_mode="multipart",
        credential=credential  # Pasar la credencial explícitamente
    )
    print(f"  - Tiempo: {time_new:.2f} segundos")
    print(f"  - Resultado exitoso: {result_new[0] is not None}")
    
    # 2. Analizar documento con base64
    print("\n2. Analizar documento con base64:")
    
    print("\nEnfoque original:")
    result_orig, time_orig = time_function(
        analyze_document_original, 
        pdf_path, 
        upload_mode="base64"
    )
    print(f"  - Tiempo: {time_orig:.2f} segundos")
    print(f"  - Resultado exitoso: {result_orig[0] is not None}")
    
    print("\nEnfoque nuevo (con AzureDocumentProvider):")
    result_new, time_new = time_function(
        analyze_document_new, 
        pdf_path, 
        upload_mode="base64",
        credential=credential  # Pasar la credencial explícitamente
    )
    print(f"  - Tiempo: {time_new:.2f} segundos")
    print(f"  - Resultado exitoso: {result_new[0] is not None}")
    
    # 3. Analizar documento directamente desde base64
    with open(pdf_path, "rb") as f:
        file_content = f.read()
    
    base64_string = base64.b64encode(file_content).decode("utf-8")
    
    print("\n3. Analizar documento directamente desde base64:")
    
    print("\nEnfoque original:")
    result_orig, time_orig = time_function(
        analyze_document_from_base64_original, 
        base64_string=base64_string,
        content_type="application/pdf"
    )
    print(f"  - Tiempo: {time_orig:.2f} segundos")
    print(f"  - Resultado exitoso: {result_orig[0] is not None}")
    
    print("\nEnfoque nuevo (con AzureDocumentProvider):")
    result_new, time_new = time_function(
        analyze_document_from_base64_new, 
        base64_string=base64_string,
        content_type="application/pdf",
        credential=credential  # Pasar la credencial explícitamente
    )
    print(f"  - Tiempo: {time_new:.2f} segundos")
    print(f"  - Resultado exitoso: {result_new[0] is not None}")
    
    # 4. Analizar múltiples documentos
    documents = [
        {"base64_string": base64_string, "content_type": "application/pdf"},
        {"base64_string": base64_string, "content_type": "application/pdf"}
    ]
    
    print("\n4. Analizar múltiples documentos:")
    
    print("\nEnfoque original:")
    result_orig, time_orig = time_function(
        analyze_multiple_base64_documents_original, 
        documents=documents
    )
    print(f"  - Tiempo: {time_orig:.2f} segundos")
    print(f"  - Documentos procesados: {len(result_orig)}")
    print(f"  - Resultados exitosos: {sum(1 for v in result_orig.values() if v is not None)}")
    
    print("\nEnfoque nuevo (con AzureDocumentProvider):")
    result_new, time_new = time_function(
        analyze_multiple_base64_documents_new, 
        documents=documents,
        credential=credential  # Pasar la credencial explícitamente
    )
    print(f"  - Tiempo: {time_new:.2f} segundos")
    print(f"  - Documentos procesados: {len(result_new)}")
    print(f"  - Resultados exitosos: {sum(1 for v in result_new.values() if v is not None)}")
    
    print("\n=== Resumen ===")
    print("El nuevo enfoque utilizando AzureDocumentProvider proporciona:")
    print("- Una interfaz similar al enfoque original")
    print("- Mejor manejo de errores con excepciones tipadas")
    print("- Respuestas estructuradas a través de modelos de datos")
    print("- Mayor robustez y flexibilidad")

if __name__ == "__main__":
    compare_approaches()

