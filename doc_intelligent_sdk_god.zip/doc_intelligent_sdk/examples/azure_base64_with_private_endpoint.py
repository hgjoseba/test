#!/usr/bin/env python
"""
Ejemplo de análisis de documentos usando base64 con endpoint privado.

Este ejemplo demuestra:
1. El uso de endpoints privados con Document Intelligence
2. Configuración automática de NO_PROXY para evitar problemas de conectividad
3. Autenticación con Service Principal Name (SPN)
4. Análisis de documentos en formato base64
5. Uso del modelo prebuilt-read para OCR eficiente
"""

import os
import sys
import base64
import time
from doc_intelligent.utils import analyze_base64_document, analyze_multiple_base64_documents

# Verificar variables de entorno requeridas
REQUIRED_ENV = [
    "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT",  # Endpoint privado (usando Private Link)
    "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT",  # Endpoint público (para reemplazo)
    "AZURE_TENANT_ID",  # Para autenticación SPN
    "AZURE_CLIENT_ID",  # Para autenticación SPN
    "AZURE_CLIENT_SECRET"  # Para autenticación SPN
]

def check_env_vars():
    """Verifica si están configuradas todas las variables de entorno necesarias."""
    missing = [var for var in REQUIRED_ENV if not os.environ.get(var)]
    if missing:
        print(f"❌ Error: Faltan variables de entorno requeridas: {', '.join(missing)}")
        print("\nConfigura estas variables con los siguientes comandos:")
        print("export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://tu-recurso-privado.cognitiveservices.azure.com/")
        print("export AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT=https://tu-region.api.cognitive.microsoft.com/")
        print("export AZURE_TENANT_ID=tu-tenant-id")
        print("export AZURE_CLIENT_ID=tu-client-id")
        print("export AZURE_CLIENT_SECRET=tu-client-secret")
        return False
    return True

def file_to_base64(file_path):
    """Convierte un archivo a string base64."""
    try:
        with open(file_path, "rb") as f:
            file_bytes = f.read()
        return base64.b64encode(file_bytes).decode("utf-8")
    except Exception as e:
        print(f"❌ Error al leer o codificar el archivo: {e}")
        return None

def main():
    print("\n=== Ejemplo de análisis de documentos base64 con endpoint privado ===\n")
    
    # Verificar variables de entorno
    if not check_env_vars():
        return 1
    
    # Mostrar configuración
    private_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    public_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
    print(f"Endpoint privado: {private_endpoint}")
    print(f"Endpoint público: {public_endpoint}")
    
    # Path al documento para analizar
    file_path = input("\nIngresa la ruta al archivo PDF a analizar: ")
    if not os.path.exists(file_path):
        print(f"❌ Error: El archivo {file_path} no existe.")
        return 1
    
    print(f"\nConvirtiendo archivo a base64: {file_path}")
    base64_data = file_to_base64(file_path)
    if not base64_data:
        return 1
    
    print(f"✅ Archivo convertido a base64 ({len(base64_data)/1024:.1f} KB)")
    
    # Analizar documento
    print("\n=== Iniciando análisis de documento con prebuilt-read ===")
    print("1. Configurando NO_PROXY para el endpoint privado")
    print("2. Obteniendo token con Service Principal")
    print("3. Enviando datos en formato base64")
    print("4. Reemplazando endpoint público por privado para polling")
    
    start_time = time.time()
    content = analyze_base64_document(
        base64_string=base64_data,
        content_type="application/pdf",
        model_id="prebuilt-read",
        poll_interval=5,
        timeout=300,
        api_version="2024-11-30"
    )
    
    elapsed_time = time.time() - start_time
    
    if content:
        print(f"\n✅ Análisis completado en {elapsed_time:.1f} segundos")
        print(f"\nExtraído {len(content)} caracteres de texto")
        
        # Mostrar fragmento del contenido
        preview_len = min(500, len(content))
        print(f"\n=== Primeros {preview_len} caracteres del texto extraído ===")
        print(f"\n{content[:preview_len]}...\n")
        
        # Guardar el contenido extraído
        output_file = os.path.splitext(file_path)[0] + "_extracted.txt"
        try:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(content)
            print(f"✅ Texto extraído guardado en: {output_file}")
        except Exception as e:
            print(f"❌ Error al guardar el texto extraído: {e}")
    else:
        print("\n❌ Error al analizar el documento")
        return 1
    
    # Demostrar análisis por lotes
    batch_option = input("\n¿Deseas demostrar el análisis por lotes de múltiples documentos? (s/n): ")
    if batch_option.lower() != "s":
        return 0
    
    # Crear una lista de documentos para procesar por lotes
    documents = [
        {"base64_string": base64_data, "content_type": "application/pdf"}
    ]
    
    # Opcional: añadir un segundo documento
    second_file = input("\nIngresa la ruta a un segundo archivo (opcional, presiona Enter para omitir): ")
    if second_file and os.path.exists(second_file):
        second_data = file_to_base64(second_file)
        if second_data:
            documents.append({"base64_string": second_data, "content_type": "application/pdf"})
    
    print(f"\n=== Analizando {len(documents)} documentos en lote ===")
    batch_start_time = time.time()
    results = analyze_multiple_base64_documents(
        documents=documents,
        model_id="prebuilt-read",
        poll_interval=5
    )
    batch_elapsed_time = time.time() - batch_start_time
    
    print(f"\n✅ Análisis por lotes completado en {batch_elapsed_time:.1f} segundos")
    
    for doc_id, content in results.items():
        if content:
            print(f"\nDocumento {doc_id}: {len(content)} caracteres extraídos")
        else:
            print(f"\nDocumento {doc_id}: Error al extraer texto")
    
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\nOperación cancelada por el usuario.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error inesperado: {e}")
        sys.exit(1) 