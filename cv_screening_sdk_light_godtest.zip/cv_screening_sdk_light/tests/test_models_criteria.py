"""
Tests for job criteria models.
"""
import unittest
import pytest
from pydantic import ValidationError

from src.cv_screening.models.criteria import JobCriteria


class TestJobCriteria(unittest.TestCase):
    """Tests for the JobCriteria model."""
    
    def test_default_values(self):
        """Test default values of JobCriteria."""
        criteria = JobCriteria()
        
        self.assertEqual(criteria.required_skills, [])
        self.assertEqual(criteria.preferred_skills, [])
        self.assertIsNone(criteria.min_years_experience)
        self.assertIsNone(criteria.education_level)
        self.assertIsNone(criteria.job_title)
        self.assertIsNone(criteria.job_description)
    
    def test_custom_values(self):
        """Test custom values of JobCriteria."""
        criteria = JobCriteria(
            required_skills=["Python", "Django", "SQL"],
            preferred_skills=["Docker", "AWS"],
            min_years_experience=3,
            education_level="bachelor's",
            job_title="Backend Developer",
            job_description="Developing backend services for our web application"
        )
        
        self.assertEqual(criteria.required_skills, ["Python", "Django", "SQL"])
        self.assertEqual(criteria.preferred_skills, ["Docker", "AWS"])
        self.assertEqual(criteria.min_years_experience, 3)
        self.assertEqual(criteria.education_level, "bachelor's")
        self.assertEqual(criteria.job_title, "Backend Developer")
        self.assertEqual(criteria.job_description, "Developing backend services for our web application")
    
    def test_partial_initialization(self):
        """Test initialization with only some fields."""
        criteria = JobCriteria(
            required_skills=["Python"],
            min_years_experience=2
        )
        
        self.assertEqual(criteria.required_skills, ["Python"])
        self.assertEqual(criteria.preferred_skills, [])  # Default value
        self.assertEqual(criteria.min_years_experience, 2)
        self.assertIsNone(criteria.education_level)  # Default value
        self.assertIsNone(criteria.job_title)  # Default value
        self.assertIsNone(criteria.job_description)  # Default value
    
    def test_to_dict_with_all_fields(self):
        """Test to_dict method with all fields set."""
        criteria = JobCriteria(
            required_skills=["Python", "Django"],
            preferred_skills=["React"],
            min_years_experience=2,
            education_level="master's",
            job_title="Full Stack Developer",
            job_description="Development of web applications"
        )
        
        result = criteria.to_dict()
        
        # Check all fields are included
        self.assertIn("required_skills", result)
        self.assertIn("preferred_skills", result)
        self.assertIn("min_years_experience", result)
        self.assertIn("education_level", result)
        self.assertIn("job_title", result)
        self.assertIn("job_description", result)
        
        # Check values
        self.assertEqual(result["required_skills"], ["Python", "Django"])
        self.assertEqual(result["preferred_skills"], ["React"])
        self.assertEqual(result["min_years_experience"], 2)
        self.assertEqual(result["education_level"], "master's")
        self.assertEqual(result["job_title"], "Full Stack Developer")
        self.assertEqual(result["job_description"], "Development of web applications")
    
    def test_to_dict_excludes_none(self):
        """Test to_dict method excludes None values."""
        criteria = JobCriteria(
            required_skills=["Python"],
            min_years_experience=1
        )
        
        result = criteria.to_dict()
        
        # Check only non-None fields are included
        self.assertIn("required_skills", result)
        self.assertIn("preferred_skills", result)  # Empty list is not None
        self.assertIn("min_years_experience", result)
        
        # Check None fields are excluded
        self.assertNotIn("education_level", result)
        self.assertNotIn("job_title", result)
        self.assertNotIn("job_description", result)
    
    def test_list_type_validation(self):
        """Test list type validation."""
        # Valid initialization with lists
        JobCriteria(required_skills=["Python"])
        JobCriteria(preferred_skills=["Docker"])
        
        # Invalid initialization with non-list for required_skills
        with self.assertRaises(ValidationError):
            JobCriteria(required_skills="Python")  # String instead of list
        
        # Invalid initialization with non-list for preferred_skills
        with self.assertRaises(ValidationError):
            JobCriteria(preferred_skills="Docker")  # String instead of list
    
    def test_integer_type_validation(self):
        """Test integer type validation for min_years_experience."""
        # Valid initialization with integer
        JobCriteria(min_years_experience=5)
        
        # Invalid initialization with non-integer
        with self.assertRaises(ValidationError):
            JobCriteria(min_years_experience="five")  # String instead of int


if __name__ == '__main__':
    unittest.main() 