"""
Manages prompts for Azure OpenAI provider.
"""
import json
from typing import List, Dict, Optional, Any
from datetime import datetime

class AzurePromptManager:
    """Handles prompt generation and management for Azure OpenAI provider."""

    def __init__(self):
        self.system_prompt = f"""You are an HR recruiter specialized in CV (Curriculum Vitae) analysis.
        In your analysis, take into account the current date: '{datetime.now().strftime('%B %Y')}'.
        Act with objectivity and transparency when reviewing the content of the documents, removing any personal
        information about the candidates. Analyze, organize, and structure all the content into the following
        sections without leaving out any information. The sections are:
            1) Work Experience (include all the details, do not summarize),
            2) Official Degree Studies (indicate whether the studies have been completed as of the current date),
            3) Non-official Programs and Certifications (indicate whether the programs have been completed as of the current date),
            4) Languages (If no language is explicitly mentioned in any section of the document, infer the candidate’s native language and explain it.
            It is important to indicate which languages have been inferred and which are explicitly mentioned in any section of the document being analyzed),
            5) Skills (Soft and hard), and 6) Explanation (Explain the reasoning followed to generate the structure from the content step by step).
        Include all types of details explicitly found in the document content and do not repeat information across different sections. Also it's important to
        remove all personal or sensitive information from the content. If the document is not a CV (Curriculum Vitae), indicate this in your response and explain why.
        Below are several documents with different names, as they belong to different candidates, so do not mix the content between them and keep the document names
        in the response to identify the results:
        """
        self.secondary_system_prompt =  f"""You are an expert auditor analyzing sensitive or personal information in content
        intended for human resources. Keep in mind that today's date is '{datetime.now().strftime('%B %Y')}'"""

        self.secondary_jsonparsed_prompt = f"""Parse the same content into JSON format (do not summarize) and remove all personal or
        sensitive information from the content previously organized by another model from a CV (Curriculum Vitae).
        The content below includes both CV and non-CV information, so process and include both in the output, along with an explanation:
        """

        # Default schema for batch CV analysis
        self.json_schema = {"type":"object","properties":{"results":{"type":"array","items":{"type":"object","properties":{"document_id":{"type":"string","description":"ID of the processed document"},"document_type":{"type":"string","enum":["CV","NO_CV"],"description":"Indicates whether the document is a Curriculum Vitae (CV) or not."},"work_experience":{"type":"array","items":{"type":"object","properties":{"role":{"type":"string","description":"Role performed in the work experience"},"company":{"type":"string","description":"Company name in the work experience"},"responsibility":{"type":"string","description":"Responsibility in the role, indicating all the tasks with detail (e.g., - Management of risk-based audits, ensuring compliance with established deadlines and budgets. - Identification of key risks and regulatory requirements for the scope of audits and work programs. - Execution of investigative audits and risk assessments focused on irregularities, policy violations, or high-risk areas.)"},"timeframe":{"type":"string","description":"Timeframe in which each experience took place"},"years_experience":{"type":"number","description":"Years of experience in this role, expressed in decimal format including months (e.g., 2.5 for 2 years and 6 months)."}},"required":["role","company","responsibility","timeframe","years_experience"],"additionalProperties":False},"description":"List of the candidate's work experiences"},"educational_level":{"type":"array","items":{"type":"object","properties":{"university":{"type":"string","description":"Name of the University"},"degree_title":{"type":"string","description":"Name of the Degree"},"degree_level":{"type":"string","enum":["BSc","MSc","PhD"],"description":"Level of the official degree. Use: BSc = Bachelor's degree, MSc = Master's degree, PhD = Doctorate."},"discipline":{"type":"string","description":"Field of study of the obtained degree"},"finished":{"type":"boolean","description":"Indicates whether the studies are finished (true) or still in progress (False), based on the current date provided in the prompt."},"timeframe":{"type":"string","description":"Timeframe in which the education was pursued (e.g. 2015–2019)"}},"required":["university","degree_title","degree_level","discipline","finished","timeframe"],"additionalProperties":False},"description":"Candidate's educational level"},"certificates":{"type":"array","items":{"type":"object","properties":{"course_name":{"type":"string","description":"Name of the non-official course or program"},"organization":{"type":"string","description":"Name of the organization that provided the course"},"finished":{"type":"boolean","description":"Indicates whether the course or program was completed (true) or not (False), based on the current date provided in the prompt."},"timeframe":{"type":"string","description":"Timeframe in which the course or program took place (e.g. Jan 2021 – Mar 2021)"}},"required":["course_name","organization","finished","timeframe"],"additionalProperties":False},"description":"List of non-official courses or programs taken by the candidate"},"soft_skills":{"type":"array","items":{"type":"string"},"description":"List of the candidate's soft skills"},"hard_skills":{"type":"array","items":{"type":"string"},"description":"List of the candidate's hard skills"},"languages":{"type":"array","items":{"type":"object","properties":{"language":{"type":"string","description":"Name of the language"},"level":{"type":"string","enum":["Basic","Intermediate","High","Advanced","Native"],"description":"Level of proficiency in the language"},"source":{"type":"string","enum":["explicit","inferred"],"description":"Indicates whether the language was explicitly mentioned in the content of de document name or inferred by the system."}},"required":["language","level","source"],"additionalProperties":False},"description":"List of languages spoken by the candidate and their proficiency level"},"explanation":{"type":"string","description":"Explicitly extract the explanation provided in the content about the steps followed by another model to structure it in earlier stages, without summarizing or altering it."}},"required":["document_id","document_type","work_experience","educational_level","languages","soft_skills","hard_skills","explanation","certificates"],"additionalProperties":False}}},"required":["results"],"additionalProperties":False}



    def get_system_prompt(self) -> str:
        """Get the system prompt for single CV analysis."""
        return self.system_prompt
   
    def get_secondary_system_prompt(self) -> str:
        """Get the system prompt for parsed JSON schema."""
        return self.secondary_system_prompt
   
    def get_secondary_jsonparsed_prompt(self) -> str:
        """Get the system prompt for parsed JSON schema."""
        return self.secondary_jsonparsed_prompt

    def get_json_schema(self):
        """Get JSON schema."""
        return self.json_schema

    def build_multiple_screening_prompt(
        self,
        contents: List[Dict]
    ) -> str:
        prompt = "Process each document individually and extract the information according to the specific instructions:\n\n"

        for doc in contents:
            document_id = doc["document_id"]
            content_md = doc["content_md"]
            prompt += (
                f"---\n"
                f"Start of content for document ID '{document_id}':\n\n"
                f"{content_md}\n\n"
                f"End of document ID '{document_id}'\n"
                f"---\n\n"
            )

        return prompt