"""
Ejemplo de cómo usar la funcionalidad de carga de CV desde un servicio de Azure.

Este ejemplo muestra:
1. Cómo autenticarse con Azure utilizando AzureAuthProvider
2. Cómo obtener contenido de CV directamente desde un servicio de Azure que devuelve texto plano
"""

import os
import logging

from src import CVScreeningClient
from src.auth.azure import AzureAuthProvider
from src.utils.document import load_cv_from_base64
from src.models.criteria import JobCriteria

# Configuración de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Credenciales de Azure desde variables de entorno
tenant_id = os.environ.get("AZURE_TENANT_ID")
client_id = os.environ.get("AZURE_CLIENT_ID")
client_secret = os.environ.get("AZURE_CLIENT_SECRET")
azure_url = os.environ.get("AZURE_CV_SERVICE_URL")  # URL del servicio que devuelve el texto plano del CV
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")

def main():
    """Función principal que demuestra cómo cargar un CV desde un servicio de Azure."""
    try:
        # Paso 1: Inicializar el proveedor de autenticación de Azure
        logger.info("Inicializando el proveedor de autenticación de Azure")
        azure_auth = AzureAuthProvider(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        # Paso 2: Cargar el contenido del CV directamente desde Azure
        logger.info(f"Cargando contenido del CV desde el servicio Azure: {azure_url}")
        cv_content = load_cv_from_base64(
            credential=azure_auth,  # Pasar AzureAuthProvider directamente
            service_url=azure_url,
            content_type="application/json",  # Ajustar según el tipo de contenido esperado
            verify_ssl=True
        )
        
        logger.info(f"CV cargado correctamente, longitud: {len(cv_content)} caracteres")
        
        # Opcional - mostrar una vista previa del contenido del CV
        if cv_content:
            preview_length = min(200, len(cv_content))
            logger.info(f"Vista previa del CV: {cv_content[:preview_length]}...")
        
        # Paso 3: Usar el token de autenticación para el cliente de análisis de CV
        token = azure_auth.get_token()
        
        # Paso 4: Inicializar el cliente de análisis
        logger.info("Inicializando el cliente de análisis de CV")
        client = CVScreeningClient(
            api_key=token,  # Usar token como api_key
            endpoint=endpoint,
            model_name="gpt-4",  # o el nombre específico de tu despliegue
            temperature=0.1,
        )
        
        # Paso 5: Definir los criterios del trabajo
        job_criteria = JobCriteria(
            title="Desarrollador de Software",
            description="""
            Buscamos un Desarrollador de Software con experiencia en Python y servicios cloud.
            El candidato ideal tiene experiencia en desarrollo de APIs y buenas prácticas de código.
            """,
            required_skills=["Python", "REST APIs", "Git"],
            preferred_skills=["Azure", "Docker", "CI/CD"],
            minimum_years_experience=3,
            education="Licenciatura en Informática o campo relacionado"
        )
        
        # Paso 6: Analizar el CV
        logger.info("Analizando el CV según los criterios del trabajo")
        result = client.analyze_cv(
            cv_content=cv_content,
            job_criteria=job_criteria
        )
        
        # Paso 7: Mostrar los resultados
        logger.info("Resultados del análisis del CV:")
        logger.info(f"Puntuación de coincidencia: {result.score}")
        logger.info(f"Decisión: {result.decision}")
        logger.info(f"Resumen:\n{result.summary}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error en el análisis del CV: {str(e)}", exc_info=True)
        raise

if __name__ == "__main__":
    main() 