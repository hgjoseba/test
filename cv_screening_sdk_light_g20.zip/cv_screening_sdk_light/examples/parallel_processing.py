#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Example of parallel processing of CVs using process_partition.

This example shows how to analyze a batch of CVs in parallel
using multiple threads through the process_partition function.
Each thread processes a batch of CVs using analyze_multiple_cvs.
"""

import os
import time
import logging
from typing import Dict, Any, List

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

from cv_screening_sdk import (
    CVScreeningClient,
    process_partition,
    ContentType
)

# Example callbacks
def on_success_callback(result: Dict[str, Any]) -> None:
    """Callback that executes when an analysis is successful"""
    logger.info(f"CV successfully analyzed. Index: {result.get('_original_index')}")
    # Here you could save the result to a database, etc.

def on_error_callback(error: Exception, cv_content: str) -> None:
    """Callback that executes when an analysis fails"""
    logger.error(f"Error analyzing CV: {str(error)}")
    # Here you could log the error, retry, etc.

def main():
    # Configure client
    client = CVScreeningClient(
        endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT"),
        api_key=os.environ.get("AZURE_OPENAI_API_KEY"),
        deployment_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
        max_rpm=60,
        max_tpm=40000
    )
    
    # Example criteria
    criteria = {
        "skills": ["Python", "Machine Learning", "Data Science"],
        "experience": "Minimum 3 years in software development",
        "education": "Degree in Computer Science or similar"
    }
    
    # Simulate a batch of CVs (normally would be in files or a database)
    # In a real case, these could be file paths, text content, etc.
    cv_contents = [
        "Engineer with 5 years of experience in Python and Machine Learning...",
        "Developer with experience in Java and databases...",
        "Data scientist specializing in predictive analysis...",
        "AI specialist with publications in the field of NLP...",
        "Software engineer with 10 years of experience in distributed systems...",
        "Frontend developer with knowledge of React and Angular...",
        "Software architect specializing in cloud systems...",
        "DevOps engineer with experience in Docker and Kubernetes...",
        "Data analyst with knowledge of SQL and Python...",
        "QA engineer with experience in automated testing..."
    ]
    
    # Measure execution time
    start_time = time.time()
    
    # Process CVs in parallel using batches
    logger.info(f"Starting parallel processing of {len(cv_contents)} CVs...")
    results = process_partition(
        client=client,
        cvs_partition=cv_contents,
        criteria=criteria,
        content_type=ContentType.TEXT,
        max_workers=3,    # Use 3 parallel threads
        batch_size=2,     # Each thread processes 2 CVs at a time
        timeout=300,      # 5 minute timeout
        on_success=on_success_callback,
        on_error=on_error_callback
    )
    
    # Show results
    elapsed_time = time.time() - start_time
    logger.info(f"Processing completed in {elapsed_time:.2f} seconds")
    
    # Analyze results
    success_count = sum(1 for r in results if not r.get("_error", False))
    logger.info(f"Successful results: {success_count}/{len(results)}")
    
    # Print a summary of each result
    for i, result in enumerate(results):
        if result.get("_error", False):
            logger.info(f"CV {i}: Error - {result.get('error')}")
        else:
            # Extract the general evaluation if it exists (depends on the response schema)
            evaluation = result.get("overall_evaluation", 
                          result.get("match_score", 
                          result.get("summary", "No evaluation available")))
            logger.info(f"CV {i}: {evaluation}")

if __name__ == "__main__":
    main() 