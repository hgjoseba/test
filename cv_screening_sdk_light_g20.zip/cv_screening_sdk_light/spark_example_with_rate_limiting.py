#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Ejemplo de implementación del SDK de CV Screening en un cluster Databricks
con control de límites de tasa (rate limiting) para TPM y RPM.

Este script muestra cómo procesar múltiples CVs en paralelo utilizando
Apache Spark en Databricks y el CV Screening SDK, respetando los límites de Azure OpenAI.
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, pandas_udf, lit
from pyspark.sql.types import StringType, StructType, StructField
import pandas as pd
import json
import time
import os
import logging
from typing import Dict, List, Iterator, Tuple
import argparse
from pyspark.dbutils import DBUtils
import backoff  # Importar la librería backoff de PyPI

# Importar SDK de CV Screening
from src import CVScreeningClient
from src.core.types import ContentType
from src.core.exceptions import OpenAIError, RateLimitError
from src.utils.rate_limiting import (
    RateLimiter, 
    DistributedRateLimiter,
    estimate_cv_tokens,
    create_rate_limiter_for_distributed as create_rate_limiter_for_executor
)

# Importar SDK de Azure para autenticación
from azure.identity import DefaultAzureCredential

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger("cv_screening_spark")

# Configuraciones de límites de API
# Estos valores deben ajustarse según tu cuota real en Azure OpenAI
GLOBAL_RPM = 600  # Peticiones por minuto para todo el cluster
GLOBAL_TPM = 240000  # Tokens por minuto para todo el cluster

# Configuración de Azure Blob Storage
AZURE_STORAGE_ACCOUNT = os.environ.get("AZURE_STORAGE_ACCOUNT")
AZURE_STORAGE_KEY = os.environ.get("AZURE_STORAGE_KEY")
AZURE_CONTAINER = os.environ.get("AZURE_CONTAINER", "cv-screening")
AZURE_METADATA_PATH = os.environ.get("AZURE_METADATA_PATH", "cvs_metadata.csv")
AZURE_RESULTS_PATH = os.environ.get("AZURE_RESULTS_PATH", "rate_limited_results")
AZURE_PANDAS_RESULTS_PATH = os.environ.get("AZURE_PANDAS_RESULTS_PATH", "pandas_rate_limited_results")

# Crear una sola instancia de Azure DefaultAzureCredential para todo el script
# Esta credencial buscará automáticamente el método de autenticación disponible
# (identidad administrada, CLI de Azure, credenciales de entorno, etc.)
azure_credential = DefaultAzureCredential()
logger.info("DefaultAzureCredential inicializada globalmente para el SDK de Azure")

# Configura el logger para backoff para ver los reintentos
backoff_logger = logging.getLogger('backoff')
backoff_logger.addHandler(logging.StreamHandler())
backoff_logger.setLevel(logging.INFO)

# Función auxiliar para analizar CVs con control de límites
@backoff.on_exception(
    backoff.expo, 
    (OpenAIError, RateLimitError),
    max_tries=4,  # Intento inicial + 3 reintentos
    factor=1.0,   # Factor base para el backoff exponencial
    jitter=backoff.full_jitter,  # Jitter completo para evitar sincronización
    logger=logger  # Usar nuestro logger
)
def analyze_cv_with_rate_limit(
    client,
    cv_content: str,
    rate_limiter: RateLimiter = None,
    content_type = None,
    criteria: dict = None,
    max_retries: int = 3
) -> dict:
    """
    Función de conveniencia para analizar un CV con control de límites de tasa
    
    Esta función utiliza tanto límites de tasa (para prevenir errores)
    como la librería backoff (para recuperarse automáticamente de errores).
    
    Args:
        client: Instancia de CVScreeningClient
        cv_content: Contenido del CV
        rate_limiter: Limitador de tasa a utilizar
        content_type: Tipo de contenido del CV
        criteria: Criterios del trabajo (opcional)
        max_retries: Máximo de reintentos para rate_limiter
        
    Returns:
        Resultados del análisis
    """
    # Usar limitador por defecto si no se proporciona
    if rate_limiter is None:
        rate_limiter = RateLimiter()
    
    # Estimar tokens
    criteria_str = str(criteria) if criteria else ""
    tokens_estimate = estimate_cv_tokens(cv_content, criteria_str)
    
    # Ejecutar con límite de tasa
    return rate_limiter.execute_with_rate_limit(
        client.analyze_cv,
        content=cv_content,
        criteria=criteria,
        content_type=content_type,
        tokens_estimate=tokens_estimate,
        max_retries=max_retries
    )

def get_openai_endpoint(spark) -> str:
    """
    Obtiene el endpoint para Azure OpenAI
    
    Args:
        spark: SparkSession
        
    Returns:
        str: URL del endpoint de Azure OpenAI
    """
    dbutils = DBUtils(spark)
    
    # Intentar obtener endpoint desde Databricks secrets
    try:
        endpoint = dbutils.secrets.get(scope="azure-openai", key="endpoint")
        logger.info("Endpoint de Azure OpenAI obtenido desde secretos de Databricks")
        return endpoint
    except Exception:
        # Fallback a variables de entorno
        endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
        if endpoint:
            logger.info("Endpoint de Azure OpenAI obtenido desde variables de entorno")
            return endpoint
    
    # Si no se encuentra el endpoint, lanzar error
    raise ValueError("No se pudo obtener el endpoint de Azure OpenAI. Configúralo en el scope 'azure-openai' o mediante AZURE_OPENAI_ENDPOINT")

def get_azure_storage_credentials(spark) -> Tuple[str, str]:
    """Obtiene las credenciales para Azure Blob Storage desde Databricks secrets"""
    dbutils = DBUtils(spark)
    
    try:
        # Intenta obtener desde los secrets de Databricks
        storage_account = dbutils.secrets.get(scope="azure-storage", key="account-name")
        storage_key = dbutils.secrets.get(scope="azure-storage", key="account-key")
    except Exception:
        # Fallback a variables de entorno
        storage_account = AZURE_STORAGE_ACCOUNT
        storage_key = AZURE_STORAGE_KEY
    
    if not storage_account or not storage_key:
        raise ValueError(
            "Debes configurar las credenciales de Azure Storage en el scope 'azure-storage' o variables de entorno"
        )
    
    return storage_account, storage_key

def create_client(spark) -> CVScreeningClient:
    """
    Crea y devuelve una instancia del cliente CV Screening usando DefaultAzureCredential
    
    Esta función usa la autenticación integrada del SDK de Azure OpenAI,
    que es compatible con entornos Databricks a través de DefaultAzureCredential.
    """
    # Obtener endpoint para el servicio
    endpoint = get_openai_endpoint(spark)
    
    # Crear cliente con la variable global DefaultAzureCredential
    return CVScreeningClient(
        endpoint=endpoint,
        credential=azure_credential,  # Usamos la credencial global del SDK de Azure
        deployment_name="gpt-4",
        temperature=0.1,
        max_tokens=2000
    )

def process_cv_batch_with_rate_limit(
    partition: Iterator[Dict], 
    executor_count: int = 4
) -> Iterator[Tuple[str, str, Dict]]:
    """
    Procesa un lote de CVs con control de límites de tasa
    
    Args:
        partition: Iterador sobre los registros de la partición
        executor_count: Número total de ejecutores en el cluster
        
    Yields:
        Tuplas de (cv_id, nombre_archivo, resultado_analisis)
    """
    # Usar SparkSession activa
    spark = SparkSession.getActiveSession()
    
    # Crear cliente una vez por ejecutor
    client = create_client(spark)
    logger.info("Cliente inicializado en el ejecutor con DefaultAzureCredential")
    
    # Crear limitador de tasa distribuido usando el API del SDK
    # Obtener ID único para este ejecutor
    try:
        import socket
        hostname = socket.gethostname()
        pid = os.getpid()
        node_id = f"{hostname}-{pid}"
    except:
        import random
        node_id = str(random.randint(10000, 99999))
    
    # Crear limitador de tasa distribuido
    rate_limiter = create_rate_limiter_for_executor(
        global_rpm=GLOBAL_RPM,
        global_tpm=GLOBAL_TPM,
        node_count=executor_count,
        node_id=node_id
    )
    
    for record in partition:
        cv_id = record["cv_id"]
        filename = record["filename"]
        cv_content = record["content"]
        
        try:
            # Analizar CV con control de límites
            logger.info(f"Procesando CV ID: {cv_id}, Archivo: {filename}")
            
            # Con la nueva implementación, analyze_cv_with_rate_limit usa @backoff internamente
            # para reintentos automáticos ante errores de tasa y otros fallos
            result = analyze_cv_with_rate_limit(
                client=client,
                cv_content=cv_content,
                rate_limiter=rate_limiter,
                content_type=ContentType.TEXT
            )
            
            # Devolver resultado con metadatos
            yield (cv_id, filename, result)
            
        except (OpenAIError, RateLimitError) as e:
            # A pesar de los reintentos, el análisis falló
            logger.error(f"Error al procesar CV {cv_id} después de reintentos: {str(e)}")
            # Devolver error en formato json
            yield (cv_id, filename, {"error": str(e)})
        except Exception as e:
            # Otro tipo de error no relacionado con OpenAI
            logger.error(f"Error inesperado al procesar CV {cv_id}: {str(e)}")
            yield (cv_id, filename, {"error": f"Error inesperado: {str(e)}"})


@backoff.on_exception(
    backoff.expo, 
    (OpenAIError, RateLimitError),
    max_tries=3,  # Intento inicial + 2 reintentos
    factor=1.0,
    jitter=backoff.full_jitter,
    logger=logger
)
def pandas_rate_limited_cv_analysis(cvs_batch: pd.Series) -> pd.Series:
    """
    UDF Pandas con control de límites de tasa
    
    Ahora incorpora la librería backoff para reintentos automáticos
    ante errores de OpenAI o límites de tasa.
    
    Args:
        cvs_batch: Serie de pandas con contenido de CVs
        
    Returns:
        Serie de pandas con resultados
    """
    # Usar SparkSession activa
    spark = SparkSession.getActiveSession()
    
    # Crear cliente una vez para toda la serie
    client = create_client(spark)
    
    # Crear limitador de tasa (usar el del SDK directamente)
    # Considera cada grupo de Pandas como una "partición"
    rate_limiter = RateLimiter(
        max_rpm=GLOBAL_RPM // 4,  # Asumimos 4 particiones activas
        max_tpm=GLOBAL_TPM // 4
    )
    
    results = []
    for cv in cvs_batch:
        try:
            # Usar la función de conveniencia con control de límites
            result = analyze_cv_with_rate_limit(
                client=client,
                cv_content=cv,
                rate_limiter=rate_limiter,
                content_type=ContentType.TEXT
            )
            results.append(json.dumps(result))
        except Exception as e:
            results.append(json.dumps({"error": str(e)}))
    
    return pd.Series(results)


def broadcast_rate_limiter_config(spark, executor_count):
    """
    Transmite la configuración del limitador de tasa a todos los ejecutores
    
    Args:
        spark: SparkSession
        executor_count: Número de ejecutores
    """
    # Crear un diccionario con la configuración
    rate_config = {
        "global_rpm": GLOBAL_RPM,
        "global_tpm": GLOBAL_TPM,
        "executor_count": executor_count  # Usado como node_count en el SDK
    }
    
    # Convertir a JSON para broadcast
    config_json = json.dumps(rate_config)
    
    # Broadcast a todos los ejecutores
    return spark.sparkContext.broadcast(config_json)


def main(
    input_path=None,
    output_path=None,
    pandas_output_path=None,
    container=None,
    executor_count=None
):
    """
    Función principal
    
    Args:
        input_path: Ruta al archivo CSV con metadatos de CVs
        output_path: Ruta para guardar resultados del RDD
        pandas_output_path: Ruta para guardar resultados de Pandas
        container: Nombre del contenedor de Azure Blob Storage
        executor_count: Número de ejecutores del cluster
    """
    logger.info("Iniciando procesamiento de CVs con Spark y control de límites de tasa")
    
    # Usar SparkSession existente en Databricks
    spark = SparkSession.builder.getOrCreate()
    
    # Obtener credenciales de Azure Blob Storage
    storage_account, storage_key = get_azure_storage_credentials(spark)
    
    # Configurar número de ejecutores
    if not executor_count:
        executor_count = int(spark.conf.get("spark.executor.instances", "4"))
    logger.info(f"Configurando para {executor_count} ejecutores")
    
    # Broadcast de la configuración de límites
    rate_config = broadcast_rate_limiter_config(spark, executor_count)
    
    # Definir rutas
    container_name = container or AZURE_CONTAINER
    input_file_path = input_path or AZURE_METADATA_PATH
    results_path = output_path or AZURE_RESULTS_PATH
    pandas_results_path = pandas_output_path or AZURE_PANDAS_RESULTS_PATH
    
    # Construir rutas completas para Azure Blob Storage
    wasbs_metadata_path = f"wasbs://{container_name}@{storage_account}.blob.core.windows.net/{input_file_path}"
    wasbs_results_path = f"wasbs://{container_name}@{storage_account}.blob.core.windows.net/{results_path}"
    wasbs_pandas_results_path = f"wasbs://{container_name}@{storage_account}.blob.core.windows.net/{pandas_results_path}"
    
    try:
        # Cargar datos de CVs desde Azure Blob Storage
        logger.info(f"Cargando datos de CVs desde: {wasbs_metadata_path}")
        cvs_df = (spark.read
            .option("header", "true")
            .option("multiline", "true")
            .csv(wasbs_metadata_path))
        
        # Calcular número óptimo de particiones
        # Un buen punto de partida es: ejecutores * 2-4 tareas por ejecutor
        partition_count = executor_count * 3
        logger.info(f"Configurando para {partition_count} particiones")
        
        # Repartición para mejor distribución de carga
        cvs_df = cvs_df.repartition(partition_count)
        
        # Método 1: Usando RDD con mapPartitions y limitador de tasa
        logger.info("Procesando CVs con mapPartitions y control de límites")
        
        # Convertir a RDD
        cvs_rdd = cvs_df.rdd.map(lambda row: row.asDict())
        
        # Procesar con límites de tasa
        results_rdd = cvs_rdd.mapPartitions(
            lambda partition: process_cv_batch_with_rate_limit(
                partition, 
                executor_count=executor_count
            )
        )
        
        # Convertir resultados a DataFrame
        results_df = spark.createDataFrame(
            results_rdd,
            ["cv_id", "filename", "analysis_result"]
        )
        
        # Guardar resultados en Azure Blob Storage
        logger.info(f"Guardando resultados en: {wasbs_results_path}")
        (results_df
            .write
            .mode("overwrite")
            .parquet(wasbs_results_path))
        
        # Método 2: Usando Pandas UDF con control de límites
        logger.info("Procesando CVs con Pandas UDF y control de límites")
        
        # Registrar UDF
        rate_limited_analyze = pandas_udf(
            pandas_rate_limited_cv_analysis, 
            returnType=StringType()
        )
        
        # Aplicar UDF
        pandas_results_df = cvs_df.withColumn(
            "analysis_result",
            rate_limited_analyze(col("content"))
        )
        
        # Guardar resultados del método Pandas en Azure Blob Storage
        logger.info(f"Guardando resultados de Pandas en: {wasbs_pandas_results_path}")
        (pandas_results_df
            .select("cv_id", "filename", "analysis_result")
            .write
            .mode("overwrite")
            .parquet(wasbs_pandas_results_path))
        
        logger.info("Procesamiento completado con éxito")
        
    except Exception as e:
        logger.error(f"Error en el procesamiento: {str(e)}")
        raise
    
    finally:
        logger.info("Procesamiento finalizado")


# Para ejecución directa en Databricks
def run_as_databricks_job():
    """Punto de entrada para ejecutar como job de Databricks"""
    try:
        spark = SparkSession.builder.getOrCreate()
        dbutils = DBUtils(spark)
        
        # Obtener parámetros del widget o job parameters
        # Si se ejecuta como notebook, estos parámetros deben configurarse con widgets primero
        try:
            input_path = dbutils.widgets.get("input_path")
        except:
            input_path = None
            
        try:
            output_path = dbutils.widgets.get("output_path")
        except:
            output_path = None
            
        try:
            pandas_output_path = dbutils.widgets.get("pandas_output_path")
        except:
            pandas_output_path = None
            
        try:
            container = dbutils.widgets.get("container")
        except:
            container = None
            
        try:
            executor_count = int(dbutils.widgets.get("executor_count"))
        except:
            executor_count = None
        
        # Ejecutar proceso principal
        main(
            input_path=input_path,
            output_path=output_path,
            pandas_output_path=pandas_output_path,
            container=container,
            executor_count=executor_count
        )
    except Exception as e:
        logger.error(f"Error al ejecutar job de Databricks: {str(e)}")
        raise


if __name__ == "__main__":
    # Si se ejecuta como script
    if "DATABRICKS_RUNTIME_VERSION" in os.environ:
        # Estamos en Databricks
        run_as_databricks_job()
    else:
        # Ejecución local o en otro entorno
        parser = argparse.ArgumentParser(description="CV Screening en Spark con control de límites de tasa")
        parser.add_argument("--input-path", help="Ruta al archivo CSV con metadatos de CVs")
        parser.add_argument("--output-path", help="Ruta para guardar resultados del RDD")
        parser.add_argument("--pandas-output-path", help="Ruta para guardar resultados de Pandas")
        parser.add_argument("--container", help="Nombre del contenedor de Azure Blob Storage")
        parser.add_argument("--executor-count", type=int, help="Número de ejecutores del cluster")
        
        args = parser.parse_args()
        
        main(
            input_path=args.input_path,
            output_path=args.output_path,
            pandas_output_path=args.pandas_output_path,
            container=args.container,
            executor_count=args.executor_count
        ) 