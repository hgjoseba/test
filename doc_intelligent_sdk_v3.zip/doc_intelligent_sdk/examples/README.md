# Ejemplos de uso del SDK de Document Intelligence

Esta carpeta contiene ejemplos prácticos que muestran cómo utilizar el SDK de Document Intelligence para extraer texto e información estructurada de documentos utilizando diferentes proveedores de servicios.

## Requisitos previos

Para ejecutar estos ejemplos, necesitas:

1. Python 3.8 o superior
2. El SDK de Document Intelligence instalado
3. Credenciales configuradas para los proveedores que desees utilizar (Azure, Google, AWS)

## Instalación

```bash
pip install doc-intelligent-sdk
```

## Ejemplos disponibles

### Análisis básico de documentos
- **[basic_usage.py](basic_usage.py)**: Ejemplo básico de cómo inicializar el SDK y analizar un documento PDF.

### Procesamiento por lotes (batch)
- **[batch_processing.py](batch_processing.py)**: Demuestra cómo procesar múltiples documentos en un lote para mayor eficiencia.

### Múltiples proveedores
- **[multiple_providers.py](multiple_providers.py)**: Ejemplo de cómo usar y comparar diferentes proveedores (Azure, Google, AWS) con la misma interfaz.

### Análisis de documentos desde datos base64
- **[base64_document.py](base64_document.py)**: Muestra cómo analizar documentos a partir de datos codificados en base64, útil para APIs y aplicaciones web.

### Autenticación con Service Principal
- **[azure_service_principal.py](azure_service_principal.py)**: Ejemplo de cómo autenticarse con Azure Document Intelligence usando un Service Principal en lugar de claves de API directas. Recomendado para entornos de producción.

### Configuración de endpoints personalizados
- **[custom_endpoints.py](custom_endpoints.py)**: Ejemplo de cómo configurar y gestionar diferentes endpoints para cada proveedor, útil para escenarios multiregionales o con requisitos específicos de ubicación de datos.

### Proveedor de Azure: Ejemplo completo
- **[azure_provider_example.py](azure_provider_example.py)**: Ejemplo completo que muestra las capacidades específicas del proveedor de Azure, incluyendo el uso de modelos preconfigurados para diferentes tipos de documentos (facturas, recibos, documentos de identidad) y parámetros específicos de Azure.

### Endpoints privados con Azure
- **[azure_private_endpoint.py](azure_private_endpoint.py)**: Demuestra cómo el SDK maneja automáticamente el reemplazo de URLs de operación públicas con endpoints privados durante las operaciones de polling, crucial para entornos con seguridad reforzada o redes restringidas.

### Service Principal con análisis base64
- **[service_principal_base64.py](service_principal_base64.py)**: Ejemplo completo que combina autenticación con Service Principal, configuración automática de NO_PROXY y análisis de documentos PDF convertidos a base64. Ideal para integraciones empresariales con APIs y servicios web.

## Estructura de directorios

Para que los ejemplos funcionen correctamente, debes crear una carpeta `samples` con algunos documentos de ejemplo:

```
examples/
├── samples/
│   ├── invoice.pdf
│   ├── receipt.pdf
│   ├── contract.pdf
│   ├── document.pdf
│   ├── id_document.jpg
│   ├── large_document.pdf
│   └── invoices/
│       ├── invoice1.pdf
│       ├── invoice2.pdf
│       └── invoice3.pdf
├── basic_usage.py
├── batch_processing.py
├── multiple_providers.py
├── base64_document.py
├── azure_service_principal.py
├── custom_endpoints.py
├── azure_provider_example.py
├── azure_private_endpoint.py
├── service_principal_base64.py
└── README.md
```

## Uso

Para ejecutar cualquiera de los ejemplos, simplemente utiliza:

```bash
python examples/basic_usage.py
```

> **Nota**: Asegúrate de reemplazar las credenciales de ejemplo con tus propias claves de API y configuración para cada proveedor.

## Adaptando los ejemplos

Puedes adaptar estos ejemplos para tus propias necesidades:

1. Cambia los tipos de documentos (facturas, recibos, contratos, etc.)
2. Modifica los modelos utilizados según el tipo de documento
3. Ajusta los parámetros de configuración como el idioma (`locale`)
4. Implementa tu propio procesamiento para los resultados obtenidos

## Proveedores soportados

El SDK actualmente soporta los siguientes proveedores:

- Azure Document Intelligence (anteriormente Form Recognizer)
- Google Cloud Document AI
- Amazon Textract y Amazon Comprehend

## Métodos de autenticación

El SDK admite varios métodos de autenticación:

- Claves de API directas (ejemplos básicos)
- Service Principal para Azure (entornos de producción)
- Roles de IAM para AWS
- Cuentas de servicio para Google Cloud

## Configuración regional y endpoints

El SDK permite configurar endpoints específicos para cada proveedor:

- **Azure**: Endpoints regionales o privados mediante el parámetro `endpoint`
  - Soporte para reemplazo automático de URLs públicas con privadas durante polling
  - Configuración automática de la variable de entorno NO_PROXY para evitar proxies
- **AWS**: La región determina automáticamente el endpoint mediante el parámetro `region`  
- **Google**: La ubicación del servicio se configura con el parámetro `location` 