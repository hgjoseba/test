"""
Document model classes for Document Intelligence SDK (OCR version).

This module defines simplified data models for representing analyzed documents
and their text content.
"""

from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel, Field
from enum import Enum

# Use validator instead of root_validator in Pydantic v1
from pydantic import validator


class DocumentStatus(Enum):
    """Estado del proceso de análisis de documentos."""
    SUCCEEDED = "succeeded"
    RUNNING = "running"
    FAILED = "failed"


class BoundingBox(BaseModel):
    """Represents a bounding box with normalized coordinates."""
    left: float
    top: float
    width: float
    height: float
    
    @classmethod
    def from_azure_polygon(cls, points: List[Dict[str, float]]) -> "BoundingBox":
        """
        Create a BoundingBox from Azure SDK polygon points.
        
        Args:
            points: List of points in the polygon (usually 4 points).
                Can be either list of dicts with 'x' and 'y' keys or
                a flat list of coordinates [x1, y1, x2, y2, ...].
            
        Returns:
            BoundingBox: The constructed bounding box.
        """
        if not points or len(points) < 4:
            return cls(left=0, top=0, width=0, height=0)
        
        # Check if points is a flat list of coordinates [x1, y1, x2, y2, ...]
        if isinstance(points[0], (int, float)):
            # Extract x and y coordinates from the flat list
            xs = [points[i] for i in range(0, len(points), 2)]
            ys = [points[i] for i in range(1, len(points), 2)]
            
            # Calculate bounding box
            min_x = min(xs)
            min_y = min(ys)
            max_x = max(xs)
            max_y = max(ys)
        else:
            # Calculate bounding box from polygon points as dicts
            min_x = min(p.get('x', 0) for p in points)
            min_y = min(p.get('y', 0) for p in points)
            max_x = max(p.get('x', 0) for p in points)
            max_y = max(p.get('y', 0) for p in points)
        
        return cls(
            left=min_x,
            top=min_y,
            width=max_x - min_x,
            height=max_y - min_y
        )


class TextLine(BaseModel):
    """Represents a line of text in a document."""
    content: str
    bounding_box: Optional[BoundingBox] = None
    confidence: float = 1.0
    span: Optional[Dict[str, int]] = None
    
    @classmethod
    def from_azure_line(cls, line: Any) -> "TextLine":
        """
        Create a TextLine from an Azure SDK line object.
        
        Args:
            line: Azure SDK line object.
            
        Returns:
            TextLine: The constructed text line.
        """
        bounding_box = None
        if hasattr(line, 'polygon') and line.polygon:
            bounding_box = BoundingBox.from_azure_polygon(line.polygon)
        
        span = None
        if hasattr(line, 'span') and line.span:
            span = {"offset": line.span.offset, "length": line.span.length}
        
        return cls(
            content=line.content,
            bounding_box=bounding_box,
            confidence=getattr(line, 'confidence', 1.0),
            span=span
        )


class TextPage(BaseModel):
    """Represents a page of text in a document."""
    page_number: int
    width: float = 0.0
    height: float = 0.0
    unit: str = "pixel"
    lines: List[TextLine] = Field(default_factory=list)
    language: Optional[str] = None
    
    @classmethod
    def from_azure_page(cls, page: Any) -> "TextPage":
        """
        Create a TextPage from an Azure SDK page object.
        
        Args:
            page: Azure SDK page object.
            
        Returns:
            TextPage: The constructed text page.
        """
        lines = []
        for line in page.lines:
            lines.append(TextLine.from_azure_line(line))
        
        return cls(
            page_number=page.page_number,
            width=page.width,
            height=page.height,
            unit=page.unit,
            lines=lines,
            language=getattr(page, "language", None)
        )
    
    def get_text(self) -> str:
        """
        Get the text content of the page.
        
        Returns:
            str: The text content of the page.
        """
        return "\n".join([line.content for line in self.lines])


class DocumentModel(BaseModel):
    """Represents a document model available in the service."""
    model_id: str
    description: str
    created_on: Optional[datetime] = None
    is_prebuilt: bool = False
    capabilities: List[str] = Field(default_factory=list)
    
    @classmethod
    def from_azure_model(cls, model: Any) -> "DocumentModel":
        """
        Create a DocumentModel from an Azure SDK model object.
        
        Args:
            model: Azure SDK model object.
            
        Returns:
            DocumentModel: The constructed document model.
        """
        return cls(
            model_id=model.model_id,
            description=model.description,
            created_on=getattr(model, "created_on", None),
            is_prebuilt=getattr(model, "is_prebuilt", False),
            capabilities=getattr(model, "capabilities", [])
        )


class AnalyzedDocument(BaseModel):
    """
    Represents an analyzed document with extracted text information.
    
    This is the main model that contains the text information extracted
    from a document.
    """
    document_id: Optional[str] = None
    model_id: str
    pages: List[TextPage] = Field(default_factory=list)
    content: str = ""
    content_type: str = ""
    file_name: Optional[str] = None
    language: Optional[str] = None
    analysis_timestamp: Optional[datetime] = None
    status: DocumentStatus = DocumentStatus.RUNNING
    paragraphs: List[Any] = Field(default_factory=list)
    tables: List[Any] = Field(default_factory=list)
    
    @classmethod
    def from_azure_result(cls, result: Any) -> "AnalyzedDocument":
        """
        Create an AnalyzedDocument from an Azure SDK result object.
        
        Args:
            result: Azure SDK result object.
            
        Returns:
            AnalyzedDocument: The constructed analyzed document.
        """
        # Establecer el estado según el resultado
        status_str = getattr(result, 'status', None)
        if status_str == "succeeded":
            status = DocumentStatus.SUCCEEDED
        elif status_str == "running":
            status = DocumentStatus.RUNNING
        else:
            status = DocumentStatus.FAILED
            
        # Process response differently based on API version
        if hasattr(result, 'documents') and result.documents:
            # Handle newer Azure response format
            doc_result = result.documents[0]
            
            # Extract pages
            pages = []
            for page in result.pages:
                pages.append(TextPage.from_azure_page(page))
            
            # Create the document
            return cls(
                document_id=getattr(doc_result, 'doc_type', None),
                model_id=getattr(result, 'model_id', 'unknown'),
                pages=pages,
                content=result.content if hasattr(result, 'content') else "",
                content_type=getattr(result, 'content_type', ''),
                file_name=getattr(result, 'file_name', None),
                language=getattr(result, 'language', None),
                analysis_timestamp=datetime.now(),
                status=status,
                paragraphs=getattr(result, 'paragraphs', []),
                tables=getattr(result, 'tables', [])
            )
        # Handle analyzeResult attribute
        elif hasattr(result, 'analyze_result'):
            # Extract pages from analyze_result
            pages = []
            analyze_result = result.analyze_result
            if hasattr(analyze_result, 'pages'):
                for page in analyze_result.pages:
                    pages.append(TextPage.from_azure_page(page))
            
            # Create the document
            return cls(
                document_id=None,
                model_id=getattr(analyze_result, 'model_id', 'unknown'),
                pages=pages,
                content=getattr(analyze_result, 'content', ''),
                content_type=getattr(result, 'content_type', ''),
                file_name=getattr(result, 'file_name', None),
                language=getattr(analyze_result, 'language', None),
                analysis_timestamp=datetime.now(),
                status=status,
                paragraphs=getattr(analyze_result, 'paragraphs', []),
                tables=getattr(analyze_result, 'tables', [])
            )
        else:
            # Handle older Azure response format or custom formats
            # Define mock objects for conversion
            class PageObject:
                def __init__(self, data):
                    self.page_number = data.get('page_number', 0)
                    self.width = data.get('width', 0)
                    self.height = data.get('height', 0)
                    self.unit = data.get('unit', 'pixel')
                    self.angle = data.get('angle', 0)
                    
                    # Convert lines
                    self.lines = []
                    for line_data in data.get('lines', []):
                        line = type('LineObject', (), {})()
                        line.content = line_data.get('content', '')
                        line.polygon = line_data.get('polygon', [])
                        line.span = type('SpanObject', (), {})()
                        span_data = line_data.get('span', {})
                        line.span.offset = span_data.get('offset', 0)
                        line.span.length = span_data.get('length', 0)
                        line.confidence = line_data.get('confidence', 1.0)
                        self.lines.append(line)
            
            # Convert pages
            pages = []
            for page_data in result.get('pages', []):
                page_obj = PageObject(page_data)
                pages.append(TextPage.from_azure_page(page_obj))
            
            # Extract status from dictionary if present
            if isinstance(result, dict):
                status_str = result.get('status')
                if status_str == "succeeded":
                    status = DocumentStatus.SUCCEEDED
                elif status_str == "running":
                    status = DocumentStatus.RUNNING
                else:
                    status = DocumentStatus.FAILED
            
            # Create the document
            return cls(
                document_id=result.get('document_id'),
                model_id=result.get('model_id', 'unknown'),
                pages=pages,
                content=result.get('content', ''),
                content_type=result.get('content_type', ''),
                file_name=result.get('file_name'),
                language=result.get('language'),
                analysis_timestamp=datetime.now(),
                status=status,
                paragraphs=result.get('paragraphs', []),
                tables=result.get('tables', [])
            )
    
    def get_text(self) -> str:
        """
        Get the complete text content of the document.
        
        Returns:
            str: The text content of the document.
        """
        if self.content and len(self.content) > 0:
            return self.content
        
        return "\n\n".join([page.get_text() for page in self.pages])
    
    def get_page_text(self, page_number: int) -> str:
        """
        Get the text content of a specific page.
        
        Args:
            page_number: The page number (1-based index).
            
        Returns:
            str: The text content of the specified page.
        """
        for page in self.pages:
            if page.page_number == page_number:
                return page.get_text()
        
        return "" 