"""
Azure Document Intelligence Provider (OCR version).

This module defines the specific provider for Azure's document intelligence services
focused on text extraction using direct HTTP requests to the Azure Document Intelligence service.
"""

import os
import time
import logging
import requests
from pathlib import Path
from typing import Dict, Optional, Any, Union

from .base import DocumentProvider
from ..auth.azure import AzureCredential
from ..models.response import DocumentAnalysisResponse
from ..utils.errors import DocumentIntelligenceError, ModelNotFoundError, ServiceError

# Logger configuration
logger = logging.getLogger(__name__)

class AzureDocumentProvider(DocumentProvider):
    """
    Provider for accessing Azure Document Intelligence services for text extraction.
    
    This class implements the DocumentProvider interface for Azure Document Intelligence.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        api_key: str = None,
        api_version: str = "2023-07-31",
        credential: AzureCredential = None,
        connection_verify: Union[bool, str] = True,
        public_endpoint: str = None,
    ):
        """
        Initialize the Azure Document Intelligence provider.
        
        Args:
            endpoint: Azure Document Intelligence endpoint URL.
                Can also be set via the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT environment variable.
            api_key: Azure Document Intelligence API key.
                Can also be set via the AZURE_DOCUMENT_INTELLIGENCE_KEY environment variable.
            api_version: API version to use. Default: "2023-07-31".
            credential: AzureCredential object for authentication.
                If not provided, api_key will be used if available.
            connection_verify: Controls SSL certificate verification. Set to False to disable verification,
                or provide a path to a CA bundle to use. Default: True.
            public_endpoint: Public Azure Document Intelligence endpoint URL used in response URLs.
                If provided, will be automatically replaced with the private endpoint for polling operations.
                Can also be set via the AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT environment variable.
        """
        # Endpoint configuration
        self.endpoint = endpoint or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        self.api_key = api_key or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
        self.api_version = api_version
        self.credential = credential
        self.connection_verify = connection_verify
        # Use the provided public endpoint or environment variable, with fallback to the private endpoint
        self.public_endpoint = public_endpoint or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT", self.endpoint)
        
        # Enhanced proxy configuration
        if self.endpoint:
            # Extract the FQDN of the private endpoint for NO_PROXY
            private_fqdn = self.endpoint.replace("https://", "").split("/")[0]
            
            # Check if the domain is already in NO_PROXY
            current_no_proxy = os.environ.get("NO_PROXY", "")
            if private_fqdn not in current_no_proxy.split(","):
                if current_no_proxy:
                    os.environ["NO_PROXY"] = f"{current_no_proxy},{private_fqdn}"
                else:
                    os.environ["NO_PROXY"] = private_fqdn
                logger.info(f"Added {private_fqdn} to NO_PROXY to bypass proxy for private endpoints")
        
        # Validation
        if not self.endpoint:
            raise ValueError("Endpoint must be provided directly or through an environment variable")
        
        if not self.api_key and not self.credential:
            raise ValueError("Either an API key or credentials must be provided for authentication")
    
    def _get_headers(self) -> Dict[str, str]:
        """
        Get authentication headers for API requests.
        
        Returns:
            Dict[str, str]: Authentication headers.
        
        Raises:
            DocumentIntelligenceError: If authentication fails.
        """
        try:
            if self.api_key:
                return {"Ocp-Apim-Subscription-Key": self.api_key}
            elif self.credential:
                # Directly use the get_token method from AzureCredential
                token = self.credential.get_token()
                return {"Authorization": f"Bearer {token}"}
            else:
                raise DocumentIntelligenceError("No authentication method available")
        except Exception as e:
            logger.error(f"Error getting authentication headers: {str(e)}")
            raise DocumentIntelligenceError(f"Authentication error: {str(e)}")
    
    def _get_content_type(self, file_path: Path) -> str:
        """
        Determine content type based on file extension.
        Only supports PDF and DOCX.
        
        Args:
            file_path: Path to the file.
            
        Returns:
            str: The content type of the file.
        """
        extension = file_path.suffix.lower()
        content_types = {
            ".pdf": "application/pdf",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }
        
        return content_types.get(extension, "application/octet-stream")
    
    def analyze_document(
        self,
        file_path: Union[str, Path],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document for text extraction using Azure Document Intelligence.
        
        If a public endpoint different from the private endpoint was provided, the system
        will automatically replace the public endpoint with the private one in the
        Operation-Location URL for polling, allowing access to private endpoints
        with restrictive firewalls or in virtual networks.
        
        Args:
            file_path: Path to the document file to analyze.
            model_id: ID of the model to use. Default: "prebuilt-document".
            locale: Language locale of the document. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Default: 5.
            timeout: Maximum time (in seconds) to wait for the result. Default: 300.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Prepare the URL for analysis
        analyze_url = f"{self.endpoint}/documentModels/{model_id}:analyze?api-version={self.api_version}"
        logger.info(f"Analysis URL: {analyze_url}")
        
        # Get authentication headers
        headers = self._get_headers()
        
        # Determine content type based on file extension
        content_type = self._get_content_type(file_path)
        logger.info(f"Determined content type: {content_type}")
        
        # PHASE 1: Send analysis request
        try:
            with open(file_path, "rb") as f:
                files = {"file": (file_path.name, f, content_type)}
                
                # Prepare form data with options
                form_data = {}
                if locale:
                    form_data["locale"] = locale
                if pages:
                    form_data["pages"] = ','.join(map(str, pages))
                # Add additional parameters
                form_data.update(kwargs)
                
                response = requests.post(
                    analyze_url,
                    headers=headers,
                    files=files,
                    data=form_data, 
                    timeout=30,
                    verify=self.connection_verify
                )
        except Exception as e:
            logger.error(f"Error sending analysis request: {str(e)}")
            raise DocumentIntelligenceError(f"Request error: {str(e)}")
        
        # Verify response
        logger.info(f"Response status: {response.status_code}")
        if response.status_code not in [200, 202]:
            logger.error(f"Request failed: {response.status_code} {response.text}")
            if response.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                raise ServiceError(f"Service error: {response.text}", response.status_code)
        
        # Get operation location for polling
        op_location = response.headers.get("Operation-Location")
        if not op_location:
            logger.error("Operation-Location header not found in response")
            raise DocumentIntelligenceError("Missing Operation-Location header in response")
        
        logger.info(f"Operation-Location: {op_location}")
        
        # PHASE 2: Poll for results
        start_time = time.time()
        
        # Replace public endpoint with private if necessary
        if self.public_endpoint and op_location.startswith(self.public_endpoint):
            poll_url = op_location.replace(self.public_endpoint, self.endpoint)
        else:
            poll_url = op_location
            
        logger.info(f"Polling URL: {poll_url}")
        
        # Polling loop
        while True:
            try:
                poll_response = requests.get(
                    poll_url,
                    headers=headers,
                    timeout=30,
                    verify=self.connection_verify
                )
            except Exception as e:
                logger.error(f"Error during polling: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            if poll_response.status_code != 200:
                logger.error(f"Polling failed: {poll_response.status_code} {poll_response.text}")
                raise ServiceError(f"Polling error: {poll_response.text}", poll_response.status_code)
            
            try:
                result = poll_response.json()
            except Exception as e:
                logger.error(f"Error parsing JSON response: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            status = result.get("status")
            logger.info(f"Current status: {status}")
            
            if status in ["running", "notStarted"]:
                if time.time() - start_time > timeout:
                    logger.error("Polling timeout exceeded")
                    raise DocumentIntelligenceError(f"Analysis timeout after {timeout} seconds")
                time.sleep(poll_interval)
            elif status == "succeeded":
                logger.info("Analysis job completed successfully")
                # Create a DocumentAnalysisResponse from the result
                return DocumentAnalysisResponse.from_azure_result(result)
            else:
                logger.error(f"Analysis failed with status: {status}")
                errors = result.get("errors", [])
                error_message = errors[0].get("message", "Unknown error") if errors else "Analysis failed"
                raise DocumentIntelligenceError(error_message)
    
    def analyze_document_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document from base64 encoded data for text extraction.
        
        Args:
            base64_string: Base64 encoded document data.
            content_type: Content type of the document (e.g., "application/pdf").
            model_id: ID of the model to use. Default: "prebuilt-document".
            locale: Language locale of the document. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Default: 5.
            timeout: Maximum time (in seconds) to wait for the result. Default: 300.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        # Prepare the URL for analysis
        analyze_url = f"{self.endpoint}/documentModels/{model_id}:analyze?api-version={self.api_version}"
        logger.info(f"Analysis URL (base64): {analyze_url}")
        
        # Get authentication headers
        headers = self._get_headers()
        
        # Add content type and other headers
        headers["Content-Type"] = "application/json"
        
        # Prepare the request body
        body = {"base64Source": base64_string}
        
        # Add options
        options = {}
        if locale:
            options["locale"] = locale
        if pages:
            options["pages"] = pages
        
        # Add additional parameters
        options.update(kwargs)
        
        if options:
            body["analyzeRequest"] = {"modelId": model_id, "options": options}
        
        # PHASE 1: Send analysis request
        try:
            response = requests.post(
                analyze_url,
                headers=headers,
                json=body,
                timeout=30,
                verify=self.connection_verify
            )
        except Exception as e:
            logger.error(f"Error sending base64 analysis request: {str(e)}")
            raise DocumentIntelligenceError(f"Request error: {str(e)}")
        
        # Verify response
        logger.info(f"Base64 response status: {response.status_code}")
        if response.status_code not in [200, 202]:
            logger.error(f"Base64 request failed: {response.status_code} {response.text}")
            if response.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                raise ServiceError(f"Service error: {response.text}", response.status_code)
        
        # Get operation location for polling
        op_location = response.headers.get("Operation-Location")
        if not op_location:
            logger.error("Operation-Location header not found in base64 response")
            raise DocumentIntelligenceError("Missing Operation-Location header in response")
        
        logger.info(f"Operation-Location (base64): {op_location}")
        
        # PHASE 2: Poll for results
        start_time = time.time()
        
        # Replace public endpoint with private if necessary
        if self.public_endpoint and op_location.startswith(self.public_endpoint):
            poll_url = op_location.replace(self.public_endpoint, self.endpoint)
        else:
            poll_url = op_location
            
        logger.info(f"Polling URL (base64): {poll_url}")
        
        # Polling loop
        while True:
            try:
                poll_response = requests.get(
                    poll_url,
                    headers=headers,
                    timeout=30,
                    verify=self.connection_verify
                )
            except Exception as e:
                logger.error(f"Error during base64 polling: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            if poll_response.status_code != 200:
                logger.error(f"Base64 polling failed: {poll_response.status_code} {poll_response.text}")
                raise ServiceError(f"Polling error: {poll_response.text}", poll_response.status_code)
            
            try:
                result = poll_response.json()
            except Exception as e:
                logger.error(f"Error parsing base64 JSON response: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            status = result.get("status")
            logger.info(f"Current base64 status: {status}")
            
            if status in ["running", "notStarted"]:
                if time.time() - start_time > timeout:
                    logger.error("Base64 polling timeout exceeded")
                    raise DocumentIntelligenceError(f"Analysis timeout after {timeout} seconds")
                time.sleep(poll_interval)
            elif status == "succeeded":
                logger.info("Base64 analysis job completed successfully")
                # Create a DocumentAnalysisResponse from the result
                return DocumentAnalysisResponse.from_azure_result(result)
            else:
                logger.error(f"Base64 analysis failed with status: {status}")
                errors = result.get("errors", [])
                error_message = errors[0].get("message", "Unknown error") if errors else "Analysis failed"
                raise DocumentIntelligenceError(error_message) 