"""
Text extractor module for Document Intelligence SDK (OCR version).

This module provides the TextExtractor class for extracting text
from analyzed documents.
"""

import os
from pathlib import Path
from typing import Optional, Union

from ..models.document import AnalyzedDocument
from ..utils.logging import get_logger

logger = get_logger(__name__)


class TextExtractor:
    """
    Text extractor for extracting plain text from analyzed documents.
    
    This class provides methods for extracting and saving text content
    from document analysis results.
    """
    
    def __init__(self):
        """Initialize the text extractor."""
        pass
    
    def to_text(self, document: AnalyzedDocument, output_path: Optional[Union[str, Path]] = None) -> str:
        """
        Extract plain text from an analyzed document.
        
        Args:
            document: The analyzed document to extract text from.
            output_path: Optional path to save the text output.
            
        Returns:
            str: The extracted text content.
        """
        text_content = document.get_text()
        
        # Save to file if output path is provided
        if output_path:
            output_path = Path(output_path)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(text_content)
                
        return text_content
    
    def extract_by_page(self, document: AnalyzedDocument, page_number: int) -> str:
        """
        Extract text from a specific page of an analyzed document.
        
        Args:
            document: The analyzed document to extract text from.
            page_number: The page number to extract (1-based index).
            
        Returns:
            str: The extracted text content for the specified page.
        """
        return document.get_page_text(page_number)
    
    def extract_all_pages(self, document: AnalyzedDocument, output_dir: Union[str, Path] = None) -> dict:
        """
        Extract text from each page of an analyzed document separately.
        
        Args:
            document: The analyzed document to extract text from.
            output_dir: Optional directory to save individual page text files.
            
        Returns:
            dict: Dictionary mapping page numbers to their text content.
        """
        page_texts = {}
        
        for page in document.pages:
            page_num = page.page_number
            text = page.get_text()
            page_texts[page_num] = text
            
            # Save to files if output directory is provided
            if output_dir:
                output_dir_path = Path(output_dir)
                output_dir_path.mkdir(parents=True, exist_ok=True)
                
                file_name = f"{os.path.splitext(document.file_name)[0] if document.file_name else 'document'}_page_{page_num}.txt"
                file_path = output_dir_path / file_name
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(text)
        
        return page_texts 