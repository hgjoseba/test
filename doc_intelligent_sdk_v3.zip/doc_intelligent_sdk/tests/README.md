# Document Intelligence SDK - Tests

Este directorio contiene las pruebas unitarias para el SDK de Document Intelligence.

## Estructura

- `test_client.py`: Pruebas para la clase principal `DocIntelligenceClient`.
- `test_azure_provider.py`: Pruebas para el proveedor Azure `AzureDocumentProvider`.
- `test_response_model.py`: Pruebas para el modelo de respuesta `DocumentAnalysisResponse`.
- `test_document_model.py`: Pruebas para los modelos de documento como `AnalyzedDocument`, `TextPage`, etc.
- `conftest.py`: Configuración y fixtures para pytest.
- `run_tests.py`: Script para ejecutar todas las pruebas con análisis de cobertura.
- `examples/`: Ejemplos de uso del SDK para pruebas manuales.
- `resources/`: Archivos de recursos para las pruebas.

## Ejecución de pruebas

Para ejecutar todas las pruebas, utilice:

```bash
python tests/run_tests.py
```

Para generar un informe de cobertura HTML:

```bash
python tests/run_tests.py --html
```

El informe HTML se generará en el directorio `coverage_html/`.

Alternativamente, puede usar directamente `pytest`:

```bash
pytest tests/
```

## Ejemplos

El directorio `examples/` contiene ejemplos de uso del SDK para pruebas manuales. Para ejecutar los ejemplos, es necesario configurar las variables de entorno con las credenciales de Azure:

```bash
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT="https://your-endpoint.cognitiveservices.azure.com/"
export AZURE_DOCUMENT_INTELLIGENCE_KEY="your-api-key"
```

Luego, puede ejecutar los ejemplos:

```bash
python tests/examples/test_basic_usage.py
```

Asegúrese de modificar las rutas de los archivos en los ejemplos para apuntar a archivos de documentos válidos en su sistema.

## Cobertura

El objetivo de estas pruebas es proporcionar una cobertura completa de todas las funcionalidades del SDK. Las pruebas están diseñadas para verificar:

1. Inicialización correcta de los objetos
2. Manejo adecuado de errores
3. Flujos de trabajo completos
4. Transformación correcta de datos
5. Integración con la API de Azure Document Intelligence

## Contribuciones

Al agregar nuevas funcionalidades al SDK, asegúrese de:

1. Agregar pruebas unitarias correspondientes
2. Mantener o mejorar el nivel de cobertura
3. Verificar que todas las pruebas existentes pasen con los cambios 