# CV Screening SDK

A SDK for screening CVs using Azure OpenAI Service.

## Features

- Simple synchronous API for CV analysis
- Direct integration with Azure OpenAI Service
- Raw response handling without complex processing
- Support for PDF and DOCX file formats (with optional dependencies)
- Minimal dependencies and easy installation
- Custom system prompt support for tailored CV analysis
- SSL verification control for corporate environments
- Automatic JSON formatting for non-standard models via secondary processing

## Installation

Install from PyPI:

```bash
pip install cv-screening-sdk
```

For PDF and DOCX support, install with optional dependencies:

```bash
pip install "cv-screening-sdk[document_processing]"
```

For development, install with dev dependencies:

```bash
pip install "cv-screening-sdk[dev]"
```

### Installation from source code

If you want to install from source code, you can do the following:

```bash
git clone https://github.com/yourusername/cv-screening-sdk.git
cd cv-screening-sdk
pip install -e .
```

Or install it with all dependencies:

```bash
pip install -e ".[document_processing,dev]"
```

## Development

To set up the development environment:

```bash
# Clone the repository
git clone https://github.com/yourusername/cv-screening-sdk.git
cd cv-screening-sdk

# Install development dependencies
pip install -r requirements.txt

# Or install in development mode with all optional dependencies
pip install -e ".[document_processing,dev]"
```

## Quick Start

```python
from src import CVScreeningClient, JobCriteria

# Initialize client with Azure OpenAI credentials
client = CVScreeningClient(
    api_key="your-azure-openai-api-key",
    endpoint="https://your-resource.openai.azure.com/",
    model_name="gpt-4"  # Your deployment name in Azure
)

# Create job criteria
criteria = JobCriteria(
    required_skills=["python", "javascript"],
    preferred_skills=["react", "docker"],
    min_years_experience=3,
    education_level="bachelor's"
)

# Load CV from file
cv_text = client.load_cv_content("path/to/resume.pdf")

# Analyze CV
result = client.analyze_cv(cv_text, criteria)

# Print results
print(f"CV Analysis Result:")
print(result)
```

## Working with Base64 Content

The SDK now supports base64 encoded content through the ContentType enum, which is useful when passing CV data through APIs or when you have the CV content in memory instead of a file.

### Loading and Analyzing Base64 Content

```python
import base64
from src import CVScreeningClient, ContentType

# Initialize client
client = CVScreeningClient(
    api_key="your-azure-openai-api-key",
    endpoint="https://your-resource.openai.azure.com/",
    model_name="gpt-4"
)

# Convert a file to base64
with open("path/to/resume.pdf", "rb") as f:
    file_content = f.read()
    base64_content = base64.b64encode(file_content)

# The client can analyze base64 content directly by specifying the content type
result = client.analyze_cv(base64_content, criteria, content_type=ContentType.BASE64)

# You can also encode text content
text_content = "John Doe\nSoftware Engineer\n5 years experience with Python..."
text_base64 = base64.b64encode(text_content.encode('utf-8'))
result = client.analyze_cv(text_base64, criteria, content_type=ContentType.BASE64)

# The load_cv_content method can also handle different content types
decoded_content = client.load_cv_content(base64_content, content_type=ContentType.BASE64)
print(decoded_content)  # Prints the decoded text content

# Or load a file directly
file_content = client.load_cv_content("path/to/resume.pdf", content_type=ContentType.FILE_PATH)
```

### Different Content Types

The SDK supports the following content types:

- `ContentType.TEXT`: Plain text content (default)
- `ContentType.BASE64`: Base64 encoded content
- `ContentType.FILE_PATH`: Path to a file on disk

### Using the Command Line Interface with Base64

The command line interface also supports base64 encoded content:

```bash
# Analyze a CV file
cv-screening --cv-file resume.pdf --criteria job_criteria.json

# Analyze base64 content
cv-screening --cv-base64 "SGVsbG8sIHRoaXMgaXMgYSB0ZXN0" --criteria job_criteria.json
```

## Customizing System Prompt

You can customize the system prompt used for CV analysis:

```python
# Define a custom system prompt
custom_prompt = """You are a CV analysis expert for technical roles.
Evaluate CVs against job criteria and provide a thorough assessment.
Your response should be a JSON object with an overall match score,
skill matching details, and specific recommendations."""

# Initialize client with custom system prompt
client = CVScreeningClient(
    api_key="your-azure-openai-api-key",
    endpoint="https://your-resource.openai.azure.com/",
    model_name="gpt-4",
    system_prompt=custom_prompt
)

# Analyze with custom prompt
result = client.analyze_cv(cv_text, criteria)
```

## Using Azure OpenAI Service Directly

You can also use the Azure OpenAI provider directly:

```python
from src.cv_screening.providers.azure_provider import AzureOpenAIProvider

# Initialize the Azure OpenAI provider
provider = AzureOpenAIProvider(
    endpoint="https://your-resource.openai.azure.com/",
    api_key="your-azure-openai-api-key",
    deployment_name="gpt-4",  # Your deployment name in Azure
    system_prompt="Your custom system prompt here"  # Optional
)

# Define job criteria
criteria = {
    "required_skills": ["python", "api development"],
    "preferred_skills": ["docker", "aws"],
    "min_years_experience": 3
}

# Analyze CV
result = provider.analyze_cv(cv_content, criteria)
print(result)
```

### SSL Verification in Corporate Environments

When working behind corporate proxies or in environments with SSL inspection, you might need to disable SSL verification:

```python
# Initialize Azure OpenAI provider with SSL verification disabled
provider = AzureOpenAIProvider(
    endpoint="https://your-resource.openai.azure.com/",
    api_key="your-azure-openai-api-key",
    deployment_name="gpt-4",
    connection_verify=False  # Disable SSL verification
)
```

> **Warning**: Disabling SSL verification reduces security. Only use this option in controlled environments where you understand the risks.

## Key Differences from Full SDK

- Synchronous-only operations (no async support)
- Focus on Azure OpenAI Service
- Raw output from Azure OpenAI without complex post-processing
- Minimal dependencies for easier installation
- Simplified configuration with fewer options

## Configuration via Environment Variables

You can configure the client using environment variables:

```bash
# Azure OpenAI credentials
export AZURE_OPENAI_API_KEY=your-api-key
export AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
export AZURE_OPENAI_DEPLOYMENT=gpt-4

# Optional configuration
export OPENAI_TEMPERATURE=0.1
export OPENAI_MAX_TOKENS=2000
export OPENAI_CONNECTION_VERIFY=true
export OPENAI_SYSTEM_PROMPT="Your custom system prompt here"
```

## License

MIT

## Model Processing and Verification

The SDK now includes functionality that checks whether the Azure OpenAI model being used is in a predefined list of allowed models. This enables a two-step processing approach for models that don't support the structured output features.

### Allowed Models List

By default, the following models are considered "allowed" and support response_format:

```python
ALLOWED_MODELS = ["gpt-4", "gpt-4-32k", "gpt-35-turbo"]
```

### Two-Step Processing for Different Models

#### For Allowed Models (e.g., GPT-4)
When using a model from the allowed list:
1. The CV analysis is performed in a single API call
2. `response_format={"type": "json_object"}` and a JSON schema are used to ensure structured output
3. The response is properly formatted as JSON directly by the model

#### For Non-Allowed Models (e.g., o1-mini)
When using a model that is not on the allowed list:
1. First, the CV is analyzed using the primary model (e.g., o1-mini)
2. Then, the response from this model is sent to a secondary model (GPT-4 by default)
3. The secondary model formats the response according to the JSON schema
4. The final result maintains a consistent JSON structure

This approach is especially useful when:
- Using specialized models that don't support response_format
- Working with fine-tuned models for CV analysis
- Needing to ensure consistent JSON formatting in outputs

### Example Usage with Custom Model

```python
from src import CVScreeningClient

# Initialize client with a specialized model
client = CVScreeningClient(
    api_key="your-azure-openai-api-key",
    endpoint="https://your-resource.openai.azure.com/",
    model_name="o1-mini",  # A model that doesn't support response_format
    # Optional: Use a different endpoint for the secondary formatting model
    secondary_endpoint="https://gpt4-endpoint.openai.azure.com/",
    secondary_api_key="your-gpt4-api-key"
)

# The analysis will work through the two-step process:
# 1. Initial analysis with o1-mini
# 2. Formatting with GPT-4 (potentially on a different endpoint)
result = client.analyze_cv(cv_text, criteria)

# The result will have a consistent JSON structure
print(f"Match score: {result['overall_match']}")
print(f"Skills: {result['skills_match']}")
```

### Customizing the Secondary Processing

You can customize the secondary processing by extending the `AzureOpenAIProvider` class:

```python
from src.cv_screening.providers.azure_provider import AzureOpenAIProvider

class CustomProvider(AzureOpenAIProvider):
    # Override the secondary processing model
    SECONDARY_PROCESSING_MODEL = "gpt-35-turbo"
    
    def __init__(self, *args, **kwargs):
        # Add your custom secondary endpoint and API key
        super().__init__(
            *args,
            secondary_endpoint="https://your-formatting-endpoint.azure.com",
            secondary_api_key="your-formatting-api-key",
            **kwargs
        )
    
    # Custom implementation if needed
    def analyze_cv(self, content, criteria):
        # ...
``` 