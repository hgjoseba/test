"""
Tests for core type definitions.
"""
import unittest
import pytest

from src.cv_screening.core.types import ContentType


class TestContentType(unittest.TestCase):
    """Tests for ContentType enum."""
    
    def test_enum_values(self):
        """Test ContentType enum values."""
        # Verify all expected enum values exist
        self.assertTrue(hasattr(ContentType, 'TEXT'))
        self.assertTrue(hasattr(ContentType, 'BASE64'))
        self.assertTrue(hasattr(ContentType, 'FILE_PATH'))
    
    def test_from_string_text(self):
        """Test from_string with 'text'."""
        # Test with lowercase
        self.assertEqual(ContentType.from_string('text'), ContentType.TEXT)
        # Test with uppercase
        self.assertEqual(ContentType.from_string('TEXT'), ContentType.TEXT)
        # Test with mixed case
        self.assertEqual(ContentType.from_string('Text'), ContentType.TEXT)
    
    def test_from_string_base64(self):
        """Test from_string with 'base64'."""
        # Test with lowercase
        self.assertEqual(ContentType.from_string('base64'), ContentType.BASE64)
        # Test with uppercase
        self.assertEqual(ContentType.from_string('BASE64'), ContentType.BASE64)
        # Test with mixed case
        self.assertEqual(ContentType.from_string('Base64'), ContentType.BASE64)
    
    def test_from_string_file_path(self):
        """Test from_string with 'file' and 'file_path'."""
        # Test 'file' with lowercase
        self.assertEqual(ContentType.from_string('file'), ContentType.FILE_PATH)
        # Test 'file' with uppercase
        self.assertEqual(ContentType.from_string('FILE'), ContentType.FILE_PATH)
        
        # Test 'file_path' with lowercase
        self.assertEqual(ContentType.from_string('file_path'), ContentType.FILE_PATH)
        # Test 'file_path' with uppercase
        self.assertEqual(ContentType.from_string('FILE_PATH'), ContentType.FILE_PATH)
    
    def test_from_string_invalid(self):
        """Test from_string with invalid input."""
        # Test with invalid value
        with self.assertRaises(ValueError):
            ContentType.from_string('invalid_type')
        
        # Test with empty string
        with self.assertRaises(ValueError):
            ContentType.from_string('')


if __name__ == '__main__':
    unittest.main() 