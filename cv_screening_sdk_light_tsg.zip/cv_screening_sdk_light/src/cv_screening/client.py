"""
Main client for CV screening operations.

This module provides the main entry point for the CV Screening SDK,
handling CV analysis with a simplified interface.
"""

import logging
import os
import base64
from typing import Any, Dict, List, Optional, Union, Tuple, Iterator
import time
import json
import uuid
import logging
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import socket

from .auth.azure import AzureCredential
from .core.config import Config
from .core.exceptions import ConfigurationError, OpenAIError, ValidationError, DocumentParsingError, RateLimitError
from .core.types import ContentType
from .models.criteria import JobCriteria
from .providers.azure_provider import AzureOpenAIProvider
from .providers.base_provider import BaseLLMProvider
from .utils.document import load_cv_content, load_cv_from_base64

logger = logging.getLogger(__name__)


class CVScreeningClient:
    """
    Client for CV screening using Azure OpenAI.
   
    This is the main client class for interacting with the CV Screening SDK.
    """
   
    def __init__(
        self,
        endpoint: str = None,
        credential = None,
        deployment_name: str = "gpt-4",
        api_version: str = "2023-05-15",
        temperature: float = 0,
        max_tokens: Optional[int] = None,
        connection_verify: bool = True,
        base_model: Optional[str] = None,
        custom_provider: Optional[BaseLLMProvider] = None,
        rate_limiter = None,
        max_rpm: int = 100,
        max_tpm: int = 60000,
    ) -> None:
        """
        Initialize the CV screening client.

        Args:
            endpoint: The Azure OpenAI endpoint URL (default: from AZURE_OPENAI_ENDPOINT env).
            api_key: The API key for Azure OpenAI (default: from AZURE_OPENAI_API_KEY env).
            deployment_name: The deployment name to use (default: "gpt-4").
            api_version: The API version to use (default: "2023-05-15").
            temperature: The temperature to use for generations (default: 0.1).
            max_tokens: The maximum number of tokens to generate (optional).
            system_prompt: A custom system prompt to use (optional).
            connection_verify: Whether to verify SSL connections (default: True).
            base_model: The base model name of the deployment (e.g., "gpt-4", "gpt-35-turbo").
                       Used to determine capabilities instead of inferring from deployment name.
            custom_provider: Custom LLM provider to use instead of AzureOpenAI (optional).
            rate_limiter: Optional custom rate limiter instance to use for rate limiting.
            max_rpm: Maximum requests per minute when using the default rate limiter (default: 100).
            max_tpm: Maximum tokens per minute when using the default rate limiter (default: 60000).
        """
        self.logger = logging.getLogger(__name__)

        # Configurar el limitador de tasa
        #self.rate_limiter = rate_limiter or RateLimiter(max_rpm=max_rpm, max_tpm=max_tpm)
        #self.logger.info(f"Rate limiter configured: {max_rpm} RPM, {max_tpm} TPM")

        if custom_provider:
            self.provider = custom_provider
        else:
            # Use provided values or look for environment variables
            endpoint = endpoint or os.environ.get("AZURE_OPENAI_ENDPOINT")
            #api_key = api_key or os.environ.get("AZURE_OPENAI_API_KEY")

            if not endpoint or not credential:
                raise ValueError(
                    "AzureOpenAI endpoint and Credentials must be provided either through "
                    "parameters or environment variables."
                )

            self.provider = AzureOpenAIProvider(
                endpoint=endpoint,
                credential=credential,
                deployment_name=deployment_name,
                api_version=api_version,
                temperature=temperature,
                max_tokens=max_tokens,
                connection_verify=connection_verify,
                base_model=base_model,
            )
           
            self.logger.info("CV Screening SDK client initialized with Azure OpenAI")
   
    def analyze_cv_simple(
        self,
        content: Dict,
        content_type: ContentType = ContentType.BASE64
    ) -> Dict[str, Any]:
        """
        Analyze a CV against given criteria.
       
        This is the main method for CV screening. It analyzes a single CV
        against the provided criteria and returns the raw analysis results.
       
        This method is decorated with @backoff_on_exception to automatically retry on OpenAIError
        and RateLimitError exceptions with exponential backoff.
       
        Args:
            content: CV content as text, base64 or file path
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            content_type: Type of content provided (default: ContentType.TEXT)
            schema_json_ob: Optional JSON schema to use for response formatting. If not provided,
                   the default schema will be used.
            use_rate_limiting: Whether to apply rate limiting (default: True)
            max_retries: Maximum number of retries for rate limit errors (default: 3)
       
        Returns:
            Raw analysis results from Azure OpenAI
       
        Raises:
            OpenAIError: If the analysis fails after retries
            RateLimitError: If rate limits are exceeded after retries
        """
        self.logger.info(f"Starting CV analysis with content type: {content_type.name}")
       
        # Process content based on its type
        if content_type == ContentType.BASE64:
            try:
                content["content_md"] = self.load_cv_content(content["content_cv"], credential=self.credential, content_type=ContentType.BASE64)
                self.logger.info("Successfully decoded base64 content")
            except Exception as e:
                self.logger.error(f"Failed to decode base64 content: {str(e)}")
                raise OpenAIError(f"Failed to decode base64 content: {str(e)}") from e
        elif content_type == ContentType.FILE_PATH:
            if not isinstance(content, dict) or "content_cv" not in content:
                raise OpenAIError("Content must be a dictionary with 'content_cv' key containing the file path")
            if not isinstance(content["content_cv"], str):
                raise OpenAIError("File path must be a string")
            try:
                content["content_md"] = self.load_cv_content(content["content_cv"], credential=self.credential)
                self.logger.info(f"Successfully loaded content from file: {content['content_cv']}")
            except Exception as e:
                self.logger.error(f"Failed to load content from file: {str(e)}")
                raise OpenAIError(f"Failed to load content from file: {str(e)}") from e
        try:
            result = self.provider.analyze_cv(content)
            self.logger.info("CV analysis completed")
            return result
        except Exception as e:
            self.logger.error(f"Failed to analyze CV: {str(e)}")
            raise OpenAIError(f"Failed to analyze CV: {str(e)}") from e

    # Expose utility method directly
    @staticmethod
    def load_cv_content(file_path_or_content: Union[str, bytes], credential: AzureCredential, content_type: ContentType = ContentType.FILE_PATH) -> str:
        """
        Load CV content from a file or decode from base64.
       
        This is a convenience method that handles different types of content.
       
        Args:
            file_path_or_content: Path to the CV file or content (plain text or base64)
            content_type: Type of content provided (default: ContentType.FILE_PATH)
            credential: AzureCredential instance for authentication (if needed)
       
        Returns:
            String content of the CV
       
        Raises:
            DocumentParsingError: If the file cannot be parsed or base64 cannot be decoded
            FileNotFoundError: If the file does not exist
        """
        # Process based on content type
        if content_type == ContentType.FILE_PATH:
            # Load from file
            if not isinstance(file_path_or_content, str):
                raise DocumentParsingError("File path must be a string")
           
            return load_cv_content(file_path_or_content)
           
        elif content_type == ContentType.BASE64:
            # Decode base64
            try:
                return load_cv_from_base64(file_path_or_content, credential=credential)
            except Exception as e:
                raise DocumentParsingError(f"Failed to decode base64 content: {str(e)}")
       
        else:  # ContentType.TEXT
            # Return as is (assuming it's already text content)
            if isinstance(file_path_or_content, bytes):
                try:
                    return file_path_or_content.decode('utf-8')
                except Exception as e:
                    raise DocumentParsingError(f"Failed to decode content as UTF-8: {str(e)}")
           
            return file_path_or_content

   
    def analyze_cvs(
            self,
            rows: Iterator[Dict],
            batch_size: Optional[int] = None,
            max_workers: Optional[int] = 1,
            partition_id: int = -1) -> Iterator[str]:
        rows = list(rows)
        results: List[str] = []

        def analyze_multiple_cvs(
            self,
            contents: List[Dict],
            content_type: ContentType = ContentType.BASE64,
            batch_size: Optional[int] = None
        ) -> List[Dict[str, Any]]:
                """
                Analyze multiple CVs against given criteria.
               
                This method analyzes multiple CVs at once against the provided criteria
                and returns a list of analysis results.
               
                Args:
                    contents: List of CV contents as text, base64 or file paths
                    criteria: Job criteria as dictionary, JobCriteria object, or prompt string
                    content_type: Type of content provided (default: ContentType.TEXT)
                    batch_size: Batch size for processing CVs. If not provided,
                            all CVs will be processed in a single batch.
                    schema_json_ob: Optional JSON schema to use for response formatting. If not provided,
                        the default schema will be used.
               
                Returns:
                    List of raw analysis results from Azure OpenAI
               
                Raises:
                    OpenAIError: If the analysis fails
                """
                self.logger.info(f"Starting multiple CV analysis with content type: {content_type.name}")
               
                # Process each CV content based on its type
                processed_contents = []
                for cv_content in contents:
                    if content_type == ContentType.BASE64:
                        try:
                            cv_content["content_md"] = self.load_cv_content(cv_content["content_cv"], credential=self.credential, content_type=ContentType.BASE64)
                            processed_contents.append(cv_content)
                        except Exception as e:
                            self.logger.error(f"Failed to decode base64 content: {str(e)}")
                            raise OpenAIError(f"Failed to decode base64 content: {str(e)}") from e
                    elif content_type == ContentType.FILE_PATH:
                        if not isinstance(cv_content, dict) or "content_cv" not in cv_content:
                            raise OpenAIError("Content must be a dictionary with 'content_cv' key containing the file path")
                        if not isinstance(cv_content["content_cv"], str):
                            raise OpenAIError("File path must be a string")
                        try:
                            cv_content["content_md"] = self.load_cv_content(cv_content["content_cv"],  credential=self.credential)
                            processed_contents.append(cv_content)
                        except Exception as e:
                            self.logger.error(f"Failed to load content from file: {str(e)}")
                            raise OpenAIError(f"Failed to load content from file: {str(e)}") from e
                    else:
                        # Assume it's already text content
                        processed_contents.append(cv_content)
               
                try:
                    # Analyze with Azure OpenAI
                    results = self.provider.analyze_multiple_cvs(
                        contents=processed_contents,
                        batch_size=batch_size
                    )
                   
                    self.logger.info(f"Multiple CV analysis completed for {len(contents)} CVs")
                    return results
                except Exception as e:
                    self.logger.error(f"Failed to analyze multiple CVs: {str(e)}")
                    raise OpenAIError(f"Failed to analyze multiple CVs: {str(e)}") from e
       
        def batch_list(lst, batch_size):
            return [lst[i : i + batch_size] for i in range(0, len(lst), batch_size)]

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            row_batches = batch_list(rows, batch_size)
            futures = [executor.submit(analyze_multiple_cvs, self=self, contents=batch, batch_size=batch_size) for batch in row_batches]
            for future in as_completed(futures):
                results.append(future.result())

        return iter(results)