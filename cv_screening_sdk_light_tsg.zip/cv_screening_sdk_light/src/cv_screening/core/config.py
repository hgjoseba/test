"""Configuration for CV Screening SDK."""

import os
from typing import Optional
from pydantic import BaseModel, Field


class AzureConfig(BaseModel):
    """Azure OpenAI configuration."""
   
    endpoint: str = Field(
        default="",
        description="Azure OpenAI endpoint URL"
    )
   
    api_version: str = Field(
        default="2023-05-15",
        description="Azure OpenAI API version"
    )


class OpenAIConfig(BaseModel):
    """API configuration for LLM services."""
   
    api_key: str = Field(
        default="",
        description="API key for Azure OpenAI"
    )
   
    model_name: str = Field(
        default="gpt-4",
        description="Model or deployment name to use"
    )
   
    temperature: float = Field(
        default=0.1,
        description="Sampling temperature (0-1)",
        ge=0.0,
        le=1.0
    )
   
    max_tokens: Optional[int] = Field(
        default=None,
        description="Maximum tokens to generate"
    )
   
    connection_verify: bool = Field(
        default=True,
        description="Whether to verify SSL connections"
    )
   
    system_prompt: Optional[str] = Field(
        default=None,
        description="Custom system prompt to use for CV screening"
    )
   
    http_proxy: Optional[str] = Field(
        default=None,
        description="HTTP proxy URL (e.g., 'http://user:pass@proxy:port')"
    )
   
    https_proxy: Optional[str] = Field(
        default=None,
        description="HTTPS proxy URL (e.g., 'https://user:pass@proxy:port')"
    )


class Config(BaseModel):
    """Main configuration for CV Screening SDK."""
   
    openai: OpenAIConfig = Field(
        default_factory=lambda: OpenAIConfig(
            api_key=os.environ.get("AZURE_OPENAI_API_KEY", ""),
            model_name=os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4"),
            temperature=float(os.environ.get("OPENAI_TEMPERATURE", "0.1")),
            max_tokens=int(os.environ.get("OPENAI_MAX_TOKENS", "0")) or None,
            connection_verify=os.environ.get("OPENAI_CONNECTION_VERIFY", "True").lower() != "false",
            system_prompt=os.environ.get("OPENAI_SYSTEM_PROMPT", None),
            http_proxy=os.environ.get("OPENAI_HTTP_PROXY", None),
            https_proxy=os.environ.get("OPENAI_HTTPS_PROXY", None),
        ),
        description="API configuration"
    )
   
    azure: AzureConfig = Field(
        default_factory=lambda: AzureConfig(
            endpoint=os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        ),
        description="Azure OpenAI configuration"
    )
