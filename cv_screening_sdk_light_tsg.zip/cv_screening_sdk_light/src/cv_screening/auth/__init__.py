"""
Authentication modules for CV Screening SDK Light.

This package provides authentication capabilities for different services.
"""

from .azure import AzureCredential

__all__ = ["AzureCredential"] 