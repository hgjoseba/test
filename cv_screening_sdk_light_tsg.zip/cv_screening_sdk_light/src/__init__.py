"""
CV Screening SDK - Paquete principal

Este paquete proporciona funcionalidades para analizar currículums vitae utilizando
modelos de lenguaje de OpenAI a través de Azure OpenAI Service.
"""

from .cv_screening.client import CVScreeningClient
from .cv_screening.models import JobCriteria
from .cv_screening.core.types import ContentType
from .cv_screening.core.exceptions import (
    SDKError,
    AuthenticationError,
    ValidationError,
    OpenAIError,
    DocumentParsingError,
    RateLimitError
)

__all__ = [
    'CVScreeningClient',
    'JobCriteria',
    'ContentType',
    'SDKError',
    'AuthenticationError',
    'ValidationError',
    'OpenAIError',
    'DocumentParsingError',
    'RateLimitError'
] 