#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script de prueba para verificar la importación del paquete cv_screening_sdk
"""

import os
import sys

# Forzar que se busquen los paquetes solo desde la raíz del proyecto
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

try:
    print("Intentando importar desde src")
    import cv_screening as cv_screening
    print("Éxito importando desde src")
    print("Módulos disponibles:", cv_screening.__all__)
except Exception as e:
    print(f"Error al importar desde src: {str(e)}")

try:
    print("\nIntentando importar directamente desde cv_screening")
    from src.cv_screening import CVScreeningClient
    print("Éxito importando CVScreeningClient")
except Exception as e:
    print(f"Error al importar CVScreeningClient: {str(e)}")

try:
    print("\nIntentando importar todas las clases principales")
    from cv_screening.client import CVScreeningClient
    from cv_screening.core.types import ContentType
    from cv_screening.core.exceptions import SDKError, OpenAIError, RateLimitError
    print("Éxito importando todas las clases principales")
except Exception as e:
    print(f"Error al importar todas las clases: {str(e)}") 