#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para mover el paquete cv_screening desde src/cv_screening a la raíz del proyecto.
"""

import os
import shutil
import sys
from pathlib import Path


def create_directory_if_not_exists(directory):
    """Crear un directorio si no existe."""
    try:
        os.makedirs(directory, exist_ok=True)
        print(f"Directorio creado o verificado: {directory}")
        return True
    except Exception as e:
        print(f"Error al crear el directorio {directory}: {str(e)}")
        return False


def copy_files(source_dir, target_dir):
    """Copiar archivos y directorios de origen a destino."""
    try:
        # Verificar que el directorio de origen existe
        if not os.path.exists(source_dir):
            print(f"El directorio de origen {source_dir} no existe.")
            return False
        
        # Copiar todos los archivos y subdirectorios
        for item in os.listdir(source_dir):
            source_item = os.path.join(source_dir, item)
            target_item = os.path.join(target_dir, item)
            
            if os.path.isdir(source_item):
                # Si es un directorio, copiar recursivamente
                shutil.copytree(source_item, target_item, dirs_exist_ok=True)
                print(f"Directorio copiado: {source_item} -> {target_item}")
            else:
                # Si es un archivo, copiarlo
                shutil.copy2(source_item, target_item)
                print(f"Archivo copiado: {source_item} -> {target_item}")
        
        return True
    except Exception as e:
        print(f"Error al copiar archivos: {str(e)}")
        return False


def remove_directory(directory):
    """Eliminar un directorio y todo su contenido."""
    try:
        if os.path.exists(directory):
            shutil.rmtree(directory)
            print(f"Directorio eliminado: {directory}")
            return True
        else:
            print(f"El directorio {directory} no existe.")
            return False
    except Exception as e:
        print(f"Error al eliminar el directorio {directory}: {str(e)}")
        return False


def main():
    """Función principal que mueve el paquete."""
    print("Moviendo el paquete cv_screening desde src/ a la raíz del proyecto...")
    
    # Directorios de origen y destino
    source_dir = "src/cv_screening"
    target_dir = "cv_screening"
    
    # Verificar que el directorio de origen existe
    if not os.path.exists(source_dir):
        print(f"Error: El directorio {source_dir} no existe.")
        return 1
    
    # Crear directorio de destino
    if not create_directory_if_not_exists(target_dir):
        print("Error: No se pudo crear el directorio de destino.")
        return 1
    
    # Copiar archivos
    if not copy_files(source_dir, target_dir):
        print("Error: No se pudieron copiar los archivos.")
        return 1
    
    # No eliminar automáticamente el directorio de origen
    # para permitir verificar que todo funciona correctamente primero
    print("\nEl paquete se ha movido correctamente.")
    print("Verifica que todo funciona correctamente antes de eliminar el directorio original.")
    print("\nUna vez verificado, puedes eliminar el directorio original con:")
    print(f"rm -rf {source_dir}")
    print("\nRecuerda reinstalar el paquete con: pip install -e .")
    
    return 0


if __name__ == "__main__":
    sys.exit(main()) 