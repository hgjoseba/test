#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para corregir las importaciones duplicadas en los archivos de test
eliminando 'cv_screening.cv_screening' por 'cv_screening'.
"""

import os
import re
import sys

def fix_imports_in_file(file_path):
    """Corregir las importaciones duplicadas en un archivo."""
    # Leer el contenido del archivo
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Corregir las importaciones duplicadas
    updated_content = re.sub(
        r'from src\.cv_screening\.cv_screening\.', 
        r'from cv_screening.', 
        content
    )
    
    # Si hay cambios, escribir el archivo
    if content != updated_content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(updated_content)
        print(f"Corregido: {file_path}")
    else:
        print(f"Sin cambios: {file_path}")

def fix_test_files():
    """Recorrer los archivos de test y corregir las importaciones."""
    tests_dir = "tests"
    if not os.path.exists(tests_dir):
        print(f"El directorio {tests_dir} no existe.")
        return
    
    # Recorrer los archivos de test
    for file_name in os.listdir(tests_dir):
        if file_name.endswith(".py") and file_name.startswith("test_"):
            file_path = os.path.join(tests_dir, file_name)
            fix_imports_in_file(file_path)

if __name__ == "__main__":
    fix_test_files()
    print("Proceso completado.") 