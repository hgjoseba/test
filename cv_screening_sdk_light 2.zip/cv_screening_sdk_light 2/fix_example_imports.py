#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para actualizar los imports en los ejemplos,
cambiando 'from src.cv_screening', 'from src.core', etc. por 'from cv_screening', 'from cv_screening.core', etc.
"""

import os
import re
import sys
from pathlib import Path


def fix_imports_in_file(file_path):
    """Actualizar los imports en un archivo."""
    try:
        # Leer el contenido del archivo
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Reemplazar 'from src.cv_screening' por 'from cv_screening'
        updated_content = re.sub(
            r'from src\.cv_screening', 
            r'from cv_screening', 
            content
        )
        
        # Reemplazar 'from src.core' por 'from cv_screening.core'
        updated_content = re.sub(
            r'from src\.core', 
            r'from cv_screening.core', 
            updated_content
        )
        
        # Reemplazar 'from src.auth' por 'from cv_screening.auth'
        updated_content = re.sub(
            r'from src\.auth', 
            r'from cv_screening.auth', 
            updated_content
        )
        
        # Reemplazar 'from src.models' por 'from cv_screening.models'
        updated_content = re.sub(
            r'from src\.models', 
            r'from cv_screening.models', 
            updated_content
        )
        
        # Reemplazar 'from src.utils' por 'from cv_screening.utils'
        updated_content = re.sub(
            r'from src\.utils', 
            r'from cv_screening.utils', 
            updated_content
        )
        
        # Reemplazar 'from src.providers' por 'from cv_screening.providers'
        updated_content = re.sub(
            r'from src\.providers', 
            r'from cv_screening.providers', 
            updated_content
        )
        
        # Reemplazar import directo 'import src.cv_screening' por 'import cv_screening'
        updated_content = re.sub(
            r'import src\.cv_screening', 
            r'import cv_screening', 
            updated_content
        )
        
        # Si hay cambios, escribir el archivo
        if content != updated_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(updated_content)
            print(f"Actualizado: {file_path}")
            return True
        else:
            print(f"Sin cambios: {file_path}")
            return False
    except Exception as e:
        print(f"Error al procesar {file_path}: {str(e)}")
        return False


def fix_examples():
    """Recorrer todos los ejemplos y actualizar los imports."""
    examples_dir = "examples"
    updated_files = 0
    
    # Verificar que el directorio existe
    if not os.path.exists(examples_dir):
        print(f"El directorio {examples_dir} no existe.")
        return 0
    
    # Recorrer los archivos de ejemplo
    for file_name in os.listdir(examples_dir):
        if file_name.endswith(".py"):
            file_path = os.path.join(examples_dir, file_name)
            if fix_imports_in_file(file_path):
                updated_files += 1
    
    return updated_files


def main():
    """Función principal."""
    print("Corrigiendo imports en los ejemplos...")
    
    updated_files = fix_examples()
    
    print(f"Total de archivos actualizados: {updated_files}")
    print("\nProceso completado.")


if __name__ == "__main__":
    main() 