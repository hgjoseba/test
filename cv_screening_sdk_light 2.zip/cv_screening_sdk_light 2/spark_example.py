#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Ejemplo de implementación del SDK de CV Screening en un cluster Spark

Este script muestra cómo procesar múltiples CVs en paralelo utilizando
Apache Spark y el CV Screening SDK.
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, pandas_udf
from pyspark.sql.types import StringType, MapType, BooleanType, FloatType, StructType, StructField
import pandas as pd
import json
import time
import os
import base64
from typing import Dict, List, Any, Iterator, Tuple

# Para pruebas locales, puedes descomentar estas líneas
# import sys
# sys.path.append("/path/to/cv_screening_sdk")

from src.cv_screening import CVScreeningClient, ContentType, JobCriteria

# Configuración de logging
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger("cv_screening_spark")

# Criterios del trabajo para el análisis
JOB_CRITERIA = {
    "required_skills": ["Python", "Spark", "Data Engineering"],
    "preferred_skills": ["AWS", "Azure", "Docker", "Kubernetes"],
    "min_years_experience": 3,
    "education": "Ingeniería, Ciencias de la Computación o similar"
}

# Esquema para los resultados de análisis
ANALYSIS_SCHEMA = StructType([
    StructField("match_score", FloatType(), True),
    StructField("required_skills_match", MapType(StringType(), BooleanType()), True),
    StructField("preferred_skills_match", MapType(StringType(), BooleanType()), True),
    StructField("experience_match", BooleanType(), True),
    StructField("education_match", BooleanType(), True),
    StructField("recommendations", StringType(), True)
])

def get_openai_credentials() -> Tuple[str, str]:
    """
    Obtiene las credenciales para Azure OpenAI
    En un entorno de producción, debería obtenerse de un servicio seguro
    como Azure Key Vault o AWS Secrets Manager.
    """
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        raise ValueError(
            "Debes configurar AZURE_OPENAI_ENDPOINT y AZURE_OPENAI_API_KEY"
        )
    
    return endpoint, api_key

def create_client() -> CVScreeningClient:
    """
    Crea y devuelve una instancia del cliente CV Screening
    """
    endpoint, api_key = get_openai_credentials()
    
    return CVScreeningClient(
        endpoint=endpoint,
        api_key=api_key,
        deployment_name="gpt-4",  # O el nombre de tu despliegue
        temperature=0.1,
        max_tokens=2000
    )

def process_cv_batch(partition: Iterator[Dict]) -> Iterator[Tuple[str, str, Dict[str, Any]]]:
    """
    Procesa un lote de CVs dentro de una partición Spark
    Usando una sola instancia del cliente por ejecutor
    
    Args:
        partition: Iterador sobre los registros de la partición
        
    Yields:
        Tuplas de (cv_id, nombre_archivo, resultado_analisis)
    """
    # Crear una sola instancia del cliente por partición
    client = create_client()
    logger.info("Cliente inicializado en el ejecutor")
    
    # Contador para control de tasas
    request_count = 0
    
    for record in partition:
        cv_id = record["cv_id"]
        filename = record["filename"]
        cv_content = record["content"]
        
        # Control básico de tasas
        if request_count > 0 and request_count % 20 == 0:
            logger.info(f"Esperando antes de continuar... (processed: {request_count})")
            time.sleep(1)  # Pausa para evitar limitación de tasa
        
        try:
            # Analizar CV
            logger.info(f"Procesando CV ID: {cv_id}, Archivo: {filename}")
            result = client.analyze_cv(
                content=cv_content,
                criteria=JOB_CRITERIA,
                content_type=ContentType.TEXT
            )
            request_count += 1
            
            # Devolver resultado con metadatos
            yield (cv_id, filename, result)
            
        except Exception as e:
            logger.error(f"Error al procesar CV {cv_id}: {str(e)}")
            # Devolver error en formato json
            yield (cv_id, filename, {"error": str(e)})

@pandas_udf(StringType())
def analyze_cv_pandas(cvs: pd.Series) -> pd.Series:
    """
    UDF de Pandas para analizar CVs
    Más eficiente para vectorización con Pandas
    
    Args:
        cvs: Serie de Pandas con el contenido de los CVs
        
    Returns:
        Serie de Pandas con los resultados de análisis en formato JSON
    """
    # Crear cliente una vez para toda la serie
    client = create_client()
    
    results = []
    for cv in cvs:
        try:
            result = client.analyze_cv(
                content=cv,
                criteria=JOB_CRITERIA,
                content_type=ContentType.TEXT
            )
            results.append(json.dumps(result))
        except Exception as e:
            results.append(json.dumps({"error": str(e)}))
            
    return pd.Series(results)

def main():
    """Función principal"""
    logger.info("Iniciando procesamiento de CVs con Spark")
    
    # Crear sesión Spark
    spark = (SparkSession.builder
        .appName("CV Screening Batch")
        .config("spark.executor.memory", "4g")
        .config("spark.driver.memory", "2g")
        .config("spark.default.parallelism", "10")
        .getOrCreate())
    
    # Opcional: Registrar el SDK en Spark
    # spark.sparkContext.addPyFile("/path/to/cv_screening_sdk-0.1.0-py3-none-any.whl")
    
    try:
        # Cargar datos de CVs
        # Puede ser desde cualquier fuente compatible con Spark
        logger.info("Cargando datos de CVs")
        
        # Este es un ejemplo usando un CSV, pero en producción
        # probablemente cargarías desde una base de datos o almacenamiento
        cvs_df = (spark.read
            .option("header", "true")
            .option("multiline", "true")  # Para manejar saltos de línea en CVs
            .csv("s3://your-bucket/cvs_metadata.csv"))
        
        # Suponiendo que el CSV tiene las columnas: cv_id, filename, content
        
        # Método 1: Usando RDD y mapPartitions
        logger.info("Procesando CVs con mapPartitions")
        
        # Convertir a RDD para procesamiento
        cvs_rdd = cvs_df.rdd.map(lambda row: row.asDict())
        
        # Aplicar procesamiento en paralelo
        results_rdd = cvs_rdd.mapPartitions(process_cv_batch)
        
        # Convertir de vuelta a DataFrame
        results_df = spark.createDataFrame(
            results_rdd,
            ["cv_id", "filename", "analysis_result"]
        )
        
        # Guardar resultados
        logger.info("Guardando resultados del análisis")
        (results_df
            .write
            .mode("overwrite")
            .parquet("s3://your-bucket/results/"))
        
        # Método 2: Usando Pandas UDF
        logger.info("Procesando CVs con Pandas UDF")
        
        # Aplicar UDF a todo el DataFrame
        pandas_results_df = cvs_df.withColumn(
            "analysis_result", 
            analyze_cv_pandas(col("content"))
        )
        
        # Guardar resultados
        (pandas_results_df
            .select("cv_id", "filename", "analysis_result")
            .write
            .mode("overwrite")
            .parquet("s3://your-bucket/pandas_results/"))
        
        logger.info("Procesamiento completado con éxito")
    
    except Exception as e:
        logger.error(f"Error en el procesamiento: {str(e)}")
        raise
    
    finally:
        # Detener sesión Spark
        spark.stop()
        logger.info("Sesión Spark detenida")

if __name__ == "__main__":
    main() 