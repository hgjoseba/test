#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Simple example showing how to use the rate limiting (TPM/RPM) 
integrated in the CV Screening SDK.
"""

import os
import logging
from typing import List, Dict

from src.cv_screening import CVScreeningClient, ContentType
from cv_screening.utils.rate_limiting import RateLimiter, DistributedRateLimiter

# Logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s'
)
logger = logging.getLogger("cv_screening_rate_limiting_example")

# CV Example
CV_EXAMPLE = """
JUAN PÉREZ
Senior Python Developer

EXPERIENCE
- 7 years as Python developer at ABC Company (2016-2023)
- 3 years as web developer at XYZ Tech (2013-2016)

SKILLS
- Python, Django, Flask, FastAPI
- JavaScript, React
- Docker, Kubernetes
- AWS, Azure

EDUCATION
- Computer Engineering, University of Barcelona (2010-2014)
"""

# Job criteria
JOB_CRITERIA = {
    "required_skills": ["Python", "Django", "API", "Docker"],
    "preferred_skills": ["AWS", "Kubernetes", "React"],
    "min_years_experience": 5,
    "education": "Computer Engineering or similar"
}

def client_with_default_rate_limiting():
    """
    Example of client usage with default rate limiting.
    
    The default client uses a RateLimiter configured with
    default values of 100 RPM and 60000 TPM.
    """
    logger.info("\n===== EXAMPLE 1: Client with default limits =====")
    
    # Configure credentials (from environment variables)
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        logger.error("You must configure AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY")
        return
    
    # Create client with default parameters for rate limiting
    client = CVScreeningClient(
        endpoint=endpoint,
        api_key=api_key,
        deployment_name="gpt-4",
        temperature=0.1
    )
    
    logger.info("Client initialized with default limits (100 RPM, 60000 TPM)")
    
    # Analyze CV with rate limiting (default behavior)
    try:
        result = client.analyze_cv(
            content=CV_EXAMPLE,
            criteria=JOB_CRITERIA,
            content_type=ContentType.TEXT,
            use_rate_limiting=True  # This is the default value
        )
        
        logger.info("Analysis completed successfully")
        logger.info(f"Result: {result}")
    except Exception as e:
        logger.error(f"Error in analysis: {str(e)}")

def client_with_custom_rate_limiting():
    """
    Example of client usage with custom rate limits.
    
    In this example, we configure more restrictive limits
    to demonstrate rate limiting.
    """
    logger.info("\n===== EXAMPLE 2: Client with custom limits =====")
    
    # Configure credentials (from environment variables)
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        logger.error("You must configure AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY")
        return
    
    # Create a custom rate limiter
    # We use low values to demonstrate the behavior
    rate_limiter = RateLimiter(
        max_rpm=10,        # Maximum 10 requests per minute
        max_tpm=10000,     # Maximum 10,000 tokens per minute
        max_concurrent=2,  # Maximum 2 concurrent requests
        base_delay=0.2     # Base delay for retries
    )
    
    # Create client with custom limiter
    client = CVScreeningClient(
        endpoint=endpoint,
        api_key=api_key,
        deployment_name="gpt-4",
        temperature=0.1,
        rate_limiter=rate_limiter  # Pass the custom limiter
    )
    
    logger.info("Client initialized with custom limits (10 RPM, 10000 TPM)")
    
    # Analyze multiple CVs sequentially to demonstrate rate limiting
    cvs = [CV_EXAMPLE] * 5  # Use the same CV 5 times for the example
    
    try:
        results = client.analyze_multiple_cvs(
            contents=cvs,
            criteria=JOB_CRITERIA,
            content_type=ContentType.TEXT,
            use_rate_limiting=True,
            max_retries=2
        )
        
        logger.info(f"Processed {len(results)} CVs with rate limiting")
    except Exception as e:
        logger.error(f"Error in multiple analysis: {str(e)}")

def client_without_rate_limiting():
    """
    Example of client usage without rate limiting.
    
    In this case, rate limiting is disabled for requests,
    which can be useful in test environments or for critical requests.
    """
    logger.info("\n===== EXAMPLE 3: Client without rate limiting =====")
    
    # Configure credentials (from environment variables)
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        logger.error("You must configure AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY")
        return
    
    # Create normal client
    client = CVScreeningClient(
        endpoint=endpoint,
        api_key=api_key,
        deployment_name="gpt-4",
        temperature=0.1
    )
    
    logger.info("Client initialized")
    
    # Analyze CV without rate limiting
    try:
        result = client.analyze_cv(
            content=CV_EXAMPLE,
            criteria=JOB_CRITERIA,
            content_type=ContentType.TEXT,
            use_rate_limiting=False  # Disable rate limiting
        )
        
        logger.info("Analysis without rate limiting completed")
        logger.info(f"Result: {result}")
    except Exception as e:
        logger.error(f"Error in analysis: {str(e)}")

def client_with_distributed_rate_limiting():
    """
    Example of how to configure a client for use in distributed systems.
    
    This is an example of how the client could be configured in a
    distributed system like Spark, where each node needs to share
    global limits.
    """
    logger.info("\n===== EXAMPLE 4: Client with distributed limits =====")
    
    # Configure credentials (from environment variables)
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not endpoint or not api_key:
        logger.error("You must configure AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY")
        return
    
    # Create a distributed rate limiter
    # In a real environment, these values would be obtained from configuration
    global_rpm = 600        # Global RPM limit for the entire system
    global_tpm = 240000     # Global TPM limit for the entire system
    total_nodes = 4         # Total number of nodes/executors
    
    # Create a distributed limiter that will divide the limits
    # among the number of nodes
    distributed_limiter = DistributedRateLimiter(
        max_rpm=global_rpm,
        max_tpm=global_tpm,
        max_concurrent=3,
        base_delay=0.1,
        node_count=total_nodes,
        node_id="node-1"    # Unique ID for this node
    )
    
    # Create client with distributed limiter
    client = CVScreeningClient(
        endpoint=endpoint,
        api_key=api_key,
        deployment_name="gpt-4",
        temperature=0.1,
        rate_limiter=distributed_limiter
    )
    
    logger.info(f"Client initialized with distributed limits for 4 nodes")
    logger.info(f"Limits per node: {global_rpm//total_nodes} RPM, {global_tpm//total_nodes} TPM")
    
    # Analyze CV with distributed limiter
    try:
        result = client.analyze_cv(
            content=CV_EXAMPLE,
            criteria=JOB_CRITERIA,
            content_type=ContentType.TEXT
        )
        
        logger.info("Analysis completed with distributed rate limiting")
    except Exception as e:
        logger.error(f"Error in analysis: {str(e)}")
    
    # Example of cluster size update
    logger.info("\nSimulating cluster size change...")
    
    # Let's assume the number of nodes changes to 6
    new_node_count = 6
    distributed_limiter.update_cluster_size(new_node_count)
    
    logger.info(f"Limits updated for {new_node_count} nodes")
    logger.info(f"New limits per node: {global_rpm//new_node_count} RPM, {global_tpm//new_node_count} TPM")

def main():
    """Main function that runs all examples"""
    logger.info("RATE LIMITING EXAMPLES IN CV SCREENING SDK")
    
    # Run examples
    client_with_default_rate_limiting()
    client_with_custom_rate_limiting()
    client_without_rate_limiting()
    client_with_distributed_rate_limiting()
    
    logger.info("\nExamples completed.")

if __name__ == "__main__":
    main() 