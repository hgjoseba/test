"""
Tests for Azure authentication module.
"""
import os
import unittest
from unittest.mock import patch, MagicMock, PropertyMock
import pytest

from cv_screening.auth.azure import AzureCredential
from azure.core.credentials import AccessToken
from datetime import datetime, timedelta
from azure.identity import (
    DefaultAzureCredential,
    ClientSecretCredential,
    AzureCliCredential,
    ManagedIdentityCredential,
)


class TestAzureCredential(unittest.TestCase):
    """Tests for AzureCredential class."""

    def setUp(self):
        """Set up test fixtures."""
        # Mock access token
        self.mock_token = "mock_token_value"
        self.expiry = datetime.utcnow() + timedelta(hours=1)
        self.mock_token_obj = AccessToken(token=self.mock_token, expires_on=int(self.expiry.timestamp()))
        
        # Mock credential
        self.mock_credential = MagicMock()
        self.mock_credential.get_token.return_value = self.mock_token_obj
        
    def test_init_with_api_key(self):
        """Test initialization with API key."""
        api_key = "test_api_key"
        cred = AzureCredential(api_key=api_key)
        
        self.assertEqual(cred.api_key, api_key)
        self.assertIsNone(cred._credential)
        
    def test_init_with_service_principal(self):
        """Test initialization with service principal."""
        with patch("cv_screening.auth.azure.ClientSecretCredential") as mock_client_secret:
            mock_client_secret.return_value = self.mock_credential
            
            cred = AzureCredential(
                tenant_id="test-tenant",
                client_id="test-client",
                client_secret="test-secret"
            )
            
            mock_client_secret.assert_called_once_with(
                tenant_id="test-tenant",
                client_id="test-client",
                client_secret="test-secret",
                verify_certificate=True
            )
            
            self.assertEqual(cred._credential, self.mock_credential)
            
    def test_init_with_azure_cli(self):
        """Test initialization with Azure CLI."""
        with patch("cv_screening.auth.azure.AzureCliCredential") as mock_cli:
            mock_cli.return_value = self.mock_credential
            
            cred = AzureCredential(use_azure_cli=True)
            
            mock_cli.assert_called_once()
            self.assertEqual(cred._credential, self.mock_credential)
            
    def test_init_with_managed_identity(self):
        """Test initialization with managed identity."""
        with patch("cv_screening.auth.azure.ManagedIdentityCredential") as mock_mi:
            mock_mi.return_value = self.mock_credential
            
            cred = AzureCredential(use_managed_identity=True)
            
            mock_mi.assert_called_once()
            self.assertEqual(cred._credential, self.mock_credential)
            
    def test_init_with_default(self):
        """Test initialization with default credential."""
        with patch("cv_screening.auth.azure.DefaultAzureCredential") as mock_default:
            mock_default.return_value = self.mock_credential
            
            cred = AzureCredential()
            
            mock_default.assert_called_once_with(verify_certificate=True)
            self.assertEqual(cred._credential, self.mock_credential)
            
    def test_init_with_provided_credential(self):
        """Test initialization with provided credential."""
        cred = AzureCredential(credential=self.mock_credential)
        
        self.assertEqual(cred._credential, self.mock_credential)
            
    def test_get_token(self):
        """Test get_token method."""
        # Configuramos el mock para devolver un objeto AccessToken en lugar de una tupla
        self.mock_credential.get_token.return_value = self.mock_token_obj
        
        cred = AzureCredential(credential=self.mock_credential)
        
        token, expires = cred.get_token()
        
        self.mock_credential.get_token.assert_called_once_with(cred.scope)
        self.assertEqual(token, self.mock_token)
        self.assertEqual(expires, datetime.utcfromtimestamp(int(self.expiry.timestamp())))
        
    def test_get_token_no_credential(self):
        """Test get_token method with no credential."""
        cred = AzureCredential(api_key="test_key")
        cred._credential = None
        
        with self.assertRaises(ValueError):
            cred.get_token()
            
    def test_get_azure_credential_with_api_key(self):
        """Test get_azure_credential with API key."""
        api_key = "test_api_key"
        cred = AzureCredential(api_key=api_key)
        
        azure_cred = cred.get_azure_credential()
        
        from azure.core.credentials import AzureKeyCredential
        self.assertIsInstance(azure_cred, AzureKeyCredential)
        self.assertEqual(azure_cred.key, api_key)
        
    def test_get_azure_credential_with_token(self):
        """Test get_azure_credential with token credential."""
        cred = AzureCredential(credential=self.mock_credential)
        
        azure_cred = cred.get_azure_credential()
        
        self.assertEqual(azure_cred, self.mock_credential)
        
    def test_get_azure_credential_no_auth(self):
        """Test get_azure_credential with no authentication."""
        cred = AzureCredential()
        cred.api_key = None
        cred._credential = None
        
        with self.assertRaises(ValueError):
            cred.get_azure_credential()
            
    def test_class_method_default_credential(self):
        """Test class method default_credential."""
        with patch("cv_screening.auth.azure.DefaultAzureCredential") as mock_default:
            mock_default.return_value = self.mock_credential
            
            cred = AzureCredential.default_credential()
            
            mock_default.assert_called_once_with(verify_certificate=True)
            self.assertEqual(cred._credential, self.mock_credential)
            
    def test_class_method_from_service_principal(self):
        """Test class method from_service_principal."""
        with patch("cv_screening.auth.azure.ClientSecretCredential") as mock_client_secret:
            mock_client_secret.return_value = self.mock_credential
            
            cred = AzureCredential.from_service_principal(
                tenant_id="test-tenant",
                client_id="test-client",
                client_secret="test-secret"
            )
            
            mock_client_secret.assert_called_once_with(
                tenant_id="test-tenant",
                client_id="test-client",
                client_secret="test-secret",
                verify_certificate=True
            )
            
            self.assertEqual(cred._credential, self.mock_credential)
            
    def test_env_variables(self):
        """Test environment variables are used."""
        with patch.dict('os.environ', {
            'AZURE_OPENAI_KEY': 'env_api_key',
            'AZURE_TENANT_ID': 'env_tenant',
            'AZURE_CLIENT_ID': 'env_client',
            'AZURE_CLIENT_SECRET': 'env_secret'
        }):
            cred = AzureCredential()
            
            self.assertEqual(cred.api_key, 'env_api_key')
            self.assertEqual(cred.tenant_id, 'env_tenant')
            self.assertEqual(cred.client_id, 'env_client')
            self.assertEqual(cred.client_secret, 'env_secret')


if __name__ == '__main__':
    unittest.main() 