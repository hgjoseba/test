"""
Tests for the CVScreeningClient class.
"""
import os
import base64
import unittest
from unittest.mock import patch, MagicMock, mock_open, call
import pytest
from datetime import datetime

from cv_screening.client import CVScreeningClient
from cv_screening.core.exceptions import ConfigurationError, OpenAIError, ValidationError, DocumentParsingError
from cv_screening.core.types import ContentType
from cv_screening.auth.azure import AzureCredential
from cv_screening.providers.azure_provider import AzureOpenAIProvider


class TestCVScreeningClient(unittest.TestCase):
    """Tests for the CVScreeningClient class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_endpoint = "https://test-endpoint.openai.azure.com"
        self.mock_credential = MagicMock(spec=AzureCredential)
        # Configura el mock credential para que devuelva una tupla válida
        self.mock_credential.get_token.return_value = ("mock_token", datetime.now())
        
        self.mock_provider = MagicMock(spec=AzureOpenAIProvider)
        
        # Patch environment variables
        self.env_patcher = patch.dict('os.environ', {
            'AZURE_OPENAI_ENDPOINT': self.mock_endpoint,
        })
        self.env_patcher.start()
    
    def tearDown(self):
        """Tear down test fixtures."""
        self.env_patcher.stop()
    
    @patch("cv_screening.client.AzureOpenAIProvider")
    def test_init_with_params(self, mock_provider_class):
        """Test initialization with parameters."""
        # Configure the mock provider class
        mock_provider_instance = MagicMock()
        mock_provider_class.return_value = mock_provider_instance
        
        client = CVScreeningClient(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4",
            api_version="2023-05-15",
            temperature=0.1,
            max_tokens=1000,
            connection_verify=True,
            base_model="gpt-4",
            custom_provider=None,
            max_rpm=100,
            max_tpm=60000,
        )
        
        self.assertIsNotNone(client)
        self.assertIsNotNone(client.provider)
        # Verify that AzureOpenAIProvider was created with the correct params
        mock_provider_class.assert_called_once_with(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4",
            api_version="2023-05-15",
            temperature=0.1,
            max_tokens=1000,
            connection_verify=True,
            base_model="gpt-4"
        )
    
    def test_init_with_custom_provider(self):
        """Test initialization with custom provider."""
        client = CVScreeningClient(
            custom_provider=self.mock_provider
        )
        
        self.assertIsNotNone(client)
        self.assertEqual(client.provider, self.mock_provider)
    
    def test_init_missing_params(self):
        """Test initialization with missing parameters."""
        with patch.dict('os.environ', {}, clear=True):
            with self.assertRaises(ValueError):
                CVScreeningClient()
    
    @patch("cv_screening.client.load_cv_from_base64")
    def test_analyze_cv_simple_base64(self, mock_load_b64):
        """Test analyze_cv_simple with base64 input."""
        # Setup
        mock_load_b64.return_value = "Parsed CV content"
        mock_result = {"analysis": "test results"}
        
        # Create client with mocked provider
        client = CVScreeningClient(custom_provider=self.mock_provider)
        # Agregar el atributo credential al cliente para evitar el error
        client.credential = self.mock_credential
        client.provider.analyze_cv.return_value = mock_result
        
        # Test
        content = {"content_cv": "base64_content", "document_id": "doc123"}
        result = client.analyze_cv_simple(content, content_type=ContentType.BASE64)
        
        # Assert
        self.assertEqual(result, mock_result)
        client.provider.analyze_cv.assert_called_once()
    
    @patch("cv_screening.client.load_cv_content")
    def test_analyze_cv_simple_file_path(self, mock_load_file):
        """Test analyze_cv_simple with file path input."""
        # Setup
        mock_load_file.return_value = "Parsed CV content"
        mock_result = {"analysis": "test results"}
        
        # Create client with mocked provider
        client = CVScreeningClient(custom_provider=self.mock_provider)
        # Agregar el atributo credential al cliente
        client.credential = self.mock_credential
        client.provider.analyze_cv.return_value = mock_result
        
        # Test - Asegurarse de que sea un diccionario con las claves necesarias
        content = {"content_cv": "/path/to/cv.pdf", "document_id": "doc456"}
        result = client.analyze_cv_simple(content, content_type=ContentType.FILE_PATH)
        
        # Assert
        self.assertEqual(result, mock_result)
        client.provider.analyze_cv.assert_called_once()
        # Verificar que se pasó el contenido correcto
        called_content = client.provider.analyze_cv.call_args[0][0]
        self.assertEqual(called_content["content_md"], "Parsed CV content")
        self.assertEqual(called_content["document_id"], "doc456")
    
    def test_analyze_cv_simple_error(self):
        """Test analyze_cv_simple with provider error."""
        # Setup
        client = CVScreeningClient(custom_provider=self.mock_provider)
        client.provider.analyze_cv.side_effect = Exception("Test error")
        
        # Test
        content = {"content_cv": "content", "content_md": "parsed content", "document_id": "doc789"}
        
        # Assert
        with self.assertRaises(OpenAIError):
            client.analyze_cv_simple(content, content_type=ContentType.TEXT)
    
    @patch("cv_screening.client.load_cv_content")
    def test_load_cv_content_file_path(self, mock_load_file):
        """Test load_cv_content with file path."""
        # Setup
        mock_load_file.return_value = "CV content from file"
        
        # Test
        result = CVScreeningClient.load_cv_content(
            "/path/to/file.pdf",
            credential=self.mock_credential,
            content_type=ContentType.FILE_PATH
        )
        
        # Assert
        self.assertEqual(result, "CV content from file")
        mock_load_file.assert_called_with("/path/to/file.pdf")
    
    @patch("cv_screening.client.load_cv_from_base64")
    def test_load_cv_content_base64(self, mock_load_b64):
        """Test load_cv_content with base64."""
        # Setup
        mock_load_b64.return_value = "CV content from base64"
        
        # Test
        result = CVScreeningClient.load_cv_content(
            "base64string",
            credential=self.mock_credential,
            content_type=ContentType.BASE64
        )
        
        # Assert
        self.assertEqual(result, "CV content from base64")
        mock_load_b64.assert_called_with("base64string", credential=self.mock_credential)
    
    def test_load_cv_content_invalid_file_path(self):
        """Test load_cv_content with invalid file path type."""
        with self.assertRaises(DocumentParsingError):
            CVScreeningClient.load_cv_content(
                123,  # Not a string
                credential=self.mock_credential,
                content_type=ContentType.FILE_PATH
            )
    
    @patch("cv_screening.client.load_cv_from_base64")
    def test_load_cv_content_base64_error(self, mock_load_b64):
        """Test load_cv_content with base64 decoding error."""
        # Setup
        mock_load_b64.side_effect = Exception("Decoding error")
        
        # Test & Assert
        with self.assertRaises(DocumentParsingError):
            CVScreeningClient.load_cv_content(
                "base64string",
                credential=self.mock_credential,
                content_type=ContentType.BASE64
            )
    
    @patch("cv_screening.client.load_cv_from_base64")
    def test_analyze_cvs_single_batch(self, mock_load_b64):
        """Test analyze_cvs with single batch."""
        # Setup
        mock_load_b64.return_value = "Decoded CV content"
        
        client = CVScreeningClient(custom_provider=self.mock_provider)
        client.credential = self.mock_credential
        
        # Mock the analyze_multiple_cvs method
        mock_result = [{"analysis": "result1"}, {"analysis": "result2"}]
        client.provider.analyze_multiple_cvs = MagicMock(return_value=mock_result)
        
        # Mock el método load_cv_content para evitar la llamada real
        original_load_cv_content = client.load_cv_content
        client.load_cv_content = MagicMock(return_value="Decoded CV content")
        
        try:
            # Test data
            cv_data = [
                {"content_cv": "cv1", "document_id": "doc1"},
                {"content_cv": "cv2", "document_id": "doc2"}
            ]
            
            # Test
            results = list(client.analyze_cvs(cv_data, batch_size=2))
            
            # Assert
            self.assertEqual(len(results), 2)
            self.assertEqual(results, mock_result)
            client.provider.analyze_multiple_cvs.assert_called_once()
        finally:
            # Restaurar el método original
            client.load_cv_content = original_load_cv_content

    @patch("cv_screening.client.load_cv_from_base64")
    def test_analyze_cvs_multiple_batches(self, mock_load_b64):
        """Test analyze_cvs with multiple batches."""
        # Setup
        mock_load_b64.return_value = "Decoded CV content"
        
        client = CVScreeningClient(custom_provider=self.mock_provider)
        client.credential = self.mock_credential
        
        # Mock the analyze_multiple_cvs method to return different results for each batch
        client.provider.analyze_multiple_cvs = MagicMock()
        client.provider.analyze_multiple_cvs.side_effect = [
            [{"analysis": "result1"}, {"analysis": "result2"}],
            [{"analysis": "result3"}, {"analysis": "result4"}]
        ]
        
        # Mock el método load_cv_content para evitar la llamada real
        original_load_cv_content = client.load_cv_content
        client.load_cv_content = MagicMock(return_value="Decoded CV content")
        
        try:
            # Test data - 4 CVs to be processed in batches of 2
            cv_data = [
                {"content_cv": "cv1", "document_id": "doc1"},
                {"content_cv": "cv2", "document_id": "doc2"},
                {"content_cv": "cv3", "document_id": "doc3"},
                {"content_cv": "cv4", "document_id": "doc4"}
            ]
            
            # Test
            results = list(client.analyze_cvs(cv_data, batch_size=2))
            
            # Assert
            self.assertEqual(len(results), 4)
            self.assertEqual(results, [
                {"analysis": "result1"}, 
                {"analysis": "result2"}, 
                {"analysis": "result3"}, 
                {"analysis": "result4"}
            ])
            self.assertEqual(client.provider.analyze_multiple_cvs.call_count, 2)
        finally:
            # Restaurar el método original
            client.load_cv_content = original_load_cv_content

    @patch("cv_screening.client.load_cv_from_base64")
    def test_analyze_cvs_with_max_workers(self, mock_load_b64):
        """Test analyze_cvs with max_workers parameter."""
        # Setup
        mock_load_b64.return_value = "Decoded CV content"
        
        client = CVScreeningClient(custom_provider=self.mock_provider)
        client.credential = self.mock_credential
        
        # Mock the analyze_multiple_cvs method
        mock_result = [{"analysis": "result1"}]
        client.provider.analyze_multiple_cvs = MagicMock(return_value=mock_result)
        
        # Mock el método load_cv_content para evitar la llamada real
        original_load_cv_content = client.load_cv_content
        client.load_cv_content = MagicMock(return_value="Decoded CV content")
        
        try:
            # Test data
            cv_data = [{"content_cv": "cv1", "document_id": "doc1"}]
            
            # Test with max_workers=2
            with patch("cv_screening.client.ThreadPoolExecutor") as mock_executor, \
                 patch("cv_screening.client.as_completed") as mock_as_completed:
                
                # Configurar mock del executor
                mock_executor_instance = MagicMock()
                mock_executor.return_value.__enter__.return_value = mock_executor_instance
                
                # Configurar future mock
                mock_future = MagicMock()
                mock_future.result.return_value = mock_result
                mock_executor_instance.submit.return_value = mock_future
                
                # Configurar as_completed para devolver inmediatamente los futures
                mock_as_completed.return_value = [mock_future]
                
                # Ejecutar el método
                results = list(client.analyze_cvs(cv_data, max_workers=2))
                
                # Verificaciones
                self.assertEqual(results, mock_result)
                mock_executor.assert_called_once_with(max_workers=2)
                mock_as_completed.assert_called_once()
        finally:
            # Restaurar el método original
            client.load_cv_content = original_load_cv_content

    @patch("cv_screening.client.load_cv_from_base64")
    def test_analyze_cvs_with_partition_id(self, mock_load_b64):
        """Test analyze_cvs with partition_id parameter."""
        # Setup
        mock_load_b64.return_value = "Decoded CV content"
        
        client = CVScreeningClient(custom_provider=self.mock_provider)
        client.credential = self.mock_credential
        
        # Mock the analyze_multiple_cvs method
        mock_result = [{"analysis": "result1", "partition_id": 5}]
        client.provider.analyze_multiple_cvs = MagicMock(return_value=mock_result)
        
        # Mock el método load_cv_content para evitar la llamada real
        original_load_cv_content = client.load_cv_content
        client.load_cv_content = MagicMock(return_value="Decoded CV content")
        
        try:
            # Test data
            cv_data = [{"content_cv": "cv1", "document_id": "doc1"}]
            
            # Test with partition_id=5
            results = list(client.analyze_cvs(cv_data, partition_id=5))
            
            # Assert
            self.assertEqual(len(results), 1)
            self.assertEqual(results[0]["partition_id"], 5)
            
            # Verify partition_id was passed to analyze_multiple_cvs
            args, kwargs = client.provider.analyze_multiple_cvs.call_args
            self.assertEqual(kwargs.get("partition_id"), 5)
        finally:
            # Restaurar el método original
            client.load_cv_content = original_load_cv_content


if __name__ == '__main__':
    unittest.main() 