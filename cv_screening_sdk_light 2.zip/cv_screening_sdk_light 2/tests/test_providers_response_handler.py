"""
Tests for the Azure Response Handler.
"""
import unittest
from unittest.mock import patch, MagicMock
import pytest
import json

from cv_screening.providers.azure_response_handler import AzureResponseHandler
from cv_screening.core.exceptions import OpenAIError


class TestAzureResponseHandler(unittest.TestCase):
    """Tests for the AzureResponseHandler class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.response_handler = AzureResponseHandler()
    
    def test_process_single_response_valid_json(self):
        """Test process_single_response with valid JSON."""
        # Sample valid JSON response
        sample_response = json.dumps({"analysis": "test result"})
        
        result = self.response_handler.process_single_response(sample_response)
        
        # Verify result is processed correctly
        self.assertIsInstance(result, dict)
        self.assertEqual(result["analysis"], "test result")
    
    def test_process_single_response_invalid_json(self):
        """Test process_single_response with invalid JSON."""
        # Sample invalid JSON response
        sample_response = "This is not valid JSON"
        
        result = self.response_handler.process_single_response(sample_response)
        
        # Verify fallback behavior is correct
        self.assertIsInstance(result, dict)
        self.assertEqual(result["raw_response"], sample_response)
    
    def test_process_batch_response_list(self):
        """Test process_batch_response with list response."""
        # Sample batch response as list
        sample_response = json.dumps([
            {"analysis": "result 1", "cv_index": 0},
            {"analysis": "result 2", "cv_index": 1}
        ])
        
        results = self.response_handler.process_batch_response(sample_response, 5)
        
        # Verify results are processed correctly
        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["analysis"], "result 1")
        self.assertEqual(results[1]["analysis"], "result 2")
        
        # Verify indices are adjusted
        self.assertEqual(results[0]["cv_index"], 5)
        self.assertEqual(results[1]["cv_index"], 6)
    
    def test_process_batch_response_dict(self):
        """Test process_batch_response with dict response."""
        # Sample batch response as dict with results key
        sample_response = json.dumps({
            "results": [
                {"analysis": "result 1", "cv_index": 0},
                {"analysis": "result 2", "cv_index": 1}
            ]
        })
        
        results = self.response_handler.process_batch_response(sample_response, 10)
        
        # Verify results are processed correctly
        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["analysis"], "result 1")
        self.assertEqual(results[1]["analysis"], "result 2")
        
        # Verify indices are adjusted
        self.assertEqual(results[0]["cv_index"], 10)
        self.assertEqual(results[1]["cv_index"], 11)
    
    def test_process_batch_response_single_dict(self):
        """Test process_batch_response with single dict not containing results."""
        # Sample single response (not a batch)
        sample_response = json.dumps({"analysis": "single result"})
        
        results = self.response_handler.process_batch_response(sample_response, 0)
        
        # Verify result is wrapped in a list
        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["analysis"], "single result")
    
    def test_process_batch_response_invalid_json(self):
        """Test process_batch_response with invalid JSON."""
        # Sample invalid JSON
        sample_response = "This is not valid JSON"
        
        results = self.response_handler.process_batch_response(sample_response, 0)
        
        # Verify error handling
        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["raw_response"], sample_response)
        self.assertIn("error", results[0])
    
    def test_adjust_cv_indices(self):
        """Test _adjust_cv_indices method."""
        # Sample results with cv_index field
        results = [
            {"analysis": "result 1", "cv_index": 0},
            {"analysis": "result 2", "cv_index": 1}
        ]
        
        self.response_handler._adjust_cv_indices(results, 10)
        
        # Verify indices are adjusted
        self.assertEqual(results[0]["cv_index"], 10)
        self.assertEqual(results[1]["cv_index"], 11)
    
    def test_adjust_cv_indices_missing_field(self):
        """Test _adjust_cv_indices method with missing cv_index field."""
        # Sample results without cv_index field
        results = [
            {"analysis": "result 1"},
            {"analysis": "result 2"}
        ]
        
        # Verify no error occurs
        self.response_handler._adjust_cv_indices(results, 10)
        
        # Verify results are unchanged
        self.assertEqual(results[0]["analysis"], "result 1")
        self.assertEqual(results[1]["analysis"], "result 2")
        self.assertNotIn("cv_index", results[0])
        self.assertNotIn("cv_index", results[1])


if __name__ == '__main__':
    unittest.main() 