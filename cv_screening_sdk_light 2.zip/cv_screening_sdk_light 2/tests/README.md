# CV Screening SDK Tests

This directory contains unit tests and integration tests for the CV Screening SDK.

## Test Structure

The tests are organized following the package structure:

- `test_core_*.py` - Tests for core modules (types, exceptions, config)
- `test_auth_*.py` - Tests for authentication modules
- `test_models_*.py` - Tests for data models
- `test_utils_*.py` - Tests for utility functions
- `test_integration.py` - Integration tests that test the full workflow

## Running Tests

### Running all tests

```bash
# From project root
pytest

# With coverage
pytest --cov=src
```

### Running specific test files

```bash
# Run all tests in a specific file
pytest tests/test_core_types.py

# Run tests that match a specific pattern
pytest -k "TokenCounter"
```

### Running with verbosity

```bash
# Run tests with more detailed output
pytest -v
```

## Test Coverage

The test suite aims to cover 80% of the codebase. Current coverage by module:

- Core modules: ~90%
- Auth modules: ~85%
- Model modules: ~95%
- Utility modules: ~80%
- Integration: Covers main workflows

To generate a coverage report:

```bash
pytest --cov=src --cov-report=html
```

This will create an HTML report in the `htmlcov` directory.

## Mocking

The tests use extensive mocking to avoid:

1. Making real API calls to OpenAI or Azure
2. Reading/writing real files
3. Dependencies on external services

We use `unittest.mock` for most mocking needs and `pytest` fixtures for reusable test components.

## Adding New Tests

When adding new functionality to the SDK, please also add corresponding tests. Aim to:

1. Test both success and failure paths
2. Mock external dependencies
3. Use parameterized tests where appropriate to test multiple cases
4. Keep tests fast and deterministic 