#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para corregir las rutas en los patch de los tests,
cambiando "src.cv_screening" por "cv_screening".
"""

import os
import re
import sys
from pathlib import Path


def fix_patches_in_file(file_path):
    """Corregir los patches en un archivo."""
    try:
        # Leer el contenido del archivo
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Reemplazar los patches "src.cv_screening" por "cv_screening"
        updated_content = re.sub(
            r'patch\("src\.cv_screening\.', 
            r'patch("cv_screening.', 
            content
        )
        
        # Si hay cambios, escribir el archivo
        if content != updated_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(updated_content)
            print(f"Actualizado: {file_path}")
            return True
        else:
            print(f"Sin cambios: {file_path}")
            return False
    except Exception as e:
        print(f"Error al procesar {file_path}: {str(e)}")
        return False


def fix_all_tests():
    """Recorrer todos los archivos de test y corregir los patches."""
    tests_dir = "tests"
    updated_files = 0
    
    # Verificar que el directorio existe
    if not os.path.exists(tests_dir):
        print(f"El directorio {tests_dir} no existe.")
        return 0
    
    # Recorrer los archivos de test
    for file_name in os.listdir(tests_dir):
        if file_name.endswith(".py") and file_name.startswith("test_"):
            file_path = os.path.join(tests_dir, file_name)
            if fix_patches_in_file(file_path):
                updated_files += 1
    
    return updated_files


def main():
    """Función principal."""
    print("Corrigiendo patches en los tests...")
    
    updated_files = fix_all_tests()
    
    print(f"Total de archivos actualizados: {updated_files}")
    print("\nProceso completado.")
    print("Ahora ejecuta 'python3 -m pytest -v' para verificar si los tests funcionan correctamente.")


if __name__ == "__main__":
    main() 