"""
Handles responses from Azure OpenAI API.
"""
import json
import logging
from typing import Dict, List, Any, Union

try:
    # Intenta importación relativa
    from ...core.exceptions import OpenAIError
except ImportError:
    # Fallback a importación absoluta
    from cv_screening.core.exceptions import OpenAIError


class AzureResponseHandler:
    """Handles and processes responses from Azure OpenAI API."""

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def process_single_response(self, response_text: str) -> Dict[str, Any]:
        """Process a single CV analysis response."""
        try:
            return json.loads(response_text)
        except json.JSONDecodeError:
            return {"raw_response": response_text}

    def process_batch_response(
        self, response_text: str, start_index: int
    ) -> List[Dict[str, Any]]:
        """Process a batch CV analysis response."""
        try:
            response_data = json.loads(response_text)
           
            if isinstance(response_data, list):
                self._adjust_cv_indices(response_data, start_index)
                return response_data
            elif isinstance(response_data, dict) and 'results' in response_data:
                results = response_data['results']
                self._adjust_cv_indices(results, start_index)
                return results
            else:
                return [response_data]
        except json.JSONDecodeError as e:
            self.logger.warning(f"Error decoding JSON response: {str(e)}")
            return [{"raw_response": response_text, "error": "Invalid response format"}]

    def _adjust_cv_indices(
        self, results: List[Dict[str, Any]], start_index: int
    ) -> None:
        """Adjust CV indices in the response data."""
        for item in results:
            if 'cv_index' in item:
                item['cv_index'] += start_index