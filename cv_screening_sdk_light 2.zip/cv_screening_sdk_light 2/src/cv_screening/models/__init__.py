"""Models for CV Screening SDK."""

from .criteria import JobCriteria

__all__ = ["JobCriteria"] 