"""
Ejemplo de análisis de CV desde texto plano sin criterios específicos.

Este ejemplo muestra cómo analizar un CV utilizando el SDK en español,
obteniendo tanto el resultado crudo como procesado.
"""

import os
import json
from cv_screening import CVScreeningClient
from cv_screening.core.types import ContentType

# Configuración de Azure OpenAI
api_key = os.environ.get("AZURE_OPENAI_API_KEY", "tu-api-key")
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://tu-recurso.openai.azure.com")
model_name = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4")

# Activar modo verboso para depuración
VERBOSE = True

def log(mensaje):
    """Función simple de registro que solo imprime si VERBOSE es True."""
    if VERBOSE:
        print(mensaje)

try:
    # Inicializar el cliente de análisis de CV
    log("Inicializando el cliente de análisis de CV...")
    cliente = CVScreeningClient(
        api_key=api_key,
        endpoint=endpoint,
        model_name=model_name,
        temperature=0.7,  # Mayor temperatura para un análisis más creativo sin criterios específicos
        system_prompt="""
        Eres un experto en análisis de currículums y selección de personal en español.
        Tu objetivo es analizar detalladamente el CV proporcionado y extraer la información más relevante.
        
        INSTRUCCIONES DETALLADAS:
        1. Lee cuidadosamente todo el CV y comprende el perfil profesional completo del candidato.
        2. Identifica y clasifica las habilidades técnicas, blandas y conocimientos específicos.
        3. Evalúa la trayectoria profesional, destacando logros y responsabilidades principales.
        4. Analiza la formación académica y su relevancia para la carrera profesional.
        5. Detecta fortalezas destacables y posibles áreas de mejora en el perfil.
        6. Proporciona recomendaciones útiles y accionables para mejorar el CV.
        7. Considera la claridad, estructura y presentación del CV en tu análisis.
        
        FORMATO DE RESPUESTA:
        Proporciona un análisis detallado en formato JSON con los siguientes campos:
        {
          "nombre_candidato": "Nombre completo del candidato",
          "puesto_actual": "Puesto actual o más reciente",
          "resumen": "Resumen conciso pero completo del perfil profesional, incluyendo años de experiencia, especialización y características destacables",
          "habilidades": {
            "tecnicas": ["Lista de habilidades técnicas"],
            "blandas": ["Lista de habilidades blandas"],
            "idiomas": ["Lista de idiomas y niveles"]
          },
          "experiencia": "Análisis de la experiencia laboral, destacando logros, progresión profesional y aspectos relevantes",
          "educacion": "Análisis de la formación académica y su relevancia",
          "certificaciones": ["Lista de certificaciones relevantes"],
          "fortalezas": ["Lista de puntos fuertes identificados en el perfil"],
          "areas_mejora": ["Lista de áreas que podrían mejorarse"],
          "recomendaciones": ["Lista de sugerencias específicas para mejorar el CV"],
          "valoracion_general": "Evaluación general del CV y del potencial profesional del candidato"
        }
        
        Asegúrate de que tu análisis sea objetivo, detallado y útil tanto para el candidato como para posibles reclutadores.
        """
    )
    
    # Ejemplo de contenido de CV en español
    contenido_cv = """
    CARLOS RODRÍGUEZ LÓPEZ
    Desarrollador Full Stack
    carlos.rodriguez@ejemplo.com | +34 612 345 678 | github.com/crodriguez

    PERFIL PROFESIONAL
    Desarrollador Full Stack con 4 años de experiencia en el diseño e implementación 
    de aplicaciones web y móviles. Especializado en tecnologías JavaScript modernas 
    y desarrollo backend con Python. Apasionado por crear soluciones tecnológicas 
    de alta calidad que resuelvan problemas reales.

    HABILIDADES
    - Frontend: JavaScript, TypeScript, React, Vue.js, HTML5, CSS3
    - Backend: Python, Django, Node.js, Express
    - Bases de datos: PostgreSQL, MongoDB, MySQL
    - DevOps: Docker, Kubernetes, CI/CD, AWS
    - Metodologías: Scrum, Kanban, TDD
    - Idiomas: Español (nativo), Inglés (avanzado)

    EXPERIENCIA LABORAL
    Desarrollador Full Stack Senior | TechSolutions S.L. | 2021 - Presente
    - Liderado el desarrollo de una plataforma SaaS para gestión de proyectos utilizada por más de 5.000 usuarios
    - Implementado arquitectura de microservicios utilizando Node.js y Docker
    - Reducido el tiempo de carga de la aplicación en un 40% mediante optimización de código y CDN
    - Mentorizado a 3 desarrolladores junior del equipo
    - Integrado pasarelas de pago y sistemas de analítica

    Desarrollador Web | InnovaSoft | 2019 - 2021
    - Desarrollado interfaces de usuario con React y Redux para aplicaciones financieras
    - Colaborado en el desarrollo de APIs RESTful con Django
    - Implementado tests automatizados que aumentaron la cobertura de código al 85%
    - Participado en revisiones de código y sesiones de planificación ágil

    FORMACIÓN ACADÉMICA
    Grado en Ingeniería Informática | Universidad Politécnica de Madrid | 2015-2019
    Máster en Desarrollo Web | Universidad Complutense de Madrid | 2019-2020

    CERTIFICACIONES
    - AWS Certified Developer - Associate
    - MongoDB Certified Developer
    - Scrum Foundation Professional Certificate
    """
    
    # Analizar el CV sin proporcionar criterios específicos
    log("Analizando CV sin criterios específicos...")
    resultado = cliente.analyze_cv(
        content=contenido_cv,
        criteria=None,  # Sin criterios específicos
        content_type=ContentType.TEXT
    )
    
    # Imprimir los resultados del análisis
    print("\n==================================")
    print("RESULTADOS DEL ANÁLISIS DE CV")
    print("==================================")
    
    # Imprimir el resultado completo en formato JSON para referencia (resultado crudo)
    print("\nResultado crudo del análisis:")
    print(json.dumps(resultado, indent=2, ensure_ascii=False))
    
    # Extraer y mostrar la información clave del análisis del CV (resultado procesado)
    print("\n==================================")
    print("RESULTADO PROCESADO")
    print("==================================")
    
    # Intentar extraer información estructurada si está disponible
    if isinstance(resultado, dict):
        # Información básica
        if 'nombre_candidato' in resultado:
            print(f"\nNombre: {resultado['nombre_candidato']}")
        if 'puesto_actual' in resultado:
            print(f"Puesto actual: {resultado['puesto_actual']}")
        
        # Resumen
        if 'resumen' in resultado:
            print(f"\nResumen del perfil:")
            print(resultado['resumen'])
        
        # Habilidades
        if 'habilidades' in resultado:
            print("\nHabilidades identificadas:")
            if isinstance(resultado['habilidades'], dict):
                for tipo_habilidad, habilidades in resultado['habilidades'].items():
                    print(f"  {tipo_habilidad.upper()}:")
                    if isinstance(habilidades, list):
                        for habilidad in habilidades:
                            print(f"    - {habilidad}")
                    else:
                        print(f"    {habilidades}")
            elif isinstance(resultado['habilidades'], list):
                for habilidad in resultado['habilidades']:
                    print(f"  - {habilidad}")
            else:
                print(resultado['habilidades'])
        
        # Experiencia
        if 'experiencia' in resultado:
            print("\nExperiencia laboral:")
            print(resultado['experiencia'])
        
        # Educación
        if 'educacion' in resultado:
            print("\nFormación académica:")
            print(resultado['educacion'])
            
        # Certificaciones
        if 'certificaciones' in resultado:
            print("\nCertificaciones:")
            if isinstance(resultado['certificaciones'], list):
                for certificacion in resultado['certificaciones']:
                    print(f"  - {certificacion}")
            else:
                print(resultado['certificaciones'])
        
        # Fortalezas
        if 'fortalezas' in resultado:
            print("\nFortalezas:")
            if isinstance(resultado['fortalezas'], list):
                for fortaleza in resultado['fortalezas']:
                    print(f"  - {fortaleza}")
            else:
                print(resultado['fortalezas'])
        
        # Áreas de mejora
        if 'areas_mejora' in resultado:
            print("\nÁreas de mejora:")
            if isinstance(resultado['areas_mejora'], list):
                for area in resultado['areas_mejora']:
                    print(f"  - {area}")
            else:
                print(resultado['areas_mejora'])
        
        # Recomendaciones
        if 'recomendaciones' in resultado:
            print("\nRecomendaciones:")
            if isinstance(resultado['recomendaciones'], list):
                for recomendacion in resultado['recomendaciones']:
                    print(f"  - {recomendacion}")
            else:
                print(resultado['recomendaciones'])
                
        # Valoración general
        if 'valoracion_general' in resultado:
            print("\nValoración general:")
            print(resultado['valoracion_general'])
    
    # Si el resultado es una cadena (la respuesta cruda)
    elif isinstance(resultado, str):
        print("\nAnálisis general:")
        print(resultado)
    
    # Para cualquier otro formato de respuesta
    else:
        print("\nEl formato de respuesta es diferente al esperado.")
        print("Revisa el resultado crudo para más detalles.")
    
except Exception as e:
    print(f"Error inesperado: {e}")
    print("Ocurrió un error durante el análisis del CV.")

finally:
    print("\nNota: Al analizar CVs sin criterios específicos:")
    print("- El formato puede ser menos estructurado")
    print("- El análisis se centra en la identificación general de habilidades y experiencia")
    print("- Para mejores resultados, considere proporcionar al menos criterios mínimos cuando sea posible") 