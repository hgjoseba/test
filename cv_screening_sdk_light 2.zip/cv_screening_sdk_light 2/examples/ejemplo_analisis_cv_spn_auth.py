"""
Ejemplo de análisis de CV usando autenticación con Azure.

Este ejemplo muestra cómo analizar un CV desde texto plano utilizando el SDK en español,
con múltiples métodos de autenticación de Azure (SPN y Default Credentials), obteniendo
tanto el resultado crudo como procesado. También incluye soporte para contenido codificado
en base64 y desactiva la verificación SSL para entornos corporativos.
"""

import os
import json
import base64
import requests
from cv_screening import CVScreeningClient
from cv_screening.core.types import ContentType
from cv_screening.auth.azure import AzureAuthProvider
from cv_screening.core.exceptions import AuthenticationError, OpenAIError

# Credenciales de Service Principal de Azure
tenant_id = os.environ.get("AZURE_TENANT_ID", "tu-tenant-id")
client_id = os.environ.get("AZURE_CLIENT_ID", "tu-client-id")
client_secret = os.environ.get("AZURE_CLIENT_SECRET", "tu-client-secret")
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://tu-recurso.openai.azure.com")
model_name = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4")

# Activar modo verboso para depuración
VERBOSE = True

def log(mensaje):
    """Función simple de registro que solo imprime si VERBOSE es True."""
    if VERBOSE:
        print(mensaje)

try:
    # MÉTODO 1: Autenticación con Service Principal (SPN)
    log("=== MÉTODO 1: Autenticación con Service Principal (SPN) ===")
    log("Inicializando proveedor de autenticación de Azure con SPN...")
    azure_auth = AzureAuthProvider(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret
    )
    
    # Obtener token de autenticación
    log("Obteniendo token de autenticación de Azure...")
    token = azure_auth.get_token()
    log("Token obtenido correctamente")
    
    # Mostrar información sobre el token obtenido (sin revelar el token completo por seguridad)
    token_preview = token[:10] + "..." if token else "No se pudo obtener el token"
    log(f"Previsualización del token: {token_preview}")
    
    # MÉTODO 2: Autenticación con Azure Default Credentials
    log("\n=== MÉTODO 2: Autenticación con Azure Default Credentials ===")
    log("Este método utiliza las credenciales configuradas en tu entorno de Azure.")
    log("""
    # Para utilizar Azure Default Credentials, configura tu entorno:
    # - Azure CLI: Ejecuta 'az login' para iniciar sesión
    # - Variables de entorno: Establece AZURE_* (AZURE_TENANT_ID, AZURE_CLIENT_ID, etc.)
    # - Identidad Administrada: Disponible cuando se ejecuta en recursos de Azure
    
    # Inicializar el cliente con Azure Default Credentials
    from cv_screening.auth.azure import AzureDefaultCredentialsProvider
    
    # No se necesitan parámetros explícitos, utiliza las credenciales del entorno
    azure_default_auth = AzureDefaultCredentialsProvider()
    
    # Inicializar cliente con Default Credentials
    cliente_default_creds = CVScreeningClient(
        auth_provider=azure_default_auth,
        endpoint=endpoint,
        model_name=model_name,
        connection_verify=False
    )
    """)
    
    # MÉTODO 3: Credenciales configuradas directamente en el cliente (Recomendado para la mayoría de escenarios)
    log("\n=== MÉTODO 3: Credenciales directamente en el cliente ===")
    log("""
    # Para configurar las credenciales directamente en el cliente:
    
    # Opción 1: Usando credenciales explícitas
    cliente_con_credenciales = CVScreeningClient(
        endpoint=endpoint,
        model_name=model_name,
        azure_credential={
            "tenant_id": tenant_id,
            "client_id": client_id,
            "client_secret": client_secret
        },
        connection_verify=False
    )
    
    # Opción 2: Configurando con variables de entorno
    # export AZURE_TENANT_ID=tu-tenant-id
    # export AZURE_CLIENT_ID=tu-client-id
    # export AZURE_CLIENT_SECRET=tu-client-secret
    # export AZURE_OPENAI_ENDPOINT=https://tu-recurso.openai.azure.com
    # export AZURE_OPENAI_DEPLOYMENT=gpt-4
    
    cliente_con_env = CVScreeningClient(
        # Se tomarán automáticamente las credenciales del entorno
        use_azure_active_directory=True
    )
    """)
    
    # Ejemplo de uso directo del token para una llamada a la API de Azure OpenAI
    log("\nEjemplo de cómo usar el token directamente para hacer una llamada a Azure OpenAI API:")
    log("""
    # Ejemplo: Cómo usar el token directamente para llamadas a la API
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # URL para la API de Azure OpenAI (Ejemplo)
    url = f"{endpoint}/openai/deployments/{model_name}/chat/completions?api-version=2023-05-15"
    
    # Datos para la solicitud
    data = {
        "messages": [
            {"role": "system", "content": "Eres un asistente experto en análisis de CVs."},
            {"role": "user", "content": "Analiza este CV: ..."}
        ],
        "temperature": 0.7,
        "max_tokens": 800
    }
    
    # Realizar la solicitud con verificación SSL deshabilitada
    response = requests.post(url, headers=headers, json=data, verify=False)
    
    # Procesar la respuesta
    if response.status_code == 200:
        result = response.json()
        print(result["choices"][0]["message"]["content"])
    else:
        print(f"Error: {response.status_code} - {response.text}")
    """)
    
    # Mostrar cómo renovar el token cuando expira
    log("\nCómo renovar el token cuando expira:")
    log("""
    # Los tokens de Azure tienen un tiempo de expiración (normalmente 1 hora)
    # Cuando necesites renovar el token:
    
    def renovar_token():
        azure_auth = AzureAuthProvider(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        return azure_auth.get_token()
    
    # Cuando detectes que el token ha expirado (código 401 en respuestas):
    nuevo_token = renovar_token()
    # Actualiza tus headers con el nuevo token
    headers["Authorization"] = f"Bearer {nuevo_token}"
    """)
    
    # Inicializar el cliente de análisis de CV con el token
    log("\nInicializando el cliente de análisis de CV con token SPN...")
    cliente = CVScreeningClient(
        api_key=token,  # Usar token como clave API
        endpoint=endpoint,
        model_name=model_name,
        temperature=0.7,  # Mayor temperatura para un análisis más creativo sin criterios específicos
        connection_verify=False,  # Deshabilitar verificación SSL para entornos corporativos
        system_prompt="""
        Eres un experto en análisis de currículums y selección de personal en español.
        Tu objetivo es analizar detalladamente el CV proporcionado y extraer la información más relevante.
        
        INSTRUCCIONES DETALLADAS:
        1. Lee cuidadosamente todo el CV y comprende el perfil profesional completo del candidato.
        2. Identifica y clasifica las habilidades técnicas, blandas y conocimientos específicos.
        3. Evalúa la trayectoria profesional, destacando logros y responsabilidades principales.
        4. Analiza la formación académica y su relevancia para la carrera profesional.
        5. Detecta fortalezas destacables y posibles áreas de mejora en el perfil.
        6. Proporciona recomendaciones útiles y accionables para mejorar el CV.
        7. Considera la claridad, estructura y presentación del CV en tu análisis.
        
        FORMATO DE RESPUESTA:
        Proporciona un análisis detallado en formato JSON con los siguientes campos:
        {
          "nombre_candidato": "Nombre completo del candidato",
          "puesto_actual": "Puesto actual o más reciente",
          "resumen": "Resumen conciso pero completo del perfil profesional, incluyendo años de experiencia, especialización y características destacables",
          "habilidades": {
            "tecnicas": ["Lista de habilidades técnicas"],
            "blandas": ["Lista de habilidades blandas"],
            "idiomas": ["Lista de idiomas y niveles"]
          },
          "experiencia": "Análisis de la experiencia laboral, destacando logros, progresión profesional y aspectos relevantes",
          "educacion": "Análisis de la formación académica y su relevancia",
          "certificaciones": ["Lista de certificaciones relevantes"],
          "fortalezas": ["Lista de puntos fuertes identificados en el perfil"],
          "areas_mejora": ["Lista de áreas que podrían mejorarse"],
          "recomendaciones": ["Lista de sugerencias específicas para mejorar el CV"],
          "valoracion_general": "Evaluación general del CV y del potencial profesional del candidato"
        }
        
        Asegúrate de que tu análisis sea objetivo, detallado y útil tanto para el candidato como para posibles reclutadores.
        """
    )
    
    log("AVISO: La verificación SSL está deshabilitada. Esto puede reducir la seguridad de las conexiones.")
    
    # Ejemplo de contenido de CV en español
    contenido_cv = """
    LAURA MARTÍNEZ GARCÍA
    Ingeniera de Datos
    laura.martinez@ejemplo.com | +34 623 456 789 | linkedin.com/in/lauramartinez

    PERFIL PROFESIONAL
    Ingeniera de Datos con 6 años de experiencia en el diseño, implementación y optimización 
    de soluciones de Big Data y análisis. Especializada en arquitecturas de procesamiento 
    en tiempo real y pipelines de datos. Comprometida con la mejora continua y la 
    transformación digital basada en datos.

    HABILIDADES
    - Lenguajes: Python, SQL, Scala, Java
    - Big Data: Hadoop, Spark, Kafka, Airflow
    - Cloud: AWS (Redshift, S3, EMR), Azure (Data Factory, Synapse)
    - Bases de datos: PostgreSQL, MongoDB, Cassandra, Snowflake
    - Herramientas: Docker, Kubernetes, Terraform, Git
    - Visualización: Tableau, Power BI
    - Metodologías: Agile, DevOps, DataOps
    - Idiomas: Español (nativo), Inglés (fluido), Francés (intermedio)

    EXPERIENCIA LABORAL
    Lead Data Engineer | DataTech Solutions | 2021 - Presente
    - Diseñado e implementado plataforma de procesamiento en tiempo real procesando 3TB diarios
    - Reducido costes de infraestructura en un 35% mediante optimización de recursos cloud
    - Liderado equipo de 5 ingenieros en la migración de arquitectura on-premise a cloud
    - Implementado prácticas DataOps que redujeron el tiempo de entrega en un 40%
    - Colaborado con equipos de negocio para definir KPIs y dashboards estratégicos

    Data Engineer | Innovación Digital | 2018 - 2021
    - Desarrollado pipelines ETL para integración de múltiples fuentes de datos
    - Implementado soluciones de calidad de datos que redujeron errores en un 75%
    - Creado APIs para consumo de datos por aplicaciones internas y externas
    - Colaborado con científicos de datos para productivizar modelos de ML

    Analista de Datos | Consultoría Tecnológica | 2016 - 2018
    - Desarrollado informes y dashboards para clientes de diversos sectores
    - Automatizado procesos de reporting reduciendo tiempos de entrega en un 60%
    - Realizado análisis exploratorio de datos para identificar tendencias

    FORMACIÓN ACADÉMICA
    Máster en Big Data y Analytics | Universidad Politécnica de Madrid | 2015-2016
    Grado en Ingeniería Informática | Universidad Complutense de Madrid | 2011-2015

    CERTIFICACIONES
    - AWS Certified Data Analytics Specialty
    - Microsoft Certified: Azure Data Engineer Associate
    - Databricks Certified Associate Developer for Apache Spark
    - Google Professional Data Engineer
    """
    
    # Codificar el contenido del CV en base64
    log("Codificando el contenido del CV en base64...")
    contenido_cv_bytes = contenido_cv.encode('utf-8')
    contenido_cv_base64 = base64.b64encode(contenido_cv_bytes)
    
    # Analizar el CV codificado en base64 sin proporcionar criterios específicos
    log("Analizando CV en formato base64 sin criterios específicos...")
    resultado = cliente.analyze_cv(
        content=contenido_cv_base64,
        criteria=None,  # Sin criterios específicos
        content_type=ContentType.BASE64  # Especificar que el contenido está en base64
    )
    
    # Imprimir los resultados del análisis
    print("\n==================================")
    print("RESULTADOS DEL ANÁLISIS DE CV (BASE64)")
    print("==================================")
    
    # Imprimir el resultado completo en formato JSON para referencia (resultado crudo)
    print("\nResultado crudo del análisis:")
    print(json.dumps(resultado, indent=2, ensure_ascii=False))
    
    # Extraer y mostrar la información clave del análisis del CV (resultado procesado)
    print("\n==================================")
    print("RESULTADO PROCESADO")
    print("==================================")
    
    # Intentar extraer información estructurada si está disponible
    if isinstance(resultado, dict):
        # Información básica
        if 'nombre_candidato' in resultado:
            print(f"\nNombre: {resultado['nombre_candidato']}")
        if 'puesto_actual' in resultado:
            print(f"Puesto actual: {resultado['puesto_actual']}")
        
        # Resumen
        if 'resumen' in resultado:
            print(f"\nResumen del perfil:")
            print(resultado['resumen'])
        
        # Habilidades
        if 'habilidades' in resultado:
            print("\nHabilidades identificadas:")
            if isinstance(resultado['habilidades'], dict):
                for tipo_habilidad, habilidades in resultado['habilidades'].items():
                    print(f"  {tipo_habilidad.upper()}:")
                    if isinstance(habilidades, list):
                        for habilidad in habilidades:
                            print(f"    - {habilidad}")
                    else:
                        print(f"    {habilidades}")
            elif isinstance(resultado['habilidades'], list):
                for habilidad in resultado['habilidades']:
                    print(f"  - {habilidad}")
            else:
                print(resultado['habilidades'])
        
        # Experiencia
        if 'experiencia' in resultado:
            print("\nExperiencia laboral:")
            print(resultado['experiencia'])
        
        # Educación
        if 'educacion' in resultado:
            print("\nFormación académica:")
            print(resultado['educacion'])
            
        # Certificaciones
        if 'certificaciones' in resultado:
            print("\nCertificaciones:")
            if isinstance(resultado['certificaciones'], list):
                for certificacion in resultado['certificaciones']:
                    print(f"  - {certificacion}")
            else:
                print(resultado['certificaciones'])
        
        # Fortalezas
        if 'fortalezas' in resultado:
            print("\nFortalezas:")
            if isinstance(resultado['fortalezas'], list):
                for fortaleza in resultado['fortalezas']:
                    print(f"  - {fortaleza}")
            else:
                print(resultado['fortalezas'])
        
        # Áreas de mejora
        if 'areas_mejora' in resultado:
            print("\nÁreas de mejora:")
            if isinstance(resultado['areas_mejora'], list):
                for area in resultado['areas_mejora']:
                    print(f"  - {area}")
            else:
                print(resultado['areas_mejora'])
        
        # Recomendaciones
        if 'recomendaciones' in resultado:
            print("\nRecomendaciones:")
            if isinstance(resultado['recomendaciones'], list):
                for recomendacion in resultado['recomendaciones']:
                    print(f"  - {recomendacion}")
            else:
                print(resultado['recomendaciones'])
                
        # Valoración general
        if 'valoracion_general' in resultado:
            print("\nValoración general:")
            print(resultado['valoracion_general'])
    
    # Si el resultado es una cadena (la respuesta cruda)
    elif isinstance(resultado, str):
        print("\nAnálisis general:")
        print(resultado)
    
    # Para cualquier otro formato de respuesta
    else:
        print("\nEl formato de respuesta es diferente al esperado.")
        print("Revisa el resultado crudo para más detalles.")
    
    # Ejemplo adicional: Cargar un CV desde un archivo y codificarlo en base64
    print("\n\n==================================")
    print("EJEMPLO: CARGAR CV DESDE ARCHIVO")
    print("==================================")
    print("Este es un ejemplo de cómo cargarías un CV desde un archivo real:")
    print("""
    # Cargar CV desde un archivo y codificarlo en base64
    with open("ruta/al/cv.pdf", "rb") as f:
        contenido_archivo = f.read()
        contenido_base64 = base64.b64encode(contenido_archivo)
    
    # Analizar el CV codificado en base64
    resultado = cliente.analyze_cv(
        content=contenido_base64,
        criteria=None,
        content_type=ContentType.BASE64
    )
    """)
    
except AuthenticationError as e:
    print(f"Error de autenticación: {e}")
    print("Por favor, verifica tus credenciales de Azure e inténtalo de nuevo.")
    
except OpenAIError as e:
    print(f"Error de OpenAI: {e}")
    print("Hubo un problema con el análisis del CV. El servicio podría no admitir análisis sin criterios.")
    print("Considera proporcionar un conjunto genérico de criterios o consultar la documentación de la API.")
    
except Exception as e:
    print(f"Error inesperado: {e}")
    print("Ocurrió un error durante el análisis del CV.")

finally:
    print("\nNota: Al analizar CVs sin criterios específicos:")
    print("- El formato puede ser menos estructurado")
    print("- El análisis se centra en la identificación general de habilidades y experiencia")
    print("- Para mejores resultados, considere proporcionar al menos criterios mínimos cuando sea posible")
    print("\nNota sobre contenido en base64:")
    print("- Útil para transmitir archivos a través de APIs REST")
    print("- Permite enviar contenido binario (PDFs, DOCXs) como texto")
    print("- Funciona bien con sistemas que no pueden manejar archivos binarios directamente")
    print("\nNota sobre verificación SSL deshabilitada:")
    print("- ADVERTENCIA: Esta configuración reduce la seguridad de las conexiones")
    print("- Útil en entornos corporativos con proxies o inspección SSL")
    print("- Recomendado solo cuando sea absolutamente necesario y en redes de confianza")
    print("\nNota sobre autenticación en Azure:")
    print("- Service Principal (SPN): Mejor para aplicaciones desatendidas y automatizaciones")
    print("- Default Credentials: Más conveniente durante el desarrollo")
    print("- Variables de entorno: Útiles para configuración en servidores y contenedores")
    print("- Token de sesión: Se renueva automáticamente cuando expira (al usar auth_provider)") 