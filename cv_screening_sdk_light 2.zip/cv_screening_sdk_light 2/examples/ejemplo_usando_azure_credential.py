"""
Ejemplo de cómo utilizar CVScreeningClient con AzureCredential para obtener CVs desde Azure.

Este ejemplo muestra:
1. Cómo crear un AzureCredential para autenticación
2. Cómo configurar CVScreeningClient para obtener CVs desde un servicio Azure
3. Cómo analizar el CV obtenido
"""

import os
import logging
from typing import Optional, Union

from cv_screening import CVScreeningClient
from cv_screening.core.types import ContentType
from cv_screening.models.criteria import JobCriteria

# Configuración de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Intenta importar AzureCredential (asumiendo que se ha instalado)
try:
    from azure_credential import AzureCredential  # Ajusta la importación según tu estructura
except ImportError:
    # Creamos una clase simulada si no está disponible, solo para el ejemplo
    logger.warning("AzureCredential no está disponible. Usando una implementación simulada.")
    
    class AzureCredential:
        """Implementación simulada de AzureCredential para el ejemplo."""
        
        def __init__(
            self, 
            api_key: Optional[str] = None, 
            tenant_id: Optional[str] = None,
            client_id: Optional[str] = None,
            client_secret: Optional[str] = None,
            use_azure_cli: bool = False,
            use_managed_identity: bool = False,
            scope: str = "https://cognitiveservices.azure.com/.default",
            connection_verify: Union[bool, str] = True,
            credential = None,
        ):
            self.api_key = api_key or os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_KEY")
            self.tenant_id = tenant_id or os.environ.get("AZURE_TENANT_ID")
            self.client_id = client_id or os.environ.get("AZURE_CLIENT_ID")
            self.client_secret = client_secret or os.environ.get("AZURE_CLIENT_SECRET")
            
        def get_token(self):
            """Simula obtener un token."""
            # En una aplicación real, esto devolvería un token válido
            return os.environ.get("AZURE_API_KEY", "simulated-token")

# Credenciales de Azure desde variables de entorno
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
api_key = os.environ.get("AZURE_OPENAI_API_KEY")
cv_service_url = os.environ.get("AZURE_CV_SERVICE_URL")

def main():
    """Función principal que demuestra cómo usar CVScreeningClient con AzureCredential."""
    try:
        # Paso 1: Crear una instancia de AzureCredential
        logger.info("Creando instancia de AzureCredential")
        azure_credential = AzureCredential(
            tenant_id=os.environ.get("AZURE_TENANT_ID"),
            client_id=os.environ.get("AZURE_CLIENT_ID"),
            client_secret=os.environ.get("AZURE_CLIENT_SECRET")
        )
        
        # Paso 2: Inicializar el cliente de CV Screening
        logger.info("Inicializando CVScreeningClient")
        client = CVScreeningClient(
            endpoint=endpoint,
            api_key=api_key,
            deployment_name="gpt-4",  # Ajustar según corresponda
            temperature=0.1
        )
        
        # Paso 3: Definir criterios del trabajo
        job_criteria = JobCriteria(
            title="Desarrollador de Software",
            description="""
            Buscamos un Desarrollador de Software con experiencia en Python y servicios cloud.
            El candidato ideal tiene experiencia en desarrollo de APIs y buenas prácticas de código.
            """,
            required_skills=["Python", "REST APIs", "Git"],
            preferred_skills=["Azure", "Docker", "CI/CD"],
            minimum_years_experience=3,
            education="Licenciatura en Informática o campo relacionado"
        )
        
        # Paso 4: Analizar el CV usando el contenido obtenido desde Azure
        # Nota: Pasamos un string vacío como contenido ya que será reemplazado
        # por el contenido obtenido desde el servicio Azure
        logger.info(f"Analizando CV desde servicio Azure: {cv_service_url}")
        
        result = client.analyze_cv(
            content="",  # Contenido vacío - será reemplazado por el contenido de Azure
            criteria=job_criteria,
            content_type=ContentType.BASE64,  # Indicamos que es tipo BASE64 para que use la ruta Azure
            credential=azure_credential,      # Pasamos AzureCredential
            service_url=cv_service_url,       # URL del servicio Azure
            azure_content_type="application/json"  # Tipo MIME esperado
        )
        
        # Paso 5: Mostrar resultados
        logger.info("Análisis completado")
        logger.info(f"Puntuación de coincidencia: {result.get('score', 'N/A')}")
        logger.info(f"Decisión: {result.get('decision', 'N/A')}")
        logger.info(f"Resumen: {result.get('summary', 'N/A')}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error en el análisis del CV: {str(e)}", exc_info=True)
        raise

if __name__ == "__main__":
    main() 