"""
Example of CV screening using Azure token authentication behind a corporate proxy.

This example demonstrates how to use Azure token authentication when working
in a corporate environment that requires a proxy for outbound connections.
"""

import os
import urllib3
import warnings
from cv_screening import CVScreeningClient
from cv_screening.core.types import ContentType
from cv_screening.models.criteria import JobCriteria
from cv_screening.auth.azure import AzureAuthProvider
from cv_screening.core.exceptions import AuthenticationError, OpenAIError

# Configure proxy settings - typically found in your corporate IT documentation
# or from environment variables
http_proxy = os.environ.get("HTTP_PROXY", "http://proxy.example.com:8080")
https_proxy = os.environ.get("HTTPS_PROXY", "http://proxy.example.com:8080")

# Set proxy environment variables - these will be used by the Azure SDK
os.environ["HTTP_PROXY"] = http_proxy
os.environ["HTTPS_PROXY"] = https_proxy

# Azure Service Principal credentials
tenant_id = os.environ.get("AZURE_TENANT_ID", "your-tenant-id")
client_id = os.environ.get("AZURE_CLIENT_ID", "your-client-id")
client_secret = os.environ.get("AZURE_CLIENT_SECRET", "your-client-secret")
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://your-resource-name.openai.azure.com")

# Disable SSL verification if needed (some corporate proxies use SSL inspection)
# WARNING: Only do this in controlled environments where you understand the risks
ssl_verify = False

if not ssl_verify:
    # Suppress SSL verification warnings
    warnings.filterwarnings('ignore', message='Unverified HTTPS request')
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

try:
    print(f"Initializing Azure Auth Provider with proxy settings...")
    print(f"  HTTP Proxy: {http_proxy}")
    print(f"  HTTPS Proxy: {https_proxy}")
    print(f"  SSL Verification: {'Disabled' if not ssl_verify else 'Enabled'}")
    
    # Initialize Azure Auth Provider with SSL verification setting
    azure_auth = AzureAuthProvider(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
        connection_verify=ssl_verify  # Control SSL verification
    )
    
    # Get token from Azure
    print("Obtaining authentication token from Azure...")
    token = azure_auth.get_token()
    print("✓ Token obtained successfully")
    
    # Create the CV Screening client
    print("Initializing CV Screening client...")
    client = CVScreeningClient(
        api_key=token,  # Use token as API key
        endpoint=endpoint,
        model_name="gpt-4",  # or your specific deployment name
        connection_verify=ssl_verify  # Match the SSL verification setting
    )
    
    # Define job criteria
    criteria = JobCriteria(
        job_title="IT Support Analyst",
        job_description="Looking for an IT support professional for our corporate environment",
        required_skills=["Windows", "Active Directory", "Network Troubleshooting"],
        preferred_skills=["Proxy Configuration", "VPN Support", "Security Compliance"],
        min_years_experience=2
    )
    
    # Sample CV content
    cv_content = """
    ROBERT SMITH
    IT Support Specialist
    robert.smith@example.com | (555) 987-6543
    
    SKILLS
    - Operating Systems: Windows 10/11, Windows Server, macOS, Linux
    - Network: TCP/IP, DHCP, DNS, VPN, Firewalls, Proxy Configuration
    - Security: Antivirus Management, Patch Management, User Access Control
    - Directory Services: Active Directory, Group Policy, LDAP
    - Hardware: Desktop/Laptop Troubleshooting, Peripheral Setup
    
    EXPERIENCE
    Senior IT Support Specialist | Corporate Solutions Inc. | 2020 - Present
    - Managed IT support for 500+ corporate users in a hybrid environment
    - Configured and maintained proxy server settings for 200+ client systems
    - Handled VPN setup and troubleshooting for remote workforce
    - Reduced average ticket resolution time by 30%
    
    IT Support Technician | Business Systems LLC | 2018 - 2020
    - Provided first and second level support for hardware and software issues
    - Deployed and maintained Windows workstations and applications
    - Assisted with network troubleshooting and Active Directory management
    
    CERTIFICATIONS
    - CompTIA A+
    - Microsoft Certified: Modern Desktop Administrator Associate
    - ITIL Foundation
    """
    
    # Analyze CV
    print("Analyzing CV...")
    result = client.analyze_cv(
        content=cv_content,
        criteria=criteria.to_dict(),
        content_type=ContentType.TEXT
    )
    
    # Print results
    print("\n========================")
    print("CV Analysis Results:")
    print("========================")
    print(f"Overall Match: {result.get('overall_match', 'N/A')}%")
    
    # Print skills matching details
    if 'skills_match' in result:
        skills = result['skills_match']
        print("\nSKILLS ASSESSMENT:")
        print("-----------------")
        
        # Required skills
        if 'required_skills' in skills:
            print("Required Skills:")
            for skill, score in skills['required_skills'].items():
                status = "✓ STRONG" if score > 0.8 else "△ ADEQUATE" if score > 0.5 else "✗ WEAK"
                print(f"  {skill}: {score:.2f} [{status}]")
        
        # Preferred skills
        if 'preferred_skills' in skills:
            print("\nPreferred Skills:")
            for skill, score in skills['preferred_skills'].items():
                status = "✓ STRONG" if score > 0.8 else "△ ADEQUATE" if score > 0.5 else "✗ WEAK"
                print(f"  {skill}: {score:.2f} [{status}]")
        
        # Missing skills
        if skills.get('missing_required'):
            print("\nMissing Required Skills:")
            for skill in skills['missing_required']:
                print(f"  ✗ {skill}")
    
    # Print experience and education assessment
    if 'experience_match' in result:
        print(f"\nExperience Assessment: {result['experience_match'].get('score', 'N/A')}%")
    
    if 'education_match' in result:
        print(f"Education Assessment: {result['education_match'].get('score', 'N/A')}%")
    
    # Print final recommendation
    print("\nFINAL ASSESSMENT:")
    print("-----------------")
    if 'recommendation' in result:
        print(result['recommendation'])
    else:
        # Generate a simple recommendation based on overall match
        overall = result.get('overall_match', 0)
        if overall >= 80:
            print("RECOMMENDED FOR INTERVIEW: Strong match for the position")
        elif overall >= 60:
            print("POTENTIAL CANDIDATE: Consider for interview if other candidates are limited")
        else:
            print("NOT RECOMMENDED: Does not meet minimum requirements")

except AuthenticationError as e:
    print(f"\n⚠️ Authentication Error: {e}")
    print("Check your Azure credentials and proxy settings.")
    
except OpenAIError as e:
    print(f"\n⚠️ OpenAI API Error: {e}")
    print("There was an issue with the CV analysis service.")
    
except Exception as e:
    print(f"\n⚠️ Unexpected Error: {e}")
    print("Troubleshooting steps:")
    print("1. Verify proxy settings are correct")
    print("2. Ensure your network allows connections to Azure services")
    print("3. Check if you need to add proxy credentials")
    print("4. Consider disabling SSL verification if you're behind an SSL-inspecting proxy")
    
finally:
    print("\nNote on Corporate Proxies:")
    print("When using this SDK in corporate environments, you may need to:")
    print("1. Configure proxy settings at the OS level")
    print("2. Set HTTP_PROXY and HTTPS_PROXY environment variables")
    print("3. Consult with your IT department for specific proxy requirements") 