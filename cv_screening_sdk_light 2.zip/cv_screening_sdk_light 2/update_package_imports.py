#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para actualizar las importaciones en todos los archivos del proyecto
para que usen `cv_screening` en lugar de `src.cv_screening`.
"""

import os
import re
import sys
from pathlib import Path


def update_imports_in_file(file_path):
    """Actualizar las importaciones en un archivo."""
    try:
        # Leer el contenido del archivo
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Reemplazar las importaciones de 'from cv_screening.' por 'from cv_screening.'
        updated_content = re.sub(
            r'from src\.cv_screening\.', 
            r'from cv_screening.', 
            content
        )
        
        # Reemplazar las importaciones de 'import cv_screening' por 'import cv_screening'
        updated_content = re.sub(
            r'import src\.cv_screening', 
            r'import cv_screening', 
            updated_content
        )
        
        # Si hay cambios, escribir el archivo
        if content != updated_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(updated_content)
            print(f"Actualizado: {file_path}")
            return True
        else:
            print(f"Sin cambios: {file_path}")
            return False
    except Exception as e:
        print(f"Error al procesar {file_path}: {str(e)}")
        return False


def update_imports_in_directory(directory, extensions=None):
    """Recorrer un directorio y actualizar las importaciones en los archivos."""
    if extensions is None:
        extensions = ['.py', '.md', '.ipynb']
    
    updated_files = 0
    directory = Path(directory)
    
    # Recorrer todos los archivos en el directorio y subdirectorios
    for file_path in directory.glob('**/*'):
        if file_path.is_file() and file_path.suffix in extensions:
            # Excluir directorios específicos
            if any(part.startswith('.') for part in file_path.parts):
                continue
            if 'venv' in file_path.parts or 'env' in file_path.parts:
                continue
            
            if update_imports_in_file(file_path):
                updated_files += 1
    
    return updated_files


def update_internal_package_imports():
    """
    Actualiza las importaciones dentro del paquete para usar importaciones relativas 
    en lugar de importaciones absolutas con src.cv_screening.
    """
    package_dir = Path("src/cv_screening")
    updated_files = 0
    
    for file_path in package_dir.glob('**/*.py'):
        if file_path.is_file():
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Reemplazar try/except con importaciones absolutas
                updated_content = re.sub(
                    r'try:\n\s+# Intenta importación relativa.*?except ImportError:\n\s+# Fallback a importación absoluta\n\s+from src\.cv_screening\.', 
                    r'from cv_screening.', 
                    content, 
                    flags=re.DOTALL
                )
                
                # Si hay cambios, escribir el archivo
                if content != updated_content:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(updated_content)
                    print(f"Actualizado (imports internos): {file_path}")
                    updated_files += 1
            except Exception as e:
                print(f"Error al procesar imports internos {file_path}: {str(e)}")
    
    return updated_files


def update_setup_py():
    """Actualizar el archivo setup.py para modificar la estructura del paquete."""
    setup_file = "setup.py"
    
    try:
        with open(setup_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Modificar la configuración de paquetes para no usar src/ como directorio
        if 'package_dir={"": "src"}' in content:
            # Reemplazar la configuración de paquetes
            updated_content = content.replace(
                'package_dir={"": "src"}',
                'package_dir={}',
            )
            updated_content = updated_content.replace(
                'packages=find_packages(where="src")',
                'packages=find_packages()',
            )
            
            with open(setup_file, 'w', encoding='utf-8') as f:
                f.write(updated_content)
            
            print(f"Actualizado: {setup_file}")
            return True
        else:
            print(f"No se encontró la configuración esperada en {setup_file}")
            return False
    except Exception as e:
        print(f"Error al actualizar {setup_file}: {str(e)}")
        return False


def main():
    """Función principal que actualiza todas las importaciones."""
    print("Actualizando importaciones en el proyecto...")
    
    # Actualizar importaciones en archivos del proyecto
    dirs_to_update = [".", "examples", "tests"]
    total_updated = 0
    
    for directory in dirs_to_update:
        if os.path.exists(directory):
            updated = update_imports_in_directory(directory)
            total_updated += updated
            print(f"Archivos actualizados en {directory}: {updated}")
        else:
            print(f"El directorio {directory} no existe.")
    
    # Actualizar importaciones internas en el paquete
    internal_updated = update_internal_package_imports()
    total_updated += internal_updated
    print(f"Archivos con importaciones internas actualizados: {internal_updated}")
    
    # Actualizar setup.py
    if update_setup_py():
        total_updated += 1
    
    print(f"Total de archivos actualizados: {total_updated}")
    print("\nProceso completado.")
    print("\nAhora necesitas mover el código de src/cv_screening a la raíz del proyecto.")
    print("Ejecuta los siguientes comandos:")
    print("1. mkdir -p cv_screening")
    print("2. cp -r src/cv_screening/* cv_screening/")
    print("3. rm -rf src/cv_screening")
    print("\nLuego reinstala el paquete con: pip install -e .")
    print("Y ejecuta los tests para verificar que todo funcione correctamente.")


if __name__ == "__main__":
    main() 