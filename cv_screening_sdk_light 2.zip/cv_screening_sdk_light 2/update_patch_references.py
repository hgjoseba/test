#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Script para actualizar las referencias en los decoradores patch
y otras importaciones en los archivos de prueba.
"""

import os
import re
import sys

def update_references_in_file(file_path):
    """Actualizar las referencias en un archivo."""
    # Leer el contenido del archivo
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 1. Reemplazar las importaciones de 'from src.' por 'from cv_screening.'
    updated_content = re.sub(
        r'from src\.(?!cv_screening\.)([a-zA-Z0-9_\.]+) import', 
        r'from cv_screening.\1 import', 
        content
    )
    
    # 2. Reemplazar las referencias en patch('src.X')
    updated_content = re.sub(
        r'patch\([\'"]src\.(?!cv_screening\.)([a-zA-Z0-9_\.]+)[\'"]', 
        r'patch("src.cv_screening.\1"', 
        updated_content
    )
    
    # Si hay cambios, escribir el archivo
    if content != updated_content:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(updated_content)
        print(f"Actualizado: {file_path}")
    else:
        print(f"Sin cambios: {file_path}")

def update_test_files():
    """Recorrer los archivos de test y actualizar las referencias."""
    tests_dir = "tests"
    if not os.path.exists(tests_dir):
        print(f"El directorio {tests_dir} no existe.")
        return
    
    # Recorrer los archivos de test
    for file_name in os.listdir(tests_dir):
        if file_name.endswith(".py") and file_name.startswith("test_"):
            file_path = os.path.join(tests_dir, file_name)
            update_references_in_file(file_path)

if __name__ == "__main__":
    update_test_files()
    print("Proceso completado.") 