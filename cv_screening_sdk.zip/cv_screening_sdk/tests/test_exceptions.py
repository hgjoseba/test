"""
Unit tests for SDK exceptions.
"""

import pytest
from cv_screening_sdk.core.exceptions import (
    SDKError,
    ValidationError,
    ProcessingError,
    LLMError,
    ProviderError,
    AuthenticationError,
    ConfigurationError
)


class TestSDKError:
    """Test suite for base SDK exception."""

    def test_sdk_error_initialization(self):
        """Test SDK error initialization."""
        error = SDKError("Test error")
        assert str(error) == "Test error"
        assert error.message == "Test error"
        assert error.details is None

    def test_sdk_error_with_details(self):
        """Test SDK error with details."""
        details = {"field": "value"}
        error = SDKError("Test error", details)
        assert str(error) == "Test error"
        assert error.message == "Test error"
        assert error.details == details


class TestValidationError:
    """Test suite for validation exception."""

    def test_validation_error_initialization(self):
        """Test validation error initialization."""
        error = ValidationError("Invalid input")
        assert str(error) == "Invalid input"
        assert error.message == "Invalid input"
        assert error.details is None
        assert isinstance(error, SDKError)

    def test_validation_error_with_details(self):
        """Test validation error with details."""
        details = {"field": "value", "error": "Invalid format"}
        error = ValidationError("Invalid input", details)
        assert str(error) == "Invalid input"
        assert error.message == "Invalid input"
        assert error.details == details


class TestProcessingError:
    """Test suite for processing exception."""

    def test_processing_error_initialization(self):
        """Test processing error initialization."""
        error = ProcessingError("Processing failed")
        assert str(error) == "Processing failed"
        assert error.message == "Processing failed"
        assert error.details is None
        assert isinstance(error, SDKError)

    def test_processing_error_with_details(self):
        """Test processing error with details."""
        details = {"step": "analysis", "error": "Timeout"}
        error = ProcessingError("Processing failed", details)
        assert str(error) == "Processing failed"
        assert error.message == "Processing failed"
        assert error.details == details


class TestLLMError:
    """Test suite for LLM exception."""

    def test_llm_error_initialization(self):
        """Test LLM error initialization."""
        error = LLMError("LLM operation failed")
        assert str(error) == "LLM operation failed"
        assert error.message == "LLM operation failed"
        assert error.details is None
        assert isinstance(error, SDKError)

    def test_llm_error_with_details(self):
        """Test LLM error with details."""
        details = {"model": "gpt-4", "error": "API error"}
        error = LLMError("LLM operation failed", details)
        assert str(error) == "LLM operation failed"
        assert error.message == "LLM operation failed"
        assert error.details == details


class TestProviderError:
    """Test suite for provider exception."""

    def test_provider_error_initialization(self):
        """Test provider error initialization."""
        error = ProviderError("Provider operation failed")
        assert str(error) == "Provider operation failed"
        assert error.message == "Provider operation failed"
        assert error.details is None
        assert isinstance(error, SDKError)

    def test_provider_error_with_details(self):
        """Test provider error with details."""
        details = {"provider": "azure", "error": "Connection failed"}
        error = ProviderError("Provider operation failed", details)
        assert str(error) == "Provider operation failed"
        assert error.message == "Provider operation failed"
        assert error.details == details


class TestAuthenticationError:
    """Test suite for authentication exception."""

    def test_authentication_error_initialization(self):
        """Test authentication error initialization."""
        error = AuthenticationError("Authentication failed")
        assert str(error) == "Authentication failed"
        assert error.message == "Authentication failed"
        assert error.details is None
        assert isinstance(error, SDKError)

    def test_authentication_error_with_details(self):
        """Test authentication error with details."""
        details = {"service": "azure", "error": "Invalid credentials"}
        error = AuthenticationError("Authentication failed", details)
        assert str(error) == "Authentication failed"
        assert error.message == "Authentication failed"
        assert error.details == details


class TestConfigurationError:
    """Test suite for configuration exception."""

    def test_configuration_error_initialization(self):
        """Test configuration error initialization."""
        error = ConfigurationError("Invalid configuration")
        assert str(error) == "Invalid configuration"
        assert error.message == "Invalid configuration"
        assert error.details is None
        assert isinstance(error, SDKError)

    def test_configuration_error_with_details(self):
        """Test configuration error with details."""
        details = {"section": "azure", "error": "Missing required field"}
        error = ConfigurationError("Invalid configuration", details)
        assert str(error) == "Invalid configuration"
        assert error.message == "Invalid configuration"
        assert error.details == details 