"""
Additional tests for the coverage of Azure authentication classes.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from azure.core.credentials import AccessToken
from azure.core.exceptions import ClientAuthenticationError
from cv_screening_sdk.core.exceptions import AuthenticationError
from cv_screening_sdk.auth.azure import AzureCredentials, AzureAuthProvider
import time


class TestAzureAuthProviderAdditional:
    """Additional tests for AzureAuthProvider."""

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_validate_credentials_success(self, mock_credentials_class):
        """Test that validate_credentials works correctly with valid credentials."""
        # Setup
        mock_credentials_instance = Mock()
        mock_credentials_class.return_value = mock_credentials_instance
        
        mock_credential = Mock()
        mock_credentials_instance.get_credential.return_value = mock_credential
        
        # Mock for the token
        mock_token = AccessToken("dummy_token", int(time.time()) + 3600)
        mock_credential.get_token.return_value = mock_token
        
        # Test
        provider = AzureAuthProvider()
        result = provider.validate_credentials()
        
        # Verification
        assert result is True
        mock_credential.get_token.assert_called_once_with("https://cognitiveservices.azure.com/.default")

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_validate_credentials_client_auth_error(self, mock_credentials_class):
        """Test that validate_credentials correctly handles client authentication errors."""
        # Setup
        mock_credentials_instance = Mock()
        mock_credentials_class.return_value = mock_credentials_instance
        
        mock_credential = Mock()
        mock_credentials_instance.get_credential.return_value = mock_credential
        
        # Simulate an authentication error
        mock_credential.get_token.side_effect = ClientAuthenticationError("Test authentication error")
        
        # Test
        provider = AzureAuthProvider()
        with pytest.raises(AuthenticationError) as exc_info:
            provider.validate_credentials()
        
        # Verification
        assert "Failed to validate credentials: Test authentication error" in str(exc_info.value)

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_validate_credentials_generic_error(self, mock_credentials_class):
        """Test that validate_credentials correctly handles generic errors."""
        # Setup
        mock_credentials_instance = Mock()
        mock_credentials_class.return_value = mock_credentials_instance
        
        mock_credential = Mock()
        mock_credentials_instance.get_credential.return_value = mock_credential
        
        # Simulate a generic error
        mock_credential.get_token.side_effect = Exception("Test unexpected error")
        
        # Test
        provider = AzureAuthProvider()
        with pytest.raises(AuthenticationError) as exc_info:
            provider.validate_credentials()
        
        # Verification
        assert "Unexpected error validating credentials: Test unexpected error" in str(exc_info.value)

    def test_refresh_credentials(self):
        """Test that refresh_credentials correctly recreates the credentials."""
        # Setup - create a provider with mock credentials
        provider = AzureAuthProvider(
            tenant_id="test-tenant-id",
            client_id="test-client-id",
            client_secret="test-client-secret",
            connection_verify=False
        )
        
        # Save the original credentials for comparison
        original_credentials = provider._credentials
        
        # Test - refresh the credentials
        provider.refresh_credentials()
        
        # Verification - the credentials should be a new instance with the same values
        assert provider._credentials is not original_credentials
        assert provider._credentials.tenant_id == original_credentials.tenant_id
        assert provider._credentials.client_id == original_credentials.client_id
        assert provider._credentials.client_secret == original_credentials.client_secret
        assert provider._credentials.connection_verify == original_credentials.connection_verify

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_get_token_success(self, mock_credentials_class):
        """Test that get_token works correctly."""
        # Setup
        mock_credentials_instance = Mock()
        mock_credentials_class.return_value = mock_credentials_instance
        
        mock_credential = Mock()
        mock_credentials_instance.get_credential.return_value = mock_credential
        
        # Mock for the token
        mock_token = AccessToken("dummy_token", int(time.time()) + 3600)
        mock_credential.get_token.return_value = mock_token
        
        # Test
        provider = AzureAuthProvider()
        result = provider.get_token()
        
        # Verification
        assert result == "dummy_token"
        mock_credential.get_token.assert_called_once()

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_get_token_error(self, mock_credentials_class):
        """Test that get_token correctly handles errors."""
        # Setup
        mock_credentials_instance = Mock()
        mock_credentials_class.return_value = mock_credentials_instance
        
        mock_credential = Mock()
        mock_credentials_instance.get_credential.return_value = mock_credential
        
        # Simulate an authentication error
        mock_credential.get_token.side_effect = ClientAuthenticationError("Test token error")
        
        # Test
        provider = AzureAuthProvider()
        with pytest.raises(AuthenticationError) as exc_info:
            provider.get_token()
        
        # Verification
        assert "Failed to get authentication token: Test token error" in str(exc_info.value)

    @patch("cv_screening_sdk.auth.azure.AzureAuthProvider.get_token")
    @pytest.mark.asyncio
    async def test_get_token_async(self, mock_get_token):
        """Test that get_token_async correctly calls get_token."""
        # Setup
        mock_get_token.return_value = "dummy_token"
        
        # Test
        provider = AzureAuthProvider()
        result = await provider.get_token_async()
        
        # Verification
        assert result == "dummy_token"
        mock_get_token.assert_called_once()

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_auth_provider_initialization_error(self, mock_credentials_class):
        """Test that the initializer correctly handles errors."""
        # Setup
        mock_credentials_class.side_effect = Exception("Test initialization error")
        
        # Test
        with pytest.raises(AuthenticationError) as exc_info:
            AzureAuthProvider()
        
        # Verification
        assert "Failed to initialize Azure auth provider: Test initialization error" in str(exc_info.value) 