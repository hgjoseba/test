"""
Unit tests for SDK data models.
"""

import pytest
from cv_screening_sdk.core.exceptions import ValidationError
from cv_screening_sdk.models import (
    JobCriteria,
    TestCVScreeningResult as CVScreeningResult,
    TestSkillMatch as SkillMatch,
    CandidateProfile,
    OverallAssessment
)


class TestJobCriteria:
    """Test suite for job criteria model."""

    def test_job_criteria_initialization(self):
        """Test job criteria initialization."""
        criteria = JobCriteria(
            required_skills=["Python", "SQL"],
            preferred_skills=["Docker", "Kubernetes"],
            min_years_experience=3,
            education_level="Bachelor",
            role_title="Senior Software Engineer"
        )
        assert criteria.required_skills == ["Python", "SQL"]
        assert criteria.preferred_skills == ["Docker", "Kubernetes"]
        assert criteria.min_years_experience == 3
        assert criteria.education_level == "bachelors"
        assert criteria.role_title == "Senior Software Engineer"

    def test_job_criteria_validation(self):
        """Test job criteria validation."""
        with pytest.raises(ValidationError):
            JobCriteria(
                required_skills=[],
                preferred_skills=["Docker"],
                min_years_experience=-1,
                education_level="",
                role_title=""
            )

    def test_job_criteria_from_dict(self):
        """Test job criteria creation from dictionary."""
        criteria_dict = {
            "required_skills": ["Python", "SQL"],
            "preferred_skills": ["Docker", "Kubernetes"],
            "min_years_experience": 3,
            "education_level": "Bachelor",
            "role_title": "Senior Software Engineer"
        }
        criteria = JobCriteria.from_dict(criteria_dict)
        assert criteria.required_skills == criteria_dict["required_skills"]
        assert criteria.preferred_skills == criteria_dict["preferred_skills"]
        assert criteria.min_years_experience == criteria_dict["min_years_experience"]
        assert criteria.education_level == "bachelors"
        assert criteria.role_title == criteria_dict["role_title"]

    def test_job_criteria_to_dict(self):
        """Test job criteria conversion to dictionary."""
        criteria = JobCriteria(
            required_skills=["Python", "SQL"],
            preferred_skills=["Docker", "Kubernetes"],
            min_years_experience=3,
            education_level="Bachelor",
            role_title="Senior Software Engineer"
        )
        criteria_dict = criteria.to_dict()
        assert criteria_dict["required_skills"] == criteria.required_skills
        assert criteria_dict["preferred_skills"] == criteria.preferred_skills
        assert criteria_dict["min_years_experience"] == criteria.min_years_experience
        assert criteria_dict["education_level"] == criteria.education_level
        assert criteria_dict["role_title"] == criteria.role_title


class TestSkillMatch:
    """Test suite for skill match model."""

    def test_skill_match_initialization(self):
        """Test skill match initialization."""
        match = SkillMatch(
            skill="Python",
            is_required=True,
            confidence=0.9,
            context="5 years of experience"
        )
        assert match.skill == "Python"
        assert match.is_required is True
        assert match.confidence == 0.9
        assert match.context == "5 years of experience"

    def test_skill_match_validation(self):
        """Test skill match validation."""
        with pytest.raises(ValueError):
            SkillMatch(
                skill="",
                is_required=True,
                confidence=1.5,
                context=""
            )

    def test_skill_match_from_dict(self):
        """Test skill match creation from dictionary."""
        match_dict = {
            "skill": "Python",
            "is_required": True,
            "confidence": 0.9,
            "context": "5 years of experience"
        }
        match = SkillMatch.from_dict(match_dict)
        assert match.skill == match_dict["skill"]
        assert match.is_required == match_dict["is_required"]
        assert match.confidence == match_dict["confidence"]
        assert match.context == match_dict["context"]

    def test_skill_match_to_dict(self):
        """Test skill match conversion to dictionary."""
        match = SkillMatch(
            skill="Python",
            is_required=True,
            confidence=0.9,
            context="5 years of experience"
        )
        match_dict = match.to_dict()
        assert match_dict["skill"] == match.skill
        assert match_dict["is_required"] == match.is_required
        assert match_dict["confidence"] == match.confidence
        assert match_dict["context"] == match.context


class TestCandidateProfile:
    """Test suite for candidate profile model."""

    def test_candidate_profile_initialization(self):
        """Test candidate profile initialization."""
        profile = CandidateProfile(
            years_experience=5,
            education_level="Bachelor",
            current_role="Software Engineer",
            key_achievements=["Led team of 5", "Improved performance by 50%"]
        )
        assert profile.years_experience == 5
        assert profile.education_level == "Bachelor"
        assert profile.current_role == "Software Engineer"
        assert profile.key_achievements == ["Led team of 5", "Improved performance by 50%"]

    def test_candidate_profile_validation(self):
        """Test candidate profile validation."""
        with pytest.raises(ValueError):
            CandidateProfile(
                years_experience=-1,
                education_level="",
                current_role="",
                key_achievements=[]
            )

    def test_candidate_profile_from_dict(self):
        """Test candidate profile creation from dictionary."""
        profile_dict = {
            "years_experience": 5,
            "education_level": "Bachelor",
            "current_role": "Software Engineer",
            "key_achievements": ["Led team of 5", "Improved performance by 50%"]
        }
        profile = CandidateProfile.from_dict(profile_dict)
        assert profile.years_experience == profile_dict["years_experience"]
        assert profile.education_level == profile_dict["education_level"]
        assert profile.current_role == profile_dict["current_role"]
        assert profile.key_achievements == profile_dict["key_achievements"]

    def test_candidate_profile_to_dict(self):
        """Test candidate profile conversion to dictionary."""
        profile = CandidateProfile(
            years_experience=5,
            education_level="Bachelor",
            current_role="Software Engineer",
            key_achievements=["Led team of 5", "Improved performance by 50%"]
        )
        profile_dict = profile.to_dict()
        assert profile_dict["years_experience"] == profile.years_experience
        assert profile_dict["education_level"] == profile.education_level
        assert profile_dict["current_role"] == profile.current_role
        assert profile_dict["key_achievements"] == profile.key_achievements


class TestOverallAssessment:
    """Test suite for overall assessment model."""

    def test_overall_assessment_initialization(self):
        """Test overall assessment initialization."""
        assessment = OverallAssessment(
            strengths=["Strong technical skills", "Good communication"],
            weaknesses=["Limited cloud experience", "No team lead experience"],
            recommendations=["Get AWS certification", "Take leadership training"]
        )
        assert assessment.strengths == ["Strong technical skills", "Good communication"]
        assert assessment.weaknesses == ["Limited cloud experience", "No team lead experience"]
        assert assessment.recommendations == ["Get AWS certification", "Take leadership training"]

    def test_overall_assessment_validation(self):
        """Test overall assessment validation."""
        with pytest.raises(ValueError):
            OverallAssessment(
                strengths=[],
                weaknesses=[],
                recommendations=[]
            )

    def test_overall_assessment_from_dict(self):
        """Test overall assessment creation from dictionary."""
        assessment_dict = {
            "strengths": ["Strong technical skills", "Good communication"],
            "weaknesses": ["Limited cloud experience", "No team lead experience"],
            "recommendations": ["Get AWS certification", "Take leadership training"]
        }
        assessment = OverallAssessment.from_dict(assessment_dict)
        assert assessment.strengths == assessment_dict["strengths"]
        assert assessment.weaknesses == assessment_dict["weaknesses"]
        assert assessment.recommendations == assessment_dict["recommendations"]

    def test_overall_assessment_to_dict(self):
        """Test overall assessment conversion to dictionary."""
        assessment = OverallAssessment(
            strengths=["Strong technical skills", "Good communication"],
            weaknesses=["Limited cloud experience", "No team lead experience"],
            recommendations=["Get AWS certification", "Take leadership training"]
        )
        assessment_dict = assessment.to_dict()
        assert assessment_dict["strengths"] == assessment.strengths
        assert assessment_dict["weaknesses"] == assessment.weaknesses
        assert assessment_dict["recommendations"] == assessment.recommendations


class TestCVScreeningResult:
    """Test suite for CV screening result model."""

    @pytest.fixture
    def skill_matches(self):
        """Create test skill matches."""
        return [
            SkillMatch(
                skill="Python",
                is_required=True,
                confidence=0.9,
                context="5 years of experience"
            ),
            SkillMatch(
                skill="Docker",
                is_required=False,
                confidence=0.7,
                context="2 years of experience"
            )
        ]

    @pytest.fixture
    def candidate_profile(self):
        """Create test candidate profile."""
        return CandidateProfile(
            years_experience=5,
            education_level="Bachelor",
            current_role="Software Engineer",
            key_achievements=["Led team of 5", "Improved performance by 50%"]
        )

    @pytest.fixture
    def overall_assessment(self):
        """Create test overall assessment."""
        return OverallAssessment(
            strengths=["Strong technical skills", "Good communication"],
            weaknesses=["Limited cloud experience", "No team lead experience"],
            recommendations=["Get AWS certification", "Take leadership training"]
        )

    def test_cv_screening_result_initialization(
        self, skill_matches, candidate_profile, overall_assessment
    ):
        """Test CV screening result initialization."""
        result = CVScreeningResult(
            overall_score=0.85,
            skill_matches=skill_matches,
            candidate_profile=candidate_profile,
            overall_assessment=overall_assessment
        )
        assert result.overall_score == 0.85
        assert result.skill_matches == skill_matches
        assert result.candidate_profile == candidate_profile
        assert result.overall_assessment == overall_assessment

    def test_cv_screening_result_validation(
        self, skill_matches, candidate_profile, overall_assessment
    ):
        """Test CV screening result validation."""
        with pytest.raises(ValueError):
            CVScreeningResult(
                overall_score=1.5,
                skill_matches=[],
                candidate_profile=candidate_profile,
                overall_assessment=overall_assessment
            )

    def test_cv_screening_result_from_dict(
        self, skill_matches, candidate_profile, overall_assessment
    ):
        """Test CV screening result creation from dictionary."""
        result_dict = {
            "overall_score": 0.85,
            "skill_matches": [match.to_dict() for match in skill_matches],
            "candidate_profile": candidate_profile.to_dict(),
            "overall_assessment": overall_assessment.to_dict()
        }
        result = CVScreeningResult.from_dict(result_dict)
        assert result.overall_score == result_dict["overall_score"]
        assert [match.to_dict() for match in result.skill_matches] == result_dict["skill_matches"]
        assert result.candidate_profile.to_dict() == result_dict["candidate_profile"]
        assert result.overall_assessment.to_dict() == result_dict["overall_assessment"]

    def test_cv_screening_result_to_dict(
        self, skill_matches, candidate_profile, overall_assessment
    ):
        """Test CV screening result conversion to dictionary."""
        result = CVScreeningResult(
            overall_score=0.85,
            skill_matches=skill_matches,
            candidate_profile=candidate_profile,
            overall_assessment=overall_assessment
        )
        result_dict = result.to_dict()
        assert result_dict["overall_score"] == result.overall_score
        assert result_dict["skill_matches"] == [match.to_dict() for match in result.skill_matches]
        assert result_dict["candidate_profile"] == result.candidate_profile.to_dict()
        assert result_dict["overall_assessment"] == result.overall_assessment.to_dict() 