"""
Unit tests for CV Screening SDK client.
"""

import pytest
from unittest.mock import AsyncMock, Mock, patch
from cv_screening_sdk.client import CVScreeningClient
from cv_screening_sdk.core.exceptions import ValidationError, ProcessingError
from cv_screening_sdk.models.criteria import JobCriteria
from cv_screening_sdk.models.results import CVScreeningResult


class TestCVScreeningClient:
    """Test suite for CV Screening SDK client."""

    @pytest.fixture
    def client(self):
        """Create client instance for tests."""
        from cv_screening_sdk.client import CVScreeningClient
        from unittest.mock import MagicMock, AsyncMock
        
        # Create client
        client = CVScreeningClient()
        
        # Replace analyze methods with AsyncMocks
        client.analyze_cv = AsyncMock()
        client.analyze_cv_async = AsyncMock()
        
        return client

    def test_client_initialization(self, client):
        """Test client initialization."""
        assert client.provider is not None
        assert client.logger is not None

    @pytest.mark.asyncio
    async def test_analyze_cv_with_valid_input(self, client, test_cv_content, test_criteria, test_screening_result):
        """Test CV analysis with valid input."""
        # Set up the mock to return the test_screening_result
        client.analyze_cv.return_value = test_screening_result
        
        # Call the method and check the result
        result = await client.analyze_cv(test_cv_content, test_criteria)
        
        # Verify it's the expected instance
        assert result == test_screening_result
        assert client.analyze_cv.called

    @pytest.mark.asyncio
    async def test_analyze_cv_with_analysis_error(self, client, test_cv_content, test_criteria):
        """Test CV analysis with analysis error."""
        # Set up the method to raise an exception
        client.analyze_cv.side_effect = ProcessingError("Analysis failed")
        
        # Should raise ProcessingError
        with pytest.raises(ProcessingError) as exc_info:
            await client.analyze_cv(test_cv_content, test_criteria)
        
        assert "Analysis failed" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_analyze_cv_with_invalid_criteria(self, client, test_cv_content):
        """Test CV analysis with invalid criteria."""
        from cv_screening_sdk.core.exceptions import ValidationError
        
        # Remove the AsyncMock for this test to access the real method
        client._process_criteria = CVScreeningClient._process_criteria.__get__(client, CVScreeningClient)
        
        # Using an invalid criteria type
        invalid_criteria = 123  # Invalid type
        
        # Test directly the _process_criteria method
        with pytest.raises(ValidationError) as exc_info:
            client._process_criteria(invalid_criteria)
            
        # Check that the error message contains the expected text
        assert "Invalid criteria format" in str(exc_info.value)

    @pytest.mark.asyncio
    async def test_analyze_cv_async(self, client, test_cv_content, test_criteria, test_screening_result):
        """Test asynchronous CV analysis."""
        # Set up the mock to return the test_screening_result
        client.analyze_cv_async.return_value = test_screening_result
        
        # Call the method and check the result
        result = await client.analyze_cv_async(test_cv_content, test_criteria)
        
        # Verify it's the expected instance
        assert result == test_screening_result
        assert client.analyze_cv_async.called

    def test_process_criteria_with_job_criteria(self, client):
        """Test processing criteria with JobCriteria object."""
        from cv_screening_sdk.models.criteria import JobCriteria
        criteria = JobCriteria(
            required_skills=["Python", "AWS"],
            preferred_skills=["Docker", "Kubernetes"],
            min_years_experience=3,
            education_level="bachelors"
        )
        processed = client._process_criteria(criteria)
        assert processed["required_skills"] == ["Python", "AWS"]
        assert processed["preferred_skills"] == ["Docker", "Kubernetes"]
        assert processed["min_years_experience"] == 3
        assert processed["education_level"] == "Bachelor's"

    def test_process_criteria_with_dict(self, client):
        """Test processing criteria with dictionary."""
        criteria = {
            "required_skills": ["Python", "AWS"],
            "preferred_skills": ["Docker", "Kubernetes"],
            "min_years_experience": 3,
            "education_level": "Bachelor's"
        }
        processed = client._process_criteria(criteria)
        assert processed == criteria

    def test_process_criteria_with_string(self, client):
        """Test processing criteria with string."""
        criteria = "Analyze this CV for a Python developer position"
        processed = client._process_criteria(criteria)
        assert processed == {"prompt": criteria}

    def test_process_criteria_with_none(self, client):
        """Test processing criteria with None."""
        processed = client._process_criteria(None)
        assert processed == {} 