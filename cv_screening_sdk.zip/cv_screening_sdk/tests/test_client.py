import unittest
from unittest.mock import patch

from src import AzureCredentials, CVScreeningClient


class TestCVScreeningClient(unittest.TestCase):
    def setUp(self):
        self.credentials = AzureCredentials(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
        )
        self.client = CVScreeningClient(
            credentials=self.credentials,
            azure_endpoint="https://test.openai.azure.com",
            deployment_name="test-deployment",
        )

    @patch("cv_screening_sdk.client.DocumentParser")
    @patch("cv_screening_sdk.client.AzureOpenAIAdapter")
    def test_screen_cv(self, mock_llm, mock_parser):
        # Setup mocks
        mock_parser.return_value.parse.return_value = "Test CV content"
        mock_llm.return_value.analyze_cv.return_value = {
            "score": 85.0,
            "skills_match": {"python": 0.9},
            "experience_match": {"years": 5},
            "education_match": {"level": "masters"},
            "summary": "Great candidate",
        }

        # Test single CV screening
        result = self.client.screen_cv("test_cv.pdf")

        # Assertions
        self.assertEqual(result.score, 85.0)
        self.assertIn("python", result.skills_match)
        mock_parser.return_value.parse.assert_called_once_with("test_cv.pdf")

    @patch("cv_screening_sdk.client.DocumentParser")
    @patch("cv_screening_sdk.client.AzureOpenAIAdapter")
    def test_batch_screen_cvs(self, mock_llm, mock_parser):
        # Setup mocks
        mock_parser.return_value.parse_async.return_value = "Test CV content"
        mock_llm.return_value.analyze_cv_async.return_value = {
            "score": 85.0,
            "skills_match": {"python": 0.9},
            "experience_match": {"years": 5},
            "education_match": {"level": "masters"},
            "summary": "Great candidate",
        }

        # Test batch CV screening
        cvs = ["cv1.pdf", "cv2.pdf"]
        result = self.client.batch_screen_cvs(cvs)

        # Assertions
        self.assertEqual(len(result.successful), 2)
        self.assertEqual(len(result.failed), 0)
        self.assertEqual(result.success_rate, 100.0)


if __name__ == "__main__":
    unittest.main()
