"""
Unit tests for Azure provider.
"""

import pytest
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from openai.types.chat import ChatCompletion
from cv_screening_sdk.providers.azure import AzureProvider
from cv_screening_sdk.core.exceptions import ProviderError, ProcessingError, LLMError


@pytest.fixture
def provider(mock_azure_credential):
    """Create test provider instance."""
    return AzureProvider(
        endpoint="https://test.openai.azure.com/",
        deployment="test-deployment",
        api_version="2023-05-15",
        tenant_id="00000000-0000-0000-0000-000000000000",
        client_id="00000000-0000-0000-0000-000000000000",
        client_secret="test-secret",
        ssl_verify=False,
        ssl_cert_path=None,
        connection_verify=False,
        connection_timeout=60,
        max_keepalive_connections=10,
        max_connections=20
    )


class TestAzureProvider:
    """Test suite for Azure provider."""

    def test_provider_initialization(self, provider):
        """Test provider initialization."""
        assert provider.endpoint == "https://test.openai.azure.com/"
        assert provider.deployment == "test-deployment"
        assert provider.api_version == "2023-05-15"
        assert provider.ssl_verify is False
        assert provider.ssl_cert_path is None
        assert provider.connection_timeout == 60
        assert provider.max_keepalive_connections == 10
        assert provider.max_connections == 20
        assert provider.client is None

    @patch("cv_screening_sdk.providers.azure.httpx.Client")
    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_initialize(self, mock_client_class, mock_httpx_client, provider):
        """Test provider initialization."""
        # Setup mock token
        mock_token = "test-token"
        
        # Override auth_provider.get_token
        provider.auth_provider.get_token = Mock(return_value=mock_token)
        
        # Setup mock client
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        # Setup mock httpx client
        mock_httpx = Mock()
        mock_httpx_client.return_value = mock_httpx
        
        # Call initialize
        provider.initialize()
        
        # Verify client was initialized correctly
        mock_client_class.assert_called_once()
        call_args = mock_client_class.call_args[1]
        
        # Check that the required arguments are present
        assert call_args["azure_endpoint"] == provider.endpoint
        assert call_args["api_version"] == provider.api_version
        assert call_args["azure_deployment"] == provider.deployment
        assert call_args["api_key"] == mock_token
        assert "http_client" in call_args
        
        # Verify httpx client was initialized with correct parameters
        mock_httpx_client.assert_called_once()
        httpx_args = mock_httpx_client.call_args[1]
        assert "timeout" in httpx_args
        assert "limits" in httpx_args
        assert "verify" in httpx_args or provider.ssl_verify is True

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_initialize_error(self, mock_client_class, provider):
        """Test provider initialization error."""
        mock_client_class.side_effect = Exception("Test error")
        # Override auth_provider.get_token
        provider.auth_provider.get_token = Mock(return_value=Mock())
        with pytest.raises(ProviderError) as exc_info:
            provider.initialize()
        assert str(exc_info.value) == "Failed to initialize Azure OpenAI client: Test error"

    @patch("cv_screening_sdk.providers.azure.AsyncAzureOpenAI")
    @pytest.mark.asyncio
    async def test_initialize_async(self, mock_client_class, provider):
        """Test async provider initialization."""
        # Setup mock token
        mock_token = "test-token"
        
        # Override auth_provider.get_token_async
        provider.auth_provider.get_token_async = AsyncMock(return_value=mock_token)
        
        # Setup mock client
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        # Call initialize_async
        await provider.initialize_async()
        
        # Verify client was initialized correctly
        mock_client_class.assert_called_once()
        call_args = mock_client_class.call_args[1]
        
        # Check that the required arguments are present
        assert call_args["azure_endpoint"] == provider.endpoint
        assert call_args["api_version"] == provider.api_version
        assert call_args["azure_deployment"] == provider.deployment
        assert call_args["api_key"] == mock_token

    @patch("cv_screening_sdk.providers.azure.AsyncAzureOpenAI")
    @pytest.mark.asyncio
    async def test_initialize_async_error(self, mock_client_class, provider):
        """Test async provider initialization error."""
        mock_client_class.side_effect = Exception("Test error")
        # Override auth_provider.get_token_async
        provider.auth_provider.get_token_async = AsyncMock(return_value=Mock())
        with pytest.raises(ProviderError) as exc_info:
            await provider.initialize_async()
        assert str(exc_info.value) == "Failed to initialize Azure OpenAI client: Test error"

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_get_chat_completion(self, mock_client_class, provider):
        """Test getting chat completion."""
        mock_client = Mock()
        mock_completions = Mock()
        mock_chat = Mock()
        
        # Setup the call chain mock_client.chat.completions.create()
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_create = Mock()
        mock_completions.create = mock_create
        
        # Create a proper mock response with attribute access structure
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(role="assistant", content="Test response"),
                finish_reason="stop"
            )
        ]
        mock_response.id = "test-id"
        mock_response.model = "test-model"
        mock_response.created = 1234567890
        mock_response.usage = Mock(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        
        mock_create.return_value = mock_response
        mock_client_class.return_value = mock_client
        
        # Skip actual initialization
        provider.client = mock_client
        result = provider.get_chat_completion([{"role": "user", "content": "Test message"}])
        
        # Verify result has the expected content
        assert "choices" in result
        assert len(result["choices"]) > 0
        assert "message" in result["choices"][0]
        assert "content" in result["choices"][0]["message"]
        assert result["choices"][0]["message"]["content"] == "Test response"
        
        mock_completions.create.assert_called_once()

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_get_chat_completion_error(self, mock_client_class, provider):
        """Test chat completion error."""
        mock_client = Mock()
        mock_chat = Mock()
        mock_completions = Mock()
        
        # Setup the call chain mock_client.chat.completions.create()
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_completions.create = Mock(side_effect=Exception("Test error"))
        
        mock_client_class.return_value = mock_client
        # Skip actual initialization
        provider.client = mock_client
        with pytest.raises(LLMError) as exc_info:
            provider.get_chat_completion([{"role": "user", "content": "Test message"}])
        assert str(exc_info.value) == "Failed to get chat completion: Test error"

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    @pytest.mark.asyncio
    async def test_get_chat_completion_async(self, mock_client_class, provider):
        """Test getting async chat completion."""
        mock_client = Mock()
        mock_chat = Mock()
        mock_completions = Mock()
        
        # Setup the call chain with AsyncMock for the create method
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_completions.create = AsyncMock()
        
        # Create a proper mock response with attribute access structure
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(role="assistant", content="Test response"),
                finish_reason="stop"
            )
        ]
        mock_response.id = "test-id"
        mock_response.model = "test-model"
        mock_response.created = 1234567890
        mock_response.usage = Mock(prompt_tokens=10, completion_tokens=20, total_tokens=30)
        
        mock_completions.create.return_value = mock_response
        mock_client_class.return_value = mock_client
        
        # Skip actual initialization
        provider.client = mock_client
        result = await provider.get_chat_completion_async([{"role": "user", "content": "Test message"}])
        
        # Verify result has the expected content
        assert "choices" in result
        assert len(result["choices"]) > 0
        assert "message" in result["choices"][0]
        assert "content" in result["choices"][0]["message"]
        assert result["choices"][0]["message"]["content"] == "Test response"
        
        mock_completions.create.assert_called_once()

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    @pytest.mark.asyncio
    async def test_get_chat_completion_async_error(self, mock_client_class, provider):
        """Test async chat completion error."""
        mock_client = Mock()
        mock_chat = Mock()
        mock_completions = Mock()
        
        # Setup the call chain with AsyncMock for the create method
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_completions.create = AsyncMock(side_effect=Exception("Test error"))
        
        mock_client_class.return_value = mock_client
        # Skip actual initialization
        provider.client = mock_client
        with pytest.raises(LLMError) as exc_info:
            await provider.get_chat_completion_async([{"role": "user", "content": "Test message"}])
        assert str(exc_info.value) == "Failed to get chat completion: Test error"

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_analyze_cv(self, mock_client_class, provider):
        """Test CV analysis."""
        mock_client = Mock()
        mock_chat = Mock()
        mock_completions = Mock()
        
        # Setup the call chain mock_client.chat.completions.create()
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_create = Mock()
        mock_completions.create = mock_create
        
        # Create a proper mock response with attribute access structure
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(
                    role="assistant", 
                    content='''{
                        "match_score": 0.95,
                        "skill_matches": {
                            "required_skills": {"Python": 1.0},
                            "preferred_skills": {},
                            "overall_score": 100.0,
                            "missing_required": [],
                            "missing_preferred": []
                        },
                        "experience_match": {
                            "years_of_experience": 5.0,
                            "relevance_score": 0.9,
                            "role_matches": [],
                            "meets_minimum": true,
                            "overall_score": 95.0
                        },
                        "education_match": {
                            "level_match": true,
                            "field_relevance": 0.9,
                            "overall_score": 90.0,
                            "education_details": {
                                "highest_level": "Bachelor's",
                                "field": "Computer Science"
                            }
                        }
                    }'''
                ),
                finish_reason="stop"
            )
        ]
        
        mock_create.return_value = mock_response
        mock_client_class.return_value = mock_client
        
        # Skip actual initialization
        provider.client = mock_client
        result = provider.analyze_cv("Test CV content", {"required_skills": ["Python"]})
        assert result["match_score"] == 0.95
        assert result["skill_matches"]["overall_score"] == 100.0
        mock_completions.create.assert_called_once()

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_analyze_cv_error(self, mock_client_class, provider):
        """Test CV analysis error."""
        mock_client = Mock()
        mock_chat = Mock()
        mock_completions = Mock()
        
        # Setup the call chain mock_client.chat.completions.create()
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_completions.create = Mock(side_effect=Exception("Test error"))
        
        mock_client_class.return_value = mock_client
        # Skip actual initialization
        provider.client = mock_client
        with pytest.raises(ProcessingError) as exc_info:
            provider.analyze_cv("Test CV content", {"required_skills": ["Python"]})
        assert "Failed to analyze CV: Failed to get chat completion: Test error" in str(exc_info.value)

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    @pytest.mark.asyncio
    async def test_analyze_cv_async(self, mock_client_class, provider):
        """Test async CV analysis."""
        mock_client = Mock()
        mock_chat = Mock()
        mock_completions = Mock()
        
        # Setup the call chain with AsyncMock for the create method
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_completions.create = AsyncMock()
        
        # Create a proper mock response with attribute access structure
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(
                    role="assistant", 
                    content='''{
                        "match_score": 0.95,
                        "skill_matches": {
                            "required_skills": {"Python": 1.0},
                            "preferred_skills": {},
                            "overall_score": 100.0,
                            "missing_required": [],
                            "missing_preferred": []
                        },
                        "experience_match": {
                            "years_of_experience": 5.0,
                            "relevance_score": 0.9,
                            "role_matches": [],
                            "meets_minimum": true,
                            "overall_score": 95.0
                        },
                        "education_match": {
                            "level_match": true,
                            "field_relevance": 0.9,
                            "overall_score": 90.0,
                            "education_details": {
                                "highest_level": "Bachelor's",
                                "field": "Computer Science"
                            }
                        }
                    }'''
                ),
                finish_reason="stop"
            )
        ]
        
        mock_completions.create.return_value = mock_response
        mock_client_class.return_value = mock_client
        
        # Skip actual initialization
        provider.client = mock_client
        result = await provider.analyze_cv_async("Test CV content", {"required_skills": ["Python"]})
        assert result["match_score"] == 0.95
        assert result["skill_matches"]["overall_score"] == 100.0
        mock_completions.create.assert_called_once()

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    @pytest.mark.asyncio
    async def test_analyze_cv_async_error(self, mock_client_class, provider):
        """Test async CV analysis error."""
        mock_client = Mock()
        mock_chat = Mock()
        mock_completions = Mock()
        
        # Setup the call chain with AsyncMock for the create method
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_completions.create = AsyncMock(side_effect=Exception("Test error"))
        
        mock_client_class.return_value = mock_client
        # Skip actual initialization
        provider.client = mock_client
        with pytest.raises(ProcessingError) as exc_info:
            await provider.analyze_cv_async("Test CV content", {"required_skills": ["Python"]})
        assert "Failed to analyze CV: Failed to get chat completion: Test error" in str(exc_info.value)

    @patch("cv_screening_sdk.providers.azure.httpx.Client")
    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_initialize_with_ssl_verify_false(self, mock_client_class, mock_httpx_client):
        """Test provider initialization with SSL verification disabled."""
        # Create provider with ssl_verify=False
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15",
            tenant_id="00000000-0000-0000-0000-000000000000",
            client_id="00000000-0000-0000-0000-000000000000",
            client_secret="test-secret",
            ssl_verify=False
        )
        
        # Setup mock token
        mock_token = "test-token"
        
        # Override auth_provider.get_token
        provider.auth_provider.get_token = Mock(return_value=mock_token)
        
        # Setup mock clients
        mock_client = Mock()
        mock_httpx_client_instance = Mock()
        mock_client_class.return_value = mock_client
        mock_httpx_client.return_value = mock_httpx_client_instance
        
        # Call initialize
        provider.initialize()
        
        # Verify clients were initialized correctly
        mock_client_class.assert_called_once()
        
        # Check that SSL verification is disabled in httpx.Client
        mock_httpx_client.assert_called_once()
        http_client_kwargs = mock_httpx_client.call_args[1]
        assert "verify" in http_client_kwargs
        assert http_client_kwargs["verify"] is False

    @patch("cv_screening_sdk.providers.azure.httpx.Client")
    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_initialize_with_ssl_cert_path(self, mock_client_class, mock_httpx_client):
        """Test provider initialization with custom SSL certificate path."""
        # Create provider with ssl_cert_path
        custom_cert_path = "/path/to/custom/cert.pem"
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15",
            tenant_id="00000000-0000-0000-0000-000000000000",
            client_id="00000000-0000-0000-0000-000000000000",
            client_secret="test-secret",
            ssl_cert_path=custom_cert_path
        )
        
        # Setup mock token
        mock_token = "test-token"
        
        # Override auth_provider.get_token
        provider.auth_provider.get_token = Mock(return_value=mock_token)
        
        # Setup mock clients
        mock_client = Mock()
        mock_httpx_client_instance = Mock()
        mock_client_class.return_value = mock_client
        mock_httpx_client.return_value = mock_httpx_client_instance
        
        # Call initialize
        provider.initialize()
        
        # Verify clients were initialized correctly
        mock_client_class.assert_called_once()
        
        # Check that custom SSL certificate path is used
        mock_httpx_client.assert_called_once()
        http_client_kwargs = mock_httpx_client.call_args[1]
        assert "verify" in http_client_kwargs
        assert http_client_kwargs["verify"] == custom_cert_path

    @patch("cv_screening_sdk.providers.azure.httpx.AsyncClient")
    @patch("cv_screening_sdk.providers.azure.AsyncAzureOpenAI")
    @pytest.mark.asyncio
    async def test_initialize_async_with_ssl_options(self, mock_client_class, mock_httpx_client):
        """Test async provider initialization with SSL options."""
        # Create provider with both SSL options
        custom_cert_path = "/path/to/custom/cert.pem"
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15",
            tenant_id="00000000-0000-0000-0000-000000000000",
            client_id="00000000-0000-0000-0000-000000000000",
            client_secret="test-secret",
            ssl_verify=False,
            ssl_cert_path=custom_cert_path
        )
        
        # Setup mock token
        mock_token = "test-token"
        
        # Override auth_provider.get_token_async
        provider.auth_provider.get_token_async = AsyncMock(return_value=mock_token)
        
        # Setup mock clients
        mock_client = Mock()
        mock_httpx_client_instance = Mock()
        mock_client_class.return_value = mock_client
        mock_httpx_client.return_value = mock_httpx_client_instance
        
        # Call initialize_async
        await provider.initialize_async()
        
        # Verify clients were initialized correctly
        mock_client_class.assert_called_once()
        
        # Check that SSL options are set (cert path takes precedence over verify=False)
        mock_httpx_client.assert_called_once()
        http_client_kwargs = mock_httpx_client.call_args[1]
        assert "verify" in http_client_kwargs
        assert http_client_kwargs["verify"] == custom_cert_path 