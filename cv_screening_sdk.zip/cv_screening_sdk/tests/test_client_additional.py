"""
Additional tests for the coverage of the main client.
"""

import pytest
import os
import tempfile
from unittest.mock import Mock, patch, AsyncMock
from cv_screening_sdk.client import CVScreeningClient
from cv_screening_sdk.core.exceptions import SDKError, ProcessingError, ValidationError
from cv_screening_sdk.core.config import SDKConfig, AzureConfig, ClientConfig
from cv_screening_sdk.models.results import CVScreeningResult, BatchProcessingResult


class TestCVScreeningClientAdditional:
    """Additional tests for the main client."""

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_initialize_with_custom_provider(self, mock_provider_class):
        """Test that initialize correctly configures a custom provider."""
        # Setup
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Test
        client = CVScreeningClient(config=config)
        
        # Verification
        assert client.provider is mock_provider
        mock_provider_class.assert_called_once()

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_set_criteria_and_get(self, mock_provider_class):
        """Test that set_criteria correctly stores the criteria."""
        # Setup
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and configure criteria
        client = CVScreeningClient(config=config)
        criteria = {
            "required_skills": ["Python", "SQL"],
            "preferred_skills": ["Docker"],
            "min_experience_years": 3,
            "education_level": "Bachelor"
        }
        
        # Test
        client.set_criteria(criteria)
        
        # Verification
        assert client.criteria == criteria
        assert client.get_criteria() == criteria

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_analyze_cv_text_with_criteria_parameter(self, mock_provider_class):
        """Test that analyze_cv uses the provided criteria instead of the default ones."""
        # Setup
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        # Configure mock result for the analysis
        mock_provider.analyze_cv.return_value = {
            "match_score": 0.85,
            "skill_matches": {"required_skills": {"Python": 1.0}},
            "experience_match": {"years_of_experience": 5}
        }
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and criteria
        client = CVScreeningClient(config=config)
        
        override_criteria = {
            "required_skills": ["Python"],
            "preferred_skills": ["Django"],
        }
        
        # Test
        result = client.analyze_cv("Test CV content", criteria=override_criteria)
        
        # Verification
        assert isinstance(result, CVScreeningResult)
        mock_provider.analyze_cv.assert_called_once()
        
        # Verify that the criteria were used
        call_args = mock_provider.analyze_cv.call_args[0]
        assert call_args[0] == "Test CV content"
        assert call_args[1] == override_criteria

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_analyze_cv_text_no_criteria(self, mock_provider_class):
        """Test that analyze_cv sin criterios lanza una excepción."""
        # Setup - crea un Mock específico para el análisis que devuelve resultados formatados
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        # Forzar un error de ValidationError desde el SDK
        mock_provider.analyze_cv.side_effect = ValidationError("Test validation error")
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client without configuring criteria
        client = CVScreeningClient(config=config)
        
        # Test - debería propagarse el error de validación desde el provider
        with pytest.raises(ValidationError) as exc_info:
            client.analyze_cv("Test CV content", criteria={})
        
        # Verificación - comprobamos que se produce el error de validación
        assert "Test validation error" in str(exc_info.value)

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_analyze_cv_text_provider_error(self, mock_provider_class):
        """Test that analyze_cv handles provider errors."""
        # Setup
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        mock_provider.analyze_cv.side_effect = ProcessingError("Test provider error")
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and criteria
        client = CVScreeningClient(config=config)
        
        criteria = {"required_skills": ["Python"]}
        
        # Test
        with pytest.raises(ProcessingError) as exc_info:
            client.analyze_cv("Test CV content", criteria=criteria)
        
        # Verification
        assert "Test provider error" in str(exc_info.value)

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_analyze_cv_file_success(self, mock_provider_class):
        """Test that screen_cv correctly reads a file and analyzes its content."""
        # Setup
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        # Configure mock result for the analysis
        mock_provider.analyze_cv.return_value = {
            "match_score": 0.85,
            "skill_matches": {"required_skills": {"Python": 1.0}},
            "experience_match": {"years_of_experience": 5}
        }
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and criteria
        client = CVScreeningClient(config=config)
        
        criteria = {"required_skills": ["Python"]}
        
        # Create a temporary file for testing
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
            temp_file.write("Test CV content in a file")
            temp_file_path = temp_file.name
            cv_content = "Test CV content in a file"
        
        # Test
        try:
            result = client.screen_cv(cv_content, criteria=criteria, cv_path=temp_file_path)
            
            # Verification
            assert isinstance(result, CVScreeningResult)
            mock_provider.analyze_cv.assert_called_once()
            
            # Verify that the file content was passed
            call_args = mock_provider.analyze_cv.call_args[0]
            assert "Test CV content in a file" in call_args[0]
        finally:
            # Cleanup - delete the temporary file
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_analyze_cv_file_not_found(self, mock_provider_class):
        """Test that loading CV file handles the case of file not found."""
        # Setup
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client
        client = CVScreeningClient(config=config)
        
        # Test with a non-existent file
        non_existent_file = "/path/to/nonexistent/file.txt"
        with pytest.raises(OSError) as exc_info:
            cv_content = client.load_cv_content(non_existent_file)
        
        # Verification
        assert "File not found" in str(exc_info.value)

    @patch("cv_screening_sdk.client.AzureProvider")
    @pytest.mark.asyncio
    async def test_analyze_cv_text_async(self, mock_provider_class):
        """Test that analyze_cv_async works correctly."""
        # Setup
        mock_provider = Mock()
        mock_provider.analyze_cv_async = AsyncMock()
        mock_provider_class.return_value = mock_provider
        
        # Configure mock result for the async analysis
        mock_provider.analyze_cv_async.return_value = {
            "match_score": 0.85,
            "skill_matches": {"required_skills": {"Python": 1.0}},
            "experience_match": {"years_of_experience": 5}
        }
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and criteria
        client = CVScreeningClient(config=config)
        
        criteria = {"required_skills": ["Python"]}
        
        # Test
        result = await client.analyze_cv_async("Test CV content", criteria=criteria)
        
        # Verification
        assert isinstance(result, CVScreeningResult)
        assert result.overall_score == 0.85  # match_score no está siendo convertido a escala 0-100

    @patch("cv_screening_sdk.client.AzureProvider")
    @pytest.mark.asyncio
    async def test_analyze_cv_file_async(self, mock_provider_class):
        """Test that screen_cv_async correctly analyzes content with a file reference."""
        # Setup
        mock_provider = Mock()
        mock_provider.analyze_cv_async = AsyncMock()
        mock_provider_class.return_value = mock_provider
        
        # Configure mock result for the async analysis
        mock_provider.analyze_cv_async.return_value = {
            "match_score": 0.85,
            "skill_matches": {"required_skills": {"Python": 1.0}},
            "experience_match": {"years_of_experience": 5}
        }
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and criteria
        client = CVScreeningClient(config=config)
        
        criteria = {"required_skills": ["Python"]}
        
        # Create a temporary file for testing
        with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
            temp_file.write("Test CV content in a file for async processing")
            temp_file_path = temp_file.name
            cv_content = "Test CV content in a file for async processing"
        
        # Test
        try:
            result = await client.screen_cv_async(cv_content, criteria=criteria, cv_path=temp_file_path)
            
            # Verification
            assert isinstance(result, CVScreeningResult)
            mock_provider.analyze_cv_async.assert_called_once()
            
            # Verify that the file content was passed
            call_args = mock_provider.analyze_cv_async.call_args[0]
            assert "Test CV content in a file for async processing" in call_args[0]
        finally:
            # Cleanup - delete the temporary file
            if os.path.exists(temp_file_path):
                os.unlink(temp_file_path)

    @patch("cv_screening_sdk.client.AzureProvider")
    def test_batch_analyze_sync(self, mock_provider_class):
        """Test that batch_analyze processes multiple CVs synchronously."""
        # Setup
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        # Configure mock result for the analysis
        mock_provider.analyze_cv.side_effect = [
            {
                "match_score": 0.85,
                "skill_matches": {"required_skills": {"Python": 1.0}},
                "experience_match": {"years_of_experience": 5}
            },
            {
                "match_score": 0.65,
                "skill_matches": {"required_skills": {"Python": 0.5}},
                "experience_match": {"years_of_experience": 2}
            }
        ]
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and criteria
        client = CVScreeningClient(config=config)
        client._initialize()
        
        criteria = {"required_skills": ["Python"]}
        client.set_criteria(criteria)
        
        # Test
        cv_texts = ["CV 1 content", "CV 2 content"]
        results = client.batch_analyze(cv_texts)
        
        # Verification - usar BatchProcessingResult en vez de lista
        assert isinstance(results, BatchProcessingResult)
        assert results.success_count == 2
        assert results.failure_count == 0
        assert len(results.successful_results) == 2
        
        # Verificar que los resultados individuales son correctos
        assert results.successful_results[0].overall_score == 0.85
        assert results.successful_results[1].overall_score == 0.65

    @patch("cv_screening_sdk.client.AzureProvider")
    @pytest.mark.asyncio
    async def test_batch_analyze_async(self, mock_provider_class):
        """Test that batch_analyze_async processes multiple CVs asynchronously."""
        # Setup
        mock_provider = Mock()
        mock_provider.analyze_cv_async = AsyncMock()
        mock_provider_class.return_value = mock_provider
        
        # Configure mock result for the analysis
        mock_provider.analyze_cv_async.side_effect = [
            {
                "match_score": 0.85,
                "skill_matches": {"required_skills": {"Python": 1.0}},
                "experience_match": {"years_of_experience": 5}
            },
            {
                "match_score": 0.65,
                "skill_matches": {"required_skills": {"Python": 0.5}},
                "experience_match": {"years_of_experience": 2}
            }
        ]
        
        config = SDKConfig(
            client=ClientConfig(),
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com/",
                deployment_name="test-deployment",
                api_version="2023-05-15"
            )
        )
        
        # Create the client and criteria
        client = CVScreeningClient(config=config)
        client._initialize()
        
        criteria = {"required_skills": ["Python"]}
        client.set_criteria(criteria)
        
        # Test
        cv_texts = ["CV 1 content", "CV 2 content"]
        results = await client.batch_analyze_async(cv_texts)
        
        # Verification - usar BatchProcessingResult en vez de lista
        assert isinstance(results, BatchProcessingResult)
        assert results.success_count == 2
        assert results.failure_count == 0
        assert len(results.successful_results) == 2
        
        # Verificar que los resultados individuales son correctos
        assert results.successful_results[0].overall_score == 0.85
        assert results.successful_results[1].overall_score == 0.65 