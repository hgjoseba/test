"""Tests for the Azure authentication provider."""

from unittest.mock import Mock, patch

import pytest
from azure.core.exceptions import ClientAuthenticationError
from cv_screening_sdk.auth.azure import AzureAuthProvider
from cv_screening_sdk.core.config import AzureConfig, SDKConfig, ClientConfig
from cv_screening_sdk.core.exceptions import AuthenticationError, ConfigurationError


@pytest.fixture
def mock_credential():
    """Mock Azure credential."""
    with patch("cv_screening_sdk.auth.azure.ClientSecretCredential") as mock:
        yield mock


def test_azure_config_validation():
    """Test Azure configuration validation."""
    # Test valid configuration
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )
    assert config.endpoint == "https://test.openai.azure.com/"
    assert config.deployment_name == "test-deployment"
    assert config.model_name == "gpt-4"
    assert config.api_version == "2023-05-15"
    assert config.tenant_id == "test-tenant"
    assert config.client_id == "test-client"
    assert config.client_secret == "test-secret"

    # Test invalid endpoint
    with pytest.raises(ConfigurationError, match="endpoint must be a valid URL"):
        AzureConfig(
            endpoint="invalid-url",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2023-05-15"
        )

    # Test missing required fields
    with pytest.raises(ConfigurationError, match="endpoint must be provided"):
        AzureConfig(
            endpoint="",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2023-05-15"
        )

    with pytest.raises(ConfigurationError, match="deployment_name must be provided"):
        AzureConfig(
            endpoint="https://test.openai.azure.com/",
            deployment_name="",
            model_name="gpt-4",
            api_version="2023-05-15"
        )

    # Test invalid numeric ranges
    with pytest.raises(ConfigurationError, match="max_tokens must be positive"):
        AzureConfig(
            endpoint="https://test.openai.azure.com/",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2023-05-15",
            max_tokens=0
        )

    with pytest.raises(ConfigurationError, match="temperature must be between 0 and 2"):
        AzureConfig(
            endpoint="https://test.openai.azure.com/",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2023-05-15",
            temperature=3.0
        )

    # Test Service Principal validation
    with pytest.raises(ConfigurationError, match="If using Service Principal authentication"):
        AzureConfig(
            endpoint="https://test.openai.azure.com/",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2023-05-15",
            tenant_id="test-tenant",
            client_id="test-client"
        )


def test_azure_config_env_vars(monkeypatch):
    """Test Azure configuration from environment variables."""
    # Set environment variables
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://test.openai.azure.com/")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_NAME", "test-deployment")
    monkeypatch.setenv("AZURE_OPENAI_MODEL_NAME", "gpt-4")
    monkeypatch.setenv("AZURE_OPENAI_API_VERSION", "2023-05-15")
    monkeypatch.setenv("AZURE_TENANT_ID", "test-tenant")
    monkeypatch.setenv("AZURE_CLIENT_ID", "test-client")
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "test-secret")
    monkeypatch.setenv("AZURE_OPENAI_MAX_TOKENS", "4000")
    monkeypatch.setenv("AZURE_OPENAI_TEMPERATURE", "0.7")

    # Create config with minimal parameters
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment"
    )

    # Verify environment variables were applied
    assert config.model_name == "gpt-4"
    assert config.api_version == "2023-05-15"
    assert config.tenant_id == "test-tenant"
    assert config.client_id == "test-client"
    assert config.client_secret == "test-secret"
    assert config.max_tokens == 4000
    assert config.temperature == 0.7


def test_azure_config_dict_conversion():
    """Test Azure configuration dictionary conversion."""
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )

    # Test to_dict
    config_dict = config.to_dict()
    assert config_dict["endpoint"] == "https://test.openai.azure.com/"
    assert config_dict["deployment_name"] == "test-deployment"
    assert config_dict["model_name"] == "gpt-4"
    assert config_dict["api_version"] == "2023-05-15"
    assert config_dict["tenant_id"] == "test-tenant"
    assert config_dict["client_id"] == "test-client"
    assert config_dict["client_secret"] == "test-secret"

    # Test from_dict
    new_config = AzureConfig.from_dict(config_dict)
    assert new_config.endpoint == config.endpoint
    assert new_config.deployment_name == config.deployment_name
    assert new_config.model_name == config.model_name
    assert new_config.api_version == config.api_version
    assert new_config.tenant_id == config.tenant_id
    assert new_config.client_id == config.client_id
    assert new_config.client_secret == config.client_secret


def test_auth_provider_initialization():
    """Test Azure auth provider initialization."""
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )

    auth_provider = AzureAuthProvider(config)
    assert auth_provider.config == config


def test_auth_provider_env_fallback(monkeypatch):
    """Test Azure auth provider environment variable fallback."""
    # Set environment variables
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://test.openai.azure.com/")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT_NAME", "test-deployment")
    monkeypatch.setenv("AZURE_TENANT_ID", "test-tenant")
    monkeypatch.setenv("AZURE_CLIENT_ID", "test-client")
    monkeypatch.setenv("AZURE_CLIENT_SECRET", "test-secret")

    # Create minimal config
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment"
    )

    auth_provider = AzureAuthProvider(config)
    assert auth_provider.config.tenant_id == "test-tenant"
    assert auth_provider.config.client_id == "test-client"
    assert auth_provider.config.client_secret == "test-secret"


def test_get_credentials_with_service_principal(mock_credential):
    """Test getting credentials with Service Principal authentication."""
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )

    auth_provider = AzureAuthProvider(config)
    credentials = auth_provider.get_credentials()

    assert credentials == mock_credential.return_value
    mock_credential.assert_called_once_with(
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )


def test_get_credentials_auth_error():
    """Test error handling when getting credentials fails."""
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )

    with patch("cv_screening_sdk.auth.azure.ClientSecretCredential") as mock_credential:
        mock_credential.side_effect = Exception("Authentication failed")
        auth_provider = AzureAuthProvider(config)

        with pytest.raises(AuthenticationError, match="Failed to get Azure credentials"):
            auth_provider.get_credentials()


def test_validate_credentials_success():
    """Test successful credential validation."""
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )

    auth_provider = AzureAuthProvider(config)

    mock_token = Mock()
    mock_token.token = "test_token"

    mock_credential = Mock()
    mock_credential.get_token.return_value = mock_token

    with patch.object(auth_provider, "get_credentials", return_value=mock_credential):
        assert auth_provider.validate_credentials() is True


def test_validate_credentials_failure():
    """Test credential validation failure."""
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )

    auth_provider = AzureAuthProvider(config)

    mock_credential = Mock()
    mock_credential.get_token.side_effect = ClientAuthenticationError("Test error")

    with patch.object(auth_provider, "get_credentials", return_value=mock_credential):
        with pytest.raises(AuthenticationError, match="Failed to validate credentials"):
            auth_provider.validate_credentials()


def test_refresh_credentials():
    """Test credential refresh."""
    config = AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        model_name="gpt-4",
        api_version="2023-05-15",
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret"
    )

    auth_provider = AzureAuthProvider(config)

    with patch("cv_screening_sdk.auth.azure.ClientSecretCredential") as mock_credential:
        mock_credential.side_effect = [Mock(name="cred1"), Mock(name="cred2")]
        
        # First call to get_credentials
        cred1 = auth_provider.get_credentials()
        assert mock_credential.call_count == 1

        # Refresh credentials
        auth_provider.refresh_credentials()

        # Second call to get_credentials
        cred2 = auth_provider.get_credentials()
        assert mock_credential.call_count == 2
        assert cred1 != cred2
