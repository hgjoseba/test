"""
Unit tests for Azure authentication provider.
"""

import pytest
from unittest.mock import Mock, patch
from azure.core.exceptions import ClientAuthenticationError
from cv_screening_sdk.core.exceptions import AuthenticationError
from cv_screening_sdk.auth.azure import AzureCredentials, AzureAuthProvider


class TestAzureCredentials:
    """Test suite for Azure credentials."""

    def test_credential_initialization(self):
        """Test credential initialization."""
        credentials = AzureCredentials(
            tenant_id="00000000-0000-0000-0000-000000000000",
            client_id="00000000-0000-0000-0000-000000000000",
            client_secret="test-secret"
        )
        assert credentials.tenant_id == "00000000-0000-0000-0000-000000000000"
        assert credentials.client_id == "00000000-0000-0000-0000-000000000000"
        assert credentials.client_secret == "test-secret"

    @patch("cv_screening_sdk.auth.azure.ClientSecretCredential")
    def test_get_credential_with_service_principal(self, mock_credential_class):
        """Test getting credential with service principal."""
        mock_credential = Mock()
        mock_credential_class.return_value = mock_credential
        credentials = AzureCredentials(
            tenant_id="00000000-0000-0000-0000-000000000000",
            client_id="00000000-0000-0000-0000-000000000000",
            client_secret="test-secret"
        )
        result = credentials.get_credential()
        assert result == mock_credential
        mock_credential_class.assert_called_once_with(
            tenant_id="00000000-0000-0000-0000-000000000000",
            client_id="00000000-0000-0000-0000-000000000000",
            client_secret="test-secret"
        )

    @patch("cv_screening_sdk.auth.azure.DefaultAzureCredential")
    def test_get_credential_with_default(self, mock_credential_class):
        """Test getting credential with default."""
        mock_credential = Mock()
        mock_credential_class.return_value = mock_credential
        credentials = AzureCredentials()
        result = credentials.get_credential()
        assert result == mock_credential
        mock_credential_class.assert_called_once()

    @patch("cv_screening_sdk.auth.azure.ClientSecretCredential")
    def test_get_credential_error(self, mock_credential_class):
        """Test credential error."""
        mock_credential_class.side_effect = ClientAuthenticationError("Test error")
        credentials = AzureCredentials(
            tenant_id="00000000-0000-0000-0000-000000000000",
            client_id="00000000-0000-0000-0000-000000000000",
            client_secret="test-secret"
        )
        with pytest.raises(AuthenticationError) as exc_info:
            credentials.get_credential()
        assert str(exc_info.value) == "Failed to create Azure credentials: Test error"


class TestAzureAuthProvider:
    """Test suite for Azure authentication provider."""

    def test_auth_provider_initialization(self):
        """Test auth provider initialization."""
        provider = AzureAuthProvider()
        assert isinstance(provider._credentials, AzureCredentials)

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_get_credentials(self, mock_credentials_class):
        """Test getting credentials."""
        mock_credentials = Mock()
        mock_credentials_class.return_value = mock_credentials
        provider = AzureAuthProvider()
        result = provider.get_credentials()
        assert result == mock_credentials.get_credential.return_value
        mock_credentials.get_credential.assert_called_once()

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    def test_get_credentials_error(self, mock_credentials_class):
        """Test credentials error."""
        mock_credentials = Mock()
        mock_credentials.get_credential.side_effect = AuthenticationError("Test error")
        mock_credentials_class.return_value = mock_credentials
        provider = AzureAuthProvider()
        with pytest.raises(AuthenticationError) as exc_info:
            provider.get_credentials()
        assert str(exc_info.value) == "Failed to get Azure credentials: Test error"

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    @pytest.mark.asyncio
    async def test_get_credentials_async(self, mock_credentials_class):
        """Test getting credentials asynchronously."""
        mock_credentials = Mock()
        mock_credentials_class.return_value = mock_credentials
        provider = AzureAuthProvider()
        result = await provider.get_credentials_async()
        assert result == mock_credentials.get_credential.return_value
        mock_credentials.get_credential.assert_called_once()

    @patch("cv_screening_sdk.auth.azure.AzureCredentials")
    @pytest.mark.asyncio
    async def test_get_credentials_async_error(self, mock_credentials_class):
        """Test credentials error in async context."""
        mock_credentials = Mock()
        mock_credentials.get_credential.side_effect = AuthenticationError("Test error")
        mock_credentials_class.return_value = mock_credentials
        provider = AzureAuthProvider()
        with pytest.raises(AuthenticationError) as exc_info:
            await provider.get_credentials_async()
        assert str(exc_info.value) == "Failed to get Azure credentials: Test error" 