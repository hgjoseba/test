"""
Common test fixtures for the CV Screening SDK.
"""

import pytest
from unittest.mock import Mock, patch
from cv_screening_sdk.models.criteria import JobCriteria
from cv_screening_sdk.models.results import (
    CVScreeningResult,
    SkillMatch,
    ExperienceMatch,
    EducationMatch,
)
from cv_screening_sdk.core.config import (
    AzureConfig,
    ClientConfig,
    LogConfig,
    SDKConfig
)
from azure.core.credentials import TokenCredential


@pytest.fixture
def mock_azure_credential():
    """Mock Azure credential."""
    credential = Mock(spec=TokenCredential)
    credential.get_token.return_value = Mock(token="test-token")
    return credential


@pytest.fixture
def azure_config():
    """Create Azure configuration for tests."""
    return AzureConfig(
        api_version="2023-05-15",
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
        tenant_id="00000000-0000-0000-0000-000000000000",
        client_id="00000000-0000-0000-0000-000000000000",
        client_secret="test-secret",
        ssl_verify=True,
        ssl_cert_path=None,
        connection_verify=True,
        connection_timeout=30,
        max_keepalive_connections=5,
        max_connections=10
    )


@pytest.fixture
def client_config():
    """Create client configuration for tests."""
    return ClientConfig(
        timeout=30,
        max_retries=3,
        batch_size=10
    )


@pytest.fixture
def log_config():
    """Create logging configuration for tests."""
    return LogConfig(
        file_path="test.log",
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level="INFO"
    )


@pytest.fixture
def sdk_config(azure_config, client_config, log_config):
    """Create SDK configuration for tests."""
    return SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config
    )


@pytest.fixture
def test_cv_content():
    """Create test CV content."""
    return """
    John Doe
    Senior Software Engineer
    
    Summary:
    Experienced software engineer with 5 years of experience in Python and cloud technologies.
    
    Experience:
    - Senior Software Engineer at Tech Corp (2020-present)
    - Led team of 5 developers
    - Improved system performance by 50%
    
    Education:
    Bachelor's in Computer Science
    """


@pytest.fixture
def test_criteria():
    """Create test job criteria."""
    return JobCriteria(
        required_skills=["Python", "SQL"],
        preferred_skills=["Docker", "Kubernetes"],
        min_years_experience=3,
        preferred_years_experience=5,
        education_level="bachelors",
        education_field=None,
        role_title="Senior Software Engineer",
        description=None,
        industry=None
    )


@pytest.fixture
def test_skill_matches():
    """Create test skills match."""
    return SkillMatch(
        required_skills={"Python": 1.0, "SQL": 0.9},
        preferred_skills={"Docker": 0.8, "Kubernetes": 0.7},
        overall_score=90.0,
        missing_required=[],
        missing_preferred=[]
    )


@pytest.fixture
def test_experience_match():
    """Create test experience match."""
    return ExperienceMatch(
        years_of_experience=5.0,
        relevance_score=0.9,
        role_matches=[
            {
                "title": "Senior Software Engineer",
                "years": 3,
                "relevance": 0.9
            }
        ],
        meets_minimum=True,
        overall_score=95.0
    )


@pytest.fixture
def test_education_match():
    """Create test education match."""
    return EducationMatch(
        level_match=True,
        field_relevance=0.9,
        overall_score=90.0,
        education_details={
            "highest_level": "Bachelor's",
            "field": "Computer Science"
        }
    )


@pytest.fixture
def test_screening_result(test_skill_matches, test_experience_match, test_education_match):
    """Create test screening result."""
    return CVScreeningResult(
        cv_id="test-cv.pdf",
        overall_score=85.0,
        skill_matches=test_skill_matches,
        experience_match=test_experience_match,
        education_match=test_education_match,
        summary="Test summary",
        raw_text="Test raw text"
    ) 