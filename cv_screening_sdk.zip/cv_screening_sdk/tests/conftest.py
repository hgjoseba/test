"""Test configuration and fixtures."""

import os
from pathlib import Path
from typing import Any, Dict

import pytest
import yaml
from cv_screening_sdk.core.config import SDKConfig


@pytest.fixture
def test_config_path() -> Path:
    """Get the test configuration file path."""
    return Path(__file__).parent / "test_data" / "config.yml"


@pytest.fixture
def test_config(test_config_path: Path) -> Dict[str, Any]:
    """Load test configuration."""
    with open(test_config_path) as f:
        return yaml.safe_load(f)


@pytest.fixture
def sdk_config(test_config: Dict[str, Any]) -> SDKConfig:
    """Create SDK configuration from test config."""
    return SDKConfig(**test_config.get("sdk", {}))


@pytest.fixture
def test_cv_path() -> str:
    """Get the path to a test CV file."""
    return str(Path(__file__).parent / "test_data" / "sample_cv.pdf")


@pytest.fixture
def sample_job_criteria() -> Dict[str, Any]:
    """Get sample job criteria for testing."""
    return {
        "title": "Software Engineer",
        "required_skills": ["Python", "Docker", "AWS"],
        "experience_years": 3,
        "education": "Bachelor's degree in Computer Science or related field",
        "location": "Remote",
        "employment_type": "Full-time"
    }
