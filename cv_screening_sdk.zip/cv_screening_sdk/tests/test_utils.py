"""
Unit tests for utility modules.
"""

import os
import pytest
import asyncio
import logging
import tempfile
from datetime import datetime
from unittest.mock import Mock, patch
import time

from cv_screening_sdk.utils.validation import validate_file_path, validate_criteria, validate_config
from cv_screening_sdk.utils.logging import setup_logging
from cv_screening_sdk.utils.async_utils import to_sync, run_async, async_retry, async_timeout
from cv_screening_sdk.core.exceptions import ValidationError
from cv_screening_sdk.models import JobCriteria
from cv_screening_sdk.core.config import SDKConfig


class TestValidationUtils:
    """Test suite for validation utilities."""

    def test_validate_file_path_valid(self, tmp_path):
        """Test validation with valid file path."""
        # Create a temporary file
        temp_file = tmp_path / "test.txt"
        temp_file.write_text("test content")
        
        # Should not raise an exception
        validate_file_path(str(temp_file))
    
    def test_validate_file_path_empty(self):
        """Test validation with empty file path."""
        with pytest.raises(ValidationError, match="File path cannot be empty"):
            validate_file_path("")
    
    def test_validate_file_path_nonexistent(self):
        """Test validation with nonexistent file path."""
        with pytest.raises(ValidationError, match="File does not exist"):
            validate_file_path("/path/to/nonexistent/file.txt")
    
    def test_validate_file_path_directory(self, tmp_path):
        """Test validation with directory path."""
        with pytest.raises(ValidationError, match="Not a file"):
            validate_file_path(str(tmp_path))
    
    def test_validate_criteria_job_criteria(self):
        """Test criteria validation with JobCriteria object."""
        criteria = JobCriteria(
            required_skills=["Python", "SQL"],
            education_level="bachelors"
        )
        # Should not raise an exception
        validate_criteria(criteria)
    
    def test_validate_criteria_dict(self):
        """Test criteria validation with dictionary."""
        criteria = {
            "required_skills": ["Python", "SQL"],
            "preferred_skills": ["Docker"],
            "min_years_experience": 3,
            "education_level": "bachelors"
        }
        # Should not raise an exception
        validate_criteria(criteria)
    
    def test_validate_criteria_invalid_type(self):
        """Test criteria validation with invalid type."""
        with pytest.raises(ValidationError, match="Criteria must be a dictionary or JobCriteria object"):
            validate_criteria("invalid")
    
    def test_validate_criteria_invalid_required_skills(self):
        """Test criteria validation with invalid required_skills."""
        criteria = {
            "required_skills": "Python"  # Not a list
        }
        with pytest.raises(ValidationError, match="required_skills must be a list"):
            validate_criteria(criteria)
    
    def test_validate_criteria_invalid_education_level(self):
        """Test criteria validation with invalid education_level."""
        criteria = {
            "education_level": "invalid"
        }
        with pytest.raises(ValidationError, match="education_level must be one of"):
            validate_criteria(criteria)
    
    def test_validate_criteria_invalid_preferred_skills(self):
        """Test criteria validation with invalid preferred_skills."""
        criteria = {
            "preferred_skills": "Docker"  # Not a list
        }
        with pytest.raises(ValidationError, match="preferred_skills must be a list"):
            validate_criteria(criteria)
    
    def test_validate_criteria_invalid_skill_type(self):
        """Test criteria validation with non-string skill."""
        criteria = {
            "required_skills": ["Python", 123]  # 123 is not a string
        }
        with pytest.raises(ValidationError, match="Skill must be a string"):
            validate_criteria(criteria)
            
    def test_validate_criteria_invalid_preferred_skill_type(self):
        """Test criteria validation with non-string preferred skill."""
        criteria = {
            "preferred_skills": ["Docker", 123]  # 123 is not a string
        }
        with pytest.raises(ValidationError, match="Skill must be a string"):
            validate_criteria(criteria)
    
    def test_validate_criteria_invalid_years_type(self):
        """Test criteria validation with invalid min_years_experience type."""
        criteria = {
            "min_years_experience": "three"  # Not a number
        }
        with pytest.raises(ValidationError, match="min_years_experience must be a number"):
            validate_criteria(criteria)
    
    def test_validate_criteria_negative_years(self):
        """Test criteria validation with negative min_years_experience."""
        criteria = {
            "min_years_experience": -1  # Negative
        }
        with pytest.raises(ValidationError, match="min_years_experience cannot be negative"):
            validate_criteria(criteria)
    
    def test_validate_criteria_invalid_preferred_years_type(self):
        """Test criteria validation with invalid preferred_years_experience type."""
        criteria = {
            "preferred_years_experience": "five"  # Not a number
        }
        with pytest.raises(ValidationError, match="preferred_years_experience must be a number or None"):
            validate_criteria(criteria)
    
    def test_validate_criteria_negative_preferred_years(self):
        """Test criteria validation with negative preferred_years_experience."""
        criteria = {
            "preferred_years_experience": -1  # Negative
        }
        with pytest.raises(ValidationError, match="preferred_years_experience cannot be negative"):
            validate_criteria(criteria)
    
    def test_validate_criteria_preferred_less_than_min(self):
        """Test criteria validation with preferred_years_experience < min_years_experience."""
        criteria = {
            "min_years_experience": 5,
            "preferred_years_experience": 3  # Less than min
        }
        with pytest.raises(ValidationError, match="preferred_years_experience must be >= min_years_experience"):
            validate_criteria(criteria)
    
    def test_validate_criteria_invalid_education_level_type(self):
        """Test criteria validation with invalid education_level type."""
        criteria = {
            "education_level": 123  # Not a string
        }
        with pytest.raises(ValidationError, match="education_level must be a string"):
            validate_criteria(criteria)
    
    def test_validate_config_sdk_config(self):
        """Test config validation with SDKConfig object."""
        from cv_screening_sdk.core.config import AzureConfig, ClientConfig, LogConfig
        
        config = SDKConfig(
            azure=AzureConfig(
                endpoint="https://test.openai.azure.com",
                deployment_name="gpt-4"
            ),
            client=ClientConfig(),
            log=LogConfig()
        )
        # Should not raise an exception
        validate_config(config)
    
    def test_validate_config_invalid_type(self):
        """Test config validation with invalid type."""
        with pytest.raises(ValidationError, match="Configuration must be a dictionary or SDKConfig object"):
            validate_config("invalid")
    
    def test_validate_config_invalid_azure_type(self):
        """Test config validation with invalid azure type."""
        config = {
            "azure": "invalid"  # Not a dictionary
        }
        with pytest.raises(ValidationError, match="azure config must be a dictionary"):
            validate_config(config)
    
    def test_validate_config_missing_required_fields(self):
        """Test config validation with missing required fields."""
        config = {
            "azure": {}  # Missing required fields
        }
        with pytest.raises(ValidationError, match="Missing required Azure config field"):
            validate_config(config)
    
    def test_validate_config_empty_required_fields(self):
        """Test config validation with empty required fields."""
        config = {
            "azure": {
                "endpoint": "",
                "deployment_name": "gpt-4"
            }
        }
        with pytest.raises(ValidationError, match="Azure config field endpoint cannot be empty"):
            validate_config(config)
    
    def test_validate_config_invalid_endpoint(self):
        """Test config validation with invalid endpoint."""
        config = {
            "azure": {
                "endpoint": "invalid-url",
                "deployment_name": "gpt-4"
            }
        }
        with pytest.raises(ValidationError, match="endpoint must be a valid URL"):
            validate_config(config)
    
    def test_validate_config_invalid_endpoint_type(self):
        """Test config validation with invalid endpoint type."""
        config = {
            "azure": {
                "endpoint": 123,  # Not a string
                "deployment_name": "gpt-4"
            }
        }
        with pytest.raises(ValidationError, match="endpoint must be a string"):
            validate_config(config)
    
    def test_validate_config_numeric_fields(self):
        """Test config validation with numeric fields."""
        config = {
            "azure": {
                "endpoint": "https://test.openai.azure.com",
                "deployment_name": "gpt-4",
                "max_tokens": "100",  # Not a number
                "temperature": 3.0,   # Out of range
                "top_p": -0.5         # Out of range
            }
        }
        with pytest.raises(ValidationError, match="max_tokens must be a number"):
            validate_config(config)
            
        config["azure"]["max_tokens"] = 100  # Fix max_tokens
        with pytest.raises(ValidationError, match="temperature value is out of valid range"):
            validate_config(config)
            
        config["azure"]["temperature"] = 0.7  # Fix temperature
        with pytest.raises(ValidationError, match="top_p value is out of valid range"):
            validate_config(config)
    
    def test_validate_config_partial_credentials(self):
        """Test config validation with partial credentials."""
        config = {
            "azure": {
                "endpoint": "https://test.openai.azure.com",
                "deployment_name": "gpt-4",
                "tenant_id": "tenant-id",  # Missing other credential fields
            }
        }
        with pytest.raises(ValidationError, match="Missing required credentials"):
            validate_config(config)
    
    def test_validate_config_invalid_client_type(self):
        """Test config validation with invalid client type."""
        config = {
            "client": "invalid"  # Not a dictionary
        }
        with pytest.raises(ValidationError, match="client config must be a dictionary"):
            validate_config(config)


class TestLoggingUtils:
    """Test suite for logging utilities."""

    def test_setup_logging_default(self):
        """Test setting up logging with default parameters."""
        setup_logging()
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.level == logging.INFO
    
    def test_setup_logging_debug(self):
        """Test setting up logging with DEBUG level."""
        setup_logging(level="DEBUG")
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.level == logging.DEBUG
    
    def test_setup_logging_file(self, tmp_path):
        """Test setting up logging with log file."""
        log_file = tmp_path / "test.log"
        setup_logging(log_file=str(log_file))
        logger = logging.getLogger("cv_screening_sdk")
        logger.info("Test log message")
        
        # Check that the message was written to the file
        assert log_file.exists()
        log_content = log_file.read_text()
        assert "Test log message" in log_content
    
    def test_setup_logging_invalid_level(self):
        """Test setting up logging with invalid level."""
        setup_logging(level="INVALID_LEVEL")
        logger = logging.getLogger("cv_screening_sdk")
        # Should default to INFO
        assert logger.level == logging.INFO
    
    def test_setup_logging_warning_level(self):
        """Test setting up logging with WARNING level."""
        setup_logging(level="WARNING")
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.level == logging.WARNING
    
    def test_setup_logging_error_level(self):
        """Test setting up logging with ERROR level."""
        setup_logging(level="ERROR")
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.level == logging.ERROR
    
    def test_setup_logging_critical_level(self):
        """Test setting up logging with CRITICAL level."""
        setup_logging(level="CRITICAL")
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.level == logging.CRITICAL
    
    def test_setup_logging_case_insensitive(self):
        """Test setting up logging with case-insensitive level."""
        setup_logging(level="debug")  # lowercase
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.level == logging.DEBUG
    
    def test_setup_logging_multiple_calls(self):
        """Test setting up logging multiple times."""
        setup_logging(level="INFO")
        setup_logging(level="DEBUG")  # Should override previous setting
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.level == logging.DEBUG
    
    def test_setup_logging_propagation(self):
        """Test logger propagation setting."""
        setup_logging()
        logger = logging.getLogger("cv_screening_sdk")
        assert logger.propagate is True


class TestAsyncUtils:
    """Test suite for async utilities."""

    def test_to_sync(self):
        """Test converting async function to sync."""
        async def async_func(x):
            await asyncio.sleep(0.01)
            return x * 2
        
        sync_func = to_sync(async_func)
        result = sync_func(5)
        assert result == 10
    
    def test_run_async(self):
        """Test running a coroutine synchronously."""
        async def coro():
            await asyncio.sleep(0.01)
            return 42
        
        result = run_async(coro())
        assert result == 42
    
    @pytest.mark.asyncio
    async def test_async_retry_success(self):
        """Test async retry with successful operation."""
        mock = Mock()
        
        async def success_func():
            mock()
            return "success"
        
        result = await async_retry(success_func, retries=3)
        assert result == "success"
        assert mock.call_count == 1  # Only called once because it succeeded
    
    @pytest.mark.asyncio
    async def test_async_retry_failure_then_success(self):
        """Test async retry with failure then success."""
        mock = Mock()
        
        async def fail_then_succeed():
            mock()
            if mock.call_count < 3:
                raise ValueError("Temporary error")
            return "success"
        
        result = await async_retry(
            fail_then_succeed,
            retries=3,
            delay=0.01,
            backoff_factor=1.0,
            exceptions=ValueError
        )
        assert result == "success"
        assert mock.call_count == 3  # Called 3 times (2 failures, then success)
    
    @pytest.mark.asyncio
    async def test_async_retry_all_failures(self):
        """Test async retry with all failures."""
        mock = Mock()
        
        async def always_fail():
            mock()
            raise ValueError("Always fails")
        
        with pytest.raises(ValueError, match="Always fails"):
            await async_retry(
                always_fail,
                retries=2,
                delay=0.01,
                exceptions=ValueError
            )
        
        assert mock.call_count == 3  # Initial try + 2 retries
    
    @pytest.mark.asyncio
    async def test_async_timeout_success(self):
        """Test async timeout with successful completion."""
        async def quick_func():
            await asyncio.sleep(0.01)
            return "done"
        
        result = await async_timeout(quick_func(), timeout=1.0)
        assert result == "done"
    
    @pytest.mark.asyncio
    async def test_async_timeout_timeout(self):
        """Test async timeout with timeout."""
        async def slow_func():
            await asyncio.sleep(0.5)
            return "done"
        
        with pytest.raises(asyncio.TimeoutError):
            await async_timeout(slow_func(), timeout=0.01)
    
    @pytest.mark.asyncio
    async def test_async_timeout_custom_message(self):
        """Test async timeout with custom error message."""
        async def slow_func():
            await asyncio.sleep(0.5)
            return "done"
        
        with pytest.raises(asyncio.TimeoutError, match="Custom timeout message"):
            await async_timeout(
                slow_func(),
                timeout=0.01,
                timeout_message="Custom timeout message"
            )
    
    def test_to_sync_with_args(self):
        """Test converting async function to sync with arguments."""
        async def async_func(x, y, z=None):
            await asyncio.sleep(0.01)
            if z is None:
                return x + y
            return x + y + z
        
        sync_func = to_sync(async_func)
        assert sync_func(1, 2) == 3
        assert sync_func(1, 2, z=3) == 6
    
    def test_to_sync_with_exception(self):
        """Test converting async function that raises an exception."""
        async def async_func():
            await asyncio.sleep(0.01)
            raise ValueError("Test error")
        
        sync_func = to_sync(async_func)
        with pytest.raises(ValueError, match="Test error"):
            sync_func()
    
    def test_run_async_with_exception(self):
        """Test run_async with coroutine that raises an exception."""
        async def failing_coro():
            await asyncio.sleep(0.01)
            raise ValueError("Test error")
        
        with pytest.raises(ValueError, match="Test error"):
            run_async(failing_coro())
    
    @pytest.mark.asyncio
    async def test_async_retry_with_custom_exception(self):
        """Test async retry with custom exception type."""
        class CustomError(Exception):
            pass
        
        mock = Mock()
        
        async def fail_custom_error():
            mock()
            raise CustomError("Custom error")
        
        # This should not retry because we're only catching ValueError
        with pytest.raises(CustomError):
            await async_retry(
                fail_custom_error,
                retries=3,
                delay=0.01,
                exceptions=ValueError
            )
        assert mock.call_count == 1  # Only called once because we don't catch CustomError
    
    @pytest.mark.asyncio
    async def test_async_retry_with_multiple_exception_types_fixed(self):
        """Test async retry with multiple exception types (fixed version)."""
        mock = Mock()
        
        # Use a persistent counter to track calls
        class Counter:
            def __init__(self):
                self.count = 0
                
        counter = Counter()
        
        async def alternate_errors():
            mock()
            counter.count += 1
            if counter.count == 1:
                raise ValueError("Value error")
            elif counter.count == 2:
                raise KeyError("Key error")
            else:
                return "Success"
        
        # This should retry twice and succeed on third attempt
        result = await async_retry(
            alternate_errors,
            retries=3,
            delay=0.01,
            exceptions=(ValueError, KeyError)
        )
        
        assert result == "Success"
        assert mock.call_count == 3  # Called 3 times (initial + 2 retries)
    
    @pytest.mark.asyncio
    async def test_async_timeout_exact(self):
        """Test async timeout with exact timing."""
        start_time = time.time()
        
        async def just_in_time():
            await asyncio.sleep(0.1)
            return "completed"
        
        result = await async_timeout(just_in_time(), 0.2)  # Plenty of time
        assert result == "completed"
        elapsed = time.time() - start_time
        assert 0.09 <= elapsed <= 0.3  # Allow some timing flexibility
    
    @pytest.mark.asyncio
    async def test_async_timeout_with_nested_coroutine(self):
        """Test async timeout with nested coroutine."""
        async def outer_coro():
            await asyncio.sleep(0.05)
            
            async def inner_coro():
                await asyncio.sleep(0.05)
                return "inner result"
            
            return await inner_coro()
        
        result = await async_timeout(outer_coro(), 0.2)
        assert result == "inner result" 