"""
Unit tests for SDK configuration.
"""

import pytest
from cv_screening_sdk.core.config import (
    AzureConfig,
    ClientConfig,
    LogConfig,
    SDKConfig
)
from cv_screening_sdk.core.exceptions import ConfigurationError


class TestAzureConfig:
    """Test suite for Azure configuration."""

    def test_azure_config_initialization(self):
        """Test Azure config initialization."""
        config = AzureConfig(
            endpoint="https://test.azure.com",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2024-02-15",
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret"
        )
        assert config.endpoint == "https://test.azure.com"
        assert config.deployment_name == "test-deployment"
        assert config.model_name == "gpt-4"
        assert config.api_version == "2024-02-15"
        assert config.tenant_id == "test-tenant"
        assert config.client_id == "test-client"
        assert config.client_secret == "test-secret"

    def test_azure_config_validation(self):
        """Test Azure config validation."""
        with pytest.raises(ConfigurationError):
            AzureConfig(
                endpoint="invalid-url",
                deployment_name="test-deployment",
                model_name="gpt-4",
                api_version="2024-02-15",
                tenant_id="test-tenant",
                client_id="test-client",
                client_secret="test-secret"
            )

    def test_azure_config_from_dict(self):
        """Test Azure config creation from dictionary."""
        config_dict = {
            "endpoint": "https://test.azure.com",
            "deployment_name": "test-deployment",
            "model_name": "gpt-4",
            "api_version": "2024-02-15",
            "tenant_id": "test-tenant",
            "client_id": "test-client",
            "client_secret": "test-secret"
        }
        config = AzureConfig.from_dict(config_dict)
        assert config.endpoint == config_dict["endpoint"]
        assert config.deployment_name == config_dict["deployment_name"]
        assert config.model_name == config_dict["model_name"]
        assert config.api_version == config_dict["api_version"]
        assert config.tenant_id == config_dict["tenant_id"]
        assert config.client_id == config_dict["client_id"]
        assert config.client_secret == config_dict["client_secret"]

    def test_azure_config_to_dict(self):
        """Test Azure config conversion to dictionary."""
        config = AzureConfig(
            endpoint="https://test.azure.com",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2024-02-15",
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret"
        )
        config_dict = config.to_dict()
        assert config_dict["endpoint"] == config.endpoint
        assert config_dict["deployment_name"] == config.deployment_name
        assert config_dict["model_name"] == config.model_name
        assert config_dict["api_version"] == config.api_version
        assert config_dict["tenant_id"] == config.tenant_id
        assert config_dict["client_id"] == config.client_id
        assert config_dict["client_secret"] == config.client_secret


class TestClientConfig:
    """Test suite for client configuration."""

    def test_client_config_initialization(self):
        """Test client config initialization."""
        config = ClientConfig(
            timeout=30,
            max_retries=3,
            batch_size=10
        )
        assert config.timeout == 30
        assert config.max_retries == 3
        assert config.batch_size == 10

    def test_client_config_validation(self):
        """Test client config validation."""
        with pytest.raises(ConfigurationError):
            ClientConfig(
                timeout=-1,
                max_retries=3,
                batch_size=10
            )

    def test_client_config_from_dict(self):
        """Test client config creation from dictionary."""
        config_dict = {
            "timeout": 30,
            "max_retries": 3,
            "batch_size": 10
        }
        config = ClientConfig.from_dict(config_dict)
        assert config.timeout == config_dict["timeout"]
        assert config.max_retries == config_dict["max_retries"]
        assert config.batch_size == config_dict["batch_size"]

    def test_client_config_to_dict(self):
        """Test client config conversion to dictionary."""
        config = ClientConfig(
            timeout=30,
            max_retries=3,
            batch_size=10
        )
        config_dict = config.to_dict()
        assert config_dict["timeout"] == config.timeout
        assert config_dict["max_retries"] == config.max_retries
        assert config_dict["batch_size"] == config.batch_size


class TestLogConfig:
    """Test suite for logging configuration."""

    def test_log_config_initialization(self):
        """Test log config initialization."""
        config = LogConfig(
            file_path="test.log",
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            level="INFO"
        )
        assert config.file_path == "test.log"
        assert config.format == "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        assert config.level == "INFO"

    def test_log_config_validation(self):
        """Test log config validation."""
        with pytest.raises(ConfigurationError):
            LogConfig(
                file_path="",
                format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                level="INVALID"
            )

    def test_log_config_from_dict(self):
        """Test log config creation from dictionary."""
        config_dict = {
            "file_path": "test.log",
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            "level": "INFO"
        }
        config = LogConfig.from_dict(config_dict)
        assert config.file_path == config_dict["file_path"]
        assert config.format == config_dict["format"]
        assert config.level == config_dict["level"]

    def test_log_config_to_dict(self):
        """Test log config conversion to dictionary."""
        config = LogConfig(
            file_path="test.log",
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            level="INFO"
        )
        config_dict = config.to_dict()
        assert config_dict["file_path"] == config.file_path
        assert config_dict["format"] == config.format
        assert config_dict["level"] == config.level


class TestSDKConfig:
    """Test suite for SDK configuration."""

    @pytest.fixture
    def azure_config(self):
        """Create test Azure config."""
        return AzureConfig(
            endpoint="https://test.azure.com",
            deployment_name="test-deployment",
            model_name="gpt-4",
            api_version="2024-02-15",
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret"
        )

    @pytest.fixture
    def client_config(self):
        """Create test client config."""
        return ClientConfig(
            timeout=30,
            max_retries=3,
            batch_size=10
        )

    @pytest.fixture
    def log_config(self):
        """Create test log config."""
        return LogConfig(
            file_path="test.log",
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            level="INFO"
        )

    def test_sdk_config_initialization(self, azure_config, client_config, log_config):
        """Test SDK config initialization."""
        config = SDKConfig(
            azure=azure_config,
            client=client_config,
            log=log_config
        )
        assert config.azure == azure_config
        assert config.client == client_config
        assert config.log == log_config

    def test_sdk_config_from_dict(self, azure_config, client_config, log_config):
        """Test SDK config creation from dictionary."""
        config_dict = {
            "azure": azure_config.to_dict(),
            "client": client_config.to_dict(),
            "log": log_config.to_dict()
        }
        config = SDKConfig.from_dict(config_dict)
        assert config.azure.to_dict() == config_dict["azure"]
        assert config.client.to_dict() == config_dict["client"]
        assert config.log.to_dict() == config_dict["log"]

    def test_sdk_config_to_dict(self, azure_config, client_config, log_config):
        """Test SDK config conversion to dictionary."""
        config = SDKConfig(
            azure=azure_config,
            client=client_config,
            log=log_config
        )
        config_dict = config.to_dict()
        assert config_dict["azure"] == azure_config.to_dict()
        assert config_dict["client"] == client_config.to_dict()
        assert config_dict["log"] == log_config.to_dict() 