"""
Additional tests for the coverage of the Azure provider.
"""

import pytest
import json
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from cv_screening_sdk.core.exceptions import LLMError, ProcessingError, AuthenticationError, ProviderError
from cv_screening_sdk.providers.azure import AzureProvider
from unittest.mock import PropertyMock
from unittest import TestCase


class TestAzureProviderAdditional:
    """Additional tests for the AzureProvider."""

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_process_completion_with_non_json_response(self, mock_client_class):
        """Test that _process_completion correctly handles non-JSON responses."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Create a mock response that is not JSON
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(role="assistant", content="This is a response that is not JSON"),
                finish_reason="stop"
            )
        ]
        
        # Test
        result = provider._process_completion(mock_response)
        
        # Verification
        assert "content" in result
        assert "choices" in result
        assert result["content"] == "This is a response that is not JSON"
        assert result["choices"][0]["message"]["content"] == "This is a response that is not JSON"

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_process_completion_with_missing_fields(self, mock_client_class):
        """Test that _process_completion correctly fills in missing fields."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Create a mock response with incomplete JSON
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(role="assistant", content='{"overall_score": 85}'),
                finish_reason="stop"
            )
        ]
        
        # Test
        result = provider._process_completion(mock_response)
        
        # Verification
        assert "skill_matches" in result
        assert "experience_match" in result
        assert "education_match" in result
        assert result["overall_score"] == 85.0

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_process_completion_with_match_score(self, mock_client_class):
        """Test that _process_completion correctly converts match_score."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Create a mock response with match_score
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(role="assistant", content='{"match_score": 0.85}'),
                finish_reason="stop"
            )
        ]
        
        # Test
        result = provider._process_completion(mock_response)
        
        # Verification
        assert "overall_score" in result
        assert result["overall_score"] == 85.0

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_process_completion_error(self, mock_client_class):
        """Test that _process_completion correctly handles errors."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Crear un mock que tenga choices, pero cause un error al intentar convertir a JSON
        class MockChoice:
            @property
            def message(self):
                class Message:
                    # Devolver un objeto que no es JSON y provocará un error
                    @property
                    def content(self):
                        return {"complex_object": object()}
                return Message()
            
            @property
            def index(self):
                return 0
            
            @property
            def finish_reason(self):
                return "stop"
            
        class MockResponse:
            @property
            def choices(self):
                return [MockChoice()]
        
        # Test
        with pytest.raises(LLMError) as exc_info:
            provider._process_completion(MockResponse())
        
        # Verification
        assert "Failed to process completion response" in str(exc_info.value)

    @patch("cv_screening_sdk.providers.azure.AzureAuthProvider")
    def test_initialize_with_no_token(self, mock_auth_provider_class):
        """Test that initialize correctly handles absence of a token."""
        # Setup
        mock_auth_provider = Mock()
        mock_auth_provider_class.return_value = mock_auth_provider
        mock_auth_provider.get_token.return_value = None
        
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        provider.auth_provider = mock_auth_provider
        
        # Test
        with pytest.raises(ProviderError) as exc_info:
            provider.initialize()
        
        # Verification
        assert "Failed to initialize Azure OpenAI client" in str(exc_info.value)

    @patch("cv_screening_sdk.providers.azure.AsyncAzureOpenAI")
    @pytest.mark.asyncio
    async def test_initialize_async_with_no_token(self, mock_client_class):
        """Test that initialize_async correctly handles absence of a token."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Override the get_token_async method to return None
        provider.auth_provider.get_token_async = AsyncMock(return_value=None)
        
        # Test
        with pytest.raises(AuthenticationError) as exc_info:
            await provider.initialize_async()
        
        # Verification
        assert "No valid authentication token obtained" in str(exc_info.value)

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_get_chat_completion_without_initialization(self, mock_client_class):
        """Test that get_chat_completion initializes the client if necessary."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Mock for get_token
        provider.auth_provider.get_token = Mock(return_value="test-token")
        
        # Mock for the client and response
        mock_client = Mock()
        mock_completions = Mock()
        mock_chat = Mock()
        
        # Setup the call chain
        mock_client.chat = mock_chat
        mock_chat.completions = mock_completions
        mock_create = Mock()
        mock_completions.create = mock_create
        
        # Create mock response
        mock_response = Mock()
        mock_response.choices = [
            Mock(
                index=0,
                message=Mock(role="assistant", content="Test response"),
                finish_reason="stop"
            )
        ]
        
        mock_create.return_value = mock_response
        mock_client_class.return_value = mock_client
        
        # Test - client is not initialized
        assert provider.client is None
        result = provider.get_chat_completion([{"role": "user", "content": "Test message"}])
        
        # Verification
        assert provider.client is not None
        assert "choices" in result
        mock_client_class.assert_called_once()

    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_get_chat_completion_with_null_client(self, mock_client_class):
        """Test that get_chat_completion handles the case where the client is still None after initialize."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Mock for initialize but leaving client as None
        provider.initialize = Mock()
        provider.client = None
        
        # Test
        with pytest.raises(LLMError) as exc_info:
            provider.get_chat_completion([{"role": "user", "content": "Test message"}])
        
        # Verification
        assert "Failed to get chat completion: Client not initialized" in str(exc_info.value)

    @patch("cv_screening_sdk.providers.azure.AzureProvider._parse_response")
    @patch("cv_screening_sdk.providers.azure.AzureOpenAI")
    def test_analyze_cv_with_parsing_error(self, mock_client_class, mock_parse_response):
        """Test that analyze_cv correctly handles parsing errors."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Mock for get_chat_completion
        mock_response = {
            "choices": [
                {
                    "message": {
                        "content": "Test response"
                    }
                }
            ]
        }
        provider.get_chat_completion = Mock(return_value=mock_response)
        
        # Mock for _parse_response that raises an error
        mock_parse_response.side_effect = ProcessingError("Test parsing error")
        
        # Test
        with pytest.raises(ProcessingError) as exc_info:
            provider.analyze_cv("Test CV", {"required_skills": ["Python"]})
        
        # Verification
        assert "Failed to analyze CV: Test parsing error" in str(exc_info.value)

    @patch("cv_screening_sdk.providers.azure.AzureProvider.get_chat_completion")
    def test_analyze_cv_with_empty_choices(self, mock_get_chat_completion):
        """Test that analyze_cv correctly handles responses without choices."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Mock for get_chat_completion that returns a response without choices
        mock_get_chat_completion.return_value = {"no_choices": True}
        
        # Test
        with pytest.raises(ProcessingError) as exc_info:
            provider.analyze_cv("Test CV", {"required_skills": ["Python"]})
        
        # Verification
        assert "No completion choices returned" in str(exc_info.value)

    def test_get_system_prompt_custom(self):
        """Test that _get_system_prompt uses the custom prompt if provided."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        custom_prompt = "This is a custom prompt"
        
        # Test
        result = provider._get_system_prompt(custom_prompt)
        
        # Verification
        assert result == custom_prompt

    def test_get_system_prompt_default(self):
        """Test that _get_system_prompt returns the default prompt if no custom prompt is provided."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # Test
        result = provider._get_system_prompt()
        
        # Verification
        assert "You are an expert CV screening assistant" in result
        assert "Format your response as a JSON object" in result

    def test_parse_response_valid_json(self):
        """Test that _parse_response correctly processes valid JSON."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        valid_json = json.dumps({
            "match_score": 0.85,
            "skill_matches": {"Python": 1.0},
            "experience_match": {"years": 5}
        })
        
        # Test
        result = provider._parse_response(valid_json)
        
        # Verification
        assert result["match_score"] == 0.85
        assert "Python" in result["skill_matches"]
        assert result["experience_match"]["years"] == 5

    def test_parse_response_extract_json(self):
        """Test that _parse_response correctly extracts JSON from text."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        text_with_json = """Here's the CV analysis:
        
        {
            "match_score": 0.85,
            "skill_matches": {"Python": 1.0},
            "experience_match": {"years": 5}
        }
        
        I hope this is helpful."""
        
        # Test
        result = provider._parse_response(text_with_json)
        
        # Verification
        assert result["match_score"] == 0.85
        assert "Python" in result["skill_matches"]
        assert result["experience_match"]["years"] == 5

    def test_parse_response_no_json_structure(self):
        """Test that _parse_response correctly handles text without JSON structure."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        text_without_json = "This is a text that does not contain JSON."
        
        # Test
        with pytest.raises(ProcessingError) as exc_info:
            provider._parse_response(text_without_json)
        
        # Verification
        assert "Failed to parse response as JSON" in str(exc_info.value)

    def test_parse_response_missing_fields_fix(self):
        """Test that _parse_response attempts to fix missing fields."""
        # Setup
        provider = AzureProvider(
            endpoint="https://test.openai.azure.com/",
            deployment="test-deployment",
            api_version="2023-05-15"
        )
        
        # JSON with overall_score but without match_score
        incomplete_json = json.dumps({
            "overall_score": 85,
            "matched_skills": {"Python": 1.0}
        })
        
        # Test
        result = provider._parse_response(incomplete_json)
        
        # Verification
        assert "match_score" in result
        assert result["match_score"] == 85
        assert "skill_matches" in result
        assert "required_skills" in result["skill_matches"]
        assert "Python" in result["skill_matches"]["required_skills"]
        assert "experience_match" in result 