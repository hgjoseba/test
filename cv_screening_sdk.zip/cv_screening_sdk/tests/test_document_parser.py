"""
Tests for the document parser module.

This module contains tests for the DocumentParser class, verifying
its ability to parse different file formats in both sync and async modes.
"""

import asyncio
from unittest.mock import Mock, mock_open, patch

import pytest

from cv_screening_sdk.core.exceptions import ConfigurationError, DocumentParsingError
from cv_screening_sdk.parsers.document import DocumentParser


class TestDocumentParser:
    """Test suite for the DocumentParser class."""

    @pytest.fixture
    def parser(self):
        """Create a DocumentParser instance for testing."""
        return DocumentParser()

    @pytest.fixture
    def mock_file_exists(self):
        """Mock os.path.exists to return True."""
        with patch("os.path.exists", return_value=True):
            yield

    def test_init(self):
        """Test parser initialization."""
        parser = DocumentParser()
        assert parser.SUPPORTED_EXTENSIONS == {".pdf", ".txt", ".docx"}
        assert parser.logger is not None

    def test_validate_file_missing(self, parser):
        """Test validation of a missing file."""
        with patch("os.path.exists", return_value=False):
            with pytest.raises(DocumentParsingError, match="File not found"):
                parser._validate_file("nonexistent.pdf")

    def test_validate_file_unsupported(self, parser, mock_file_exists):
        """Test validation of an unsupported file format."""
        with pytest.raises(DocumentParsingError, match="Unsupported file format"):
            parser._validate_file("test.xyz")

    def test_validate_file_valid(self, parser, mock_file_exists):
        """Test validation of a valid file."""
        ext = parser._validate_file("test.pdf")
        assert ext == ".pdf"

    @patch("cv_screening_sdk.parsers.document.PdfReader")
    def test_parse_pdf_sync(self, mock_pdf_reader, parser, mock_file_exists):
        """Test synchronous PDF parsing."""
        # Setup mock
        mock_page = Mock()
        mock_page.extract_text.return_value = "Test PDF content"
        mock_pdf_reader.return_value.pages = [mock_page]

        # Test PDF parsing
        with patch("builtins.open", mock_open()):
            result = parser._parse_pdf_sync("test.pdf")
            assert result == "Test PDF content"

    def test_parse_txt_sync(self, parser, mock_file_exists):
        """Test synchronous text file parsing."""
        with patch("builtins.open", mock_open(read_data="Test text content")):
            result = parser._parse_txt_sync("test.txt")
            assert result == "Test text content"

    def test_parse_docx_sync_missing_package(self, parser, mock_file_exists):
        """Test DOCX parsing when python-docx is missing."""
        with patch.dict("sys.modules", {"docx": None}):
            with patch("importlib.import_module", side_effect=ImportError):
                with pytest.raises(
                    ConfigurationError, match="python-docx package is required"
                ):
                    parser._parse_docx_sync("test.docx")

    def test_parse(self, parser, mock_file_exists):
        """Test the main parse method."""
        # Setup mocks for different file types
        with patch.object(parser, "_parse_pdf_sync", return_value="PDF content"):
            with patch.object(parser, "_parse_txt_sync", return_value="TXT content"):
                with patch.object(
                    parser, "_parse_docx_sync", return_value="DOCX content"
                ):
                    # Test each file type
                    assert parser.parse("test.pdf") == "PDF content"
                    assert parser.parse("test.txt") == "TXT content"
                    assert parser.parse("test.docx") == "DOCX content"

    def test_parse_unsupported(self, parser, mock_file_exists):
        """Test parsing an unsupported file format."""
        with pytest.raises(DocumentParsingError, match="Unsupported file format"):
            parser.parse("test.xyz")


@pytest.mark.asyncio
class TestAsyncDocumentParser:
    """Test suite for the asynchronous methods of DocumentParser."""

    @pytest.fixture
    def parser(self):
        """Create a DocumentParser instance for testing."""
        return DocumentParser()

    @pytest.fixture
    def mock_file_exists(self):
        """Mock os.path.exists to return True."""
        with patch("os.path.exists", return_value=True):
            yield

    async def test_parse_txt_async(self, parser, mock_file_exists):
        """Test asynchronous text file parsing."""
        mock_file = Mock()
        mock_file.__aenter__.return_value.read = asyncio.coroutine(
            lambda: "Test async content"
        )()

        with patch(
            "cv_screening_sdk.parsers.document.aiofiles.open", return_value=mock_file
        ):
            result = await parser._parse_txt_async("test.txt")
            assert result == "Test async content"

    async def test_parse_pdf_async(self, parser, mock_file_exists):
        """Test asynchronous PDF parsing."""
        # Setup mock
        mock_file = Mock()
        mock_file.__aenter__.return_value.read = asyncio.coroutine(
            lambda: b"PDF data"
        )()

        mock_reader = Mock()
        mock_page = Mock()
        mock_page.extract_text.return_value = "Test PDF content"
        mock_reader.pages = [mock_page]

        with patch(
            "cv_screening_sdk.parsers.document.aiofiles.open", return_value=mock_file
        ):
            with patch(
                "cv_screening_sdk.parsers.document.PdfReader", return_value=mock_reader
            ):
                result = await parser._parse_pdf_async("test.pdf")
                assert result == "Test PDF content"

    async def test_parse_async_error(self, parser):
        """Test error handling in parse_async."""
        with patch("os.path.exists", return_value=False):
            with pytest.raises(DocumentParsingError, match="File not found"):
                await parser.parse_async("nonexistent.pdf")

    async def test_parse_async(self, parser, mock_file_exists):
        """Test the main async parse method."""
        # Setup mocks for different file types
        with patch.object(
            parser,
            "_parse_pdf_async",
            return_value=asyncio.coroutine(lambda: "PDF content")(),
        ):
            with patch.object(
                parser,
                "_parse_txt_async",
                return_value=asyncio.coroutine(lambda: "TXT content")(),
            ):
                with patch.object(
                    parser,
                    "_parse_docx_async",
                    return_value=asyncio.coroutine(lambda: "DOCX content")(),
                ):
                    # Test each file type
                    assert await parser.parse_async("test.pdf") == "PDF content"
                    assert await parser.parse_async("test.txt") == "TXT content"
                    assert await parser.parse_async("test.docx") == "DOCX content"
