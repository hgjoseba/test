#!/bin/bash

set -e  # Exit on error

# Ensure build directory exists and is clean
mkdir -p dist
rm -rf dist/*

# Ensure virtual environment is present
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Ensure pip is available and up to date
python3 -m ensurepip --upgrade
python3 -m pip install --upgrade pip

# Install build dependencies
echo "Installing build dependencies..."
python3 -m pip install build wheel setuptools

# Install project requirements
echo "Installing project requirements..."
python3 -m pip install -r requirements.txt

# Run linting and type checking
echo "Running linting and type checking..."
if command -v mypy &> /dev/null; then
    python3 -m mypy cv_screening_sdk
fi

if command -v black &> /dev/null; then
    python3 -m black --check cv_screening_sdk
fi

if command -v flake8 &> /dev/null; then
    python3 -m flake8 cv_screening_sdk
fi

# Run tests
#echo "Running tests..."
if command -v pytest &> /dev/null; then
    python3 -m pytest -xvs tests/
fi

# Build the package
echo "Building the package..."
python3 -m build

# Create wheel package
python3 -m pip wheel --no-deps -w dist .

echo "CV Screening SDK compilation complete!"
echo "Built files can be found in the 'dist' directory:"
ls -la dist/
# Deactivate virtual environment
deactivate
