#!/usr/bin/env python3
"""
Version bumping utility for CV Screening SDK.

This script helps maintain consistent versioning by updating the version
in __version__.py according to semantic versioning principles.

Usage:
    python scripts/bump_version.py [major|minor|patch]
"""

import argparse
import re
import sys
from pathlib import Path

VERSION_FILE = "cv_screening_sdk/__version__.py"


def bump_version(version_type: str) -> None:
    """
    Bump the version number in __version__.py.

    Args:
        version_type: One of "major", "minor", or "patch"
    """
    # Check if version file exists
    version_path = Path(VERSION_FILE)
    if not version_path.exists():
        print(f"Error: Version file not found at {VERSION_FILE}")
        sys.exit(1)

    # Read current version
    with open(version_path, "r") as f:
        content = f.read()

    # Extract version number
    version_match = re.search(r'__version__ = "(\d+)\.(\d+)\.(\d+)"', content)
    if not version_match:
        print("Error: Could not find version in file")
        sys.exit(1)

    # Parse version components
    major, minor, patch = map(int, version_match.groups())

    # Bump version according to specified type
    if version_type == "major":
        major += 1
        minor = 0
        patch = 0
    elif version_type == "minor":
        minor += 1
        patch = 0
    elif version_type == "patch":
        patch += 1
    else:
        print(f"Invalid version type: {version_type}")
        print("Use one of: major, minor, patch")
        sys.exit(1)

    # Create new version string
    new_version = f"{major}.{minor}.{patch}"
    new_content = re.sub(
        r'__version__ = "(\d+)\.(\d+)\.(\d+)"',
        f'__version__ = "{new_version}"',
        content,
    )

    # Write updated version back to file
    with open(version_path, "w") as f:
        f.write(new_content)

    print(f"Version bumped to {new_version}")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Bump CV Screening SDK version")
    parser.add_argument(
        "version_type",
        choices=["major", "minor", "patch"],
        help="Type of version increment to apply",
    )

    args = parser.parse_args()
    bump_version(args.version_type)


if __name__ == "__main__":
    main()
