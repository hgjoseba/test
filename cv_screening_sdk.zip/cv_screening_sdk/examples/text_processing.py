"""
Text Processing Example for CV Screening SDK

This example demonstrates how to:
1. Process CV content from plain text
2. Use different text formats and structures
3. Handle text preprocessing and cleaning
4. Generate structured results from text input
"""

import os
from pathlib import Path
from typing import Dict, List
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig

def load_cv_text(file_path: str) -> str:
    """Load CV content from a text file."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def format_cv_text(text: str) -> str:
    """Format CV text for better processing."""
    # Remove extra whitespace
    text = ' '.join(text.split())
    # Ensure proper line breaks
    text = text.replace('. ', '.\n')
    return text

def text_processing_example():
    """Run a text processing example."""
    # Load environment variables
    load_dotenv()

    # Create configuration
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        max_tokens=int(os.getenv("AZURE_OPENAI_MAX_TOKENS", "4000")),
        temperature=float(os.getenv("AZURE_OPENAI_TEMPERATURE", "0.7")),
        top_p=float(os.getenv("AZURE_OPENAI_TOP_P", "1.0")),
        frequency_penalty=float(os.getenv("AZURE_OPENAI_FREQUENCY_PENALTY", "0.0")),
        presence_penalty=float(os.getenv("AZURE_OPENAI_PRESENCE_PENALTY", "0.0")),
        # SSL options (optional)
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"],
        ssl_cert_path=os.getenv("AZURE_OPENAI_SSL_CERT_PATH"),
    )

    sdk_config = SDKConfig(
        max_batch_size=int(os.getenv("CV_SCREENING_MAX_BATCH_SIZE", "10")),
        timeout_seconds=int(os.getenv("CV_SCREENING_TIMEOUT", "30")),
        retry_attempts=int(os.getenv("CV_SCREENING_RETRY_ATTEMPTS", "3")),
        log_level=os.getenv("CV_SCREENING_LOG_LEVEL", "INFO"),
    )

    client_config = ClientConfig(
        azure=azure_config,
        sdk=sdk_config
    )

    # Initialize client
    client = CVScreeningClient(config=client_config)

    # Define evaluation criteria
    criteria = JobCriteria(
        required_skills=["Python", "AWS", "Docker"],
        preferred_skills=["Kubernetes", "CI/CD"],
        min_years_experience=3,
        education_level="Bachelor's",
        role_title="Software Engineer"
    )

    # Example 1: Structured text format
    structured_cv = """
    PROFESSIONAL SUMMARY
    Senior Software Engineer with 5 years of experience in Python development and cloud technologies.

    SKILLS
    - Python, Django, Flask
    - AWS (EC2, S3, Lambda)
    - Docker, Kubernetes
    - CI/CD (Jenkins, GitHub Actions)
    - Git, Linux

    EXPERIENCE
    Senior Software Engineer | Tech Corp | 2020-Present
    - Led development of microservices architecture
    - Implemented CI/CD pipelines
    - Mentored junior developers

    Software Engineer | StartUp Inc | 2018-2020
    - Developed REST APIs
    - Managed AWS infrastructure
    - Implemented automated testing

    EDUCATION
    Bachelor's in Computer Science | University of Technology | 2018
    """

    # Example 2: Unstructured text format
    unstructured_cv = """
    John Smith is a passionate software engineer with expertise in Python and cloud technologies.
    He has worked on various projects using AWS, Docker, and Kubernetes. His experience includes
    building scalable applications and implementing CI/CD pipelines. He holds a Bachelor's degree
    in Computer Science and has mentored junior developers throughout his career.
    """

    try:
        # Process structured CV
        print("\n=== Processing Structured CV ===")
        structured_result = client.analyze_cv(structured_cv, criteria)
        print(f"Match Score: {structured_result.overall_score}/100")
        print(f"Skills Found: {', '.join(structured_result.skills_found)}")
        print(f"Experience: {structured_result.experience_years} years")
        print(f"Key Strengths: {', '.join(structured_result.key_strengths)}")

        # Process unstructured CV
        print("\n=== Processing Unstructured CV ===")
        unstructured_result = client.analyze_cv(unstructured_cv, criteria)
        print(f"Match Score: {unstructured_result.overall_score}/100")
        print(f"Skills Found: {', '.join(unstructured_result.skills_found)}")
        print(f"Experience: {unstructured_result.experience_years} years")
        print(f"Key Strengths: {', '.join(unstructured_result.key_strengths)}")

        # Example 3: Load from file
        cv_file = Path(__file__).parent / "resumes" / "sample_cv.txt"
        if cv_file.exists():
            print("\n=== Processing CV from File ===")
            cv_text = load_cv_text(str(cv_file))
            formatted_text = format_cv_text(cv_text)
            file_result = client.analyze_cv(formatted_text, criteria)
            print(f"Match Score: {file_result.overall_score}/100")
            print(f"Skills Found: {', '.join(file_result.skills_found)}")
            print(f"Experience: {file_result.experience_years} years")
            print(f"Key Strengths: {', '.join(file_result.key_strengths)}")

    except Exception as e:
        print(f"Error during text processing: {e}")

if __name__ == "__main__":
    text_processing_example() 