"""
Text Processing Example for CV Screening SDK

This example demonstrates how to:
1. Process CV content from plain text
2. Use different text formats and structures
3. Handle text preprocessing and cleaning
4. Generate structured results from text input
"""

import os
from pathlib import Path
from typing import Dict, List
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig

def load_cv_text(file_path: str) -> str:
    """Load CV content from a text file."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def format_cv_text(text: str) -> str:
    """Format CV text for better processing."""
    # Remove extra whitespace
    text = ' '.join(text.split())
    # Ensure proper line breaks
    text = text.replace('. ', '.\n')
    return text

def text_processing_example():
    """Run a text processing example."""
    # Load environment variables
    load_dotenv()

    # Configure Azure settings
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        # SSL settings
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"],
        ssl_cert_path=os.getenv("AZURE_OPENAI_SSL_CERT_PATH"),
        # Connection settings
        connection_timeout=int(os.getenv("AZURE_OPENAI_CONNECTION_TIMEOUT", "30")),
        max_keepalive_connections=int(os.getenv("AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS", "5")),
        max_connections=int(os.getenv("AZURE_OPENAI_MAX_CONNECTIONS", "10")),
        connection_verify=os.getenv("AZURE_OPENAI_CONNECTION_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    sdk_config = SDKConfig(
        max_batch_size=int(os.getenv("CV_SCREENING_MAX_BATCH_SIZE", "10")),
        timeout_seconds=int(os.getenv("CV_SCREENING_TIMEOUT", "30")),
        retry_attempts=int(os.getenv("CV_SCREENING_RETRY_ATTEMPTS", "3")),
        log_level=os.getenv("CV_SCREENING_LOG_LEVEL", "INFO"),
    )

    client_config = ClientConfig(
        azure=azure_config,
        sdk=sdk_config
    )

    # Initialize client with configuration
    client = CVScreeningClient(config=client_config)

    # Define evaluation criteria
    criteria = JobCriteria(
        required_skills=["python", "aws"],
        preferred_skills=["docker", "kubernetes"],
        min_years_experience=3,
        education_level="bachelors"
    )

    # Example 1: Structured text format
    structured_cv = """
    PROFESSIONAL SUMMARY
    Senior Software Engineer with 5 years of experience in Python development and cloud technologies.

    SKILLS
    - Python, Django, Flask
    - AWS (EC2, S3, Lambda)
    - Docker, Kubernetes
    - CI/CD (Jenkins, GitHub Actions)
    - Git, Linux

    EXPERIENCE
    Senior Software Engineer | Tech Corp | 2020-Present
    - Led development of microservices architecture
    - Implemented CI/CD pipelines
    - Mentored junior developers

    Software Engineer | StartUp Inc | 2018-2020
    - Developed REST APIs
    - Managed AWS infrastructure
    - Implemented automated testing

    EDUCATION
    Bachelor's in Computer Science | University of Technology | 2018
    """

    # Example 2: Unstructured text format
    unstructured_cv = """
    John Smith is a passionate software engineer with expertise in Python and cloud technologies.
    He has worked on various projects using AWS, Docker, and Kubernetes. His experience includes
    building scalable applications and implementing CI/CD pipelines. He holds a Bachelor's degree
    in Computer Science and has mentored junior developers throughout his career.
    """

    try:
        # Process structured CV
        print("\n=== Processing Structured CV ===")
        structured_result = client.analyze_cv(structured_cv, criteria)
        print(f"Match Score: {structured_result.overall_score}/100")
        print(f"Skills Found: {', '.join(structured_result.skills_found)}")
        print(f"Experience: {structured_result.experience_years} years")
        print(f"Key Strengths: {', '.join(structured_result.key_strengths)}")

        # Process unstructured CV
        print("\n=== Processing Unstructured CV ===")
        unstructured_result = client.analyze_cv(unstructured_cv, criteria)
        print(f"Match Score: {unstructured_result.overall_score}/100")
        print(f"Skills Found: {', '.join(unstructured_result.skills_found)}")
        print(f"Experience: {unstructured_result.experience_years} years")
        print(f"Key Strengths: {', '.join(unstructured_result.key_strengths)}")

        # Example 3: Load from file
        cv_file = Path(__file__).parent / "resumes" / "sample_cv.txt"
        if cv_file.exists():
            print("\n=== Processing CV from File ===")
            cv_text = load_cv_text(str(cv_file))
            formatted_text = format_cv_text(cv_text)
            file_result = client.analyze_cv(formatted_text, criteria)
            print(f"Match Score: {file_result.overall_score}/100")
            print(f"Skills Found: {', '.join(file_result.skills_found)}")
            print(f"Experience: {file_result.experience_years} years")
            print(f"Key Strengths: {', '.join(file_result.key_strengths)}")

        # Generate structured report
        generate_structured_report(structured_result)

    except Exception as e:
        print(f"Error during text processing: {e}")

def generate_structured_report(result):
    """Generate a structured report from the CV analysis results."""
    report = f"""
    CV Analysis Report
    ================
    
    Candidate Profile
    ----------------
    Overall Match Score: {result.overall_score}%
    
    Skills Assessment
    ----------------
    Required Skills Match: {result.skills_match.score}%
    Preferred Skills Match: {result.skills_match.preferred_score}%
    
    Required Skills Found:
    {', '.join(result.skills_match.required_skills)}
    
    Preferred Skills Found:
    {', '.join(result.skills_match.preferred_skills)}
    
    Experience Assessment
    -------------------
    Years of Experience: {result.experience_years}
    Experience Match Score: {result.experience_match.score}%
    Meets Minimum Experience: {'Yes' if result.experience_match.meets_minimum else 'No'}
    
    Education Assessment
    ------------------
    Education Level Match: {'Yes' if result.education_match.level_match else 'No'}
    Field Relevance: {result.education_match.field_relevance}%
    Education Match Score: {result.education_match.score}%
    
    Education Details:
    - Highest Level: {result.education_match.education_details.highest_level}
    - Field: {result.education_match.education_details.field}
    - Institution: {result.education_match.education_details.institution}
    
    Recommendations
    --------------
    {result.recommendations}
    """
    
    # Save report to file
    with open("cv_structured_report.txt", "w") as f:
        f.write(report)
    print("\nStructured report has been saved to 'cv_structured_report.txt'")

if __name__ == "__main__":
    text_processing_example() 