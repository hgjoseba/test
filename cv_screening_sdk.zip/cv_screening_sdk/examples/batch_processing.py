"""
Batch Processing Example for CV Screening SDK

This example demonstrates how to:
1. Initialize the client with proper configuration
2. Create screening criteria
3. Process multiple CVs in batch
4. Sort and analyze results collectively
5. Generate detailed reports
"""

import os
import time
from pathlib import Path
from typing import List
from datetime import datetime
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig


def generate_report(results, processing_time: float, output_dir: Path) -> None:
    """Generate a detailed report of the screening results."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"screening_report_{timestamp}.txt"
    
    with open(report_path, "w") as f:
        f.write("=== CV Screening Batch Report ===\n\n")
        f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Total Processing Time: {processing_time:.2f} seconds\n")
        f.write(f"Success Rate: {results.success_rate() * 100:.1f}%\n")
        f.write(f"Average Score: {results.average_score():.1f}/100\n\n")
        
        f.write("=== Candidate Rankings ===\n")
        sorted_results = sorted(
            results.successful_results, key=lambda x: x.overall_score, reverse=True
        )
        for i, result in enumerate(sorted_results, 1):
            f.write(f"\nRank #{i}: {os.path.basename(result.cv_path)}\n")
            f.write(f"Overall Score: {result.overall_score}/100\n")
            f.write(f"Skills Match: {', '.join(result.skills_found[:5])}...\n")
            f.write(f"Experience: {result.experience_years} years\n")
            f.write(f"Education: {result.education_level}\n")
            f.write(f"Key Strengths: {', '.join(result.key_strengths)}\n")
            f.write(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}\n")
            f.write("-" * 50 + "\n")
        
        if results.failed_results:
            f.write("\n=== Processing Failures ===\n")
            for failure in results.failed_results:
                f.write(f"\nFailed to process {failure.cv_path}:\n")
                f.write(f"Error: {failure.error}\n")
                f.write("-" * 50 + "\n")


def batch_cv_screening():
    """Run a batch CV screening example."""
    # Load environment variables
    load_dotenv()

    # Initialize the client with proper configuration
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
    )

    sdk_config = SDKConfig(
        max_batch_size=20,
        log_level="INFO",
        timeout_seconds=60,
        retry_attempts=3,
        retry_delay_seconds=1
    )

    config = ClientConfig(azure=azure_config, sdk=sdk_config)

    try:
        client = CVScreeningClient(config)
    except Exception as e:
        print(f"Error initializing client: {e}")
        return

    # Define screening criteria for a developer role
    criteria = JobCriteria(
        required_skills=["Python", "Java", "SQL"],
        preferred_skills=["Spring Boot", "Microservices", "Docker"],
        min_years_experience=5,
        education_level="Master's",
        role_title="Senior Backend Developer",
        industry="Finance",
        additional_requirements=[
            "Experience with cloud platforms (AWS/Azure/GCP)",
            "Strong system design skills",
            "Team leadership experience"
        ]
    )

    # Get the example CVs directory
    resumes_dir = Path(__file__).parent / "resumes"
    if not resumes_dir.exists():
        print(f"Error: Resumes directory not found at {resumes_dir}")
        return

    # List of CVs to process
    cv_paths = [
        str(resumes_dir / "senior_java_dev.pdf"),
        str(resumes_dir / "data_engineer.pdf"),
        str(resumes_dir / "tech_lead.docx"),
    ]

    # Verify CV files exist
    missing_files = [path for path in cv_paths if not Path(path).exists()]
    if missing_files:
        print("Error: The following CV files were not found:")
        for file in missing_files:
            print(f"- {file}")
        return

    # Record processing time
    start_time = time.time()

    try:
        # Batch process CVs
        batch_results = client.batch_screen_cvs(cv_paths, criteria)

        # Calculate processing time
        processing_time = time.time() - start_time

        # Print overall statistics
        print("\n=== Processing Statistics ===")
        print(f"Processed {len(cv_paths)} CVs in {processing_time:.2f} seconds")
        print(f"Success rate: {batch_results.success_rate() * 100:.1f}%")
        print(f"Average score: {batch_results.average_score():.1f}/100")

        # Generate detailed report
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        generate_report(batch_results, processing_time, reports_dir)
        print(f"\nDetailed report generated in: {reports_dir}")

        # Display top candidates
        print("\n=== Top Candidates ===")
        sorted_results = sorted(
            batch_results.successful_results, key=lambda x: x.overall_score, reverse=True
        )
        for i, result in enumerate(sorted_results[:3], 1):
            print(f"\nRank #{i}: {os.path.basename(result.cv_path)}")
            print(f"Overall Score: {result.overall_score}/100")
            print(f"Key Skills: {', '.join(result.skills_found[:5])}...")
            print(f"Experience: {result.experience_years} years")
            print(f"Education: {result.education_level}")

        # Print any failures
        if batch_results.failed_results:
            print("\n=== Processing Failures ===")
            for failure in batch_results.failed_results:
                print(f"Failed to process {failure.cv_path}: {failure.error}")

    except Exception as e:
        print(f"Error during batch processing: {e}")


if __name__ == "__main__":
    batch_cv_screening()
