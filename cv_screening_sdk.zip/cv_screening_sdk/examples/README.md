# CV Screening SDK Examples

This directory contains example scripts demonstrating how to use the CV Screening SDK for different use cases.

## Example Files

- [`basic_usage.py`](basic_usage.py): Simple example showing how to screen a single CV against criteria
- [`batch_processing.py`](batch_processing.py): Example of processing multiple CVs in batch mode
- [`async_processing.py`](async_processing.py): Demonstrates asynchronous processing for improved performance
- [`cv_screening_with_prompt.py`](cv_screening_with_prompt.py): Shows how to use natural language prompts instead of structured criteria
- [`ssl_configuration.py`](ssl_configuration.py): Demonstrates how to configure SSL options for Azure OpenAI connections
- [`system_prompt_example.py`](system_prompt_example.py): Muestra cómo personalizar el system prompt para análisis más especializados

## Getting Started

1. Make sure you have installed the CV Screening SDK:
   ```bash
   # Build the wheel package
   ./compile_sdk.sh
   
   # Install from wheel package
   pip install dist/cv_screening_sdk-*.whl
   ```

2. Set up your Azure OpenAI credentials:
   ```bash
   # Create a .env file in the examples directory with your credentials
   AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
   AZURE_OPENAI_DEPLOYMENT_NAME="your_deployment_name"
   AZURE_OPENAI_API_VERSION="2023-05-15"
   AZURE_TENANT_ID="your-tenant-id"
   AZURE_CLIENT_ID="your-client-id"
   AZURE_CLIENT_SECRET="your-client-secret"
   # SSL options (optional)
   AZURE_OPENAI_SSL_VERIFY="False"  # Disable SSL verification
   AZURE_OPENAI_SSL_CERT_PATH="/path/to/custom/cert.pem"  # Use custom certificate
   ```

3. Run any example:
   ```bash
   python examples/basic_usage.py
   ```

## Example Features

### Basic Usage
- Initialize the client with proper Azure configuration
- Create screening criteria with JobCriteria class
- Process a single CV
- Display detailed match results
- Generate comprehensive reports

### Batch Processing
- Process multiple CVs in sequence
- Track processing time and success rate
- Sort candidates by match score
- Handle processing failures
- Generate detailed batch reports
- Advanced error handling and retries

### Async Processing
- Concurrent CV processing with improved performance
- Custom filtering and categorization of results
- Detailed error handling
- Candidate qualification assessment
- Generate analytics reports
- Skills distribution analysis

### Natural Language Prompt
- Use free-text job descriptions
- Let the LLM extract structured criteria automatically
- Get detailed breakdowns of skills, experience, and education
- Receive personalized recommendations
- Generate comprehensive screening reports
- Advanced prompt engineering examples

### SSL Configuration
- Configure SSL options to resolve connection issues with Azure OpenAI
- Disable SSL verification for development environments
- Use custom SSL certificates for corporate environments
- Apply SSL settings through environment variables or code

### Custom System Prompt
- Personalizar las instrucciones de análisis con system prompts especializados
- Comparar resultados entre el system prompt estándar y el personalizado
- Enfocar el análisis en aspectos específicos de los roles o industrias
- Adaptar la evaluación a criterios organizacionales específicos
- Procesar lotes de CVs con un system prompt personalizado
- Ver documentación detallada en [`README_system_prompt.md`](README_system_prompt.md)

## Report Generation

All examples now include report generation capabilities:
- Detailed screening reports
- Analytics reports for batch processing
- Skills distribution analysis
- Candidate rankings and assessments
- Processing statistics and metrics

Reports are saved in the `examples/reports` directory with timestamps.

## Customizing the Examples

The examples include comments explaining each step and how to customize them for your needs. The main components you'll need to modify are:

1. **Azure Configuration**: Set up your credentials in the `.env` file
2. **CV Paths**: Update the file paths to point to your actual CV files
3. **Screening Criteria**: Adjust the skills, experience, and education requirements to match your job description
4. **Report Generation**: Customize the report format and content as needed
5. **SSL Settings**: Configure SSL options if you have connection issues with Azure OpenAI

## Supported Document Formats

The SDK supports the following document formats:
- PDF (.pdf)
- Plain text (.txt)
- Microsoft Word (.docx) - Requires `python-docx` package

## Error Handling

All examples now include comprehensive error handling:
- File existence checks
- Configuration validation
- Processing error handling
- Retry mechanisms for transient failures
- Detailed error reporting

## Advanced Usage

For more advanced use cases, check out the [API Documentation](../API.md) and [Configuration Guide](../docs/configuration.md).