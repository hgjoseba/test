"""
Direct API Access Example for CV Screening SDK

This example demonstrates how to:
1. Access the raw completion_response field from Azure OpenAI API
2. Extract technical metadata from the raw response
3. Compare raw and processed responses
4. Use the raw response for custom processing logic
"""

import os
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional
from dotenv import load_dotenv
import asyncio

from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig, LogConfig
from cv_screening_sdk.providers.azure import AzureProvider


def get_raw_completion_with_provider():
    """Example showing how to directly use the AzureProvider to get raw completions."""
    # Load environment variables
    load_dotenv()

    # Initialize provider directly
    provider = AzureProvider(
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    # Initialize the provider
    provider.initialize()

    # Simple messages for chat completion
    messages = [
        {"role": "system", "content": "You are a helpful assistant that specializes in data analysis."},
        {"role": "user", "content": "What are three key Python libraries for data analysis?"}
    ]

    print("\n=== Direct Provider Raw Response Example ===")
    
    try:
        # Get raw completion response
        raw_response = provider.get_chat_completion(
            messages=messages,
            temperature=0.7,
            return_raw_response=True
        )
        
        # Get processed completion response for comparison
        processed_response = provider.get_chat_completion(
            messages=messages,
            temperature=0.7,
            return_raw_response=False
        )
        
        # Display raw response details
        print("Raw Response Details:")
        print(f"Model: {raw_response.model}")
        print(f"Object type: {raw_response.object}")
        print(f"Created timestamp: {raw_response.created}")
        
        if hasattr(raw_response, 'usage'):
            print("\nToken Usage:")
            print(f"Prompt tokens: {raw_response.usage.prompt_tokens}")
            print(f"Completion tokens: {raw_response.usage.completion_tokens}")
            print(f"Total tokens: {raw_response.usage.total_tokens}")
        
        # Display first choice content
        if hasattr(raw_response, 'choices') and len(raw_response.choices) > 0:
            print("\nResponse Content:")
            print(f"Role: {raw_response.choices[0].message.role}")
            print(f"Content: {raw_response.choices[0].message.content}")
            print(f"Finish reason: {raw_response.choices[0].finish_reason}")
        
        # Compare with processed response
        print("\nProcessed Response Structure:")
        print(f"Type: {type(processed_response)}")
        print(f"Keys: {list(processed_response.keys())}")
        if "choices" in processed_response:
            print(f"Number of choices: {len(processed_response['choices'])}")
            
        # Save both responses for comparison
        output_dir = Path(__file__).parent / "comparison_responses"
        output_dir.mkdir(exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Function to safely convert response to dict
        def to_dict(obj: Any) -> Dict[str, Any]:
            if hasattr(obj, "model_dump"):
                return obj.model_dump()
            elif hasattr(obj, "__dict__"):
                result = {}
                for k, v in vars(obj).items():
                    if hasattr(v, "__dict__") or hasattr(v, "model_dump"):
                        result[k] = to_dict(v)
                    elif isinstance(v, list):
                        result[k] = [to_dict(item) if hasattr(item, "__dict__") else item for item in v]
                    else:
                        result[k] = v
                return result
            elif isinstance(obj, dict):
                return obj
            else:
                return {"value": str(obj)}
        
        # Save raw response
        with open(output_dir / f"raw_response_{timestamp}.json", "w") as f:
            json.dump(to_dict(raw_response), f, indent=2, default=str)
        
        # Save processed response
        with open(output_dir / f"processed_response_{timestamp}.json", "w") as f:
            json.dump(processed_response, f, indent=2)
            
        print(f"\nResponses saved to {output_dir} for comparison")
        
    except Exception as e:
        print(f"Error accessing raw response: {e}")
        import traceback
        traceback.print_exc()


async def analyze_cv_with_raw_response():
    """Example showing how to analyze a CV and get the raw response for debugging."""
    # Load environment variables
    load_dotenv()

    # Configure Azure settings
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    # Create SDK configuration
    sdk_config = SDKConfig(
        azure=azure_config,
        client=ClientConfig(),
        log=LogConfig(level="INFO")
    )

    # Initialize client
    client = CVScreeningClient(config=sdk_config)

    # Job criteria
    criteria = JobCriteria(
        required_skills=["python", "machine learning"],
        preferred_skills=["tensorflow", "pytorch", "nlp"],
        min_years_experience=2,
        education_level="masters"
    )

    # Sample CV
    cv_text = """
    Dr. Emily Chen
    Machine Learning Engineer

    Experience:
    - Senior ML Engineer at AI Research (2019-present)
    - Data Scientist at Tech Innovation (2017-2019)

    Technical Skills:
    - Python, R, C++
    - TensorFlow, PyTorch, Keras
    - Natural Language Processing, Computer Vision
    - Data visualization (Matplotlib, Seaborn)
    - Big Data (Spark, Hadoop)

    Education:
    - Ph.D. in Computer Science, Stanford University
    - M.S. in Data Science, MIT
    - B.S. in Mathematics, UC Berkeley

    Publications:
    - "Advances in Neural Network Architectures" (2021)
    - "Efficient Transformer Models for NLP Tasks" (2020)
    """

    print("\n=== CV Analysis with Raw Response ===")

    try:
        # First, get the processed result for reference
        result = await client.analyze_cv_async(cv_text, criteria)
        
        print("Processed Analysis Result:")
        print(f"Overall Score: {result.overall_score}/100")
        print(f"Skills Match: Found {len(result.skills_found)} required/preferred skills")
        print(f"Experience: {result.experience_years} years")
        print(f"Education: {result.education_level}")
        
        # Now get the raw response
        raw_response = await client.analyze_cv_async(cv_text, criteria, return_raw_response=True)
        
        print("\nRaw Response Metadata:")
        print(f"Model: {raw_response.model}")
        if hasattr(raw_response, 'usage'):
            print(f"Token usage: {raw_response.usage.total_tokens} tokens")
            print(f"  - Prompt tokens: {raw_response.usage.prompt_tokens}")
            print(f"  - Completion tokens: {raw_response.usage.completion_tokens}")
        
        # Extract JSON from the raw response
        if hasattr(raw_response, 'choices') and len(raw_response.choices) > 0:
            content = raw_response.choices[0].message.content
            print("\nRaw JSON Response:")
            print(f"{content[:200]}...")  # Just show the start
            
            # Parse the content to extract the same fields as the processed response
            try:
                json_data = json.loads(content)
                
                print("\nExtracted Data from Raw Response:")
                print(f"Match Score: {json_data.get('match_score', 'N/A')}")
                print(f"Overall Score: {json_data.get('overall_score', 'N/A')}")
                
                # Show skill matches
                if 'skill_matches' in json_data:
                    skills = json_data['skill_matches']
                    print("\nSkill Matches:")
                    if 'required_skills' in skills:
                        print("Required Skills:")
                        for skill, score in skills['required_skills'].items():
                            print(f"  - {skill}: {score}")
                    
                    if 'preferred_skills' in skills:
                        print("Preferred Skills:")
                        for skill, score in skills['preferred_skills'].items():
                            print(f"  - {skill}: {score}")
                
                # Show missing skills
                missing_required = json_data.get('skill_matches', {}).get('missing_required', [])
                if missing_required:
                    print("\nMissing Required Skills:")
                    for skill in missing_required:
                        print(f"  - {skill}")
                
            except json.JSONDecodeError:
                print("Could not parse JSON from raw response")
        
        # Demonstrate a custom calculation using the raw response
        if hasattr(raw_response, 'usage'):
            token_cost_estimate = (
                raw_response.usage.prompt_tokens * 0.0001 + 
                raw_response.usage.completion_tokens * 0.0002
            )
            print(f"\nEstimated API cost: ${token_cost_estimate:.6f} (example calculation)")
        
    except Exception as e:
        print(f"Error in CV analysis with raw response: {e}")
        import traceback
        traceback.print_exc()


async def main():
    """Run all examples."""
    get_raw_completion_with_provider()
    print("\n" + "="*50 + "\n")
    await analyze_cv_with_raw_response()


if __name__ == "__main__":
    asyncio.run(main()) 