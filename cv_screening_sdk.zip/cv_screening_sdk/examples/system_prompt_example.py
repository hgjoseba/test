"""
Ejemplo de Uso Personalizado del System Prompt en CV Screening SDK

Este ejemplo demuestra cómo:
1. Inicializar el cliente con la configuración adecuada
2. Utilizar un system prompt personalizado para análisis de CV
3. Procesar varios CVs con diferentes enfoques de análisis
4. Comparar los resultados con y sin un system prompt personalizado
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig, LogConfig
from datetime import datetime
import asyncio
import json
from pprint import pprint
from typing import Dict, Any, List, Optional

# Importamos estas clases para crear manualmente los objetos de resultado si es necesario
from cv_screening_sdk.models.results import CVScreeningResult, SkillMatch, ExperienceMatch, EducationMatch

def generar_reporte_comparativo(resultado_estandar, resultado_personalizado, output_dir: Path) -> None:
    """Genera un reporte comparativo de los resultados de screening con diferentes prompts."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"comparacion_prompts_{timestamp}.txt"
    
    with open(report_path, "w") as f:
        f.write("=== Comparación de Resultados de Screening de CV ===\n\n")
        f.write(f"Generado el: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        f.write("=== Resultados con System Prompt Estándar ===\n")
        f.write(f"Puntuación Global: {resultado_estandar.overall_score}/100\n")
        f.write(f"Habilidades Encontradas: {', '.join(resultado_estandar.skills_found)}\n")
        f.write(f"Habilidades Faltantes: {', '.join(resultado_estandar.missing_skills)}\n")
        f.write(f"Años de Experiencia: {resultado_estandar.experience_years}\n\n")
        f.write(f"Resumen: {resultado_estandar.summary}\n\n")
        
        f.write("=== Resultados con System Prompt Personalizado ===\n")
        f.write(f"Puntuación Global: {resultado_personalizado.overall_score}/100\n")
        f.write(f"Habilidades Encontradas: {', '.join(resultado_personalizado.skills_found)}\n")
        f.write(f"Habilidades Faltantes: {', '.join(resultado_personalizado.missing_skills)}\n")
        f.write(f"Años de Experiencia: {resultado_personalizado.experience_years}\n\n")
        f.write(f"Resumen: {resultado_personalizado.summary}\n\n")
        
        f.write("=== Análisis Comparativo ===\n")
        diferencia_score = abs(resultado_estandar.overall_score - resultado_personalizado.overall_score)
        f.write(f"Diferencia en Puntuación: {diferencia_score} puntos\n")
        
        # Comparar habilidades encontradas
        skills_estandar = set(resultado_estandar.skills_found)
        skills_personalizado = set(resultado_personalizado.skills_found)
        skills_adicionales = skills_personalizado - skills_estandar
        skills_omitidas = skills_estandar - skills_personalizado
        
        if skills_adicionales:
            f.write(f"Habilidades adicionales identificadas con prompt personalizado: {', '.join(skills_adicionales)}\n")
        if skills_omitidas:
            f.write(f"Habilidades omitidas con prompt personalizado: {', '.join(skills_omitidas)}\n")
        
        # Comparar resumen
        f.write("\nDiferencias en el enfoque del análisis:\n")
        f.write("El prompt personalizado puede proporcionar análisis más específicos o enfocados en ciertos aspectos.\n")
        
    print(f"Reporte comparativo generado en: {report_path}")

def adaptar_resultado_llm(respuesta_llm: Dict[str, Any]) -> Dict[str, Any]:
    """
    Adapta la respuesta del LLM para que tenga la estructura esperada por CVScreeningResult.from_llm_response.
    
    Args:
        respuesta_llm: Respuesta original del LLM
        
    Returns:
        Respuesta adaptada con la estructura correcta
    """
    # Creamos una copia para no modificar el original
    respuesta_adaptada = respuesta_llm.copy()
    
    # Aseguramos que exista overall_score (o match_score)
    if "overall_score" not in respuesta_adaptada and "match_score" not in respuesta_adaptada:
        # Buscamos cualquier campo que pueda contener un score
        for key in respuesta_adaptada:
            if "score" in key.lower() and isinstance(respuesta_adaptada[key], (int, float)):
                respuesta_adaptada["overall_score"] = float(respuesta_adaptada[key])
                break
        
        # Si aún no encontramos un score, usamos un valor por defecto
        if "overall_score" not in respuesta_adaptada:
            respuesta_adaptada["overall_score"] = 0.0
    
    # Convertimos match_score a escala 0-100 si es necesario
    if "match_score" in respuesta_adaptada and isinstance(respuesta_adaptada["match_score"], (int, float)):
        score = float(respuesta_adaptada["match_score"])
        if 0 <= score <= 1:
            respuesta_adaptada["overall_score"] = score * 100
        else:
            respuesta_adaptada["overall_score"] = score
    
    # Aseguramos que exista skill_matches
    if "skill_matches" not in respuesta_adaptada:
        # Intentamos encontrar campos relacionados con habilidades
        required_skills = {}
        preferred_skills = {}
        missing_required = []
        
        # Buscar campos relacionados con habilidades
        if "skills_found" in respuesta_adaptada and isinstance(respuesta_adaptada["skills_found"], list):
            for skill in respuesta_adaptada["skills_found"]:
                required_skills[skill] = 1.0
                
        if "matched_skills" in respuesta_adaptada and isinstance(respuesta_adaptada["matched_skills"], list):
            for skill in respuesta_adaptada["matched_skills"]:
                required_skills[skill] = 1.0
                
        if "missing_skills" in respuesta_adaptada and isinstance(respuesta_adaptada["missing_skills"], list):
            missing_required = respuesta_adaptada["missing_skills"]
        
        # Usar un valor por defecto para overall_score si no existe
        skill_score = 0.0
        if "skill_score" in respuesta_adaptada:
            skill_score = float(respuesta_adaptada["skill_score"])
        
        respuesta_adaptada["skill_matches"] = {
            "required_skills": required_skills,
            "preferred_skills": preferred_skills,
            "overall_score": skill_score,
            "missing_required": missing_required,
            "missing_preferred": []
        }
    
    # Aseguramos que exista experience_match
    if "experience_match" not in respuesta_adaptada:
        # Extraemos años de experiencia si es posible
        years_exp = 0.0
        if "experience_years" in respuesta_adaptada:
            years_exp = float(respuesta_adaptada["experience_years"])
        elif "years_of_experience" in respuesta_adaptada:
            years_exp = float(respuesta_adaptada["years_of_experience"])
        
        respuesta_adaptada["experience_match"] = {
            "years_of_experience": years_exp,
            "relevance_score": 0.5,  # Valor por defecto
            "role_matches": [],
            "meets_minimum": True,  # Asumimos que cumple
            "overall_score": 50.0    # Valor por defecto
        }
    
    # Aseguramos que exista education_match
    if "education_match" not in respuesta_adaptada:
        education_details = {}
        if "education_level" in respuesta_adaptada:
            education_details["highest_level"] = respuesta_adaptada["education_level"]
        
        respuesta_adaptada["education_match"] = {
            "level_match": True,     # Asumimos que cumple
            "field_relevance": 0.5,  # Valor por defecto
            "overall_score": 50.0,   # Valor por defecto
            "education_details": education_details
        }
    
    # Aseguramos que exista un summary
    if "summary" not in respuesta_adaptada:
        if "analysis" in respuesta_adaptada:
            respuesta_adaptada["summary"] = respuesta_adaptada["analysis"]
        else:
            respuesta_adaptada["summary"] = "No hay resumen disponible."

    return respuesta_adaptada

async def analizar_con_prompt_personalizado():
    """Ejecuta un ejemplo de análisis de CV con un system prompt personalizado."""
    # Cargar variables de entorno
    load_dotenv()

    # Configurar ajustes de Azure
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"],
        ssl_cert_path=os.getenv("AZURE_OPENAI_SSL_CERT_PATH"),
        connection_timeout=int(os.getenv("AZURE_OPENAI_CONNECTION_TIMEOUT", "30")),
        max_keepalive_connections=int(os.getenv("AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS", "5")),
        max_connections=int(os.getenv("AZURE_OPENAI_MAX_CONNECTIONS", "10")),
        connection_verify=os.getenv("AZURE_OPENAI_CONNECTION_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    # Configuración del cliente
    client_config = ClientConfig(
        timeout=int(os.getenv("CV_SCREENING_TIMEOUT", "30")),
        max_retries=int(os.getenv("CV_SCREENING_RETRY_ATTEMPTS", "3")),
        batch_size=int(os.getenv("CV_SCREENING_MAX_BATCH_SIZE", "10"))
    )

    # Configuración de log
    log_config = LogConfig(
        level=os.getenv("CV_SCREENING_LOG_LEVEL", "INFO")
    )

    # Configuración completa del SDK
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config
    )

    # Inicializar cliente con configuración
    client = CVScreeningClient(config=sdk_config)

    # Definir criterios de evaluación
    criterios = JobCriteria(
        required_skills=["python", "machine learning", "data analysis"],
        preferred_skills=["deep learning", "tensorflow", "pytorch", "cloud computing"],
        min_years_experience=3,
        education_level="masters",
        education_field="computer science",
        role_title="Data Scientist",
        description="Responsible for developing machine learning models and analyzing large datasets",
        industry="Technology"
    )

    # Contenido del CV como texto
    cv_text = """
    María Rodríguez
    Data Scientist & Machine Learning Engineer
    
    Experiencia:
    - Senior Data Scientist en Tech Solutions (2019-presente)
      • Desarrollé modelos de machine learning para predecir comportamiento de usuarios
      • Implementé flujos de procesamiento de datos en AWS y Google Cloud
      • Lideré un equipo de 3 analistas de datos
    
    - Machine Learning Engineer en DataCorp (2017-2019)
      • Creación de modelos de deep learning con TensorFlow y PyTorch
      • Análisis de datos para identificar patrones y tendencias
    
    Habilidades:
    - Python, R, SQL
    - Scikit-learn, TensorFlow, PyTorch
    - Machine Learning, Deep Learning
    - AWS, GCP, Docker
    - Data Analysis, Data Visualization
    
    Educación:
    - Maestría en Ciencias de la Computación, especialización en Inteligencia Artificial
      Universidad Politécnica de Madrid (2015-2017)
    - Licenciatura en Matemáticas Aplicadas
      Universidad Complutense de Madrid (2011-2015)
    """

    try:
        # System prompt estándar (dejamos que el SDK use el predeterminado)
        print("\n=== Analizando CV con system prompt estándar ===")
        resultado_estandar = client.analyze_cv(cv_text, criterios)
        
        print(f"Puntuación: {resultado_estandar.overall_score}/100")
        print(f"Habilidades encontradas: {', '.join(resultado_estandar.skills_found)}")
        print(f"Años de experiencia: {resultado_estandar.experience_years}")
        print(f"Resumen: {resultado_estandar.summary[:150]}...\n")

        # Definir un system prompt personalizado que se enfoca en aspectos específicos
        prompt_personalizado = """Eres un experto asistente de screening de CV especializado en roles técnicos de Data Science.
        Tu tarea es analizar CVs y determinar si coinciden con los criterios de trabajo dados.
        
        Debes enfocarte especialmente en:
        1. Profundidad del conocimiento en machine learning (no solo menciones, sino proyectos concretos)
        2. Experiencia real en proyectos de análisis de datos
        3. Nivel de experiencia con las tecnologías específicas mencionadas
        4. Potencial de liderazgo y trabajo en equipo
        
        Proporciona un análisis detallado que incluya:
        1. Puntuación de coincidencia (0-100) como overall_score
        2. Lista de habilidades encontradas como skills_found
        3. Lista de habilidades faltantes como missing_skills
        4. Años de experiencia como experience_years
        5. Nivel educativo como education_level
        6. Fortalezas principales como key_strengths
        7. Áreas de mejora como areas_for_improvement
        8. Análisis general como summary
        
        Formatea tu respuesta como un objeto JSON con estos campos."""
        
        # Analizar el mismo CV con el system prompt personalizado
        print("=== Analizando CV con system prompt personalizado ===")
        
        # Aquí es donde usamos la capacidad de usar un system prompt personalizado
        # Necesitamos acceder al proveedor LLM directamente para usar el prompt_system
        resultado_personalizado_raw = await client.provider.analyze_cv_async(
            cv_text, 
            criterios.to_dict(), 
            prompt_system=prompt_personalizado
        )
        
        # Adaptamos la respuesta para asegurar que tiene la estructura correcta
        resultado_adaptado = adaptar_resultado_llm(resultado_personalizado_raw)
        
        # Convertir el resultado adaptado a un objeto CVScreeningResult
        from cv_screening_sdk.models.results import CVScreeningResult
        try:
            resultado_personalizado = CVScreeningResult.from_llm_response(resultado_adaptado)
        except Exception as e:
            print(f"Error al convertir la respuesta del LLM: {e}")
            print("Creando manualmente el objeto CVScreeningResult...")
            
            # Si la conversión falla, creamos manualmente el objeto
            skill_matches = SkillMatch(
                required_skills={s: 1.0 for s in resultado_adaptado.get("skills_found", [])},
                preferred_skills={},
                overall_score=float(resultado_adaptado.get("skill_score", 50.0)),
                missing_required=resultado_adaptado.get("missing_skills", [])
            )
            
            experience_match = ExperienceMatch(
                years_of_experience=float(resultado_adaptado.get("experience_years", 0.0)),
                relevance_score=0.8,
                role_matches=[],
                meets_minimum=True,
                overall_score=75.0
            )
            
            education_match = EducationMatch(
                level_match=True,
                field_relevance=0.9,
                overall_score=80.0,
                education_details={"highest_level": resultado_adaptado.get("education_level", "Unknown")}
            )
            
            resultado_personalizado = CVScreeningResult(
                cv_id="custom_prompt_result",
                overall_score=float(resultado_adaptado.get("overall_score", 0.0)),
                skill_matches=skill_matches,
                experience_match=experience_match,
                education_match=education_match,
                summary=resultado_adaptado.get("summary", "No hay resumen disponible.")
            )
        
        print(f"Puntuación: {resultado_personalizado.overall_score}/100")
        print(f"Habilidades encontradas: {', '.join(resultado_personalizado.skills_found)}")
        print(f"Años de experiencia: {resultado_personalizado.experience_years}")
        print(f"Resumen: {resultado_personalizado.summary[:150]}...\n")

        # Generar reporte comparativo
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        generar_reporte_comparativo(resultado_estandar, resultado_personalizado, reports_dir)

        # También podemos usar el método de procesamiento por lotes con prompt personalizado
        print("\n=== Ejemplo de procesamiento por lotes con prompt personalizado ===")
        
        # Crear algunos CVs adicionales para demostrar el procesamiento por lotes
        cv_text2 = """
        Juan López
        Data Analyst
        
        Experiencia:
        - Data Analyst en Analytics Co (2020-presente)
          • Análisis de datos de ventas y comportamiento de usuarios
          • Desarrollo de dashboards con Power BI
        
        - Junior Analyst en DataFirm (2018-2020)
          • Limpieza y preparación de datos
        
        Habilidades:
        - Python, SQL
        - Pandas, NumPy
        - Visualización de datos
        - Excel avanzado
        
        Educación:
        - Licenciatura en Estadística
          Universidad Autónoma de Barcelona (2014-2018)
        """
        
        # Crear lista de CVs para procesamiento por lotes
        cv_contents = [cv_text, cv_text2]
        
        # Procesar lote de CVs con prompt personalizado
        try:
            batch_results = await client.analyze_cvs_batch(
                cv_contents,
                criterios.to_dict(),
                prompt_system=prompt_personalizado
            )
            
            # Mostrar resultados del lote
            for i, result in enumerate(batch_results):
                # Adaptamos la respuesta para el procesamiento por lotes
                result_adapted = adaptar_resultado_llm(result)
                print(f"\nCV #{i+1} - Puntuación: {result_adapted.get('overall_score', 'N/A')}/100")
                if "skills_found" in result_adapted:
                    print(f"Habilidades encontradas: {', '.join(result_adapted['skills_found'])}")
                elif "skill_matches" in result_adapted and "required_skills" in result_adapted["skill_matches"]:
                    print(f"Habilidades encontradas: {', '.join(result_adapted['skill_matches']['required_skills'].keys())}")
                else:
                    print("No se encontraron habilidades")
        except Exception as e:
            print(f"Error en el procesamiento por lotes: {e}")
            
    except Exception as e:
        print(f"Error durante el análisis del CV: {e}")

if __name__ == "__main__":
    # Ejecutar la función asíncrona
    asyncio.run(analizar_con_prompt_personalizado()) 