"""
Ejemplo de Uso Personalizado del System Prompt en CV Screening SDK

Este ejemplo demuestra cómo:
1. Inicializar el cliente con la configuración adecuada
2. Utilizar un system prompt personalizado para análisis de CV
3. Procesar varios CVs con diferentes enfoques de análisis
4. Comparar los resultados con y sin un system prompt personalizado
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig
from datetime import datetime
import asyncio
import json
from pprint import pprint

def generar_reporte_comparativo(resultado_estandar, resultado_personalizado, output_dir: Path) -> None:
    """Genera un reporte comparativo de los resultados de screening con diferentes prompts."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"comparacion_prompts_{timestamp}.txt"
    
    with open(report_path, "w") as f:
        f.write("=== Comparación de Resultados de Screening de CV ===\n\n")
        f.write(f"Generado el: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        f.write("=== Resultados con System Prompt Estándar ===\n")
        f.write(f"Puntuación Global: {resultado_estandar.overall_score}/100\n")
        f.write(f"Habilidades Encontradas: {', '.join(resultado_estandar.skills_found)}\n")
        f.write(f"Habilidades Faltantes: {', '.join(resultado_estandar.missing_skills)}\n")
        f.write(f"Años de Experiencia: {resultado_estandar.experience_years}\n\n")
        f.write(f"Resumen: {resultado_estandar.summary}\n\n")
        
        f.write("=== Resultados con System Prompt Personalizado ===\n")
        f.write(f"Puntuación Global: {resultado_personalizado.overall_score}/100\n")
        f.write(f"Habilidades Encontradas: {', '.join(resultado_personalizado.skills_found)}\n")
        f.write(f"Habilidades Faltantes: {', '.join(resultado_personalizado.missing_skills)}\n")
        f.write(f"Años de Experiencia: {resultado_personalizado.experience_years}\n\n")
        f.write(f"Resumen: {resultado_personalizado.summary}\n\n")
        
        f.write("=== Análisis Comparativo ===\n")
        diferencia_score = abs(resultado_estandar.overall_score - resultado_personalizado.overall_score)
        f.write(f"Diferencia en Puntuación: {diferencia_score} puntos\n")
        
        # Comparar habilidades encontradas
        skills_estandar = set(resultado_estandar.skills_found)
        skills_personalizado = set(resultado_personalizado.skills_found)
        skills_adicionales = skills_personalizado - skills_estandar
        skills_omitidas = skills_estandar - skills_personalizado
        
        if skills_adicionales:
            f.write(f"Habilidades adicionales identificadas con prompt personalizado: {', '.join(skills_adicionales)}\n")
        if skills_omitidas:
            f.write(f"Habilidades omitidas con prompt personalizado: {', '.join(skills_omitidas)}\n")
        
        # Comparar resumen
        f.write("\nDiferencias en el enfoque del análisis:\n")
        f.write("El prompt personalizado puede proporcionar análisis más específicos o enfocados en ciertos aspectos.\n")
        
    print(f"Reporte comparativo generado en: {report_path}")

async def analizar_con_prompt_personalizado():
    """Ejecuta un ejemplo de análisis de CV con un system prompt personalizado."""
    # Cargar variables de entorno
    load_dotenv()

    # Configurar ajustes de Azure
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"],
        ssl_cert_path=os.getenv("AZURE_OPENAI_SSL_CERT_PATH"),
        connection_timeout=int(os.getenv("AZURE_OPENAI_CONNECTION_TIMEOUT", "30")),
        max_keepalive_connections=int(os.getenv("AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS", "5")),
        max_connections=int(os.getenv("AZURE_OPENAI_MAX_CONNECTIONS", "10")),
        connection_verify=os.getenv("AZURE_OPENAI_CONNECTION_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    sdk_config = SDKConfig(
        max_batch_size=int(os.getenv("CV_SCREENING_MAX_BATCH_SIZE", "10")),
        timeout_seconds=int(os.getenv("CV_SCREENING_TIMEOUT", "30")),
        retry_attempts=int(os.getenv("CV_SCREENING_RETRY_ATTEMPTS", "3")),
        log_level=os.getenv("CV_SCREENING_LOG_LEVEL", "INFO"),
    )

    client_config = ClientConfig(
        azure=azure_config,
        sdk=sdk_config
    )

    # Inicializar cliente con configuración
    client = CVScreeningClient(config=client_config)

    # Definir criterios de evaluación
    criterios = JobCriteria(
        required_skills=["python", "machine learning", "data analysis"],
        preferred_skills=["deep learning", "tensorflow", "pytorch", "cloud computing"],
        min_years_experience=3,
        education_level="masters",
        education_field="computer science",
        role_title="Data Scientist",
        description="Responsible for developing machine learning models and analyzing large datasets",
        industry="Technology"
    )

    # Contenido del CV como texto
    cv_text = """
    María Rodríguez
    Data Scientist & Machine Learning Engineer
    
    Experiencia:
    - Senior Data Scientist en Tech Solutions (2019-presente)
      • Desarrollé modelos de machine learning para predecir comportamiento de usuarios
      • Implementé flujos de procesamiento de datos en AWS y Google Cloud
      • Lideré un equipo de 3 analistas de datos
    
    - Machine Learning Engineer en DataCorp (2017-2019)
      • Creación de modelos de deep learning con TensorFlow y PyTorch
      • Análisis de datos para identificar patrones y tendencias
    
    Habilidades:
    - Python, R, SQL
    - Scikit-learn, TensorFlow, PyTorch
    - Machine Learning, Deep Learning
    - AWS, GCP, Docker
    - Data Analysis, Data Visualization
    
    Educación:
    - Maestría en Ciencias de la Computación, especialización en Inteligencia Artificial
      Universidad Politécnica de Madrid (2015-2017)
    - Licenciatura en Matemáticas Aplicadas
      Universidad Complutense de Madrid (2011-2015)
    """

    try:
        # System prompt estándar (dejamos que el SDK use el predeterminado)
        print("\n=== Analizando CV con system prompt estándar ===")
        resultado_estandar = client.analyze_cv(cv_text, criterios)
        
        print(f"Puntuación: {resultado_estandar.overall_score}/100")
        print(f"Habilidades encontradas: {', '.join(resultado_estandar.skills_found)}")
        print(f"Años de experiencia: {resultado_estandar.experience_years}")
        print(f"Resumen: {resultado_estandar.summary[:150]}...\n")

        # Definir un system prompt personalizado que se enfoca en aspectos específicos
        prompt_personalizado = """Eres un experto asistente de screening de CV especializado en roles técnicos de Data Science.
        Tu tarea es analizar CVs y determinar si coinciden con los criterios de trabajo dados.
        
        Debes enfocarte especialmente en:
        1. Profundidad del conocimiento en machine learning (no solo menciones, sino proyectos concretos)
        2. Experiencia real en proyectos de análisis de datos
        3. Nivel de experiencia con las tecnologías específicas mencionadas
        4. Potencial de liderazgo y trabajo en equipo
        
        Proporciona un análisis detallado que incluya:
        1. Puntuación de coincidencia (0-100)
        2. Evaluación de habilidades técnicas
        3. Evaluación de experiencia relevante
        4. Evaluación de educación
        5. Fortalezas específicas para el rol de Data Scientist
        6. Áreas de mejora o habilidades faltantes
        7. Análisis general
        
        Formatea tu respuesta como un objeto JSON con estos campos."""
        
        # Analizar el mismo CV con el system prompt personalizado
        print("=== Analizando CV con system prompt personalizado ===")
        
        # Aquí es donde usamos la capacidad de usar un system prompt personalizado
        # Necesitamos acceder al proveedor LLM directamente para usar el prompt_system
        resultado_personalizado_raw = await client.provider.analyze_cv_async(
            cv_text, 
            criterios.to_dict(), 
            prompt_system=prompt_personalizado
        )
        
        # Convertir el resultado raw a un objeto CVScreeningResult
        from cv_screening_sdk.models.results import CVScreeningResult
        resultado_personalizado = CVScreeningResult.from_llm_response(resultado_personalizado_raw)
        
        print(f"Puntuación: {resultado_personalizado.overall_score}/100")
        print(f"Habilidades encontradas: {', '.join(resultado_personalizado.skills_found)}")
        print(f"Años de experiencia: {resultado_personalizado.experience_years}")
        print(f"Resumen: {resultado_personalizado.summary[:150]}...\n")

        # Generar reporte comparativo
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        generar_reporte_comparativo(resultado_estandar, resultado_personalizado, reports_dir)

        # También podemos usar el método de procesamiento por lotes con prompt personalizado
        print("\n=== Ejemplo de procesamiento por lotes con prompt personalizado ===")
        
        # Crear algunos CVs adicionales para demostrar el procesamiento por lotes
        cv_text2 = """
        Juan López
        Data Analyst
        
        Experiencia:
        - Data Analyst en Analytics Co (2020-presente)
          • Análisis de datos de ventas y comportamiento de usuarios
          • Desarrollo de dashboards con Power BI
        
        - Junior Analyst en DataFirm (2018-2020)
          • Limpieza y preparación de datos
        
        Habilidades:
        - Python, SQL
        - Pandas, NumPy
        - Visualización de datos
        - Excel avanzado
        
        Educación:
        - Licenciatura en Estadística
          Universidad Autónoma de Barcelona (2014-2018)
        """
        
        # Crear lista de CVs para procesamiento por lotes
        cv_contents = [cv_text, cv_text2]
        
        # Procesar lote de CVs con prompt personalizado
        batch_results = await client.analyze_cvs_batch(
            cv_contents,
            criterios.to_dict(),
            prompt_system=prompt_personalizado
        )
        
        # Mostrar resultados del lote
        for i, result in enumerate(batch_results):
            print(f"\nCV #{i+1} - Puntuación: {result.get('overall_score', 'N/A')}/100")
            print(f"Habilidades encontradas: {', '.join(result.get('skills_found', []))}")
            
    except Exception as e:
        print(f"Error durante el análisis del CV: {e}")

if __name__ == "__main__":
    # Ejecutar la función asíncrona
    asyncio.run(analizar_con_prompt_personalizado()) 