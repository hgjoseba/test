
'''
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk import AzureConfig, ClientConfig, SDKConfig, JobCriteria
from pathlib import Path
from datetime import datetime

AZURE_TENANT_ID = "35595a02-4d6d-44ac-99e1-f9ab4cd872db"
AZURE_CLIENT_ID = "646e1920-11d4-49ed-98dc-d478a0d17df5"
AZURE_CLIENT_SECRET = "LzM8Q~d1JeLbgpVpGNTgm_Q.-uryMgHeFYnIZa12"
AZURE_OPENAI_ENDPOINT = "https://gscd3scdacsmvpcvscrit100.mvpcvs.cloud.aacc.dev.corp"
AZURE_OPENAI_DEPLOYMENT_NAME = "mvpcvs-gpt-4o-2024-05-13"

AZURE_OPENAI_MODEL_NAME = "gpt-4"  # Default: gpt-4
AZURE_OPENAI_API_VERSION = "2024-05-13"  # Default: 2023-05-15 #"2024-07-01-preview"
AZURE_OPENAI_MAX_TOKENS = 4000  # Default: 4000
AZURE_OPENAI_TEMPERATURE = 0.7  # Default: 0.7




# Azure OpenAI Configuration
azure_config = AzureConfig(
    endpoint=AZURE_OPENAI_ENDPOINT,
    deployment_name=AZURE_OPENAI_DEPLOYMENT_NAME,
    tenant_id=AZURE_TENANT_ID,
    client_id=AZURE_CLIENT_ID,
    client_secret=AZURE_CLIENT_SECRET,
    ssl_verify=True,
    model_name=AZURE_OPENAI_MODEL_NAME,
    api_version=AZURE_OPENAI_API_VERSION,
    max_tokens=AZURE_OPENAI_MAX_TOKENS,
    temperature=AZURE_OPENAI_TEMPERATURE,
)

# Client Configuration
client_config = ClientConfig(
    timeout=30,  # Optional
    max_retries=3,  # Optional
    batch_size=5  # Optional
)

# Complete SDK Configuration
sdk_config = SDKConfig(
    azure=azure_config,
    client=client_config
)

# Initialize the client with configuration
client = CVScreeningClient(config=sdk_config)

def generate_detailed_report(result, output_dir):
    """Generate a detailed report from CV analysis results."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"cv_analysis_report_{timestamp}.txt"
    
    with open(report_path, 'w') as f:
        f.write("=== CV ANALYSIS DETAILED REPORT ===\n\n")
        f.write(f"Overall Match Score: {result.overall_score}/100\n\n")
        
        f.write("=== Skills Assessment ===\n")
        f.write("Required Skills Found:\n")
        for skill in result.skills_found:
            f.write(f"✓ {skill}\n")
            
        f.write("\nMissing Required Skills:\n")
        for skill in result.missing_skills:
            f.write(f"✗ {skill}\n")
            
        f.write("\n=== Candidate Profile ===\n")
        f.write(f"Experience: {result.experience_years} years\n")
        f.write(f"Education Level: {result.education_level}\n")
        f.write(f"Key Strengths: {', '.join(result.key_strengths)}\n")
        f.write(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}\n")
        
        f.write("\n=== Overall Assessment ===\n")
        f.write(result.summary)
    
    return report_path

# Define evaluation criteria
criteria = JobCriteria(
    required_skills=["Python", "AWS", "Docker"],
    preferred_skills=["Kubernetes", "CI/CD"],
    min_years_experience=3,
    education_level="bachelor",
    role_title="Software Engineer"
)

# CV content as text
cv_text = """
PROFESSIONAL SUMMARY
Senior Software Engineer with 5 years of experience in Python development and cloud technologies.

SKILLS
- Python, Django, Flask
- AWS (EC2, S3, Lambda)
- Docker, Kubernetes
- CI/CD (Jenkins, GitHub Actions)
- Git, Linux

EXPERIENCE
Senior Software Engineer | Tech Corp | 2020-Present
- Led development of microservices architecture
- Implemented CI/CD pipelines
- Mentored junior developers

Software Engineer | StartUp Inc | 2018-2020
- Developed REST APIs
- Managed AWS infrastructure
- Implemented automated testing

EDUCATION
Bachelor's in Computer Science | University of Technology | 2018
"""

try:
    # Analyze CV
    result = client.analyze_cv(cv_text, criteria)

    # Generate detailed report
    reports_dir = Path(__file__).parent / "reports"
    reports_dir.mkdir(exist_ok=True)
    report_path = generate_detailed_report(result, reports_dir)
    print(f"\nDetailed report generated in: {report_path}")

    # Process and display results
    print("\n=== CV Analysis Results ===")
    print(f"Match Score: {result.overall_score}/100")

    # Skills analysis
    print("\n=== Skills Analysis ===")
    print("\nRequired Skills Found:")
    for skill in result.skills_found:
        print(f"✓ {skill}")

    print("\nMissing Required Skills:")
    for skill in result.missing_skills:
        print(f"✗ {skill}")

    print("\n=== Candidate Profile ===")
    print(f"Experience: {result.experience_years} years")
    print(f"Education Level: {result.education_level}")
    print(f"Key Strengths: {', '.join(result.key_strengths)}")
    print(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}")

    print("\n=== Overall Assessment ===")
    print(result.summary)

except Exception as e:
    print(f"Error during CV analysis: {e}")
    
'''

import openai
from openai import AzureOpenAI
from openai import OpenAI

from openai import AzureOpenAI
from azure.identity import ClientSecretCredential
import requests

import asyncio

from openai.lib.azure import AzureOpenAI, AsyncAzureOpenAI, AzureADTokenProvider, AsyncAzureADTokenProvider


# Azure Credentials
AZURE_TENANT_ID = "35595a02-4d6d-44ac-99e1-f9ab4cd872db"
AZURE_CLIENT_ID = "646e1920-11d4-49ed-98dc-d478a0d17df5"
AZURE_CLIENT_SECRET = "LzM8Q~d1JeLbgpVpGNTgm_Q.-uryMgHeFYnIZa12"
AZURE_OPENAI_ENDPOINT = "https://gscd3scdacsmvpcvscrit100.mvpcvs.cloud.aacc.dev.corp"
AZURE_OPENAI_DEPLOYMENT_NAME = "mvpcvs-gpt-4o-2024-05-13"
AZURE_OPENAI_MODEL_NAME = "gpt-4o"
AZURE_OPENAI_API_VERSION = "2024-07-01-preview"

scopes = "https://cognitiveservices.azure.com/.default"

# May change in the future
# https://learn.microsoft.com/en-us/azure/ai-services/openai/reference#rest-api-versioning
api_version = "2023-07-01-preview"

# https://learn.microsoft.com/en-us/azure/cognitive-services/openai/how-to/create-resource?pivots=web-portal#create-a-resource
endpoint = AZURE_OPENAI_ENDPOINT

deployment_name = AZURE_OPENAI_DEPLOYMENT_NAME  # e.g. gpt-35-instant


def sync_main() -> None:
    from azure.identity import DefaultAzureCredential, get_bearer_token_provider

    
    credential = ClientSecretCredential(
    tenant_id=AZURE_TENANT_ID,
    client_id=AZURE_CLIENT_ID,
    client_secret=AZURE_CLIENT_SECRET
    )   
    
    token_provider: AzureADTokenProvider = get_bearer_token_provider(credential, scopes)

    print(token_provider)
    client = AzureOpenAI(
        api_version=api_version,
        azure_endpoint=endpoint,
        azure_ad_token_provider=token_provider,
    )
    ''''
    completion = client.chat.completions.create(
        model=deployment_name,
        messages=[
            {
                "role": "user",
                "content": "How do I output all files in a directory using Python?",
            }
        ],
    )

    print(completion.to_json())
    '''

async def async_main() -> None:
    from azure.identity.aio import DefaultAzureCredential, get_bearer_token_provider

    token_provider: AsyncAzureADTokenProvider = get_bearer_token_provider(DefaultAzureCredential(), scopes)
    print(token_provider)

    client = AsyncAzureOpenAI(
        api_version=api_version,
        azure_endpoint=endpoint,
        azure_ad_token_provider=token_provider,
    )
    
    
  
    completion = await client.chat.completions.create(
        model=deployment_name,
        messages=[
            {
                "role": "user",
                "content": "How do I output all files in a directory using Python?",
            }
        ],
    )
    print(completion.to_json())
    


sync_main()

#asyncio.run(async_main())






""""
client = AzureOpenAI(api_key=token.token,
azure_endpoint=AZURE_OPENAI_ENDPOINT,
api_version=AZURE_OPENAI_API_VERSION)
"""



'''
# Authenticate with Azure
credential = ClientSecretCredential(
    tenant_id=AZURE_TENANT_ID,
    client_id=AZURE_CLIENT_ID,
    client_secret=AZURE_CLIENT_SECRET
)


token = credential.get_token("https://cognitiveservices.azure.com/.default")
# Crear cliente de OpenAI en Azure
client = AzureOpenAI(
    api_key=token,
    api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
)






# Define tu clave de API
openai.api_key = f"{token}"

# Define la versión de la API que deseas utilizar
openai.api_version = "2024-07-01-preview"  # Este es solo un ejemplo

# Define la base del API de OpenAI
openai.api_base = AZURE_OPENAI_ENDPOINT   # Asegúrate de usar tu propio endpoint

# Llamada para generar una respuesta con GPT-4
response = openai.completions.create(
    model="gpt-4o",  # El modelo que quieres usar
    prompt="Dime un chiste sobre inteligencia artificial",
    max_tokens=50
)

print(response.choices[0].text.strip())

# Imprimir la respuesta
print(response['choices'][0]['message']['content'])

# Verificar la respuesta
if response.status_code == 200:
    deployments = response.json()
    for deployment in deployments.get("data", []):
        print(f"Deployment: {deployment['id']}, Modelo: {deployment['model']}")
else:
    print(f"Error {response.status_code}: {response.text}")

# Set up OpenAI client
client = openai.AzureOpenAI(
    api_key=token,
    api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
)

client.chat.completions.create(
    model=AZURE_OPENAI_DEPLOYMENT_NAME,
    messages=[{"role": "system", "content": "You are a helpful assistant."},
              {"role": "user", "content": "Tell me a joke about AI."}],
)

"""
simple_completion = client.chat.completions.create(
    model="gpt-4o",  
    messages=[
        {
            "role": "user",
            "content": "Explain the difference between OpenAI and Azure OpenAI in 20 words",
        },
    ],
)

print(simple_completion.to_json())

'''