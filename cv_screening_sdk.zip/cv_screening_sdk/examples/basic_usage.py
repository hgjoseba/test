"""
Basic Usage Example for CV Screening SDK

This example demonstrates how to:
1. Initialize the client with proper configuration
2. Create screening criteria
3. Screen a single CV
4. Process and display results
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig


def basic_cv_screening():
    """Run a basic CV screening example."""
    # Load environment variables
    load_dotenv()

    # Initialize the client with proper configuration
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
    )

    sdk_config = SDKConfig(
        max_batch_size=10,
        log_level="INFO",
        timeout_seconds=30,
        retry_attempts=3,
        retry_delay_seconds=1
    )

    config = ClientConfig(azure=azure_config, sdk=sdk_config)

    try:
        client = CVScreeningClient(config)
    except Exception as e:
        print(f"Error initializing client: {e}")
        return

    # Define screening criteria using JobCriteria class for better validation
    criteria = JobCriteria(
        required_skills=["Python", "Machine Learning", "AWS"],
        preferred_skills=["Docker", "Kubernetes", "CI/CD"],
        min_years_experience=3,
        education_level="Bachelor's",
        role_title="Data Scientist",
        additional_requirements=[
            "Experience with large language models",
            "Strong problem-solving skills",
            "Team leadership experience"
        ]
    )

    # Get the example CV path
    cv_path = Path(__file__).parent / "resumes" / "software_engineer_resume.pdf"
    
    if not cv_path.exists():
        print(f"Error: CV file not found at {cv_path}")
        return

    try:
        # Screen a single CV
        result = client.screen_cv(str(cv_path), criteria)

        # Process and display results
        print("\n=== CV Screening Results ===")
        print(f"Match Score: {result.overall_score}/100")
        print(f"Processing Time: {result.processing_time:.2f} seconds")

        # Skills analysis
        print("\n=== Skills Analysis ===")
        print("\nRequired Skills Matched:")
        for skill in result.skills_found:
            print(f"✓ {skill}")

        print("\nMissing Required Skills:")
        for skill in result.missing_skills:
            print(f"✗ {skill}")

        print("\n=== Candidate Profile ===")
        print(f"Experience: {result.experience_years} years")
        print(f"Education Level: {result.education_level}")
        print(f"Key Strengths: {', '.join(result.key_strengths)}")
        print(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}")

        print("\n=== Overall Assessment ===")
        print(result.summary)

    except Exception as e:
        print(f"Error during CV screening: {e}")


if __name__ == "__main__":
    basic_cv_screening()
