"""
Basic Usage Example for CV Screening SDK

This example demonstrates how to:
1. Initialize the client with proper configuration
2. Process a CV in text format
3. Handle results and display analysis
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig, LogConfig
from datetime import datetime

def generate_detailed_report(result, output_dir: Path) -> None:
    """Generate a detailed report of the screening results."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"cv_report_{timestamp}.txt"
    
    with open(report_path, "w") as f:
        f.write("=== CV Screening Report ===\n\n")
        f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Overall Score: {result.overall_score}/100\n\n")
        
        f.write("=== Skills Analysis ===\n")
        f.write("\nRequired Skills Found:\n")
        for skill in result.skills_found:
            f.write(f"✓ {skill}\n")
        
        f.write("\nMissing Required Skills:\n")
        for skill in result.missing_skills:
            f.write(f"✗ {skill}\n")
        
        f.write("\n=== Candidate Profile ===\n")
        f.write(f"Experience: {result.experience_years} years\n")
        f.write(f"Education Level: {result.education_level}\n")
        f.write(f"Key Strengths: {', '.join(result.key_strengths)}\n")
        f.write(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}\n")
        
        f.write("\n=== Overall Assessment ===\n")
        f.write(result.summary)

def basic_cv_screening():
    """Run a basic CV screening example."""
    # Load environment variables
    load_dotenv()

    # Configure Azure settings
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        # SSL settings
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"],
        ssl_cert_path=os.getenv("AZURE_OPENAI_SSL_CERT_PATH"),
        # Connection settings
        connection_timeout=int(os.getenv("AZURE_OPENAI_CONNECTION_TIMEOUT", "30")),
        max_keepalive_connections=int(os.getenv("AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS", "5")),
        max_connections=int(os.getenv("AZURE_OPENAI_MAX_CONNECTIONS", "10")),
        connection_verify=os.getenv("AZURE_OPENAI_CONNECTION_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    # Configure client settings
    client_config = ClientConfig(
        timeout=int(os.getenv("CV_SCREENING_TIMEOUT", "30")),
        max_retries=int(os.getenv("CV_SCREENING_RETRY_ATTEMPTS", "3")),
        batch_size=int(os.getenv("CV_SCREENING_MAX_BATCH_SIZE", "10"))
    )
    
    # Configure logging settings
    log_config = LogConfig(
        level=os.getenv("CV_SCREENING_LOG_LEVEL", "INFO")
    )

    # Create SDK configuration
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config
    )

    # Initialize client with configuration
    client = CVScreeningClient(config=sdk_config)

    # Define evaluation criteria
    criteria = JobCriteria(
        required_skills=["python", "aws"],
        preferred_skills=["docker", "kubernetes"],
        min_years_experience=3,
        education_level="bachelors"
    )

    # CV content as text
    cv_text = """
    John Doe
    Software Engineer
    
    Experience:
    - Senior Software Engineer at Tech Corp (2018-present)
    - Software Engineer at StartUp Inc (2015-2018)
    
    Skills:
    - Python, AWS, Docker, Kubernetes
    - Microservices architecture
    - CI/CD
    
    Education:
    - Bachelor's in Computer Science
    """

    try:
        # Analyze CV
        result = client.analyze_cv(cv_text, criteria)

        # Generate detailed report
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        generate_detailed_report(result, reports_dir)
        print(f"\nDetailed report generated in: {reports_dir}")

        # Process and display results
        print("\n=== CV Analysis Results ===")
        print(f"Match Score: {result.overall_score}/100")

        # Skills analysis
        print("\n=== Skills Analysis ===")
        print("\nRequired Skills Found:")
        for skill in result.skills_found:
            print(f"✓ {skill}")

        print("\nMissing Required Skills:")
        for skill in result.missing_skills:
            print(f"✗ {skill}")

        print("\n=== Candidate Profile ===")
        print(f"Experience: {result.experience_years} years")
        print(f"Education Level: {result.education_level}")
        print(f"Key Strengths: {', '.join(result.key_strengths)}")
        print(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}")

        print("\n=== Overall Assessment ===")
        print(result.summary)

    except Exception as e:
        print(f"Error during CV analysis: {e}")

if __name__ == "__main__":
    basic_cv_screening()
