# Example Resumes Directory

Place your sample CV/resume files in this directory to run the examples.

## Expected Files

For the examples to work properly, place the following files in this directory:

- `software_engineer_resume.pdf` - For basic_usage.py
- `frontend_dev.pdf` - For async_processing.py
- `backend_dev.pdf` - For async_processing.py
- `fullstack_dev.docx` - For async_processing.py
- `senior_java_dev.pdf` - For batch_processing.py
- `data_engineer.pdf` - For batch_processing.py
- `tech_lead.docx` - For batch_processing.py
- `senior_python_dev.pdf` - For cv_screening_with_prompt.py

## Important Notes

- These files are not included in the repository for privacy reasons
- You should use your own CV files for testing
- The file format should match the extension (.pdf, .docx, etc.)
- Files can be actual CVs or sample documents for testing purposes

## Creating Test Files

If you don't have sample CVs available, you can create simple text files with relevant content:

```bash
# Create a sample PDF (requires first installing reportlab)
python -c "
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

c = canvas.Canvas('software_engineer_resume.pdf', pagesize=letter)
c.drawString(100, 750, 'Sample Software Engineer Resume')
c.drawString(100, 700, 'Skills: Python, AWS, Machine Learning, Docker')
c.drawString(100, 650, 'Experience: 5 years as Software Engineer')
c.drawString(100, 600, 'Education: Bachelor\'s in Computer Science')
c.save()
"
```

Or simply place text files with the .pdf extension (the SDK will attempt to parse them but may show errors).