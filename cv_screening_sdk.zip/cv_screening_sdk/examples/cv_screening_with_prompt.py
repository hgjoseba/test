"""
CV Screening with Natural Language Prompt Example

This example demonstrates how to:
1. Initialize the client with proper configuration
2. Use a natural language prompt instead of structured criteria
3. Let the LLM extract structured criteria from the prompt
4. Process and display detailed results
5. Generate comprehensive reports
"""

import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig


def generate_detailed_report(result: Any, output_dir: Path) -> None:
    """Generate a detailed report of the screening results."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"prompt_screening_report_{timestamp}.txt"
    
    with open(report_path, "w") as f:
        f.write("=== CV Screening with Natural Language Prompt Report ===\n\n")
        f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Overall Match Score: {result.overall_score}/100\n\n")
        
        f.write("=== Extracted Job Requirements ===\n")
        f.write(f"Role: {result.metadata.get('role', 'Not specified')}\n")
        f.write(f"Required Skills: {', '.join(result.skills_match.required_skills.keys())}\n")
        f.write(f"Preferred Skills: {', '.join(result.skills_match.preferred_skills.keys())}\n")
        f.write(f"Min Experience: {result.metadata.get('min_years_experience', 'Not specified')} years\n")
        f.write(f"Education Level: {result.education_match.education_details.get('highest_level', 'Not specified')}\n\n")
        
        f.write("=== Skills Assessment ===\n")
        f.write("\nRequired Skills Found:\n")
        for skill, confidence in result.skills_match.required_skills.items():
            f.write(f"  - {skill}: {confidence * 100:.0f}%\n")
        
        f.write("\nPreferred Skills Found:\n")
        for skill, confidence in result.skills_match.preferred_skills.items():
            f.write(f"  - {skill}: {confidence * 100:.0f}%\n")
        
        f.write("\nMissing Required Skills:\n")
        for skill in result.skills_match.missing_required:
            f.write(f"  - {skill}\n")
        
        f.write("\n=== Experience Assessment ===\n")
        f.write(f"Years of Experience: {result.experience_match.years_of_experience}\n")
        f.write(f"Relevance to Role: {result.experience_match.relevance_score * 100:.0f}%\n")
        f.write(f"Meets Requirements: {'Yes' if result.experience_match.meets_minimum else 'No'}\n")
        
        f.write("\n=== Education Assessment ===\n")
        f.write(f"Education Level: {result.education_match.education_details.get('highest_level', 'Not specified')}\n")
        f.write(f"Field of Study: {result.education_match.education_details.get('field', 'Not specified')}\n")
        f.write(f"Level Match: {'Yes' if result.education_match.level_match else 'No'}\n")
        
        f.write("\n=== Overall Assessment ===\n")
        f.write(result.summary if hasattr(result, "summary") else "No summary available\n")


def main():
    """Run an example using natural language job description for screening criteria."""
    # Load environment variables
    load_dotenv()

    # Initialize the client with proper configuration
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
    )

    sdk_config = SDKConfig(
        log_level="INFO",
        timeout_seconds=60,
        retry_attempts=3,
        retry_delay_seconds=1
    )

    config = ClientConfig(azure=azure_config, sdk=sdk_config)

    try:
        client = CVScreeningClient(config)
    except Exception as e:
        print(f"Error initializing client: {e}")
        return

    # Natural language prompt describing job requirements
    job_requirements_prompt = """
    Looking for a Senior Python Developer with at least 5 years of experience.

    Required technical skills:
    - Strong Python programming experience
    - AWS cloud services expertise (EC2, S3, Lambda)
    - Docker containerization experience
    - Experience with RESTful API development
    - Strong problem-solving and analytical skills
    - Excellent communication and teamwork abilities

    Preferred skills:
    - Kubernetes and container orchestration
    - Microservices architecture
    - CI/CD pipeline implementation
    - Automated testing frameworks
    - Infrastructure as Code (Terraform)
    - Experience with large-scale systems
    - Agile development methodologies

    Education: Bachelor's degree in Computer Science or related field required
    Location: Remote, with occasional travel to headquarters
    Salary range: $120,000 - $150,000 depending on experience
    """

    # Get the example CV path
    cv_path = Path(__file__).parent / "resumes" / "senior_python_dev.pdf"
    if not cv_path.exists():
        print(f"Error: CV file not found at {cv_path}")
        return

    try:
        # Screen a CV using the natural language prompt
        result = client.screen_cv(
            cv_path=str(cv_path),
            criteria=job_requirements_prompt,
        )

        # Generate detailed report
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        generate_detailed_report(result, reports_dir)
        print(f"\nDetailed report generated in: {reports_dir}")

        # Print summary results
        print("\n=== CV Screening Results ===")
        print(f"Overall Match Score: {result.overall_score}/100")

        # Print extracted criteria
        print("\n=== Extracted Job Requirements ===")
        print(f"Role: {result.metadata.get('role', 'Not specified')}")
        print(f"Required Skills: {', '.join(result.skills_match.required_skills.keys())}")
        print(f"Preferred Skills: {', '.join(result.skills_match.preferred_skills.keys())}")
        print(f"Min Experience: {result.metadata.get('min_years_experience', 'Not specified')} years")
        print(f"Education Level: {result.education_match.education_details.get('highest_level', 'Not specified')}")

        # Print candidate's skills assessment
        print("\n=== Skills Assessment ===")
        print("Required Skills Found:")
        for skill, confidence in result.skills_match.required_skills.items():
            print(f"  - {skill}: {confidence * 100:.0f}%")

        print("\nPreferred Skills Found:")
        for skill, confidence in result.skills_match.preferred_skills.items():
            print(f"  - {skill}: {confidence * 100:.0f}%")

        print("\nMissing Required Skills:")
        for skill in result.skills_match.missing_required:
            print(f"  - {skill}")

        # Print experience assessment
        print("\n=== Experience Assessment ===")
        print(f"Years of Experience: {result.experience_match.years_of_experience}")
        print(f"Relevance to Role: {result.experience_match.relevance_score * 100:.0f}%")
        print(f"Meets Requirements: {'Yes' if result.experience_match.meets_minimum else 'No'}")

        # Print education assessment
        print("\n=== Education Assessment ===")
        print(f"Education Level: {result.education_match.education_details.get('highest_level', 'Not specified')}")
        print(f"Field of Study: {result.education_match.education_details.get('field', 'Not specified')}")
        print(f"Level Match: {'Yes' if result.education_match.level_match else 'No'}")

        # Print overall assessment
        print("\n=== Overall Assessment ===")
        print(result.summary if hasattr(result, "summary") else "No summary available")

    except Exception as e:
        print(f"Error during CV screening: {e}")


if __name__ == "__main__":
    main()
