"""
Asynchronous Processing Example for CV Screening SDK

This example demonstrates how to:
1. Initialize the client with proper configuration
2. Process CVs asynchronously for improved performance
3. Handle async results with error handling
4. Create a custom filtering pipeline for results
5. Generate detailed reports and analytics
"""

import asyncio
import os
import time
from pathlib import Path
from typing import List, Tuple, Dict
from datetime import datetime
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig
from cv_screening_sdk.models.results import CVScreeningResult


def generate_analytics_report(
    results: List[Tuple[str, CVScreeningResult]],
    processing_time: float,
    output_dir: Path
) -> None:
    """Generate a detailed analytics report of the screening results."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"analytics_report_{timestamp}.txt"
    
    # Calculate statistics
    total_candidates = len(results)
    scores = [result[1].overall_score for result in results]
    avg_score = sum(scores) / len(scores) if scores else 0
    max_score = max(scores) if scores else 0
    min_score = min(scores) if scores else 0
    
    # Skills analysis
    all_skills = {}
    for _, result in results:
        for skill in result.skills_found:
            all_skills[skill] = all_skills.get(skill, 0) + 1
    
    with open(report_path, "w") as f:
        f.write("=== CV Screening Analytics Report ===\n\n")
        f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Processing Time: {processing_time:.2f} seconds\n")
        f.write(f"Total Candidates: {total_candidates}\n")
        f.write(f"Average Score: {avg_score:.1f}/100\n")
        f.write(f"Highest Score: {max_score}/100\n")
        f.write(f"Lowest Score: {min_score}/100\n\n")
        
        f.write("=== Skills Distribution ===\n")
        for skill, count in sorted(all_skills.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / total_candidates) * 100
            f.write(f"{skill}: {count} candidates ({percentage:.1f}%)\n")
        
        f.write("\n=== Detailed Results ===\n")
        for cv_path, result in sorted(results, key=lambda x: x[1].overall_score, reverse=True):
            f.write(f"\n{os.path.basename(cv_path)}\n")
            f.write(f"Score: {result.overall_score}/100\n")
            f.write(f"Experience: {result.experience_years} years\n")
            f.write(f"Education: {result.education_level}\n")
            f.write(f"Key Skills: {', '.join(result.skills_found[:5])}\n")
            f.write(f"Key Strengths: {', '.join(result.key_strengths)}\n")
            f.write(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}\n")
            f.write("-" * 50 + "\n")


async def async_cv_screening():
    """Run an asynchronous CV screening example."""
    # Load environment variables
    load_dotenv()

    # Initialize the client with proper configuration
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
    )

    sdk_config = SDKConfig(
        max_batch_size=25,  # Higher batch size for async processing
        log_level="INFO",
        timeout_seconds=45,  # Longer timeout for async operations
        retry_attempts=3,
        retry_delay_seconds=1
    )

    config = ClientConfig(azure=azure_config, sdk=sdk_config)

    try:
        client = CVScreeningClient(config)
    except Exception as e:
        print(f"Error initializing client: {e}")
        return

    # Define screening criteria for a web developer role
    criteria = JobCriteria(
        required_skills=["React", "Node.js", "MongoDB"],
        preferred_skills=["TypeScript", "AWS", "Docker", "GraphQL"],
        min_years_experience=2,
        education_level="Bachelor's",
        role_title="Full Stack Web Developer",
        industry="Technology",
        additional_requirements=[
            "Experience with modern web frameworks",
            "Understanding of microservices architecture",
            "Strong problem-solving skills"
        ]
    )

    # Get the example CVs directory
    resumes_dir = Path(__file__).parent / "resumes"
    if not resumes_dir.exists():
        print(f"Error: Resumes directory not found at {resumes_dir}")
        return

    # List of CVs to process
    cv_paths = [
        str(resumes_dir / "frontend_dev.pdf"),
        str(resumes_dir / "backend_dev.pdf"),
        str(resumes_dir / "fullstack_dev.docx"),
    ]

    # Verify CV files exist
    missing_files = [path for path in cv_paths if not Path(path).exists()]
    if missing_files:
        print("Error: The following CV files were not found:")
        for file in missing_files:
            print(f"- {file}")
        return

    print(f"\nStarting async processing of {len(cv_paths)} CVs...")
    start_time = time.time()

    try:
        # Process CVs asynchronously
        results = await client._batch_screen_cvs_async(cv_paths, criteria.to_dict())

        processing_time = time.time() - start_time
        print(f"Completed in {processing_time:.2f} seconds")

        # Custom function to filter results
        def is_qualified_candidate(result: CVScreeningResult) -> bool:
            """Determine if a candidate meets our qualification criteria."""
            if isinstance(result, Exception):
                return False

            # Must have at least 75% overall match
            if result.overall_score < 75:
                return False

            # Must have at least 2 years experience
            if result.experience_years < 2:
                return False

            # Must have React skill
            if "React" not in result.skills_found:
                return False

            return True

        # Process and categorize results
        qualified_candidates = []
        promising_candidates = []
        rejected_candidates = []
        errors = []

        for i, result in enumerate(results):
            cv_path = cv_paths[i]
            if isinstance(result, Exception):
                errors.append((cv_path, str(result)))
                continue

            if is_qualified_candidate(result):
                qualified_candidates.append((cv_path, result))
            elif result.overall_score >= 60:
                promising_candidates.append((cv_path, result))
            else:
                rejected_candidates.append((cv_path, result))

        # Generate analytics report
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        generate_analytics_report(qualified_candidates + promising_candidates + rejected_candidates,
                                processing_time, reports_dir)
        print(f"\nAnalytics report generated in: {reports_dir}")

        # Display qualified candidates
        print(f"\n=== Qualified Candidates ({len(qualified_candidates)}) ===")
        for cv_path, result in sorted(
            qualified_candidates, key=lambda x: x[1].overall_score, reverse=True
        ):
            print(f"\n{os.path.basename(cv_path)}")
            print(f"Overall Score: {result.overall_score}/100")
            print(f"Experience: {result.experience_years} years")
            print(f"Key Skills: {', '.join(result.skills_found[:3])}")
            print(f"Key Strengths: {', '.join(result.key_strengths)}")

        # Display promising candidates
        print(f"\n=== Promising Candidates ({len(promising_candidates)}) ===")
        for cv_path, result in sorted(
            promising_candidates, key=lambda x: x[1].overall_score, reverse=True
        ):
            print(f"\n{os.path.basename(cv_path)}")
            print(f"Overall Score: {result.overall_score}/100")
            print(f"Missing Skills: {', '.join(result.missing_skills)}")
            print(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}")

        # Summary
        print("\n=== Summary ===")
        print(f"Total CVs: {len(cv_paths)}")
        print(f"Qualified: {len(qualified_candidates)}")
        print(f"Promising: {len(promising_candidates)}")
        print(f"Rejected: {len(rejected_candidates)}")
        print(f"Errors: {len(errors)}")

        # Display errors if any
        if errors:
            print("\n=== Errors ===")
            for cv_path, error in errors:
                print(f"Error processing {os.path.basename(cv_path)}: {error}")

    except Exception as e:
        print(f"Error during async processing: {e}")


if __name__ == "__main__":
    asyncio.run(async_cv_screening())
