"""
Asynchronous Processing Example for CV Screening SDK

This example demonstrates how to:
1. Initialize the client with proper configuration
2. Process CVs asynchronously for improved performance
3. Handle async results with error handling
4. Create a custom filtering pipeline for results
5. Generate detailed reports and analytics
6. Get raw API responses for detailed debugging
"""

import asyncio
import os
import time
import json
from pathlib import Path
from typing import List, Tuple, Dict, Any
from datetime import datetime
from dotenv import load_dotenv
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig, LogConfig
from cv_screening_sdk.models.results import CVScreeningResult


def generate_analytics_report(
    results: List[Tuple[str, CVScreeningResult]],
    processing_time: float,
    output_dir: Path
) -> None:
    """Generate a detailed analytics report of the screening results."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"analytics_report_{timestamp}.txt"
    
    # Calculate statistics
    total_candidates = len(results)
    scores = [result[1].overall_score for result in results]
    avg_score = sum(scores) / len(scores) if scores else 0
    max_score = max(scores) if scores else 0
    min_score = min(scores) if scores else 0
    
    # Skills analysis
    all_skills = {}
    for _, result in results:
        for skill in result.skills_found:
            all_skills[skill] = all_skills.get(skill, 0) + 1
    
    with open(report_path, "w") as f:
        f.write("=== CV Screening Analytics Report ===\n\n")
        f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Processing Time: {processing_time:.2f} seconds\n")
        f.write(f"Total Candidates: {total_candidates}\n")
        f.write(f"Average Score: {avg_score:.1f}/100\n")
        f.write(f"Highest Score: {max_score}/100\n")
        f.write(f"Lowest Score: {min_score}/100\n\n")
        
        f.write("=== Skills Distribution ===\n")
        for skill, count in sorted(all_skills.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / total_candidates) * 100
            f.write(f"{skill}: {count} candidates ({percentage:.1f}%)\n")
        
        f.write("\n=== Detailed Results ===\n")
        for cv_id, result in sorted(results, key=lambda x: x[1].overall_score, reverse=True):
            f.write(f"\nCV ID: {cv_id}\n")
            f.write(f"Score: {result.overall_score}/100\n")
            f.write(f"Experience: {result.experience_years} years\n")
            f.write(f"Education: {result.education_level}\n")
            f.write(f"Key Skills: {', '.join(result.skills_found[:5])}\n")
            f.write(f"Key Strengths: {', '.join(result.key_strengths)}\n")
            f.write(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}\n")
            f.write("-" * 50 + "\n")


async def async_cv_screening():
    """Run an asynchronous CV screening example."""
    # Load environment variables
    load_dotenv()

    # Configure Azure settings
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        # SSL settings
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"],
        ssl_cert_path=os.getenv("AZURE_OPENAI_SSL_CERT_PATH"),
        # Connection settings
        connection_timeout=int(os.getenv("AZURE_OPENAI_CONNECTION_TIMEOUT", "30")),
        max_keepalive_connections=int(os.getenv("AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS", "5")),
        max_connections=int(os.getenv("AZURE_OPENAI_MAX_CONNECTIONS", "10")),
        connection_verify=os.getenv("AZURE_OPENAI_CONNECTION_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    # Configure client settings
    client_config = ClientConfig(
        timeout=int(os.getenv("CV_SCREENING_TIMEOUT", "30")),
        max_retries=int(os.getenv("CV_SCREENING_RETRY_ATTEMPTS", "3")),
        batch_size=int(os.getenv("CV_SCREENING_MAX_BATCH_SIZE", "10"))
    )
    
    # Configure logging settings
    log_config = LogConfig(
        level=os.getenv("CV_SCREENING_LOG_LEVEL", "INFO")
    )

    # Create SDK configuration
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config
    )

    # Initialize client with configuration
    client = CVScreeningClient(config=sdk_config)

    # Define evaluation criteria
    criteria = JobCriteria(
        required_skills=["python", "aws"],
        preferred_skills=["docker", "kubernetes"],
        min_years_experience=3,
        education_level="bachelors"
    )

    # Sample CVs as text
    cv_texts = [
        """
        John Doe
        Software Engineer
        
        Experience:
        - Senior Software Engineer at Tech Corp (2018-present)
        - Software Engineer at StartUp Inc (2015-2018)
        
        Skills:
        - Python, AWS, Docker, Kubernetes
        - Microservices architecture
        - CI/CD
        
        Education:
        - Bachelor's in Computer Science
        """,
        """
        Jane Smith
        Full Stack Developer
        
        Experience:
        - Full Stack Developer at Web Solutions (2019-present)
        - Junior Developer at Tech Start (2017-2019)
        
        Skills:
        - Python, JavaScript, React
        - AWS, Docker
        - Web development
        
        Education:
        - Bachelor's in Software Engineering
        """,
        """
        Mike Johnson
        DevOps Engineer
        
        Experience:
        - DevOps Engineer at Cloud Corp (2018-present)
        - System Administrator at IT Solutions (2015-2018)
        
        Skills:
        - AWS, Azure, GCP
        - Docker, Kubernetes, Terraform
        - CI/CD, Jenkins, GitLab
        - Python, Bash, PowerShell
        
        Education:
        - Bachelor's in Information Technology
        """
    ]

    print(f"\nStarting async processing of {len(cv_texts)} CVs...")
    start_time = time.time()

    try:
        # Process CVs asynchronously
        results = []
        for i, cv_text in enumerate(cv_texts):
            result = await client.analyze_cv_async(cv_text, criteria)
            results.append((f"CV_{i+1}", result))

        processing_time = time.time() - start_time
        print(f"Completed in {processing_time:.2f} seconds")

        # Custom function to filter results
        def is_qualified_candidate(result: CVScreeningResult) -> bool:
            """Determine if a candidate meets our qualification criteria."""
            # Must have at least 75% overall match
            if result.overall_score < 75:
                return False

            # Must have at least 2 years experience
            if result.experience_years < 2:
                return False

            # Must have Python skill
            if "Python" not in result.skills_found:
                return False

            return True

        # Process and categorize results
        qualified_candidates = []
        promising_candidates = []
        rejected_candidates = []
        errors = []

        for cv_id, result in results:
            if is_qualified_candidate(result):
                qualified_candidates.append((cv_id, result))
            elif result.overall_score >= 60:
                promising_candidates.append((cv_id, result))
            else:
                rejected_candidates.append((cv_id, result))

        # Generate analytics report
        reports_dir = Path(__file__).parent / "reports"
        reports_dir.mkdir(exist_ok=True)
        generate_analytics_report(results, processing_time, reports_dir)
        print(f"\nAnalytics report generated in: {reports_dir}")

        # Display qualified candidates
        print(f"\n=== Qualified Candidates ({len(qualified_candidates)}) ===")
        for cv_id, result in sorted(
            qualified_candidates, key=lambda x: x[1].overall_score, reverse=True
        ):
            print(f"\n{cv_id}")
            print(f"Overall Score: {result.overall_score}/100")
            print(f"Experience: {result.experience_years} years")
            print(f"Key Skills: {', '.join(result.skills_found[:3])}")
            print(f"Key Strengths: {', '.join(result.key_strengths)}")

        # Display promising candidates
        print(f"\n=== Promising Candidates ({len(promising_candidates)}) ===")
        for cv_id, result in sorted(
            promising_candidates, key=lambda x: x[1].overall_score, reverse=True
        ):
            print(f"\n{cv_id}")
            print(f"Overall Score: {result.overall_score}/100")
            print(f"Missing Skills: {', '.join(result.missing_skills)}")
            print(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}")

        # Summary
        print("\n=== Summary ===")
        print(f"Total CVs: {len(cv_texts)}")
        print(f"Qualified: {len(qualified_candidates)}")
        print(f"Promising: {len(promising_candidates)}")
        print(f"Rejected: {len(rejected_candidates)}")
        print(f"Errors: {len(errors)}")

        # Display errors if any
        if errors:
            print("\n=== Errors ===")
            for cv_id, error in errors:
                print(f"Error processing {cv_id}: {error}")

    except Exception as e:
        print(f"Error during async processing: {e}")


async def async_raw_response_example():
    """Example showing how to get the raw async response from Azure OpenAI API."""
    # Load environment variables
    load_dotenv()

    # Configure Azure settings with minimal configuration
    azure_config = AzureConfig(
        endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://your-endpoint.openai.azure.com/"),
        deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "your-deployment"),
        model_name=os.getenv("AZURE_OPENAI_MODEL_NAME", "gpt-4"),
        api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2023-05-15"),
        tenant_id=os.getenv("AZURE_TENANT_ID"),
        client_id=os.getenv("AZURE_CLIENT_ID"),
        client_secret=os.getenv("AZURE_CLIENT_SECRET"),
        ssl_verify=os.getenv("AZURE_OPENAI_SSL_VERIFY", "True").lower() in ["true", "1", "yes", "y"]
    )

    # Create SDK configuration
    sdk_config = SDKConfig(
        azure=azure_config,
        client=ClientConfig(),
        log=LogConfig(level="INFO")
    )

    # Initialize client with configuration
    client = CVScreeningClient(config=sdk_config)

    # Define evaluation criteria
    criteria = JobCriteria(
        required_skills=["python", "data analysis"],
        preferred_skills=["machine learning", "statistics"],
        min_years_experience=2,
        education_level="masters"
    )

    # Sample CV as text
    cv_text = """
    Sarah Johnson
    Data Scientist
    
    Experience:
    - Senior Data Scientist at Analytics Corp (2020-present)
    - Data Analyst at Data Solutions Inc (2018-2020)
    
    Skills:
    - Python, R, SQL
    - Machine Learning, Deep Learning
    - Data Visualization, Statistics
    - Pandas, NumPy, TensorFlow, PyTorch
    
    Education:
    - Master's in Data Science
    - Bachelor's in Computer Science
    """

    print("\n=== Async Raw Response Example ===")
    print("Requesting raw response from OpenAI API...")
    
    try:
        # Request the raw response using the return_raw_response parameter
        start_time = time.time()
        raw_response = await client.analyze_cv_async(cv_text, criteria, return_raw_response=True)
        processing_time = time.time() - start_time
        
        print(f"Response received in {processing_time:.2f} seconds")
        print("Type of raw response:", type(raw_response))
        
        # Access properties of the raw completion object
        if hasattr(raw_response, 'model'):
            print("Model used:", raw_response.model)
        
        if hasattr(raw_response, 'usage'):
            print("Token usage:")
            for key, value in vars(raw_response.usage).items():
                print(f"  - {key}: {value}")
        
        if hasattr(raw_response, 'choices') and len(raw_response.choices) > 0:
            print("\nResponse details:")
            print(f"  - Finish reason: {raw_response.choices[0].finish_reason}")
            print(f"  - Message role: {raw_response.choices[0].message.role}")
            print(f"  - Content preview: {raw_response.choices[0].message.content[:150]}...")
        
        # Save the raw response for later analysis
        raw_response_dir = Path(__file__).parent / "raw_responses"
        raw_response_dir.mkdir(exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Attempt to serialize the response object
        try:
            # Handle different types of response objects
            if hasattr(raw_response, "model_dump"):
                # For newer SDKs with Pydantic models
                response_dict = raw_response.model_dump()
            elif hasattr(raw_response, "__dict__"):
                # For objects with attributes
                response_dict = vars(raw_response)
                
                # Handle nested objects with __dict__
                def process_dict(d):
                    result = {}
                    for k, v in d.items():
                        if hasattr(v, "__dict__"):
                            result[k] = process_dict(vars(v))
                        elif isinstance(v, list):
                            result[k] = [
                                process_dict(vars(item)) if hasattr(item, "__dict__") else item 
                                for item in v
                            ]
                        else:
                            result[k] = v
                    return result
                
                response_dict = process_dict(response_dict)
            else:
                # Fallback to string representation
                response_dict = {"raw_content": str(raw_response)}
            
            with open(raw_response_dir / f"async_raw_response_{timestamp}.json", "w") as f:
                json.dump(response_dict, f, indent=2, default=str)
                print(f"\nRaw response saved to: {raw_response_dir}/async_raw_response_{timestamp}.json")
        
        except Exception as e:
            print(f"Could not save raw response as JSON: {e}")
            
            # Fallback to string representation
            with open(raw_response_dir / f"async_raw_response_{timestamp}.txt", "w") as f:
                f.write(str(raw_response))
                print(f"\nRaw response saved as text to: {raw_response_dir}/async_raw_response_{timestamp}.txt")
        
        print("\nThe raw response can be used for debugging, detailed analysis, or custom processing")
        print("For example, you can build custom parsers or post-processors for special use cases")
        
    except Exception as e:
        print(f"Error getting raw response: {e}")
        import traceback
        traceback.print_exc()


async def main():
    """Run all examples."""
    await async_cv_screening()
    print("\n" + "="*50 + "\n")
    await async_raw_response_example()


if __name__ == "__main__":
    asyncio.run(main())
