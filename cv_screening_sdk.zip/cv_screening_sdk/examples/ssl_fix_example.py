"""
SSL Fix Example for Azure OpenAI

This example demonstrates how to solve SSL certificate issues when
working with Azure OpenAI, especially in corporate environments where
SSL proxies or self-signed certificates may exist.

The SDK provides two mechanisms to handle SSL issues:
1. Completely disable SSL verification (useful in development environments)
2. Use a custom SSL certificate (more secure for production)
"""

import os
import logging
import json
from typing import Dict, Any

from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import (
    AzureConfig,
    ClientConfig,
    LogConfig,
    SDKConfig
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Sample CV content for processing
CV_CONTENT = """
JOHN DOE
-----------
Experience:
- Senior Software Engineer at TechCorp (2018-2023)
- Backend Developer at DataSystems (2015-2018)

Education:
- Master's in Computer Science, Technical University (2015)
- Bachelor's in Computer Engineering, National University (2013)

Skills: Python, Java, SQL, AWS, Docker, Kubernetes
"""

def complete_ssl_fix_example() -> Dict[str, Any]:
    """
    Complete example of SSL issue solution with Azure OpenAI.
    
    This function configures the SDK to handle environments with SSL issues:
    1. Disables SSL verification
    2. Demonstrates how to process a CV with this configuration
    
    Returns:
        Dict[str, Any]: Result of CV analysis
    """
    logger.info("Starting SSL issue solution example")
    
    # Load configuration from environment variables or use default values
    api_version = os.environ.get("AZURE_API_VERSION", "2023-05-15")
    endpoint = os.environ.get("AZURE_ENDPOINT", "https://your-endpoint.openai.azure.com")
    deployment = os.environ.get("AZURE_DEPLOYMENT", "your-deployment-name")
    tenant_id = os.environ.get("AZURE_TENANT_ID", "your-tenant-id")
    client_id = os.environ.get("AZURE_CLIENT_ID", "your-client-id")
    client_secret = os.environ.get("AZURE_CLIENT_SECRET", "your-client-secret")
    
    # Configure SDK components
    azure_config = AzureConfig(
        api_version=api_version,
        endpoint=endpoint,
        deployment=deployment,
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret,
        ssl_verify=False,  # Important: Disables SSL verification
    )
    
    client_config = ClientConfig(
        timeout=int(os.environ.get("CLIENT_TIMEOUT", "30")),
        max_retries=int(os.environ.get("CLIENT_MAX_RETRIES", "3")),
        batch_size=int(os.environ.get("CLIENT_BATCH_SIZE", "10")),
    )
    
    log_config = LogConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
    )
    
    # Configure the SDK
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config,
    )
    
    # Define job criteria for CV analysis
    # Keep it simple to minimize parsing issues
    job_criteria = {
        "required_skills": ["Python"],
        "preferred_skills": ["Docker"]
    }
    
    try:
        # Initialize the client with SSL disabled
        logger.info("Initializing client with SSL disabled")
        cv_client = CVScreeningClient(sdk_config)
        cv_client.initialize()
        
        # Analyze the CV
        logger.info("Analyzing CV with SSL-disabled client")
        try:
            result = cv_client.analyze_cv(CV_CONTENT, job_criteria)
            logger.info("CV analyzed successfully with SSL disabled")
            return result
            
        except Exception as parse_error:
            logger.error(f"Error in CV analysis: {str(parse_error)}")
            return {
                "error": str(parse_error),
                "note": "There was an error analyzing the CV with SSL disabled."
            }
            
    except Exception as e:
        logger.error(f"Error initializing client with SSL disabled: {str(e)}", exc_info=True)
        return {"error": str(e)}

def explain_ssl_solution():
    """
    Explains the different options to solve SSL issues with the SDK.
    """
    print("SSL ISSUE SOLUTION WITH THE CV ANALYSIS SDK")
    print("-------------------------------------------")
    print("\nWhen working in corporate environments or with complex network configurations, ")
    print("it's common to encounter SSL certificate issues when connecting to Azure OpenAI.")
    print("\nThe SDK provides two main mechanisms to handle these issues:\n")
    
    print("1. DISABLE SSL VERIFICATION (for development/testing):")
    print("   - Simple configuration: ssl_verify=False in AzureConfig")
    print("   - The SDK handles applying the monkey patch to httpx and configuring openai")
    print("   - This option is NOT recommended for production environments\n")
    
    print("2. USE A CUSTOM SSL CERTIFICATE (better for production):")
    print("   - Allows specifying a trusted certificate: ssl_cert_path='path/to/cert.pem'")
    print("   - Maintains SSL verification but with custom certificates")
    print("   - More secure than completely disabling verification\n")
    
    print("USAGE INSTRUCTIONS:")
    print("1. Configure the necessary environment variables for Azure authentication")
    print("2. Choose the appropriate SSL strategy according to your environment")
    print("3. If you're in a development environment, you can use ssl_verify=False")
    print("4. If you're in production, consider using ssl_cert_path with your corporate certificate\n")

if __name__ == "__main__":
    # Show explanation
    explain_ssl_solution()
    
    # Run example
    print("\nRunning SSL solution example...")
    result = complete_ssl_fix_example()
    
    # Show result
    print("\nResult of CV analysis with SSL disabled:")
    print(result) 