"""
SSL Configuration Example for CV Screening SDK

This example demonstrates how to:
1. Configure SSL options for connections with Azure OpenAI
2. Disable SSL verification for development environments
3. Use custom SSL certificates
"""

import os
import logging
import json
from typing import Dict, Any
from pathlib import Path
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig, LogConfig

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Sample CV content for processing
CV_CONTENT = """
JOHN DOE
Software Developer

Experience:
- 5 years as Python developer at ABC Company
- 3 years as web developer at XYZ Company

Skills:
- Python, JavaScript, HTML/CSS
- Django, Flask, React
- Docker, Kubernetes
- AWS, Azure
"""

# Example 1: Disable SSL verification
def example_disable_ssl():
    print("=== Example 1: Disable SSL verification ===")
    
    # Configure Azure without SSL verification
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com/",
        deployment_name="your-deployment",
        api_version="2023-05-15",
        ssl_verify=False  # Disable SSL verification
    )
    
    # Configure client and log
    client_config = ClientConfig()
    log_config = LogConfig()
    
    # Create SDK configuration
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config
    )
    
    # Initialize the client
    client = CVScreeningClient(config=sdk_config)
    
    print("Client initialized with SSL verification disabled")
    print("Note: Use only in development environments or when necessary\n")


# Example 2: Use a custom SSL certificate
def example_custom_certificate():
    print("=== Example 2: Use custom SSL certificate ===")
    
    # Configure Azure with custom certificate
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com/",
        deployment_name="your-deployment",
        api_version="2023-05-15",
        ssl_cert_path="/path/to/certificate.pem"  # Path to the custom certificate
    )
    
    # Configure client and log
    client_config = ClientConfig()
    log_config = LogConfig()
    
    # Create SDK configuration
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config
    )
    
    # Initialize the client
    client = CVScreeningClient(config=sdk_config)
    
    print("Client initialized with custom SSL certificate\n")


# Example 3: Usage in a real scenario (commented to avoid errors)
def example_real_usage():
    print("=== Example 3: Usage in real scenario ===")
    print("Code commented to avoid errors - adjust parameters for your environment")
    
    """
    # Configure Azure without SSL verification
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com/",
        deployment_name="your-deployment",
        api_version="2023-05-15",
        tenant_id="your-tenant-id",  # Optional
        client_id="your-client-id",  # Optional
        client_secret="your-client-secret",  # Optional
        ssl_verify=False
    )
    
    # Configure client and log
    client_config = ClientConfig()
    log_config = LogConfig()
    
    # Create SDK configuration
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config
    )
    
    # Initialize the client
    client = CVScreeningClient(config=sdk_config)
    
    # Define job criteria
    job_criteria = {
        "required_skills": ["python", "azure"],
        "preferred_skills": ["docker", "kubernetes"],
        "min_years_experience": 3
    }
    
    # Analyze CV
    result = client.analyze_cv(CV_CONTENT, job_criteria)
    
    # Show results
    print(f"Overall match: {result.overall_match:.1f}%")
    print(f"Skills match: {result.skills_match.score:.1f}%")
    print(f"Missing required skills: {result.skills_match.missing_required}")
    """
    print("Adjust the parameters in the code to run this example\n")


def example_disable_ssl_verification() -> Dict[str, Any]:
    """
    Example to completely disable SSL verification.
    
    Useful for development environments or when there are issues with corporate proxies.
    """
    logger.info("Starting SSL verification disabling example")
    
    # Configure Azure with SSL disabled
    azure_config = AzureConfig(
        api_version=os.environ.get("AZURE_API_VERSION", "2023-05-15"),
        endpoint=os.environ.get("AZURE_ENDPOINT", "https://your-endpoint.openai.azure.com"),
        deployment=os.environ.get("AZURE_DEPLOYMENT", "your-deployment-name"),
        tenant_id=os.environ.get("AZURE_TENANT_ID", "your-tenant-id"),
        client_id=os.environ.get("AZURE_CLIENT_ID", "your-client-id"),
        client_secret=os.environ.get("AZURE_CLIENT_SECRET", "your-client-secret"),
        ssl_verify=False,  # Disable SSL verification
    )
    
    # Configure the client
    client_config = ClientConfig(
        timeout=int(os.environ.get("CLIENT_TIMEOUT", "30")),
        max_retries=int(os.environ.get("CLIENT_MAX_RETRIES", "3")),
        batch_size=int(os.environ.get("CLIENT_BATCH_SIZE", "10")),
    )
    
    # Configure logging
    log_config = LogConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
    )
    
    # Configure the SDK
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config,
    )
    
    # Define job criteria for CV analysis - simplified to reduce errors
    job_criteria = {
        "required_skills": ["Python"],
        "preferred_skills": ["Docker"]
    }
    
    try:
        # Initialize the client with SSL verification disabled
        cv_client = CVScreeningClient(sdk_config)
        cv_client.initialize()
        
        # Analyze the CV
        logger.info("Analyzing CV with SSL verification disabled")
        try:
            result = cv_client.analyze_cv(CV_CONTENT, job_criteria)
            logger.info("Successfully analyzed CV")
            return result
        except Exception as parse_error:
            logger.warning(f"Error analyzing CV: {str(parse_error)}")
            return {
                "error": str(parse_error),
                "message": "Failed to analyze CV with SSL verification disabled."
            }
    except Exception as e:
        logger.error(f"Error initializing client with SSL disabled: {str(e)}", exc_info=True)
        return {"error": str(e)}

def example_use_custom_certificate() -> Dict[str, Any]:
    """
    Example for using a custom SSL certificate.
    
    Useful when a specific certificate is needed for the connection.
    """
    logger.info("Starting custom SSL certificate usage example")
    
    # Path to the custom certificate
    cert_path = os.environ.get("SSL_CERT_PATH", "/path/to/your/certificate.pem")
    
    # Configure Azure with custom certificate
    azure_config = AzureConfig(
        api_version=os.environ.get("AZURE_API_VERSION", "2023-05-15"),
        endpoint=os.environ.get("AZURE_ENDPOINT", "https://your-endpoint.openai.azure.com"),
        deployment=os.environ.get("AZURE_DEPLOYMENT", "your-deployment-name"),
        tenant_id=os.environ.get("AZURE_TENANT_ID", "your-tenant-id"),
        client_id=os.environ.get("AZURE_CLIENT_ID", "your-client-id"),
        client_secret=os.environ.get("AZURE_CLIENT_SECRET", "your-client-secret"),
        ssl_verify=True,  # Keep SSL verification active
        ssl_cert_path=cert_path,  # Specify the custom certificate
    )
    
    # Configure the client
    client_config = ClientConfig(
        timeout=int(os.environ.get("CLIENT_TIMEOUT", "30")),
        max_retries=int(os.environ.get("CLIENT_MAX_RETRIES", "3")),
        batch_size=int(os.environ.get("CLIENT_BATCH_SIZE", "10")),
    )
    
    # Configure logging
    log_config = LogConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
    )
    
    # Configure the SDK
    sdk_config = SDKConfig(
        azure=azure_config,
        client=client_config,
        log=log_config,
    )
    
    # Define job criteria for CV analysis - simplified to reduce errors
    job_criteria = {
        "required_skills": ["Python"],
        "preferred_skills": ["Docker"]
    }
    
    try:
        # Initialize the client with the custom certificate
        cv_client = CVScreeningClient(sdk_config)
        cv_client.initialize()
        
        # Analyze the CV
        logger.info("Analyzing CV with custom SSL certificate")
        try:
            result = cv_client.analyze_cv(CV_CONTENT, job_criteria)
            logger.info("Successfully analyzed CV with custom certificate")
            return result
        except Exception as parse_error:
            logger.warning(f"Error analyzing CV: {str(parse_error)}")
            return {
                "error": str(parse_error),
                "message": "Failed to analyze CV with custom SSL certificate."
            }
    except Exception as e:
        logger.error(f"Error initializing client with custom certificate: {str(e)}", exc_info=True)
        return {"error": str(e)}

if __name__ == "__main__":
    print("SSL Configuration to solve connection issues with Azure OpenAI\n")
    
    example_disable_ssl()
    example_custom_certificate()
    example_real_usage()
    
    print("You can also configure these options using environment variables:")
    print("  export AZURE_OPENAI_SSL_VERIFY=False")
    print("  export AZURE_OPENAI_SSL_CERT_PATH=/path/to/certificate.pem")
    
    # Run examples
    print("\nExample 1: Disable SSL verification")
    result1 = example_disable_ssl_verification()
    print(f"Result 1: {result1}")
    
    print("\nExample 2: Use custom SSL certificate")
    result2 = example_use_custom_certificate()
    print(f"Result 2: {result2}") 