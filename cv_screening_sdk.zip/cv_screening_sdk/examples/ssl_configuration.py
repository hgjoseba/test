"""
Ejemplo de configuración SSL para resolver problemas de conexión con Azure OpenAI.

Este ejemplo muestra diferentes formas de configurar las opciones SSL para
resolver problemas de certificados al conectarse a Azure OpenAI.
"""

# Importar las clases necesarias
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, SDKConfig

# Contenido de ejemplo de un CV
CV_CONTENT = """
JUAN PÉREZ
Desarrollador de Software

Experiencia:
- 5 años como desarrollador Python en Empresa ABC
- 3 años como desarrollador web en Empresa XYZ

Habilidades:
- Python, JavaScript, HTML/CSS
- Django, Flask, React
- Docker, Kubernetes
- AWS, Azure
"""

# Ejemplo 1: Deshabilitar completamente la verificación SSL
def ejemplo_deshabilitar_ssl():
    print("=== Ejemplo 1: Deshabilitar verificación SSL ===")
    
    # Configurar Azure sin verificación SSL
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com/",
        deployment_name="your-deployment",
        api_version="2023-05-15",
        ssl_verify=False  # Deshabilitar verificación SSL
    )
    
    # Crear configuración del SDK
    config = SDKConfig(azure=azure_config)
    
    # Inicializar el cliente
    client = CVScreeningClient(config=config)
    
    print("Cliente inicializado con verificación SSL desactivada")
    print("Nota: Usar solo en entornos de desarrollo o cuando sea necesario\n")


# Ejemplo 2: Usar un certificado SSL personalizado
def ejemplo_certificado_personalizado():
    print("=== Ejemplo 2: Usar certificado SSL personalizado ===")
    
    # Configurar Azure con certificado personalizado
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com/",
        deployment_name="your-deployment",
        api_version="2023-05-15",
        ssl_cert_path="/ruta/al/certificado.pem"  # Ruta al certificado personalizado
    )
    
    # Crear configuración del SDK
    config = SDKConfig(azure=azure_config)
    
    # Inicializar el cliente
    client = CVScreeningClient(config=config)
    
    print("Cliente inicializado con certificado SSL personalizado\n")


# Ejemplo 3: Uso en un escenario real (comentado para evitar errores)
def ejemplo_uso_real():
    print("=== Ejemplo 3: Uso en escenario real ===")
    print("Código comentado para evitar errores - ajusta los parámetros para tu entorno")
    
    """
    # Configurar Azure sin verificación SSL
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com/",
        deployment_name="your-deployment",
        api_version="2023-05-15",
        tenant_id="your-tenant-id",  # Opcional
        client_id="your-client-id",  # Opcional
        client_secret="your-client-secret",  # Opcional
        ssl_verify=False
    )
    
    # Crear configuración del SDK
    config = SDKConfig(azure=azure_config)
    
    # Inicializar el cliente
    client = CVScreeningClient(config=config)
    
    # Definir criterios de trabajo
    job_criteria = {
        "required_skills": ["python", "azure"],
        "preferred_skills": ["docker", "kubernetes"],
        "min_years_experience": 3
    }
    
    # Analizar CV
    result = client.analyze_cv(CV_CONTENT, job_criteria)
    
    # Mostrar resultados
    print(f"Coincidencia general: {result.overall_match:.1f}%")
    print(f"Coincidencia de habilidades: {result.skills_match.score:.1f}%")
    print(f"Habilidades requeridas faltantes: {result.skills_match.missing_required}")
    """
    print("Ajusta los parámetros en el código para ejecutar este ejemplo\n")


if __name__ == "__main__":
    print("Configuración SSL para resolver problemas de conexión con Azure OpenAI\n")
    
    ejemplo_deshabilitar_ssl()
    ejemplo_certificado_personalizado()
    ejemplo_uso_real()
    
    print("También puedes configurar estas opciones mediante variables de entorno:")
    print("  export AZURE_OPENAI_SSL_VERIFY=False")
    print("  export AZURE_OPENAI_SSL_CERT_PATH=/ruta/al/certificado.pem") 