# Uso de System Prompts Personalizados en CV Screening SDK

Este ejemplo demuestra cómo utilizar system prompts personalizados con el CV Screening SDK para obtener análisis más especializados o enfocados en criterios específicos.

## ¿Qué es un System Prompt?

En el contexto de los modelos de lenguaje grandes (LLMs) como los que usa este SDK, un **system prompt** es una instrucción inicial que define el comportamiento, el tono, y los objetivos que el modelo debe seguir durante la interacción. Es como establecer las "reglas del juego" o el "rol" que el modelo debe desempeñar.

El CV Screening SDK utiliza un system prompt predeterminado que está optimizado para la evaluación general de CVs, pero permitiéndote personalizarlo, puedes adaptar el análisis a tus necesidades específicas.

## Ventajas de los System Prompts Personalizados

1. **Análisis especializado**: Enfoca el análisis en criterios específicos de la industria o rol
2. **Detección mejorada**: Mejora la identificación de habilidades o experiencias específicas
3. **Evaluación personalizada**: Adapta la evaluación a los valores o criterios organizacionales
4. **Consistencia**: Asegura que todos los CVs sean evaluados con los mismos criterios específicos

## Ejemplo de Implementación

El archivo `system_prompt_example.py` demuestra:

1. Cómo inicializar el cliente del SDK con la configuración adecuada
2. Cómo definir un system prompt personalizado para enfocarse en aspectos específicos
3. Cómo usar el system prompt personalizado con el método `analyze_cv_async`
4. Cómo comparar los resultados entre el prompt estándar y el personalizado
5. Cómo usar system prompts personalizados con el procesamiento por lotes

## Estructura del Ejemplo

```
examples/
├── system_prompt_example.py     # Ejemplo completo de uso
├── README_system_prompt.md      # Este archivo de documentación
└── reports/                     # Directorio donde se guardan los reportes generados
    └── comparacion_prompts_*.txt  # Reportes comparativos generados
```

## Casos de Uso Recomendados

Los system prompts personalizados son particularmente útiles en estos escenarios:

1. **Roles altamente especializados**: Cuando necesitas evaluar habilidades muy específicas
2. **Industrias reguladas**: Cuando necesitas verificar cumplimiento con requisitos regulatorios
3. **Análisis cultural**: Cuando quieres evaluar la alineación con valores corporativos
4. **Evaluación de soft skills**: Cuando quieres enfocarte en habilidades interpersonales
5. **Detección de potencial**: Cuando buscas identificar candidatos con alto potencial de crecimiento

## Cómo Ejecutar el Ejemplo

Asegúrate de tener configurado tu archivo `.env` con las credenciales de Azure OpenAI y luego ejecuta:

```bash
python system_prompt_example.py
```

El script generará un reporte comparativo que muestra las diferencias entre los análisis realizados con el system prompt estándar y el personalizado.

## Mejores Prácticas para System Prompts

1. **Sé específico**: Define claramente lo que quieres que el modelo evalúe
2. **Estructura el formato**: Especifica cómo quieres que se presente la información
3. **Equilibra la longitud**: Un prompt muy largo puede diluir el enfoque, uno muy corto puede ser vago
4. **Prueba y ajusta**: Experimenta con diferentes formulaciones para encontrar la óptima
5. **Mantén la objetividad**: Evita sesgos innecesarios en las instrucciones

## Referencia de System Prompt Predeterminado

El system prompt predeterminado del SDK es:

```
You are an expert CV screening assistant. Your task is to analyze CVs and determine if they match the given job criteria.
Provide a detailed analysis including:
1. Match score (0-1)
2. Skills match
3. Experience match
4. Education match
5. Overall analysis

Format your response as a JSON object with these fields.
```

## Parámetros Avanzados

Cuando utilices system prompts personalizados, recuerda que:

1. El resultado debe seguir siendo un objeto JSON válido que el SDK pueda interpretar
2. Debes incluir al menos los campos básicos que el SDK espera (puntuación, habilidades, etc.)
3. Puedes agregar campos adicionales, pero el SDK solo procesará los que reconoce
4. El formato de respuesta debe ser compatible con la estructura `CVScreeningResult`

## Consideraciones de Rendimiento

Los system prompts personalizados generalmente no afectan significativamente el rendimiento o la velocidad de procesamiento, pero si son muy largos o complejos, podrían aumentar ligeramente el tiempo de respuesta del modelo. 