# CV Screening SDK - Guía de Procesamiento por Lotes

## Introducción

El CV Screening SDK proporciona una solución completa para analizar currículums (CVs) utilizando la API de Azure OpenAI. Esta guía se centra en las capacidades de procesamiento por lotes del SDK, permitiéndote procesar múltiples CVs de manera eficiente.

## Funcionalidades principales del cliente

El SDK proporciona diversas formas de analizar currículums:

### 1. Análisis individual de CV

```python
# Análisis básico
result = client.analyze_cv(content, criteria)

# Análisis asíncrono
result = await client.analyze_cv_async(content, criteria)

# Análisis con carga de contenido desde archivo
cv_content = client.load_cv_content("ruta/al/cv.pdf")
result = client.analyze_cv(cv_content, criteria)
```

### 2. Procesamiento completo de CV

```python
# Procesamiento con ruta opcional
result = client.screen_cv(cv_content, criteria, cv_path="ruta/al/cv.pdf")

# Procesamiento asíncrono
result = await client.screen_cv_async(cv_content, criteria, cv_path="ruta/opcional.pdf")
```

### 3. Procesamiento por lotes

El SDK ofrece dos enfoques principales para procesar múltiples CVs:

#### a. Procesamiento por lotes con contenido de CV

```python
result = client.batch_screen_cvs(
    cv_contents=["Contenido del CV 1...", "Contenido del CV 2..."],
    criteria=job_criteria,
    cv_paths=["cv1.pdf", "cv2.pdf"]  # Opcional, para referencia
)
```

- Acepta una lista de contenidos de CV como texto
- Proporciona opcionalmente las rutas para referencia
- Devuelve un objeto `BatchProcessingResult` con estadísticas completas
- Procesa currículums en paralelo usando asyncio

#### b. Procesamiento por lotes completamente asíncrono

```python
results = await client.analyze_cvs_batch(
    contents=["Contenido del CV 1...", "Contenido del CV 2..."],
    criteria=job_criteria
)
```

- Acepta una lista de strings (contenido de CV)
- Ideal cuando ya tienes el texto extraído
- Devuelve una lista de resultados en formato diccionario
- Requiere contexto asíncrono (usar con `await`)

## Configuración del cliente

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import SDKConfig, AzureConfig, ClientConfig

# Configuración de Azure
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com",
    deployment_name="your-deployment",
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret",
    api_version="2023-05-15"  # Opcional, por defecto usa la más reciente
)

# Configuración del cliente para el procesamiento por lotes
client_config = ClientConfig(
    batch_size=10,  # Controla cuántos CVs se procesan en paralelo
    timeout=60,     # Tiempo máximo por CV (segundos)
    max_retries=3   # Reintentos por CV si falla
)

# Configuración completa del SDK
sdk_config = SDKConfig(
    azure=azure_config,
    client=client_config
)

# Crear cliente
client = CVScreeningClient(config=sdk_config)
```

## Criterios de evaluación

El SDK admite múltiples formatos para especificar los criterios de trabajo:

### 1. Usando la clase JobCriteria

```python
from cv_screening_sdk.models.criteria import JobCriteria

criteria = JobCriteria(
    required_skills=["Python", "SQL", "AWS"],
    preferred_skills=["Docker", "Kubernetes", "FastAPI"],
    min_years_experience=3,
    education_level="bachelors",  # Se normaliza a "Bachelor's" internamente
    job_title="Data Engineer",
    job_description="Rol de ingeniería de datos centrado en pipelines...",
    location="Madrid",
    industry="Tecnología",
    company_description="Empresa líder en análisis de datos"
)
```

### 2. Usando un diccionario

```python
criteria = {
    "required_skills": ["Python", "SQL", "AWS"],
    "preferred_skills": ["Docker", "Kubernetes", "FastAPI"],
    "min_years_experience": 3,
    "education_level": "masters",  # Se normaliza a "Master's" internamente
    "job_title": "Data Engineer"
}
```

### 3. Usando un prompt personalizado

```python
# Prompt de texto simple (para análisis más flexible)
criteria = "Buscamos un desarrollador con experiencia en Python y AWS que pueda trabajar en microservicios."
```

## Carga de CVs desde archivos

El SDK proporciona un método para cargar contenido de CV desde archivos comunes:

```python
# Cargar desde archivos de texto
content = client.load_cv_content("ruta/al/cv.txt")

# Cargar desde PDF (requiere PyPDF2)
content = client.load_cv_content("ruta/al/cv.pdf")

# Cargar desde DOCX (requiere python-docx)
content = client.load_cv_content("ruta/al/cv.docx")
```

Requisitos adicionales para formatos específicos:
- PDF: `pip install PyPDF2`
- DOCX: `pip install python-docx`

## Estructura de resultados por lotes

El objeto `BatchProcessingResult` proporciona:

```python
# Resultados exitosos y fallidos
successful_cvs = result.successful_results  # Lista de CVScreeningResult
failed_cvs = result.failed_results          # Lista de ProcessingFailure

# Estadísticas
total = result.total_items                  # Total de CVs procesados
success_rate = result.success_rate()        # Proporción de éxito (0-1)
avg_score = result.average_score()          # Puntuación media (0-100)
processing_time = result.processing_time    # Tiempo total (segundos)

# Ordenar por puntuación para encontrar los mejores candidatos
top_candidates = sorted(
    result.successful_results,
    key=lambda x: x.overall_match,
    reverse=True
)[:5]  # Top 5 candidatos
```

## Estructura de resultados individuales

Cada resultado individual (`CVScreeningResult`) contiene:

```python
# Puntuaciones de coincidencia
score = result.overall_match                # Puntuación global (0-100)
skills_match = result.skills_match.score    # Coincidencia de habilidades
exp_match = result.experience_match.score   # Coincidencia de experiencia
edu_match = result.education_match.score    # Coincidencia de educación

# Perfil del candidato
profile = result.candidate_profile          # Información estructurada
resume = result.cv_summary                  # Resumen del CV

# Ruta del archivo (si se proporcionó)
path = result.cv_path                       # Ruta al archivo original
```

## Limitaciones de la API de Azure OpenAI

Cuando proceses lotes grandes, considera estas limitaciones:

1. **Cuotas de tokens por minuto (TPM)**:
   - GPT-4: 10K-80K TPM según suscripción
   - Un CV puede consumir 2K-5K tokens

2. **Solicitudes por minuto (RPM)**:
   - Típicamente 60-1000 RPM
   - El procesamiento por lotes está limitado por estos valores

3. **Consideraciones de escalado**:
   - Establece `batch_size` acorde a tus límites de API
   - Con TPM = 40K y 2K tokens/CV → máx. ~20 CVs/minuto
   - Con RPM = 100 → máx. 100 CVs/minuto

## Estrategias de escalado

### Integración con PySpark para procesamiento masivo

Para procesar grandes volúmenes de CVs (miles o millones), PySpark ofrece una solución escalable y distribuida. El SDK de CV Screening puede integrarse con PySpark para crear un pipeline de procesamiento robusto.

#### Arquitectura de integración con PySpark

```
[Fuente de datos] → [PySpark] → [CV Screening SDK] → [Almacenamiento de resultados]
   S3/HDFS/DB       Partición      Análisis API          HDFS/S3/Database
```

#### Ejemplo de implementación con PySpark

```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, lit
from pyspark.sql.types import StringType
import json
import time
import random
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig

# 1. Configuración de Spark
spark = SparkSession.builder \
    .appName("CVScreeningBatch") \
    .config("spark.executor.memory", "8g") \
    .config("spark.driver.memory", "4g") \
    .config("spark.task.maxFailures", "10") \
    .getOrCreate()

# 2. Función de retroceso exponencial para manejar limitaciones de API
def with_rate_limit(func):
    def wrapper(*args, **kwargs):
        max_retries = 5
        for attempt in range(max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if "429" in str(e) and attempt < max_retries - 1:
                    # Retroceso exponencial con jitter
                    sleep_time = (2 ** attempt) + random.random() * 2
                    time.sleep(sleep_time)
                else:
                    raise
    return wrapper

# 3. Función para obtener cliente con estado compartido
def get_client():
    # Configurar cliente (singleton por ejecutor)
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com",
        deployment_name="your-deployment",
        tenant_id="your-tenant-id",
        client_id="your-client-id",
        client_secret="your-client-secret"
    )
    client_config = ClientConfig(batch_size=1)  # Control individual, PySpark maneja paralelismo
    sdk_config = SDKConfig(azure=azure_config, client=client_config)
    return CVScreeningClient(config=sdk_config)

# 4. UDF para procesar CVs con retroceso exponencial
@with_rate_limit
def process_cv(cv_content, criteria_json):
    """Procesa un CV individual con control de tasa"""
    client = get_client()
    criteria = json.loads(criteria_json)
    
    # Añadir pausa aleatoria para distribuir solicitudes
    time.sleep(random.random() * 0.5)
    
    try:
        result = client.analyze_cv(cv_content, criteria)
        return json.dumps(result.to_dict())
    except Exception as e:
        return json.dumps({"error": str(e), "content_preview": cv_content[:100]})

# Registrar como UDF de Spark
process_cv_udf = udf(process_cv, StringType())

# 5. Criterios de trabajo
job_criteria = JobCriteria(
    required_skills=["Python", "SQL"],
    preferred_skills=["Docker", "AWS"],
    min_years_experience=3,
    education_level="bachelors"
).to_dict()

# Convertir a JSON para pasar a los ejecutores
criteria_json = json.dumps(job_criteria)

# 6. Cargar datos (ejemplo con CSV)
cv_df = spark.read.csv("hdfs:///path/to/cvs.csv", header=True)

# 7. Procesamiento distribuido con control de paralelismo
# Reparto explícito para controlar paralelismo basado en límites de API
num_partitions = 20  # Ajustar según límites de API
result_df = cv_df.repartition(num_partitions) \
    .withColumn("analysis_result", process_cv_udf(cv_df["content"], lit(criteria_json)))

# 8. Guardar resultados
result_df.write.mode("overwrite").parquet("hdfs:///path/to/results")

# 9. Analizar resultados (opcional)
top_candidates = result_df.filter("analysis_result.error IS NULL") \
    .withColumn("score", get_score_udf("analysis_result")) \
    .orderBy(col("score").desc()) \
    .limit(100)

top_candidates.show()
```

#### Optimización de PySpark para Azure OpenAI

Para manejar las limitaciones de la API mientras se optimiza el rendimiento:

##### 1. Distribución de carga entre múltiples endpoints

```python
# Pool de endpoints para distribución de carga
endpoints = [
    "https://endpoint1.openai.azure.com",
    "https://endpoint2.openai.azure.com",
    "https://endpoint3.openai.azure.com"
]

tenant_ids = ["tenant-id-1", "tenant-id-2", "tenant-id-3"]
client_ids = ["client-id-1", "client-id-2", "client-id-3"]
client_secrets = ["secret-1", "secret-2", "secret-3"]

def get_client_for_partition(partition_id):
    """Selecciona endpoint basado en ID de partición"""
    endpoint_idx = partition_id % len(endpoints)
    azure_config = AzureConfig(
        endpoint=endpoints[endpoint_idx],
        deployment_name="deployment-name",
        tenant_id=tenant_ids[endpoint_idx],
        client_id=client_ids[endpoint_idx],
        client_secret=client_secrets[endpoint_idx]
    )
    return CVScreeningClient(config=SDKConfig(azure=azure_config))
```

##### 2. Procesamiento híbrido con cola intermedia

```python
# Configuración de cola (pseudocódigo)
from kafka import KafkaProducer, KafkaConsumer

# En el job de Spark: enviar a cola en lugar de procesar directamente
def send_to_queue(partition):
    producer = KafkaProducer(bootstrap_servers='kafka:9092')
    for record in partition:
        producer.send('cv-processing-queue', 
                     key=record['id'], 
                     value=record['content'])
    producer.flush()
```

#### Consideraciones de rendimiento para PySpark

1. **Particionamiento óptimo**:
   - Usa menos particiones que tus límites de RPM
   - Ejemplo: Si tienes 500 RPM, configura 100-200 particiones

## Ejemplos de uso completos

### Ejemplo de procesamiento por lotes simple

```python
from cv_screening_sdk import CVScreeningClient, JobCriteria
import os
import glob

# Inicializar cliente
client = CVScreeningClient()

# Definir criterios
criteria = JobCriteria(
    required_skills=["Python", "Data Analysis"],
    preferred_skills=["Pandas", "SQL", "Visualization"],
    min_years_experience=2,
    education_level="bachelors"
)

# Cargar CVs de un directorio
cv_paths = glob.glob("path/to/cvs/*.pdf")
cv_contents = []
for path in cv_paths:
    try:
        content = client.load_cv_content(path)
        cv_contents.append(content)
    except Exception as e:
        print(f"Error cargando {path}: {e}")

# Procesar por lotes
result = client.batch_screen_cvs(
    cv_contents=cv_contents,
    criteria=criteria,
    cv_paths=cv_paths
)

# Mostrar estadísticas
print(f"Procesados: {result.total_items} CVs")
print(f"Tasa de éxito: {result.success_rate()*100:.1f}%")
print(f"Puntuación media: {result.average_score():.1f}%")
print(f"Tiempo de procesamiento: {result.processing_time:.2f} segundos")

# Mostrar mejores candidatos
top_candidates = sorted(
    result.successful_results,
    key=lambda x: x.overall_match,
    reverse=True
)[:3]

for i, candidate in enumerate(top_candidates):
    print(f"\nCandidato #{i+1}: {candidate.cv_path}")
    print(f"Puntuación global: {candidate.overall_match}%")
    print(f"Habilidades: {candidate.skills_match.score}%")
    print(f"Experiencia: {candidate.experience_match.score}%")
    print(f"Perfil: {candidate.candidate_profile.current_role}")
```

### Ejemplo de procesamiento asíncrono

```python
import asyncio
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.models.criteria import JobCriteria

async def process_cvs_async():
    # Inicializar cliente
    client = CVScreeningClient()
    
    # Criterios de trabajo
    criteria = JobCriteria(
        required_skills=["Java", "Spring Boot"],
        preferred_skills=["Microservices", "Docker", "AWS"],
        min_years_experience=5,
        education_level="masters"
    )
    
    # Cargar contenido de CV
    cv_files = ["cv1.pdf", "cv2.pdf", "cv3.docx"]
    cv_contents = []
    for file in cv_files:
        cv_contents.append(client.load_cv_content(file))
    
    # Procesar de forma asíncrona
    tasks = [
        client.screen_cv_async(content, criteria, path) 
        for content, path in zip(cv_contents, cv_files)
    ]
    
    results = await asyncio.gather(*tasks)
    
    # Mostrar resultados
    for i, result in enumerate(results):
        print(f"CV {i+1}: {result.overall_match}% match")
        print(f"  Skills: {result.skills_match.score}%")
        print(f"  Experience: {result.experience_match.score}%")
        print(f"  Education: {result.education_match.score}%")
        print("  " + "-" * 30)
    
    return results

# Ejecutar la función asíncrona
if __name__ == "__main__":
    asyncio.run(process_cvs_async())
```

## Recomendaciones para entornos de producción

1. **Monitoreo**: Implementa alertas para errores de límite de tasa ("429 Too Many Requests")
2. **Retroceso exponencial**: Agrega esperas crecientes ante errores
3. **Persistencia**: Guarda resultados incrementalmente para recuperación
4. **Distribución de carga**: Considera múltiples instancias de Azure OpenAI
5. **Ajuste de contenido**: Optimiza el procesamiento de textos para reducir tokens

Este enfoque te permitirá procesar eficientemente grandes volúmenes de CVs mientras respetas los límites de API y optimizas recursos. 