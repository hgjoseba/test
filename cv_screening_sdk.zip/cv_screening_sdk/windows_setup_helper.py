#!/usr/bin/env python
"""
Script de ayuda para configurar el entorno en Windows
y resolver problemas comunes de instalación
"""

import os
import sys
import subprocess
import platform
import webbrowser
import tempfile
import shutil
from pathlib import Path
import ctypes

def is_admin():
    """Comprueba si el script se está ejecutando con privilegios de administrador"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except:
        return False

def run_command(command, check=True):
    """Ejecuta un comando y muestra su salida"""
    print(f"\n> Ejecutando: {command}")
    result = subprocess.run(command, shell=True, text=True, capture_output=True)
    if result.stdout:
        print(result.stdout)
    if result.stderr and "WARNING" not in result.stderr:
        print(f"ERRORES: {result.stderr}")
    if check and result.returncode != 0:
        print(f"ERROR: El comando falló con código {result.returncode}")
        return False
    return True

def configure_pip():
    """Configura pip para preferir binarios precompilados"""
    print("\n>> Configurando pip para evitar compilaciones innecesarias...")
    
    # Actualizar pip
    run_command("python -m pip install --upgrade pip")
    
    # Configurar pip para preferir binarios
    print("\nConfigurando pip para preferir paquetes binarios precompilados...")
    run_command('pip config set global.only-binary ":all:"')
    
    return True

def install_visual_studio_components():
    """Comprueba e instala los componentes necesarios de Visual Studio"""
    print("\n>> Comprobando Visual Studio Build Tools...")
    
    try:
        # Verificar si cl.exe (el compilador de C++) está disponible
        result = subprocess.run(["where", "cl"], 
                               capture_output=True, 
                               text=True)
        if result.returncode == 0:
            print("✅ Visual Studio Build Tools ya está instalado")
            return True
            
        print("❌ Visual Studio Build Tools no está instalado o configurado correctamente")
        print("\nNecesitas instalar Visual Studio Build Tools...")
        print("Abriendo página de descarga en el navegador...")
        
        webbrowser.open("https://visualstudio.microsoft.com/visual-cpp-build-tools/")
        
        print("\n⚠️ Al instalar Visual Studio Build Tools:")
        print("   1. Selecciona 'Desarrollo para el escritorio con C++'")
        print("   2. Después de la instalación, cierra y vuelve a abrir esta terminal")
        print("   3. Ejecuta este script nuevamente")
        
        return False
            
    except Exception as e:
        print(f"❌ Error al verificar Visual Studio Build Tools: {e}")
        return False

def main():
    """Función principal"""
    print("=" * 80)
    print("  ASISTENTE DE CONFIGURACIÓN PARA CV SCREENING SDK EN WINDOWS")
    print("=" * 80)
    
    print("\nEste script te ayudará a configurar tu entorno para usar CV Screening SDK")
    print("y resolver problemas comunes de instalación.")
    
    # Comprobar versión de Python
    python_version = sys.version.split()[0]
    print(f"\n>> Versión de Python: {python_version}")
    major, minor, *_ = python_version.split(".")
    if major != "3" or int(minor) < 8:
        print("❌ Se requiere Python 3.8 o superior.")
        sys.exit(1)
    
    # Comprobar que estamos en Windows
    print(f"\n>> Sistema operativo: {platform.system()} {platform.release()}")
    if platform.system() != "Windows":
        print("❌ Este script es solo para Windows.")
        sys.exit(1)
    
    # Configurar pip
    configure_pip()
    
    # Comprobar Visual Studio Build Tools
    install_visual_studio_components()
    
    # Intentar instalar el paquete
    print("\n>> Intentando instalar cv-screening-sdk...")
    if run_command("pip install cv-screening-sdk", check=False):
        print("\n✅ cv-screening-sdk se ha instalado correctamente.")
    else:
        print("\n⚠️ Hubo problemas instalando cv-screening-sdk.")
        print("Intentando con --only-binary...")
        if run_command("pip install cv-screening-sdk --only-binary=:all:", check=False):
            print("\n✅ cv-screening-sdk se ha instalado correctamente usando --only-binary.")
        else:
            print("\n❌ No se pudo instalar cv-screening-sdk automáticamente.")
            print("Sugerencias para solucionar problemas:")
            print("1. Asegúrate de que Visual Studio Build Tools esté correctamente instalado")
            print("2. Intenta actualizar pip: pip install --upgrade pip")
            print("3. Intenta instalar aiohttp por separado: pip install aiohttp==3.9.3 --only-binary=:all:")
            print("4. Intenta usar una versión diferente de Python (3.9 o 3.10)")
    
    print("\n>> Configuración completada.")
    print("\nSi continúas teniendo problemas, visita:")
    print("https://github.com/yourusername/cv-screening-sdk/issues")

if __name__ == "__main__":
    main() 