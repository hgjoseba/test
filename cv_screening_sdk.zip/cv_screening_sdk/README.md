# CV Screening SDK

SDK para análisis automatizado de currículums utilizando Azure OpenAI.

## Características

- **Análisis de CV**: Evalúa currículums contra criterios de trabajo específicos
- **Evaluación de habilidades**: Identifica habilidades obligatorias y preferidas
- **Valoración de experiencia**: Analiza la relevancia de la experiencia laboral
- **Puntuación global**: Genera una puntuación general para cada candidato
- **Procesamiento por lotes**: Analiza múltiples CVs de forma eficiente
- **Soporte asíncrono**: Procesa CVs en paralelo para mayor rendimiento

## Instalación

```bash
pip install cv-screening-sdk
```

## Configuración rápida

### Opción 1: Configuración mediante variables de entorno (recomendada)

```bash
# Configuración de autenticación de Azure (requerida)
export AZURE_TENANT_ID="tu-tenant-id"
export AZURE_CLIENT_ID="tu-client-id"
export AZURE_CLIENT_SECRET="tu-client-secret"

# Configuración de Azure OpenAI (requerida)
export AZURE_OPENAI_ENDPOINT="https://tu-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="tu-deployment-name"

# Configuración SSL (opcional)
export AZURE_OPENAI_SSL_VERIFY="True"
export AZURE_OPENAI_SSL_CERT_PATH="/ruta/a/certificado.pem"

# Configuración de conexión (opcional)
export AZURE_OPENAI_CONNECTION_VERIFY="True"
export AZURE_OPENAI_CONNECTION_TIMEOUT="30"
export AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS="5"
export AZURE_OPENAI_MAX_CONNECTIONS="10"
```

### Opción 2: Configuración programática

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, SDKConfig

# Configuración de Azure
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    tenant_id="tu-tenant-id",
    client_id="tu-client-id",
    client_secret="tu-client-secret",
    ssl_verify=True,
    connection_timeout=30,
    max_keepalive_connections=5,
    max_connections=10
)

# Inicializar cliente
client = CVScreeningClient(config=SDKConfig(azure=azure_config))
```

## Uso básico

```python
from cv_screening_sdk import CVScreeningClient

# Inicializar cliente (usando configuración de variables de entorno)
client = CVScreeningClient()

# Definir criterios del trabajo
job_criteria = {
    "job_title": "Desarrollador Python Senior",
    "required_skills": ["python", "django", "api", "sql"],
    "preferred_skills": ["aws", "docker", "git", "testing"],
    "min_years_experience": 3,
    "education_level": "licenciatura"
}

# Analizar texto de CV
cv_text = """
JUAN PÉREZ
Desarrollador Python

EXPERIENCIA
2018-2022 Acme Inc - Desarrollador Senior
- Desarrollé APIs RESTful con Django y Flask
- Implementé bases de datos SQL y NoSQL
- Trabajé con Docker y AWS para despliegue

2015-2018 Tech Solutions - Desarrollador Junior
- Desarrollé funcionalidades en Python
- Trabajé con Git para control de versiones

EDUCACIÓN
Licenciatura en Ingeniería Informática, Universidad Tecnológica, 2015

HABILIDADES
Python, Django, Flask, SQL, MongoDB, Docker, AWS, Git, Testing
"""

# Analizar el CV
result = client.analyze_cv_text(cv_text, job_criteria)

# Mostrar resultados
print(f"Puntuación global: {result['overall_score']}")
print(f"Habilidades obligatorias: {result['required_skills_score']}")
print(f"Habilidades preferidas: {result['preferred_skills_score']}")
print(f"Experiencia: {result['experience_score']}")
print(f"Resumen: {result['summary']}")
```

## Procesamiento por lotes

```python
# Lista de CVs para procesar
cv_texts = [cv_text1, cv_text2, cv_text3]

# Procesar todos los CVs
batch_results = client.batch_analyze_cv_texts(cv_texts, job_criteria)

# Imprimir resultados en orden de puntuación
for result in sorted(batch_results, key=lambda x: x['overall_score'], reverse=True):
    print(f"Candidato: {result['candidate_name']}")
    print(f"Puntuación: {result['overall_score']}")
    print("---")
```

## Procesamiento asíncrono

```python
import asyncio
from cv_screening_sdk import CVScreeningClient

async def process_cvs_async():
    # Inicializar cliente
    client = CVScreeningClient()
    
    # Lista de CVs y criterios
    cv_texts = [cv_text1, cv_text2, cv_text3]
    
    # Procesar CVs de forma asíncrona
    results = await client.async_analyze_cv_texts(cv_texts, job_criteria)
    
    return results

# Ejecutar procesamiento asíncrono
results = asyncio.run(process_cvs_async())
```

## Documentación

Para una documentación más detallada, consulta:

- [Guía de uso](docs/usage_guide.md)
- [Configuración](docs/configuration.md)
- [Manejo de errores](docs/error_handling.md)

## Ejemplos

Revisa la carpeta `examples` para más ejemplos completos:

- `examples/basic_usage.py`: Ejemplo básico de uso
- `examples/async_processing.py`: Procesamiento asíncrono
- `examples/text_processing.py`: Procesamiento de texto avanzado

## Requisitos

- Python 3.8+
- Suscripción a Azure OpenAI
- Service Principal de Azure con acceso al servicio OpenAI

## Licencia

Este proyecto está licenciado bajo la licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

## Contribuir

Las contribuciones son bienvenidas. Por favor, abre un issue para discutir los cambios antes de crear un pull request.