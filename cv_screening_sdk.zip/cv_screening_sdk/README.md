# CV Screening SDK

A powerful and flexible SDK for automated CV/resume screening and analysis using Azure OpenAI with Service Principal authentication. This SDK helps streamline the recruitment process by automatically evaluating candidates' resumes against job criteria.

**Version:** 0.1.0  
**Last documentation update:** March 31, 2025

## Features

### Core Features
- **Azure OpenAI Integration**: Seamless integration with Azure OpenAI using Service Principal authentication
- **Flexible Analysis**: Custom job criteria matching and skill assessment

### Processing Capabilities
- **Batch Processing**: Efficient handling of multiple CVs simultaneously
- **Async Support**: Asynchronous processing for improved performance
- **Extensible Design**: Modular LLM adapter interface for future integrations

### Development Features
- **Comprehensive Logging**: Detailed logging support for debugging
- **Error Handling**: Robust error handling and validation
- **Test Coverage**: Extensive unit test coverage
- **Type Safety**: Full type hinting support with mypy validation

## Project Structure

```
cv_screening_sdk/
├── cv_screening_sdk/  # Main package
│   ├── auth/          # Authentication providers
│   ├── core/          # Core interfaces and config
│   ├── models/        # Data models
│   ├── providers/     # LLM providers
│   └── utils/         # Utility functions
├── tests/             # Test files
├── docs/              # Documentation files
├── examples/          # Example usage scripts
├── setup.py           # Package configuration
├── pyproject.toml     # Project configuration
├── requirements.txt   # Project dependencies
└── compile_sdk.sh     # Build script for creating wheel package
```

## Installation

### Using pip with wheel package

```bash
# Build the wheel package
python setup.py bdist_wheel

# Install from wheel package
pip install dist/cv_screening_sdk-*.whl
```

### Installing with optional dependencies

The SDK supports various document formats that require additional dependencies. You can install these dependencies using the wheel package:

```bash
# Build the wheel package first
python setup.py bdist_wheel

# Install with PDF and DOCX support
pip install dist/cv_screening_sdk-*.whl[document_processing]

# Install with all dependencies (development, testing, documentation, document processing)
pip install dist/cv_screening_sdk-*.whl[all]

# Install with specific optional dependencies
pip install dist/cv_screening_sdk-*.whl[dev]  # Development dependencies
pip install dist/cv_screening_sdk-*.whl[test]  # Testing dependencies
pip install dist/cv_screening_sdk-*.whl[docs]  # Documentation dependencies
```

### Installing for Development

If you're developing the SDK, you can install it in development mode:

```bash
# Install in development mode with all dependencies
pip install -e .[all]

# Or with specific dependencies
pip install -e .[document_processing,dev,test]
```

This creates a link to your source code instead of copying the files, so changes to the code will immediately affect the installed package without needing to reinstall.

## Authentication

The SDK uses Azure Service Principal authentication. Set the following environment variables:

```bash
export AZURE_TENANT_ID="your_tenant_id"
export AZURE_CLIENT_ID="your_client_id"
export AZURE_CLIENT_SECRET="your_client_secret"
export AZURE_OPENAI_ENDPOINT="your_endpoint"
export AZURE_OPENAI_DEPLOYMENT_NAME="your_deployment_name"
export AZURE_OPENAI_MODEL_NAME="gpt-4" # Optional, defaults to gpt-4
```

Alternatively, you can provide these values in code:

```python
from cv_screening_sdk.core.config import SDKConfig, AzureConfig, ClientConfig

# Azure configuration
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com",
    deployment_name="your-deployment",
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret",
    api_version="2023-05-15"  # Optional, defaults to latest version
)

# Client configuration for batch processing
client_config = ClientConfig(
    batch_size=10,  # Controls how many CVs are processed in parallel
    timeout=60,     # Maximum time per CV (seconds)
    max_retries=3   # Retries per CV if it fails
)

# Complete SDK configuration
sdk_config = SDKConfig(
    azure=azure_config,
    client=client_config
)

# Create client
client = CVScreeningClient(config=sdk_config)
```

## Quick Start

Example usage:
```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.models.criteria import JobCriteria

# Initialize the client
client = CVScreeningClient()

# Define screening criteria
criteria = JobCriteria(
    required_skills=["Python", "Machine Learning", "AWS"],
    preferred_skills=["Docker", "Kubernetes"],
    min_years_experience=3,
    education_level="bachelors"
)

# Load CV content from file
cv_content = client.load_cv_content("./resumes/software_engineer_resume.pdf")

# Screen a single CV
result = client.screen_cv(cv_content, criteria, cv_path="./resumes/software_engineer_resume.pdf")

# Process and display results
print(f"Match Score: {result.overall_match}%")
print(f"Skills Match: {result.skills_match.score}%")
print(f"Experience Match: {result.experience_match.score}%")
print(f"Education Match: {result.education_match.score}%")

# Batch process multiple CVs
cv_paths = ["cv1.pdf", "cv2.pdf", "cv3.pdf"]
cv_contents = [client.load_cv_content(path) for path in cv_paths]
batch_results = client.batch_screen_cvs(cv_contents, criteria, cv_paths)
```

## Advanced Usage

### Client Functionality

The SDK provides several ways to analyze resumes:

#### 1. Individual CV Analysis

```python
# Basic analysis
result = client.analyze_cv(content, criteria)

# Asynchronous analysis
result = await client.analyze_cv_async(content, criteria)

# Analysis with content loaded from file
cv_content = client.load_cv_content("path/to/cv.pdf")
result = client.analyze_cv(cv_content, criteria)
```

#### 2. Complete CV Processing

```python
# Processing with optional path
result = client.screen_cv(cv_content, criteria, cv_path="path/to/cv.pdf")

# Asynchronous processing
result = await client.screen_cv_async(cv_content, criteria, cv_path="optional/path.pdf")
```

#### 3. Batch Processing

The SDK offers two main approaches for processing multiple CVs:

##### a. Batch Processing with CV Content

```python
result = client.batch_screen_cvs(
    cv_contents=["CV Content 1...", "CV Content 2..."],
    criteria=job_criteria,
    cv_paths=["cv1.pdf", "cv2.pdf"]  # Optional, for reference
)
```

- Accepts a list of CV contents as text
- Optionally provides paths for reference
- Returns a `BatchProcessingResult` object with complete statistics
- Processes CVs in parallel using asyncio

##### b. Fully Asynchronous Batch Processing

```python
results = await client.analyze_cvs_batch(
    contents=["CV Content 1...", "CV Content 2..."],
    criteria=job_criteria
)
```

- Accepts a list of strings (CV content)
- Ideal when you already have extracted text
- Returns a list of results in dictionary format
- Requires asynchronous context (use with `await`)

### Job Criteria Formats

The SDK supports multiple formats for specifying job criteria:

#### 1. Using the JobCriteria Class

```python
from cv_screening_sdk.models.criteria import JobCriteria

criteria = JobCriteria(
    required_skills=["Python", "SQL", "AWS"],
    preferred_skills=["Docker", "Kubernetes", "FastAPI"],
    min_years_experience=3,
    education_level="bachelors",  # Normalized to "Bachelor's" internally
    job_title="Data Engineer",
    job_description="Data engineering role focused on pipelines...",
    location="New York",
    industry="Technology",
    company_description="Leading data analytics company"
)
```

#### 2. Using a Dictionary

```python
criteria = {
    "required_skills": ["Python", "SQL", "AWS"],
    "preferred_skills": ["Docker", "Kubernetes", "FastAPI"],
    "min_years_experience": 3,
    "education_level": "masters",  # Normalized to "Master's" internally
    "job_title": "Data Engineer"
}
```

#### 3. Using a Custom Prompt

```python
# Simple text prompt (for more flexible analysis)
criteria = "Looking for a developer with Python and AWS experience who can work on microservices."
```

### Loading CVs from Files

The SDK provides a method to load CV content from common file formats:

```python
# Load from text files
content = client.load_cv_content("path/to/cv.txt")

# Load from PDF (requires PyPDF2)
content = client.load_cv_content("path/to/cv.pdf")

# Load from DOCX (requires python-docx)
content = client.load_cv_content("path/to/cv.docx")
```

Additional requirements for specific formats:
- PDF: `pip install PyPDF2`
- DOCX: `pip install python-docx`

## Results Structure

### Batch Processing Results

The `BatchProcessingResult` object provides:

```python
# Successful and failed results
successful_cvs = result.successful_results  # List of CVScreeningResult
failed_cvs = result.failed_results          # List of ProcessingFailure

# Statistics
total = result.total_items                  # Total CVs processed
success_rate = result.success_rate()        # Success rate (0-1)
avg_score = result.average_score()          # Average score (0-100)
processing_time = result.processing_time    # Total time (seconds)

# Sort by score to find the best candidates
top_candidates = sorted(
    result.successful_results,
    key=lambda x: x.overall_match,
    reverse=True
)[:5]  # Top 5 candidates
```

### Individual Results

Each individual result (`CVScreeningResult`) contains:

```python
# Match scores
score = result.overall_match                # Overall score (0-100)
skills_match = result.skills_match.score    # Skills match
exp_match = result.experience_match.score   # Experience match
edu_match = result.education_match.score    # Education match

# Candidate profile
profile = result.candidate_profile          # Structured information
resume = result.cv_summary                  # CV summary

# File path (if provided)
path = result.cv_path                       # Path to original file
```

## API Limitations and Scaling

When processing large batches, consider these limitations:

1. **Tokens Per Minute (TPM) Quotas**:
   - GPT-4: 10K-80K TPM depending on subscription
   - A CV can consume 2K-5K tokens

2. **Requests Per Minute (RPM)**:
   - Typically 60-1000 RPM
   - Batch processing is limited by these values

3. **Scaling Considerations**:
   - Set `batch_size` according to your API limits
   - With TPM = 40K and 2K tokens/CV → max ~20 CVs/minute
   - With RPM = 100 → max 100 CVs/minute

## Scaling Strategies

### PySpark Integration for Mass Processing

For processing large volumes of CVs (thousands or millions), PySpark offers a scalable, distributed solution. The CV Screening SDK can be integrated with PySpark to create a robust processing pipeline.

#### PySpark Integration Architecture

```
[Data Source] → [PySpark] → [CV Screening SDK] → [Results Storage]
   S3/HDFS/DB     Partition    API Analysis      HDFS/S3/Database
```

#### PySpark Implementation Example

```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, lit
from pyspark.sql.types import StringType
import json
import time
import random
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig

# 1. Spark Configuration
spark = SparkSession.builder \
    .appName("CVScreeningBatch") \
    .config("spark.executor.memory", "8g") \
    .config("spark.driver.memory", "4g") \
    .config("spark.task.maxFailures", "10") \
    .getOrCreate()

# 2. Exponential backoff function to handle API limitations
def with_rate_limit(func):
    def wrapper(*args, **kwargs):
        max_retries = 5
        for attempt in range(max_retries):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if "429" in str(e) and attempt < max_retries - 1:
                    # Exponential backoff with jitter
                    sleep_time = (2 ** attempt) + random.random() * 2
                    time.sleep(sleep_time)
                else:
                    raise
    return wrapper

# 3. Function to get client with shared state
def get_client():
    # Configure client (singleton per executor)
    azure_config = AzureConfig(
        endpoint="https://your-endpoint.openai.azure.com",
        deployment_name="your-deployment",
        tenant_id="your-tenant-id",
        client_id="your-client-id",
        client_secret="your-client-secret"
    )
    client_config = ClientConfig(batch_size=1)  # Individual control, PySpark handles parallelism
    sdk_config = SDKConfig(azure=azure_config, client=client_config)
    return CVScreeningClient(config=sdk_config)

# 4. UDF to process CVs with rate limiting
@with_rate_limit
def process_cv(cv_content, criteria_json):
    """Process an individual CV with rate control"""
    client = get_client()
    criteria = json.loads(criteria_json)
    
    # Add random pause to distribute requests
    time.sleep(random.random() * 0.5)
    
    try:
        result = client.analyze_cv(cv_content, criteria)
        return json.dumps(result.to_dict())
    except Exception as e:
        return json.dumps({"error": str(e), "content_preview": cv_content[:100]})

# Register as Spark UDF
process_cv_udf = udf(process_cv, StringType())

# 5. Job criteria
job_criteria = JobCriteria(
    required_skills=["Python", "SQL"],
    preferred_skills=["Docker", "AWS"],
    min_years_experience=3,
    education_level="bachelors"
).to_dict()

# Convert to JSON to pass to executors
criteria_json = json.dumps(job_criteria)

# 6. Load data (example with CSV)
cv_df = spark.read.csv("hdfs:///path/to/cvs.csv", header=True)

# 7. Distributed processing with parallelism control
# Explicit partitioning to control parallelism based on API limits
num_partitions = 20  # Adjust according to API limits
result_df = cv_df.repartition(num_partitions) \
    .withColumn("analysis_result", process_cv_udf(cv_df["content"], lit(criteria_json)))

# 8. Save results
result_df.write.mode("overwrite").parquet("hdfs:///path/to/results")

# 9. Analyze results (optional)
top_candidates = result_df.filter("analysis_result.error IS NULL") \
    .withColumn("score", get_score_udf("analysis_result")) \
    .orderBy(col("score").desc()) \
    .limit(100)

top_candidates.show()
```

#### PySpark Optimization for Azure OpenAI

To handle API limitations while optimizing performance:

##### 1. Load Distribution Across Multiple Endpoints

```python
# Endpoint pool for load distribution
endpoints = [
    "https://endpoint1.openai.azure.com",
    "https://endpoint2.openai.azure.com",
    "https://endpoint3.openai.azure.com"
]

tenant_ids = ["tenant-id-1", "tenant-id-2", "tenant-id-3"]
client_ids = ["client-id-1", "client-id-2", "client-id-3"]
client_secrets = ["secret-1", "secret-2", "secret-3"]

def get_client_for_partition(partition_id):
    """Select endpoint based on partition ID"""
    endpoint_idx = partition_id % len(endpoints)
    azure_config = AzureConfig(
        endpoint=endpoints[endpoint_idx],
        deployment_name="deployment-name",
        tenant_id=tenant_ids[endpoint_idx],
        client_id=client_ids[endpoint_idx],
        client_secret=client_secrets[endpoint_idx]
    )
    return CVScreeningClient(config=SDKConfig(azure=azure_config))
```

##### 2. Hybrid Processing with Intermediate Queue

```python
# Queue configuration (pseudocode)
from kafka import KafkaProducer, KafkaConsumer

# In Spark job: send to queue instead of processing directly
def send_to_queue(partition):
    producer = KafkaProducer(bootstrap_servers='kafka:9092')
    for record in partition:
        producer.send('cv-processing-queue', 
                     key=record['id'], 
                     value=record['content'])
    producer.flush()
```

## Complete Usage Examples

### Simple Batch Processing Example

```python
from cv_screening_sdk import CVScreeningClient, JobCriteria
import os
import glob

# Initialize client
client = CVScreeningClient()

# Define criteria
criteria = JobCriteria(
    required_skills=["Python", "Data Analysis"],
    preferred_skills=["Pandas", "SQL", "Visualization"],
    min_years_experience=2,
    education_level="bachelors"
)

# Load CVs from a directory
cv_paths = glob.glob("path/to/cvs/*.pdf")
cv_contents = []
for path in cv_paths:
    try:
        content = client.load_cv_content(path)
        cv_contents.append(content)
    except Exception as e:
        print(f"Error loading {path}: {e}")

# Process in batch
result = client.batch_screen_cvs(
    cv_contents=cv_contents,
    criteria=criteria,
    cv_paths=cv_paths
)

# Display statistics
print(f"Processed: {result.total_items} CVs")
print(f"Success rate: {result.success_rate()*100:.1f}%")
print(f"Average score: {result.average_score():.1f}%")
print(f"Processing time: {result.processing_time:.2f} seconds")

# Display top candidates
top_candidates = sorted(
    result.successful_results,
    key=lambda x: x.overall_match,
    reverse=True
)[:3]

for i, candidate in enumerate(top_candidates):
    print(f"\nCandidate #{i+1}: {candidate.cv_path}")
    print(f"Overall score: {candidate.overall_match}%")
    print(f"Skills: {candidate.skills_match.score}%")
    print(f"Experience: {candidate.experience_match.score}%")
    print(f"Profile: {candidate.candidate_profile.current_role}")
```

### Asynchronous Processing Example

```python
import asyncio
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.models.criteria import JobCriteria

async def process_cvs_async():
    # Initialize client
    client = CVScreeningClient()
    
    # Job criteria
    criteria = JobCriteria(
        required_skills=["Java", "Spring Boot"],
        preferred_skills=["Microservices", "Docker", "AWS"],
        min_years_experience=5,
        education_level="masters"
    )
    
    # Load CV content
    cv_files = ["cv1.pdf", "cv2.pdf", "cv3.docx"]
    cv_contents = []
    for file in cv_files:
        cv_contents.append(client.load_cv_content(file))
    
    # Process asynchronously
    tasks = [
        client.screen_cv_async(content, criteria, path) 
        for content, path in zip(cv_contents, cv_files)
    ]
    
    results = await asyncio.gather(*tasks)
    
    # Display results
    for i, result in enumerate(results):
        print(f"CV {i+1}: {result.overall_match}% match")
        print(f"  Skills: {result.skills_match.score}%")
        print(f"  Experience: {result.experience_match.score}%")
        print(f"  Education: {result.education_match.score}%")
        print("  " + "-" * 30)
    
    return results

# Run the async function
if __name__ == "__main__":
    asyncio.run(process_cvs_async())
```

## Production Recommendations

1. **Monitoring**: Implement alerts for rate limit errors ("429 Too Many Requests")
2. **Exponential Backoff**: Add increasing waits when errors occur
3. **Persistence**: Save results incrementally for recovery
4. **Load Distribution**: Consider multiple Azure OpenAI instances
5. **Content Optimization**: Optimize text processing to reduce tokens

## Error Handling

The SDK provides a comprehensive error handling hierarchy:

```python
try:
    result = client.screen_cv(cv_content, criteria)
except DocumentParsingError as e:
    print(f"Failed to parse document: {e}")
except ValidationError as e:
    print(f"Invalid input: {e}")
except LLMError as e:
    print(f"LLM processing error: {e}")
except CVScreeningError as e:
    print(f"General error: {e}")
```

## Security Best Practices

1. **Securing Credentials**
   - Never hardcode credentials in your application code
   - Use environment variables or secure secret management tools
   - Rotate credentials periodically
   - Apply principle of least privilege to service principals

2. **Data Handling**
   - Consider data retention policies for processed CVs
   - Be aware of data privacy regulations (GDPR, CCPA, etc.)
   - Implement appropriate logging levels to avoid leaking sensitive data

## Development

### Linting and Type Checking

The SDK uses black, isort, flake8, and mypy for code quality:

```bash
# Format code
black cv_screening_sdk/ examples/ tests/ scripts/
isort cv_screening_sdk/ examples/ tests/ scripts/

# Lint code
flake8 --max-line-length=88 cv_screening_sdk/ examples/ tests/ scripts/

# Type check
mypy cv_screening_sdk/
```

## Support

For issues and feature requests, please open an issue in the repository.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Procesando Contenido de CV Directamente

Ahora el SDK permite procesar contenido de CV directamente, sin necesidad de pasar rutas a archivos:

```python
from cv_screening_sdk import CVScreeningClient, JobCriteria, CVContent

# Inicializar cliente
client = CVScreeningClient()

# Definir criterios
criteria = JobCriteria(
    required_skills=["python", "machine learning"],
    preferred_skills=["aws", "docker"],
    min_years_experience=3
)

# Método 1: Analizar contenido de texto directamente
cv_text = """
John Doe
Data Scientist

Experience:
- 5 years at XYZ Corp working with Python and Machine Learning
- 2 years at ABC Inc developing cloud solutions with AWS

Education:
- Master's in Computer Science
"""

result = client.screen_cv(cv_text, criteria)
print(f"Match score: {result.match_score}")

# Método 2: Usar el helper para cargar un archivo
cv_path = "path/to/resume.pdf"
cv_content = CVScreeningClient.load_cv_content(cv_path)
result = client.screen_cv(cv_content, criteria, cv_path)

# Método 3: Usar la clase CVContent para metadatos adicionales
cv = CVContent.from_file("path/to/resume.pdf")
print(f"Filename: {cv.metadata['filename']}")
print(f"File size: {cv.metadata['size_bytes']} bytes")
result = client.screen_cv(cv.content, criteria, cv.filepath)

# Procesamiento por lotes con contenido directo
cv_contents = [
    "Resume 1 content here...",
    "Resume 2 content here...",
    "Resume 3 content here..."
]

batch_result = client.batch_screen_cvs(cv_contents, criteria)
print(f"Processed {len(batch_result)} CVs with {batch_result.success_rate():.1%} success rate")
```

### Ventajas de procesar contenido directamente

1. **Flexibilidad**: Permite obtener el contenido de los CVs de cualquier fuente (bases de datos, APIs, etc.)
2. **Control**: Mayor control sobre el proceso de extracción de texto
3. **Rendimiento**: Evita operaciones innecesarias de lectura de archivos cuando ya se tiene el contenido
4. **Integración**: Facilita la integración con otros sistemas que ya manejan el contenido del CV