# CV Screening SDK

A powerful and flexible SDK for automated CV/resume screening and analysis using Azure OpenAI with Service Principal authentication. This SDK helps streamline the recruitment process by automatically evaluating candidates' resumes against job criteria.

## Features

### Core Features
- **Azure OpenAI Integration**: Seamless integration with Azure OpenAI using Service Principal authentication
- **Document Processing**: Support for PDF, TXT, and DOCX formats
- **Flexible Analysis**: Custom job criteria matching and skill assessment

### Processing Capabilities
- **Batch Processing**: Efficient handling of multiple CVs simultaneously
- **Async Support**: Asynchronous processing for improved performance
- **Extensible Design**: Modular LLM adapter interface for future integrations

### Development Features
- **Comprehensive Logging**: Detailed logging support for debugging
- **Error Handling**: Robust error handling and validation
- **Test Coverage**: Extensive unit test coverage
- **Type Safety**: Full type hinting support with mypy validation

## Project Structure

```
cv_screening_sdk/
├── cv_screening_sdk/  # Main package
│   ├── auth/          # Authentication providers
│   ├── core/          # Core interfaces and config
│   ├── models/        # Data models
│   ├── parsers/       # Document parsers 
│   ├── providers/     # LLM providers
│   └── utils/         # Utility functions
├── tests/             # Test files
├── docs/              # Documentation files
├── examples/          # Example usage scripts
├── setup.py           # Package configuration
├── pyproject.toml     # Project configuration
├── requirements.txt   # Project dependencies
└── compile_sdk.sh     # Build script for creating wheel package
```

## Installation

### Using pip with wheel package

```bash
# Build the wheel package
./compile_sdk.sh

# Install from wheel package
pip install dist/cv_screening_sdk-*.whl
```

Required environment variables:
```bash
export AZURE_TENANT_ID="your_tenant_id"
export AZURE_CLIENT_ID="your_client_id"
export AZURE_CLIENT_SECRET="your_client_secret"
```

## Quick Start

Example usage:
```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import ClientConfig, AzureConfig, SDKConfig

# Initialize the client
azure_config = AzureConfig(
    endpoint="your-azure-endpoint",
    deployment_name="your-deployment-name",
    model_name="gpt-4"
)

config = ClientConfig(
    azure=azure_config,
    sdk=SDKConfig(max_batch_size=10)
)

client = CVScreeningClient(config)

# Define screening criteria
criteria = {
    "required_skills": ["Python", "Machine Learning", "AWS"],
    "preferred_skills": ["Docker", "Kubernetes"],
    "min_years_experience": 3,
    "education_level": "bachelors",
    "industry": "Technology"
}

# Screen a single CV
result = client.screen_cv("./resumes/software_engineer_resume.pdf", criteria)

# Process and display results
print(f"Match Score: {result.match_score}")
print(f"Skills Found: {result.skills_found}")
print(f"Experience: {result.years_experience}")
print(f"Education Level: {result.education.level}")

# Batch process multiple CVs
cv_paths = ["cv1.pdf", "cv2.pdf", "cv3.pdf"]
batch_results = client.batch_screen_cvs(cv_paths, criteria)
```

## Documentation

- [API Documentation](API.md)
- [Examples](examples/README.md)
- [Error Handling Guide](docs/error_handling.md)
- [Configuration Guide](docs/configuration.md)

## Advanced Usage

### Using JobCriteria Object

Instead of using a dictionary, you can use the `JobCriteria` class for better type safety and validation:

```python
from cv_screening_sdk import JobCriteria

criteria = JobCriteria(
    required_skills=["Python", "Machine Learning", "AWS"],
    preferred_skills=["Docker", "Kubernetes"],
    min_years_experience=3,
    education_level="bachelors",
    role_title="Senior Software Engineer",
    description="Leading the backend development team",
    industry="Technology"
)

result = client.screen_cv("resume.pdf", criteria)
```

### Asynchronous Processing

For asynchronous CV screening:

```python
import asyncio
from cv_screening_sdk import CVScreeningClient

async def process_cv_async():
    result = await client.screen_cv_async("resume.pdf", criteria)
    return result

# Run the async function
result = asyncio.run(process_cv_async())
```

### Natural Language Criteria

You can also use natural language to describe job criteria:

```python
from cv_screening_sdk import JobCriteria

# Create criteria from a prompt string
prompt = """
Looking for a Senior Software Engineer with at least 3 years of experience in Python 
and Machine Learning. Must have AWS experience. Docker and Kubernetes knowledge would 
be a plus. Bachelor's degree in Computer Science required.
"""

# The SDK will analyze this prompt and convert it to structured criteria
criteria = JobCriteria.from_prompt(prompt, client.llm_provider)
result = client.screen_cv("resume.pdf", criteria)
```

## Additional Usage Examples

For more detailed usage examples, check the `examples/` directory:

- [Basic Usage](examples/basic_usage.py): Simple CV screening with predefined criteria
- [Async Processing](examples/async_processing.py): Asynchronous processing example
- [Batch Processing](examples/batch_processing.py): Processing multiple CVs in batch
- [CV Screening with Custom Prompt](examples/cv_screening_with_prompt.py): Using custom prompts

## Supported Document Formats

The SDK supports the following document formats:
- PDF (.pdf)
- Plain text (.txt)
- Microsoft Word (.docx)

## Error Handling

The SDK provides a comprehensive error handling hierarchy:

```python
try:
    result = client.screen_cv("resume.pdf", criteria)
except DocumentParsingError as e:
    print(f"Failed to parse document: {e}")
except ValidationError as e:
    print(f"Invalid input: {e}")
except LLMError as e:
    print(f"LLM processing error: {e}")
except CVScreeningError as e:
    print(f"General error: {e}")
```

## Development

### Linting and Type Checking

The SDK uses black, isort, flake8, and mypy for code quality:

```bash
# Format code
black cv_screening_sdk/ examples/ tests/ scripts/
isort cv_screening_sdk/ examples/ tests/ scripts/

# Lint code
flake8 --max-line-length=88 cv_screening_sdk/ examples/ tests/ scripts/

# Type check
mypy cv_screening_sdk/
```

## Support

For issues and feature requests, please open an issue in the repository.

## License

This project is licensed under the MIT License - see the LICENSE file for details.