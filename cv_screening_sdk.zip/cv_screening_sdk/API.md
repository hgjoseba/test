# CV Screening SDK API Documentation

## Overview
The CV Screening SDK provides a powerful interface for analyzing and screening CVs/resumes against job criteria using Azure OpenAI. This document details the available API methods and their usage.

## Installation

```bash
# Build the wheel package
python setup.py bdist_wheel

# Install from wheel package (currently not available on PyPI)
pip install dist/cv_screening_sdk-*.whl

# Install with additional dependencies
pip install dist/cv_screening_sdk-*.whl[document_processing]  # For PDF/DOCX support
pip install dist/cv_screening_sdk-*.whl[all]  # All dependencies
```

## Authentication and Configuration

### Service Principal Authentication
The SDK uses Azure Service Principal authentication. You can provide the credentials through environment variables:

```bash
export AZURE_TENANT_ID="your-tenant-id"
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"
export AZURE_OPENAI_ENDPOINT="your-endpoint"
export AZURE_OPENAI_DEPLOYMENT_NAME="your-deployment-name"
```

### Configuration Classes

The SDK uses a structured configuration approach with several configuration classes:

```python
from cv_screening_sdk.core.config import ClientConfig, AzureConfig, SDKConfig

# Azure-specific configuration
azure_config = AzureConfig(
    endpoint="https://your-azure-endpoint.openai.azure.com/",  # Azure OpenAI endpoint
    deployment_name="your-deployment",  # Azure OpenAI deployment name
    model_name="gpt-4",                 # Model to use (default: "gpt-4")
    api_version="2023-05-15",           # API version (default: "2023-05-15")
    tenant_id="your-tenant-id",         # Azure tenant ID for Service Principal auth
    client_id="your-client-id",         # Azure client ID for Service Principal auth
    client_secret="your-client-secret"  # Azure client secret for Service Principal auth
)

# SDK-specific configuration
sdk_config = SDKConfig(
    max_batch_size=10,       # Maximum batch size for concurrent operations
    timeout_seconds=30,      # Timeout for operations in seconds
    retry_attempts=3,        # Number of retry attempts for failed operations
    log_level="INFO"         # Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
)

# Client configuration
config = ClientConfig(
    azure=azure_config,
    sdk=sdk_config
)
```

## Main Classes

### CVScreeningClient

The primary class for interacting with the CV screening functionality.

#### Constructor
```python
def __init__(self, config: Optional[ClientConfig] = None)
```

Initializes a new CV screening client with the specified configuration. If no configuration is provided, it will use environment variables.

#### Methods

##### analyze_cv
```python
def analyze_cv(
    self, 
    content: str, 
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None
) -> CVScreeningResult
```

Analyzes a CV text against specified job criteria.

- **Parameters:**
  - `content`: CV content as text
  - `criteria`: Optional job criteria as dictionary, JobCriteria object, or string prompt
- **Returns:** `CVScreeningResult` object containing the analysis results
- **Exceptions:**
  - `ValidationError`: If input validation fails
  - `LLMError`: If LLM analysis fails

##### analyze_cv_async
```python
async def analyze_cv_async(
    self, 
    content: str, 
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None
) -> CVScreeningResult
```

Asynchronous version of `analyze_cv`.

##### screen_cv
```python
def screen_cv(
    self, 
    cv_content: str, 
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    cv_path: Optional[str] = None
) -> CVScreeningResult
```

Screens a single CV against specified job criteria with the ability to associate a file path.

- **Parameters:**
  - `cv_content`: CV content as text
  - `criteria`: Optional job criteria as dictionary, JobCriteria object, or string prompt
  - `cv_path`: Optional path to the CV file (for reference only)
- **Returns:** `CVScreeningResult` object containing the screening results
- **Exceptions:**
  - `ValidationError`: If input validation fails
  - `LLMError`: If LLM analysis fails

##### screen_cv_async
```python
async def screen_cv_async(
    self, 
    cv_content: str, 
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    cv_path: Optional[str] = None
) -> CVScreeningResult
```

Asynchronous version of `screen_cv`.

##### batch_screen_cvs
```python
def batch_screen_cvs(
    self,
    cv_contents: List[str],
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    cv_paths: Optional[List[str]] = None
) -> BatchProcessingResult
```

Screens multiple CVs in batch mode with parallel processing.

- **Parameters:**
  - `cv_contents`: List of CV contents as text
  - `criteria`: Optional job criteria as dictionary, JobCriteria object, or string prompt
  - `cv_paths`: Optional list of CV file paths (for reference only)
- **Returns:** `BatchProcessingResult` object containing all screening results
- **Exceptions:**
  - `ValidationError`: If input validation fails

##### analyze_cvs_batch
```python
async def analyze_cvs_batch(
    self,
    contents: List[str],
    criteria: Dict[str, Any],
    prompt_system: Optional[str] = None
) -> List[Dict[str, Any]]
```

Processes multiple CVs sequentially using asynchronous calls.

- **Parameters:**
  - `contents`: List of CV contents as text
  - `criteria`: Job criteria as dictionary
  - `prompt_system`: Optional custom system prompt
- **Returns:** List of analysis results as dictionaries
- **Exceptions:**
  - `ProcessingError`: If analysis fails
  
##### load_cv_content
```python
@staticmethod
def load_cv_content(file_path: str) -> str
```

Loads and extracts text from a CV file.

- **Parameters:**
  - `file_path`: Path to the CV file (supports PDF, DOCX, TXT)
- **Returns:** CV content as text
- **Exceptions:**
  - `DocumentParsingError`: If the file cannot be parsed
  - `FileNotFoundError`: If the file doesn't exist

### JobCriteria

Class for defining job requirements for CV screening.

```python
from cv_screening_sdk import JobCriteria

criteria = JobCriteria(
    required_skills=["Python", "AWS", "Machine Learning"],
    preferred_skills=["Docker", "Kubernetes", "CI/CD"],
    min_years_experience=3,
    preferred_years_experience=5,
    education_level="bachelors",  # any, high school, associate, bachelors, masters, phd
    education_field="Computer Science",
    role_title="Data Scientist",
    description="Analyzing large datasets and building ML models",
    industry="Technology"
)
```

#### Methods

##### to_dict
```python
def to_dict(self) -> Dict[str, Any]
```

Converts the criteria to a dictionary.

##### from_dict
```python
@classmethod
def from_dict(cls, data: Dict[str, Any]) -> "JobCriteria"
```

Creates a JobCriteria instance from a dictionary.

##### from_prompt
```python
@classmethod
def from_prompt(cls, prompt: str, llm_provider: LLMProviderBase) -> "JobCriteria"
```

Creates a JobCriteria instance from a natural language prompt using LLM.

### Result Classes

#### CVScreeningResult

Contains the results of a CV screening operation.

```python
# Accessing result properties
result = client.screen_cv("path/to/cv.pdf", criteria)

print(f"Overall Score: {result.overall_score}/100")
print(f"Skills Found: {result.skills_found}")
print(f"Missing Skills: {result.missing_skills}")
print(f"Experience Years: {result.experience_years}")
print(f"Education Level: {result.education_level}")
print(f"Summary: {result.summary}")
```

#### BatchProcessingResult

Contains the results of batch CV screening operations.

```python
# Accessing batch result properties
batch_result = client.batch_screen_cvs(cv_paths, criteria)

print(f"Success Rate: {batch_result.success_rate()}")
print(f"Average Score: {batch_result.average_score()}")
print(f"Successful: {batch_result.success_count}/{batch_result.total_items}")
print(f"Failed: {batch_result.failure_count}/{batch_result.total_items}")

# Access individual results
for result in batch_result.successful_results:
    print(f"CV: {result.cv_id}, Score: {result.overall_score}")

# Access failures
for failure in batch_result.failed_results:
    print(f"Failed: {failure.cv_path} - {failure.error}")
```

## Error Handling

The SDK provides a comprehensive error handling hierarchy:

```python
from cv_screening_sdk.core.exceptions import (
    CVScreeningError,
    DocumentParsingError,
    ValidationError,
    LLMError,
    AuthenticationError,
    ConfigurationError
)

try:
    result = client.screen_cv("path/to/cv.pdf", criteria)
except DocumentParsingError as e:
    print(f"Document error: {e}")
    # Handle document parsing issues
except ValidationError as e:
    print(f"Validation error: {e}")
    # Handle input validation issues
except LLMError as e:
    print(f"LLM error: {e}")
    # Handle LLM-related issues
except AuthenticationError as e:
    print(f"Authentication error: {e}")
    # Handle authentication issues
except ConfigurationError as e:
    print(f"Configuration error: {e}")
    # Handle configuration issues
except CVScreeningError as e:
    print(f"General error: {e}")
    # Handle any other errors
```

## Supported Document Formats

The SDK supports the following document formats:
- PDF (`.pdf`) - Powered by pypdf
- Plain text (`.txt`) - With UTF-8 or Latin-1 encoding
- Microsoft Word (`.docx`) - Requires python-docx package

## Security and Best Practices

1. **Credential Security**
   - Never hardcode credentials in your code
   - Use environment variables or a secure secret manager
   - Rotate credentials periodically
   - Follow least privilege principle for service principals

2. **Error Handling**
   - Always catch and handle potential exceptions
   - Implement proper logging for errors
   - Consider retry mechanisms for transient failures

3. **Performance Optimization**
   - Use batch processing for multiple CVs
   - Consider using async methods for concurrent operations
   - Adjust timeout and retry settings based on your needs

## Usage Examples

For detailed usage examples, please refer to the `examples` directory in the repository:

- [`basic_usage.py`](examples/basic_usage.py): Simple CV screening with predefined criteria
- [`async_processing.py`](examples/async_processing.py): Asynchronous processing
- [`text_processing.py`](examples/text_processing.py): Processing CV as text