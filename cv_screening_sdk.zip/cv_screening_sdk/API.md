# API de CV Screening SDK

Esta documentación proporciona detalles técnicos completos sobre la API pública del CV Screening SDK.

## Clase principal: `CVScreeningClient`

La clase `CVScreeningClient` es el punto de entrada principal para interactuar con el SDK.

### Inicialización

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, SDKConfig

# Usando variables de entorno
client = CVScreeningClient()

# O con configuración explícita
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    tenant_id="tu-tenant-id",
    client_id="tu-client-id",
    client_secret="tu-client-secret",
    ssl_verify=True,
    connection_verify=True,
    connection_timeout=30,
    max_keepalive_connections=5,
    max_connections=10
)

client = CVScreeningClient(config=SDKConfig(azure=azure_config))
```

### Métodos públicos

#### Análisis de texto de CV

```python
def analyze_cv_text(
    self,
    cv_text: str,
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> Dict[str, Any]:
    """
    Analiza el texto de un CV contra criterios de trabajo.
    
    Args:
        cv_text: Texto del CV a analizar.
        job_criteria: Criterios del trabajo como diccionario o texto.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Diccionario con los resultados del análisis.
    """
```

#### Análisis de fichero de CV

```python
def analyze_cv_file(
    self, 
    cv_path: str, 
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> Dict[str, Any]:
    """
    Analiza un archivo de CV contra criterios de trabajo.
    
    Args:
        cv_path: Ruta al archivo del CV.
        job_criteria: Criterios del trabajo como diccionario o texto.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Diccionario con los resultados del análisis.
    """
```

#### Análisis por lotes

```python
def batch_analyze_cv_texts(
    self,
    cv_texts: List[str],
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Analiza una lista de textos de CV en lotes.
    
    Args:
        cv_texts: Lista de textos de CV.
        job_criteria: Criterios del trabajo.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Lista de diccionarios con los resultados del análisis.
    """
```

```python
def batch_analyze_cv_files(
    self,
    cv_paths: List[str],
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Analiza una lista de archivos de CV en lotes.
    
    Args:
        cv_paths: Lista de rutas a archivos de CV.
        job_criteria: Criterios del trabajo.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Lista de diccionarios con los resultados del análisis.
    """
```

#### Métodos asíncronos

```python
async def async_analyze_cv_text(
    self,
    cv_text: str,
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> Dict[str, Any]:
    """
    Analiza el texto de un CV de forma asíncrona.
    
    Args:
        cv_text: Texto del CV a analizar.
        job_criteria: Criterios del trabajo.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Diccionario con los resultados del análisis.
    """
```

```python
async def async_analyze_cv_file(
    self,
    cv_path: str,
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> Dict[str, Any]:
    """
    Analiza un archivo de CV de forma asíncrona.
    
    Args:
        cv_path: Ruta al archivo del CV.
        job_criteria: Criterios del trabajo.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Diccionario con los resultados del análisis.
    """
```

```python
async def async_analyze_cv_texts(
    self,
    cv_texts: List[str],
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Analiza una lista de textos de CV de forma asíncrona.
    
    Args:
        cv_texts: Lista de textos de CV.
        job_criteria: Criterios del trabajo.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Lista de diccionarios con los resultados del análisis.
    """
```

```python
async def async_analyze_cv_files(
    self,
    cv_paths: List[str],
    job_criteria: Union[Dict[str, Any], str],
    *,
    custom_prompt: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Analiza una lista de archivos de CV de forma asíncrona.
    
    Args:
        cv_paths: Lista de rutas a archivos de CV.
        job_criteria: Criterios del trabajo.
        custom_prompt: Prompt personalizado opcional.
        
    Returns:
        Lista de diccionarios con los resultados del análisis.
    """
```

#### Métodos auxiliares

```python
@staticmethod
def load_cv_content(cv_path: str) -> str:
    """
    Carga el contenido de un CV desde un archivo.
    
    Soporta formatos: .txt, .pdf, .docx
    
    Args:
        cv_path: Ruta al archivo del CV.
        
    Returns:
        Contenido del CV como texto.
        
    Raises:
        DocumentParsingError: Si hay un error al leer o analizar el documento.
    """
```

## Clases de configuración

### `AzureConfig`

```python
class AzureConfig:
    """Configuración para Azure OpenAI."""
    
    def __init__(
        self,
        endpoint: str,
        deployment_name: str,
        model_name: str = "gpt-4",
        api_version: str = "2023-05-15",
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        max_tokens: int = 4000,
        temperature: float = 0.7,
        top_p: float = 1.0,
        frequency_penalty: float = 0.0,
        presence_penalty: float = 0.0,
        ssl_verify: bool = True,
        ssl_cert_path: Optional[str] = None,
        connection_verify: bool = True,
        connection_timeout: int = 30,
        max_keepalive_connections: int = 5,
        max_connections: int = 10
    ):
        """
        Inicializa la configuración de Azure.
        
        Args:
            endpoint: URL del endpoint de Azure OpenAI.
            deployment_name: Nombre del despliegue de Azure OpenAI.
            model_name: Nombre del modelo a utilizar (por defecto: "gpt-4").
            api_version: Versión de la API (por defecto: "2023-05-15").
            tenant_id: ID del inquilino de Azure AD.
            client_id: ID del cliente del Service Principal.
            client_secret: Secreto del cliente del Service Principal.
            max_tokens: Máximo de tokens para generar (por defecto: 4000).
            temperature: Temperatura para el muestreo (0-2) (por defecto: 0.7).
            top_p: Muestreo de núcleo (0-1) (por defecto: 1.0).
            frequency_penalty: Penalización por frecuencia (-2 a 2) (por defecto: 0.0).
            presence_penalty: Penalización por presencia (-2 a 2) (por defecto: 0.0).
            ssl_verify: Verificar certificados SSL (por defecto: True).
            ssl_cert_path: Ruta a un certificado SSL personalizado.
            connection_verify: Verificar conexiones SSL en autenticación Azure (por defecto: True).
            connection_timeout: Tiempo de espera de conexión en segundos (por defecto: 30).
            max_keepalive_connections: Máximo de conexiones keepalive (por defecto: 5).
            max_connections: Máximo total de conexiones (por defecto: 10).
        """
```

#### Métodos de `AzureConfig`

```python
@classmethod
def from_env(cls) -> "AzureConfig":
    """
    Crea una instancia de AzureConfig desde variables de entorno.
    
    Returns:
        Instancia de AzureConfig configurada.
        
    Raises:
        ConfigurationError: Si faltan variables requeridas.
    """
```

```python
@classmethod
def from_dict(cls, config_dict: Dict[str, Any]) -> "AzureConfig":
    """
    Crea una instancia de AzureConfig desde un diccionario.
    
    Args:
        config_dict: Diccionario con la configuración.
        
    Returns:
        Instancia de AzureConfig configurada.
    """
```

```python
def to_dict(self) -> Dict[str, Any]:
    """
    Convierte la configuración a un diccionario.
    
    Returns:
        Diccionario con la configuración.
    """
```

```python
def validate(self) -> None:
    """
    Valida que la configuración sea correcta.
    
    Raises:
        ConfigurationError: Si la configuración es inválida.
    """
```

### `ClientConfig`

```python
class ClientConfig:
    """Configuración del cliente del SDK."""
    
    def __init__(
        self,
        timeout: int = 30,
        max_retries: int = 3,
        batch_size: int = 5
    ):
        """
        Inicializa la configuración del cliente.
        
        Args:
            timeout: Tiempo de espera para operaciones en segundos (por defecto: 30).
            max_retries: Número máximo de reintentos para operaciones (por defecto: 3).
            batch_size: Tamaño del lote para procesamiento por lotes (por defecto: 5).
        """
```

### `LogConfig`

```python
class LogConfig:
    """Configuración de registro (logging)."""
    
    def __init__(
        self,
        file_path: str = "logs/cv_screening.log",
        format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level: str = "INFO"
    ):
        """
        Inicializa la configuración de registro.
        
        Args:
            file_path: Ruta al archivo de registro (por defecto: "logs/cv_screening.log").
            format: Formato del mensaje de registro.
            level: Nivel de registro (DEBUG, INFO, WARNING, ERROR, CRITICAL) (por defecto: "INFO").
        """
```

### `SDKConfig`

```python
class SDKConfig:
    """Configuración completa del SDK."""
    
    def __init__(
        self,
        azure: Optional[AzureConfig] = None,
        client: Optional[ClientConfig] = None,
        log: Optional[LogConfig] = None
    ):
        """
        Inicializa la configuración completa del SDK.
        
        Args:
            azure: Configuración de Azure OpenAI.
            client: Configuración del cliente.
            log: Configuración de registro.
        """
```

## Estructura de criterios del trabajo

```python
job_criteria = {
    "job_title": str,                  # Título del puesto
    "required_skills": List[str],      # Habilidades obligatorias
    "preferred_skills": List[str],     # Habilidades preferidas
    "min_years_experience": int,       # Años mínimos de experiencia
    "education_level": str,            # Nivel educativo requerido
    "job_description": Optional[str],  # Descripción del puesto (opcional)
    "industry": Optional[str],         # Industria (opcional)
    "company": Optional[str],          # Nombre de la empresa (opcional)
    "location": Optional[str]          # Ubicación (opcional)
}
```

## Estructura de resultados

```python
result = {
    "candidate_name": str,                 # Nombre del candidato
    "overall_score": float,                # Puntuación global (0-100)
    "required_skills_score": float,        # Puntuación de habilidades obligatorias (0-100)
    "preferred_skills_score": float,       # Puntuación de habilidades preferidas (0-100)
    "experience_score": float,             # Puntuación de experiencia (0-100)
    "education_score": float,              # Puntuación de educación (0-100)
    "summary": str,                        # Resumen del análisis
    "matching_required_skills": List[str], # Habilidades obligatorias encontradas
    "matching_preferred_skills": List[str],# Habilidades preferidas encontradas
    "missing_required_skills": List[str],  # Habilidades obligatorias no encontradas
    "experience_details": str,             # Detalles sobre la experiencia
    "education_details": str,              # Detalles sobre la educación
    "analysis_timestamp": str,             # Marca de tiempo del análisis
    "cv_summary": Optional[str]            # Resumen del CV (si se proporciona)
}
```

## Excepciones

### Jerarquía de excepciones

```
SDKError (base)
├── ConfigurationError
├── AuthenticationError
├── ConnectionError
├── ApiError
└── ProcessingError
```

### `SDKError`

```python
class SDKError(Exception):
    """Excepción base para todos los errores del SDK."""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        """
        Inicializa la excepción.
        
        Args:
            message: Mensaje descriptivo del error.
            details: Detalles adicionales del error.
        """
```

### `ConfigurationError`

```python
class ConfigurationError(SDKError):
    """Error en la configuración del SDK."""
```

### `AuthenticationError`

```python
class AuthenticationError(SDKError):
    """Error en el proceso de autenticación."""
```

### `ConnectionError`

```python
class ConnectionError(SDKError):
    """Error en la conexión con la API de Azure."""
```

### `ApiError`

```python
class ApiError(SDKError):
    """Error en la respuesta de la API."""
    
    def __init__(
        self, 
        message: str, 
        error_code: Optional[str] = None,
        status_code: Optional[int] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Inicializa la excepción.
        
        Args:
            message: Mensaje descriptivo del error.
            error_code: Código de error devuelto por la API.
            status_code: Código de estado HTTP.
            details: Detalles adicionales del error.
        """
```

### `ProcessingError`

```python
class ProcessingError(SDKError):
    """Error en el procesamiento de documentos o datos."""
```