# CV Screening SDK API Documentation

## Overview
The CV Screening SDK provides a powerful interface for analyzing and screening CVs/resumes against job criteria using Azure OpenAI. This document details the available API methods and their usage.

## Installation

```bash
# Install from PyPI (when available)
pip install cv-screening-sdk

# Or install from local wheel
pip install dist/cv_screening_sdk-*.whl
```

## Configuration

### Configuration Classes

The SDK uses a structured configuration approach with several configuration classes:

```python
from cv_screening_sdk.core.config import ClientConfig, AzureConfig, SDKConfig

# Azure-specific configuration
azure_config = AzureConfig(
    endpoint="https://your-azure-endpoint.openai.azure.com/",  # Azure OpenAI endpoint
    deployment_name="your-deployment",  # Azure OpenAI deployment name
    model_name="gpt-4",                 # Model to use (default: "gpt-4")
    api_version="2023-05-15"            # API version (default: "2023-05-15")
)

# SDK-specific configuration
sdk_config = SDKConfig(
    max_batch_size=10,       # Maximum batch size for concurrent operations
    timeout_seconds=30,      # Timeout for operations in seconds
    retry_attempts=3,        # Number of retry attempts for failed operations
    log_level="INFO"         # Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
)

# Client configuration
config = ClientConfig(
    azure=azure_config,
    sdk=sdk_config
)
```

## Authentication

The SDK uses Azure Service Principal authentication through environment variables:

```bash
export AZURE_TENANT_ID="your-tenant-id"
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"
```

## Main Classes

### CVScreeningClient

The primary class for interacting with the CV screening functionality.

#### Constructor
```python
def __init__(self, config: ClientConfig)
```

Initializes a new CV screening client with the specified configuration.

#### Methods

##### screen_cv
```python
def screen_cv(
    self, 
    cv_path: str, 
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None
) -> CVScreeningResult
```

Screens a single CV against specified job criteria.

- **Parameters:**
  - `cv_path`: Path to the CV file
  - `criteria`: Job criteria as a dictionary, JobCriteria object, or string prompt
- **Returns:** `CVScreeningResult` object containing the screening results
- **Exceptions:**
  - `ValidationError`: If input validation fails
  - `DocumentParsingError`: If CV parsing fails
  - `LLMError`: If LLM analysis fails

##### screen_cv_async
```python
async def screen_cv_async(
    self, 
    cv_path: str, 
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None
) -> CVScreeningResult
```

Asynchronous version of `screen_cv`.

##### batch_screen_cvs
```python
def batch_screen_cvs(
    self,
    cv_paths: List[str],
    criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None
) -> BatchProcessingResult
```

Screens multiple CVs in batch mode.

- **Parameters:**
  - `cv_paths`: List of paths to CV files
  - `criteria`: Job criteria as a dictionary, JobCriteria object, or string prompt
- **Returns:** `BatchProcessingResult` object containing all screening results
- **Exceptions:**
  - `ValidationError`: If input validation fails

### JobCriteria

Class for defining job requirements for CV screening.

```python
from cv_screening_sdk import JobCriteria

criteria = JobCriteria(
    required_skills=["Python", "AWS", "Machine Learning"],
    preferred_skills=["Docker", "Kubernetes", "CI/CD"],
    min_years_experience=3,
    preferred_years_experience=5,
    education_level="bachelors",  # any, high school, associate, bachelors, masters, phd
    education_field="Computer Science",
    role_title="Data Scientist",
    description="Analyzing large datasets and building ML models",
    industry="Technology"
)
```

#### Methods

##### to_dict
```python
def to_dict(self) -> Dict[str, Any]
```

Converts the criteria to a dictionary.

##### from_dict
```python
@classmethod
def from_dict(cls, data: Dict[str, Any]) -> "JobCriteria"
```

Creates a JobCriteria instance from a dictionary.

##### from_prompt
```python
@classmethod
def from_prompt(cls, prompt: str, llm_provider: LLMProviderBase) -> "JobCriteria"
```

Creates a JobCriteria instance from a natural language prompt using LLM.

### Result Classes

#### CVScreeningResult

Contains the results of a CV screening operation.

```python
# Accessing result properties
result = client.screen_cv("path/to/cv.pdf", criteria)

print(f"Overall Score: {result.overall_score}/100")
print(f"Skills Found: {result.skills_found}")
print(f"Missing Skills: {result.missing_skills}")
print(f"Experience Years: {result.experience_years}")
print(f"Education Level: {result.education_level}")
print(f"Summary: {result.summary}")
```

#### BatchProcessingResult

Contains the results of batch CV screening operations.

```python
# Accessing batch result properties
batch_result = client.batch_screen_cvs(cv_paths, criteria)

print(f"Success Rate: {batch_result.success_rate()}")
print(f"Average Score: {batch_result.average_score()}")
print(f"Successful: {batch_result.success_count}/{batch_result.total_items}")
print(f"Failed: {batch_result.failure_count}/{batch_result.total_items}")

# Access individual results
for result in batch_result.successful_results:
    print(f"CV: {result.cv_id}, Score: {result.overall_score}")

# Access failures
for failure in batch_result.failed_results:
    print(f"Failed: {failure.cv_path} - {failure.error}")
```

## Supported Document Formats

The SDK supports the following document formats:
- PDF (`.pdf`) - Powered by pypdf
- Plain text (`.txt`) - With UTF-8 or Latin-1 encoding
- Microsoft Word (`.docx`) - Requires python-docx package

## Usage Examples

For detailed usage examples, please refer to the `examples` directory in the repository:

- [`basic_usage.py`](examples/basic_usage.py): Simple CV screening with predefined criteria
- [`batch_processing.py`](examples/batch_processing.py): Processing multiple CVs in batch
- [`async_processing.py`](examples/async_processing.py): Asynchronous processing
- [`cv_screening_with_prompt.py`](examples/cv_screening_with_prompt.py): Using natural language prompts