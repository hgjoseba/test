"""
Main client for CV screening operations.

This module provides the main entry point for the CV Screening SDK, handling
CV parsing, analysis, and result processing.
"""

import asyncio
import logging
import os
import time
from typing import Any, Dict, List, Optional, Tuple, Union

from .auth.azure import AzureAuthProvider
from .core.config import ClientConfig
from .core.exceptions import ValidationError
from .models.criteria import JobCriteria
from .models.results import BatchProcessingResult, CVScreeningResult, ProcessingFailure
from .parsers.document import DocumentParser
from .providers.azure import AzureProvider
from .utils.logging import setup_logging
from .utils.validation import validate_criteria, validate_file_path

logger = logging.getLogger(__name__)


class CVScreeningClient:
    """
    Main client for CV screening operations.

    This client orchestrates the CV screening process, handling document
    parsing, LLM analysis, and result processing.
    """

    def __init__(self, config: ClientConfig):
        """
        Initialize the CV Screening client.

        Args:
            config: Client configuration settings

        Raises:
            ConfigurationError: If configuration is invalid
        """
        self.config = config

        # Setup logging
        setup_logging(config.sdk.log_level)
        self.logger = logging.getLogger(__name__)

        # Initialize components
        self.auth_provider = AzureAuthProvider(
            tenant_id=os.getenv("AZURE_TENANT_ID"),
            client_id=os.getenv("AZURE_CLIENT_ID"),
            client_secret=os.getenv("AZURE_CLIENT_SECRET"),
            logger=self.logger,
        )

        self.llm_provider = AzureProvider(
            api_version=config.azure.api_version,
            endpoint=config.azure.endpoint,
            deployment=config.azure.deployment_name,
            tenant_id=os.getenv("AZURE_TENANT_ID"),
            client_id=os.getenv("AZURE_CLIENT_ID"),
            client_secret=os.getenv("AZURE_CLIENT_SECRET"),
            logger=self.logger,
        )

        self.document_parser = DocumentParser(logger=self.logger)

        self.logger.info("CV Screening client initialized")

    def screen_cv(
        self,
        cv_path: str,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> CVScreeningResult:
        """
        Screen a single CV against given criteria.

        Args:
            cv_path: Path to the CV file
            criteria: Optional job criteria as dictionary, JobCriteria object,
                or prompt string

        Returns:
            CVScreeningResult object containing the analysis

        Raises:
            ValidationError: If the file path or criteria are invalid
            DocumentParsingError: If the CV cannot be parsed
            LLMError: If the analysis fails

        Example:
            ```python
            # Using JobCriteria
            criteria = JobCriteria(
                required_skills=["python", "aws"],
                preferred_skills=["docker", "kubernetes"],
                min_years_experience=3,
                education_level="bachelors"
            )
            result = client.screen_cv("path/to/cv.pdf", criteria)

            # Using dictionary
            criteria = {
                "required_skills": ["python", "aws"],
                "preferred_skills": ["docker", "kubernetes"],
                "min_years_experience": 3,
                "education_level": "bachelors"
            }
            result = client.screen_cv("path/to/cv.pdf", criteria)
            ```
        """
        self.logger.info(f"Starting CV screening for: {cv_path}")

        # Process and validate criteria
        criteria_dict = self._process_criteria(criteria)

        # Validate inputs
        validate_file_path(cv_path)

        try:
            # Parse document
            content = self.document_parser.parse(cv_path)

            # Analyze with LLM
            result = self.llm_provider.analyze_cv(content, criteria_dict)

            # Create result object
            screening_result = CVScreeningResult.from_llm_response(result, cv_path)

            self.logger.info(f"CV screening completed for: {cv_path}")
            return screening_result

        except Exception as e:
            self.logger.error(f"Failed to screen CV {cv_path}: {str(e)}")
            raise

    async def screen_cv_async(
        self,
        cv_path: str,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> CVScreeningResult:
        """
        Screen a single CV asynchronously.

        Args:
            cv_path: Path to the CV file
            criteria: Optional job criteria

        Returns:
            CVScreeningResult containing the analysis

        Raises:
            ValidationError: If the file path or criteria are invalid
            DocumentParsingError: If the CV cannot be parsed
            LLMError: If the analysis fails
        """
        self.logger.info(f"Starting async CV screening for: {cv_path}")

        # Process and validate criteria
        criteria_dict = self._process_criteria(criteria)

        # Validate inputs
        validate_file_path(cv_path)

        try:
            # Parse document asynchronously
            content = await self.document_parser.parse_async(cv_path)

            # Analyze with LLM asynchronously
            result = await self.llm_provider.analyze_cv_async(content, criteria_dict)

            # Create result object
            screening_result = CVScreeningResult.from_llm_response(result, cv_path)

            self.logger.info(f"Async CV screening completed for: {cv_path}")
            return screening_result

        except Exception as e:
            self.logger.error(
                f"Failed to screen CV asynchronously {cv_path}: {
                    str(e)}"
            )
            raise

    def batch_screen_cvs(
        self,
        cv_paths: List[str],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> BatchProcessingResult:
        """
        Screen multiple CVs in batch mode.

        Args:
            cv_paths: List of paths to CV files
            criteria: Optional screening criteria

        Returns:
            BatchProcessingResult containing all screening results

        Raises:
            ValidationError: If criteria are invalid
        """
        self.logger.info(f"Starting batch screening of {len(cv_paths)} CVs")

        # Process criteria only once for the entire batch
        criteria_dict = self._process_criteria(criteria)

        # Use asyncio to run the async implementation
        start_time = time.time()
        result = asyncio.run(self._batch_screen_cvs_async(cv_paths, criteria_dict))
        processing_time = time.time() - start_time

        # Add processing time to result
        result.processing_time = processing_time

        self.logger.info(
            f"Batch screening completed in {processing_time:.2f}s. "
            f"Success rate: {result.success_rate():.1%}"
        )
        return result

    async def _batch_screen_cvs_async(
        self, cv_paths: List[str], criteria: Optional[Dict[str, Any]] = None
    ) -> BatchProcessingResult:
        """
        Internal async implementation of batch CV screening.

        Args:
            cv_paths: List of paths to CV files
            criteria: Optional screening criteria dictionary

        Returns:
            BatchProcessingResult with successful and failed results
        """
        # Create tasks for each batch of CVs
        tasks = []
        for i in range(0, len(cv_paths), self.config.sdk.max_batch_size):
            batch = cv_paths[i : i + self.config.sdk.max_batch_size]
            batch_tasks = [self._process_cv_safe(path, criteria) for path in batch]
            tasks.extend(batch_tasks)

        # Execute all tasks concurrently
        results = await asyncio.gather(*tasks)

        # Separate successful and failed results
        successful_results = []
        failed_results = []

        for result, cv_path in results:
            if isinstance(result, Exception):
                failed_results.append(
                    ProcessingFailure(cv_path=cv_path, error=str(result))
                )
            else:
                successful_results.append(result)

        return BatchProcessingResult(
            successful_results=successful_results, failed_results=failed_results
        )

    async def _process_cv_safe(
        self, cv_path: str, criteria: Optional[Dict[str, Any]]
    ) -> Tuple[Union[CVScreeningResult, Exception], str]:
        """
        Process a single CV with error handling.

        Args:
            cv_path: Path to the CV file
            criteria: Optional screening criteria

        Returns:
            Tuple of (result or exception, cv_path)
        """
        try:
            result = await self.screen_cv_async(cv_path, criteria)
            return result, cv_path
        except Exception as e:
            self.logger.error(f"Error processing {cv_path}: {str(e)}")
            return e, cv_path

    def _process_criteria(
        self, criteria: Optional[Union[Dict[str, Any], JobCriteria, str]]
    ) -> Optional[Dict[str, Any]]:
        """
        Process and validate criteria input.

        Args:
            criteria: Input criteria in various formats

        Returns:
            Criteria as dictionary or None

        Raises:
            ValidationError: If criteria format is invalid
        """
        if criteria is None:
            return None

        # Convert string prompt to JobCriteria if needed
        if isinstance(criteria, str):
            criteria = JobCriteria.from_prompt(criteria, self.llm_provider)

        # Convert JobCriteria to dictionary if needed
        if isinstance(criteria, JobCriteria):
            criteria_dict = criteria.to_dict()
        elif isinstance(criteria, dict):
            criteria_dict = criteria
        else:
            raise ValidationError(
                f"Invalid criteria type: {type(criteria)}. "
                "Expected dictionary, JobCriteria object, or string."
            )

        # Validate criteria
        validate_criteria(criteria_dict)

        return criteria_dict
