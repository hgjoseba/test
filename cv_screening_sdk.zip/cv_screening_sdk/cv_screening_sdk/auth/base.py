"""
Base authentication provider for CV Screening SDK.

This module defines the base authentication provider interface that all
authentication providers must implement.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

from ..core.exceptions import AuthenticationError


class AuthProvider(ABC):
    """Base class for authentication providers."""

    @abstractmethod
    def get_credentials(self) -> Any:
        """Get credentials for authentication.

        Returns:
            Any: The credentials object specific to the provider.

        Raises:
            AuthenticationError: If authentication fails.
        """
        raise NotImplementedError

    async def get_credentials_async(self) -> Any:
        """Get authentication credentials asynchronously.
        
        Esta versión sin aiohttp simplemente usa la versión síncrona.

        Returns:
            Authentication credentials

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        # Simplemente usamos la versión síncrona
        return self.get_credentials()

    @abstractmethod
    def validate_credentials(self) -> bool:
        """Validate the current credentials.

        Returns:
            bool: True if credentials are valid, False otherwise.

        Raises:
            AuthenticationError: If validation fails.
        """
        raise NotImplementedError

    @abstractmethod
    def refresh_credentials(self) -> None:
        """Refresh the current credentials.

        Raises:
            AuthenticationError: If refresh fails.
        """
        raise NotImplementedError 