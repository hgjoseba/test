"""
Core functionality for CV Screening SDK.

This module provides core components like configuration and exceptions.
"""

from .config import AzureConfig, ClientConfig, SDKConfig
from .exceptions import (
    AuthenticationError,
    ConfigurationError,
    ProcessingError,
    SDKError,
)

__all__ = [
    "AzureConfig",
    "ClientConfig",
    "SDKConfig",
    "SDKError",
    "AuthenticationError",
    "ConfigurationError",
    "ProcessingError",
] 