"""
Exceptions for CV Screening SDK.

This module provides custom exceptions for the CV Screening SDK to enable
clear error messages and better error handling capabilities.
"""

from typing import Optional, Dict, Any


class SDKError(Exception):
    """Base exception class for CV Screening SDK."""

    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None) -> None:
        """Initialize error.

        Args:
            message: Error message
            details: Optional error details
        """
        super().__init__(message)
        self.message = message
        self.details = details

    def __str__(self) -> str:
        """Return string representation."""
        return self.message


class ValidationError(SDKError):
    """Validation error."""


class ProcessingError(SDKError):
    """Processing error."""


class LLMError(SDKError):
    """LLM operation error."""


class ProviderError(SDKError):
    """Provider error."""


class ConfigurationError(SDKError):
    """Configuration error."""


class AuthenticationError(SDKError):
    """Authentication error."""


class DocumentParsingError(SDKError):
    """Failed to parse document."""


class RateLimitError(SDKError):
    """Rate limit exceeded."""


class TimeoutError(SDKError):
    """Operation timed out."""


class InputError(SDKError):
    """Invalid input provided."""


class APIError(SDKError):
    """Error from external API."""
