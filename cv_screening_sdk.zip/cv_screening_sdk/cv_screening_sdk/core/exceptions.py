"""
Exceptions for the CV Screening SDK.

This module defines a comprehensive exception hierarchy for the SDK to provide
clear error messages and better error handling capabilities.
"""


class CVScreeningError(Exception):
    """Base exception for all CV Screening SDK errors."""


class ConfigurationError(CVScreeningError):
    """Error in configuration parameters."""


class AuthenticationError(CVScreeningError):
    """Authentication failed or invalid credentials."""


class DocumentParsingError(CVScreeningError):
    """Failed to parse document."""


class LLMError(CVScreeningError):
    """Error from LLM provider."""


class ValidationError(CVScreeningError):
    """Data validation error."""


class RateLimitError(CVScreeningError):
    """Rate limit exceeded."""


class TimeoutError(CVScreeningError):
    """Operation timed out."""


class InputError(CVScreeningError):
    """Invalid input provided."""


class APIError(CVScreeningError):
    """Error from external API."""


class ProviderError(CVScreeningError):
    """Error in provider operations."""
