"""
Configuration management for the CV Screening SDK.

This module provides configuration classes for the CV Screening SDK with
validation, environment variable support, and sensible defaults.
"""

import os
from dataclasses import dataclass, field
from typing import Any, ClassVar, Dict, Optional

from .exceptions import ConfigurationError


@dataclass
class LogConfig:
    """
    Logging configuration.

    Attributes:
        file_path: Path to log file
        format: Log message format
        level: Logging level
    """

    file_path: str = "logs/cv_screening.log"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    level: str = "INFO"

    ENV_VARS: ClassVar[Dict[str, str]] = {
        "file_path": "CV_SCREENING_LOG_FILE",
        "format": "CV_SCREENING_LOG_FORMAT",
        "level": "CV_SCREENING_LOG_LEVEL",
    }

    def __post_init__(self) -> None:
        """Validate configuration and apply environment variables."""
        # Apply environment variables if present
        for attr, env_var in self.ENV_VARS.items():
            if env_var in os.environ:
                setattr(self, attr, os.environ[env_var])

        # Validate configuration
        self._validate()

    def _validate(self) -> None:
        """Validate configuration values."""
        if not self.file_path:
            raise ConfigurationError("file_path must be provided")
        if not self.format:
            raise ConfigurationError("format must be provided")
        if not self.level:
            raise ConfigurationError("level must be provided")
        if self.level not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            raise ConfigurationError("level must be one of: DEBUG, INFO, WARNING, ERROR, CRITICAL")

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "file_path": self.file_path,
            "format": self.format,
            "level": self.level,
        }

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "LogConfig":
        """Create a LogConfig from a dictionary."""
        return cls(**config_dict)


@dataclass
class ClientConfig:
    """
    Client configuration.

    Attributes:
        timeout: Operation timeout in seconds
        max_retries: Maximum number of retry attempts
        batch_size: Size of batches for processing
    """

    timeout: int = 30
    max_retries: int = 3
    batch_size: int = 5

    ENV_VARS: ClassVar[Dict[str, str]] = {
        "timeout": "CV_SCREENING_CLIENT_TIMEOUT",
        "max_retries": "CV_SCREENING_CLIENT_MAX_RETRIES",
        "batch_size": "CV_SCREENING_CLIENT_BATCH_SIZE",
    }

    def __post_init__(self) -> None:
        """Validate configuration and apply environment variables."""
        # Apply environment variables if present
        for attr, env_var in self.ENV_VARS.items():
            if env_var in os.environ:
                setattr(self, attr, self._convert_type(attr, os.environ[env_var]))

        # Validate configuration
        self._validate()

    def _validate(self) -> None:
        """Validate configuration values."""
        if self.timeout <= 0:
            raise ConfigurationError("timeout must be positive")
        if self.max_retries < 0:
            raise ConfigurationError("max_retries must be non-negative")
        if self.batch_size <= 0:
            raise ConfigurationError("batch_size must be positive")

    def _convert_type(self, attr: str, value: str) -> Any:
        """Convert string value to appropriate type based on attribute."""
        try:
            return int(value)
        except ValueError:
            raise ConfigurationError(f"{attr} must be an integer")

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "batch_size": self.batch_size,
        }

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "ClientConfig":
        """Create a ClientConfig from a dictionary."""
        return cls(**config_dict)


@dataclass
class AzureConfig:
    """
    Azure OpenAI configuration.

    Attributes:
        endpoint: Azure OpenAI endpoint URL
        deployment_name: Azure OpenAI deployment name
        model_name: Model name to use
        api_version: Azure OpenAI API version
        tenant_id: Optional Azure tenant ID for Service Principal authentication
        client_id: Optional Azure client ID for Service Principal authentication
        client_secret: Optional Azure client secret for Service Principal authentication
        max_tokens: Maximum number of tokens to generate
        temperature: Sampling temperature
        top_p: Nucleus sampling
        frequency_penalty: Frequency penalty
        presence_penalty: Presence penalty
        ssl_verify: Whether to verify SSL certificates
        ssl_cert_path: Optional path to a custom SSL certificate
        connection_verify: Whether to verify the connection
        connection_timeout: Connection timeout in seconds
        max_keepalive_connections: Maximum number of keepalive connections
        max_connections: Maximum number of connections
    """

    endpoint: str
    deployment_name: str
    model_name: str = "gpt-4"
    api_version: str = "2023-05-15"
    tenant_id: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    max_tokens: int = 4000
    temperature: float = 0.7
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    ssl_verify: bool = True
    ssl_cert_path: Optional[str] = None
    connection_verify: bool = True
    connection_timeout: int = 30
    max_keepalive_connections: int = 5
    max_connections: int = 10

    ENV_VARS: ClassVar[Dict[str, str]] = {
        "endpoint": "AZURE_OPENAI_ENDPOINT",
        "deployment_name": "AZURE_OPENAI_DEPLOYMENT_NAME",
        "model_name": "AZURE_OPENAI_MODEL_NAME",
        "api_version": "AZURE_OPENAI_API_VERSION",
        "tenant_id": "AZURE_TENANT_ID",
        "client_id": "AZURE_CLIENT_ID",
        "client_secret": "AZURE_CLIENT_SECRET",
        "max_tokens": "AZURE_OPENAI_MAX_TOKENS",
        "temperature": "AZURE_OPENAI_TEMPERATURE",
        "top_p": "AZURE_OPENAI_TOP_P",
        "frequency_penalty": "AZURE_OPENAI_FREQUENCY_PENALTY",
        "presence_penalty": "AZURE_OPENAI_PRESENCE_PENALTY",
        "ssl_verify": "AZURE_OPENAI_SSL_VERIFY",
        "ssl_cert_path": "AZURE_OPENAI_SSL_CERT_PATH",
        "connection_verify": "AZURE_OPENAI_CONNECTION_VERIFY",
        "connection_timeout": "AZURE_OPENAI_CONNECTION_TIMEOUT",
        "max_keepalive_connections": "AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS",
        "max_connections": "AZURE_OPENAI_MAX_CONNECTIONS",
    }

    def __post_init__(self) -> None:
        """Validate configuration and apply environment variables."""
        # Apply environment variables if present
        for attr, env_var in self.ENV_VARS.items():
            if env_var in os.environ:
                setattr(self, attr, self._convert_type(attr, os.environ[env_var]))

        # Validate configuration
        self._validate()

    def _validate(self) -> None:
        """Validate configuration values."""
        if not self.endpoint:
            raise ConfigurationError("endpoint must be provided")
        if not self.deployment_name:
            raise ConfigurationError("deployment_name must be provided")
        if not self.model_name:
            raise ConfigurationError("model_name must be provided")
        if not self.api_version:
            raise ConfigurationError("api_version must be provided")
        
        # Validate numeric ranges
        if self.max_tokens <= 0:
            raise ConfigurationError("max_tokens must be positive")
        if not 0 <= self.temperature <= 2:
            raise ConfigurationError("temperature must be between 0 and 2")
        if not 0 <= self.top_p <= 1:
            raise ConfigurationError("top_p must be between 0 and 1")
        if not -2 <= self.frequency_penalty <= 2:
            raise ConfigurationError("frequency_penalty must be between -2 and 2")
        if not -2 <= self.presence_penalty <= 2:
            raise ConfigurationError("presence_penalty must be between -2 and 2")

        # Validate URL format
        if not self.endpoint.startswith(("http://", "https://")):
            raise ConfigurationError("endpoint must be a valid URL starting with http:// or https://")

        # Validate Service Principal credentials if provided
        if any([self.tenant_id, self.client_id, self.client_secret]):
            if not all([self.tenant_id, self.client_id, self.client_secret]):
                raise ConfigurationError(
                    "If using Service Principal authentication, all credentials (tenant_id, client_id, client_secret) must be provided"
                )

        # Validate SSL certificate path
        if self.ssl_cert_path and not os.path.exists(self.ssl_cert_path):
            raise ConfigurationError(f"SSL certificate path does not exist: {self.ssl_cert_path}")

        # Validate connection parameters
        if self.connection_timeout < 1:
            raise ConfigurationError("connection_timeout must be positive")
        if self.max_keepalive_connections < 1:
            raise ConfigurationError("max_keepalive_connections must be positive")
        if self.max_connections < 1:
            raise ConfigurationError("max_connections must be positive")
        if self.max_keepalive_connections > self.max_connections:
            raise ConfigurationError("max_keepalive_connections cannot be greater than max_connections")

    def _convert_type(self, attr: str, value: str) -> Any:
        """Convert string value to appropriate type based on attribute."""
        try:
            if attr in ["max_tokens"]:
                return int(value)
            elif attr in ["temperature", "top_p", "frequency_penalty", "presence_penalty"]:
                return float(value)
            elif attr in ["ssl_verify"]:
                return value.lower() in ["true", "1", "yes", "y"]
            return value
        except ValueError:
            raise ConfigurationError(f"{attr} has invalid type")

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "endpoint": self.endpoint,
            "deployment_name": self.deployment_name,
            "model_name": self.model_name,
            "api_version": self.api_version,
            "tenant_id": self.tenant_id,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
            "ssl_verify": self.ssl_verify,
            "ssl_cert_path": self.ssl_cert_path,
            "connection_verify": self.connection_verify,
            "connection_timeout": self.connection_timeout,
            "max_keepalive_connections": self.max_keepalive_connections,
            "max_connections": self.max_connections,
        }

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "AzureConfig":
        """Create an AzureConfig from a dictionary."""
        return cls(**config_dict)

    @classmethod
    def from_env(cls) -> "AzureConfig":
        """Create an AzureConfig from environment variables."""
        config_dict = {}
        for attr, env_var in cls.ENV_VARS.items():
            if env_var in os.environ:
                config_dict[attr] = os.environ[env_var]
        return cls(**config_dict)


@dataclass
class SDKConfig:
    """
    SDK configuration.

    Attributes:
        azure: Azure-specific configuration
        client: Client configuration
        log: Logging configuration
    """

    azure: AzureConfig = field(default_factory=lambda: AzureConfig(
        endpoint="https://test.openai.azure.com/",
        deployment_name="test-deployment",
    ))
    client: ClientConfig = field(default_factory=ClientConfig)
    log: LogConfig = field(default_factory=LogConfig)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "SDKConfig":
        """
        Create an SDKConfig from a dictionary.

        Args:
            config_dict: Dictionary containing configuration values

        Returns:
            Instantiated SDKConfig object

        Raises:
            ConfigurationError: If required values are missing or invalid
        """
        try:
            # Extract Azure config
            azure_config = AzureConfig(**config_dict.get("azure", {}))

            # Extract client config
            client_config = ClientConfig(**config_dict.get("client", {}))

            # Extract logging config
            log_config = LogConfig(**config_dict.get("log", {}))

            return cls(azure=azure_config, client=client_config, log=log_config)
        except (TypeError, ValueError) as e:
            raise ConfigurationError(f"Invalid configuration: {str(e)}")

    def __post_init__(self) -> None:
        """Validate configuration."""
        self._validate()

    def _validate(self) -> None:
        """Validate configuration values."""
        if not isinstance(self.azure, AzureConfig):
            raise ConfigurationError("azure must be an instance of AzureConfig")
        if not isinstance(self.client, ClientConfig):
            raise ConfigurationError("client must be an instance of ClientConfig")
        if not isinstance(self.log, LogConfig):
            raise ConfigurationError("log must be an instance of LogConfig")

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "azure": {
                "endpoint": self.azure.endpoint,
                "deployment_name": self.azure.deployment_name,
                "model_name": self.azure.model_name,
                "api_version": self.azure.api_version,
                "tenant_id": self.azure.tenant_id,
                "client_id": self.azure.client_id,
                "client_secret": self.azure.client_secret,
                "max_tokens": self.azure.max_tokens,
                "temperature": self.azure.temperature,
                "top_p": self.azure.top_p,
                "frequency_penalty": self.azure.frequency_penalty,
                "presence_penalty": self.azure.presence_penalty,
                "ssl_verify": self.azure.ssl_verify,
                "ssl_cert_path": self.azure.ssl_cert_path,
                "connection_verify": self.azure.connection_verify,
                "connection_timeout": self.azure.connection_timeout,
                "max_keepalive_connections": self.azure.max_keepalive_connections,
                "max_connections": self.azure.max_connections,
            },
            "client": {
                "timeout": self.client.timeout,
                "max_retries": self.client.max_retries,
                "batch_size": self.client.batch_size,
            },
            "log": {
                "file_path": self.log.file_path,
                "format": self.log.format,
                "level": self.log.level,
            },
        }
