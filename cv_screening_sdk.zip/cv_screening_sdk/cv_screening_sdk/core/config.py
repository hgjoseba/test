"""
Configuration management for the CV Screening SDK.

This module provides configuration classes for the CV Screening SDK with
validation, environment variable support, and sensible defaults.
"""

import os
from dataclasses import dataclass, field
from typing import Any, ClassVar, Dict, Optional

from ..core.exceptions import ConfigurationError


@dataclass
class SDKConfig:
    """
    Global SDK configuration.

    Attributes:
        max_batch_size: Maximum number of CVs to process in a single batch
        timeout_seconds: Timeout for operations in seconds
        retry_attempts: Number of retry attempts for failed operations
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """

    max_batch_size: int = 10
    timeout_seconds: int = 30
    retry_attempts: int = 3
    log_level: str = "INFO"

    ENV_VARS: ClassVar[Dict[str, str]] = {
        "max_batch_size": "CV_SCREENING_MAX_BATCH_SIZE",
        "timeout_seconds": "CV_SCREENING_TIMEOUT",
        "retry_attempts": "CV_SCREENING_RETRY_ATTEMPTS",
        "log_level": "CV_SCREENING_LOG_LEVEL",
    }

    def __post_init__(self) -> None:
        """Validate configuration and apply environment variables."""
        # Apply environment variables if present
        for attr, env_var in self.ENV_VARS.items():
            if env_var in os.environ:
                setattr(self, attr, self._convert_type(attr, os.environ[env_var]))

        # Validate configuration
        self._validate()

    def _validate(self) -> None:
        """Validate configuration values."""
        if self.max_batch_size <= 0:
            raise ConfigurationError("max_batch_size must be positive")
        if self.timeout_seconds <= 0:
            raise ConfigurationError("timeout_seconds must be positive")
        if self.retry_attempts < 0:
            raise ConfigurationError("retry_attempts must be non-negative")
        if self.log_level not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            raise ConfigurationError(
                "log_level must be one of: DEBUG, INFO, WARNING, ERROR, CRITICAL"
            )

    def _convert_type(self, attr: str, value: str) -> Any:
        """Convert string value to appropriate type based on attribute."""
        if attr in ["max_batch_size", "timeout_seconds", "retry_attempts"]:
            try:
                return int(value)
            except ValueError:
                raise ConfigurationError(f"{attr} must be an integer")
        return value


@dataclass
class AzureConfig:
    """
    Azure-specific configuration.

    Attributes:
        endpoint: Azure OpenAI endpoint URL
        deployment_name: Azure OpenAI deployment name
        model_name: Model name (e.g., "gpt-4")
        api_version: Azure OpenAI API version
        tenant_id: Azure AD tenant ID
        client_id: Azure AD client ID
        client_secret: Azure AD client secret
        max_tokens: Maximum tokens for completions
        temperature: Temperature for model sampling
        top_p: Top-p sampling parameter
        frequency_penalty: Frequency penalty for completions
        presence_penalty: Presence penalty for completions
    """

    endpoint: str
    deployment_name: str
    model_name: str = "gpt-4"
    api_version: str = "2023-05-15"
    tenant_id: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    max_tokens: int = 4000
    temperature: float = 0.7
    top_p: float = 1.0
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0

    ENV_VARS: ClassVar[Dict[str, str]] = {
        "endpoint": "AZURE_OPENAI_ENDPOINT",
        "deployment_name": "AZURE_OPENAI_DEPLOYMENT_NAME",
        "model_name": "AZURE_OPENAI_MODEL_NAME",
        "api_version": "AZURE_OPENAI_API_VERSION",
        "tenant_id": "AZURE_TENANT_ID",
        "client_id": "AZURE_CLIENT_ID",
        "client_secret": "AZURE_CLIENT_SECRET",
        "max_tokens": "AZURE_OPENAI_MAX_TOKENS",
        "temperature": "AZURE_OPENAI_TEMPERATURE",
        "top_p": "AZURE_OPENAI_TOP_P",
        "frequency_penalty": "AZURE_OPENAI_FREQUENCY_PENALTY",
        "presence_penalty": "AZURE_OPENAI_PRESENCE_PENALTY",
    }

    def __post_init__(self) -> None:
        """Validate configuration and apply environment variables."""
        # Apply environment variables if present
        for attr, env_var in self.ENV_VARS.items():
            if env_var in os.environ:
                setattr(self, attr, self._convert_type(attr, os.environ[env_var]))

        # Validate configuration
        self._validate()

    def _validate(self) -> None:
        """Validate configuration values."""
        if not self.endpoint:
            raise ConfigurationError("endpoint must be provided")
        if not self.deployment_name:
            raise ConfigurationError("deployment_name must be provided")
        if not self.model_name:
            raise ConfigurationError("model_name must be provided")
        if not self.api_version:
            raise ConfigurationError("api_version must be provided")
        
        # Validate numeric ranges
        if self.max_tokens <= 0:
            raise ConfigurationError("max_tokens must be positive")
        if not 0 <= self.temperature <= 2:
            raise ConfigurationError("temperature must be between 0 and 2")
        if not 0 <= self.top_p <= 1:
            raise ConfigurationError("top_p must be between 0 and 1")
        if not -2 <= self.frequency_penalty <= 2:
            raise ConfigurationError("frequency_penalty must be between -2 and 2")
        if not -2 <= self.presence_penalty <= 2:
            raise ConfigurationError("presence_penalty must be between -2 and 2")

        # Validate URL format
        if not self.endpoint.startswith(("http://", "https://")):
            raise ConfigurationError("endpoint must be a valid URL starting with http:// or https://")

        # Validate Service Principal credentials if provided
        if any([self.tenant_id, self.client_id, self.client_secret]):
            if not all([self.tenant_id, self.client_id, self.client_secret]):
                raise ConfigurationError(
                    "If using Service Principal authentication, all credentials (tenant_id, client_id, client_secret) must be provided"
                )

    def _convert_type(self, attr: str, value: str) -> Any:
        """Convert string value to appropriate type based on attribute."""
        if attr in ["max_tokens"]:
            try:
                return int(value)
            except ValueError:
                raise ConfigurationError(f"{attr} must be an integer")
        elif attr in ["temperature", "top_p", "frequency_penalty", "presence_penalty"]:
            try:
                return float(value)
            except ValueError:
                raise ConfigurationError(f"{attr} must be a number")
        return value

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "endpoint": self.endpoint,
            "deployment_name": self.deployment_name,
            "model_name": self.model_name,
            "api_version": self.api_version,
            "tenant_id": self.tenant_id,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
        }

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "AzureConfig":
        """Create an AzureConfig from a dictionary."""
        return cls(**config_dict)


@dataclass
class ClientConfig:
    """
    Client configuration combining all settings.

    Attributes:
        azure: Azure-specific configuration
        sdk: Global SDK configuration
    """

    azure: AzureConfig
    sdk: SDKConfig = field(default_factory=SDKConfig)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "ClientConfig":
        """
        Create a ClientConfig from a dictionary.

        Args:
            config_dict: Dictionary containing configuration values

        Returns:
            Instantiated ClientConfig object

        Raises:
            ConfigurationError: If required values are missing or invalid
        """
        try:
            # Extract Azure config
            azure_dict = config_dict.get("azure", {})
            azure_config = AzureConfig(
                endpoint=azure_dict.get("endpoint", ""),
                deployment_name=azure_dict.get("deployment_name", ""),
                model_name=azure_dict.get("model_name", "gpt-4"),
                api_version=azure_dict.get("api_version", "2023-05-15"),
                tenant_id=azure_dict.get("tenant_id", None),
                client_id=azure_dict.get("client_id", None),
                client_secret=azure_dict.get("client_secret", None),
                max_tokens=azure_dict.get("max_tokens", 4000),
                temperature=azure_dict.get("temperature", 0.7),
                top_p=azure_dict.get("top_p", 1.0),
                frequency_penalty=azure_dict.get("frequency_penalty", 0.0),
                presence_penalty=azure_dict.get("presence_penalty", 0.0),
            )

            # Extract SDK config
            sdk_dict = config_dict.get("sdk", {})
            sdk_config = SDKConfig(
                max_batch_size=sdk_dict.get("max_batch_size", 10),
                timeout_seconds=sdk_dict.get("timeout_seconds", 30),
                retry_attempts=sdk_dict.get("retry_attempts", 3),
                log_level=sdk_dict.get("log_level", "INFO"),
            )

            return cls(azure=azure_config, sdk=sdk_config)
        except (TypeError, ValueError) as e:
            raise ConfigurationError(f"Invalid configuration: {str(e)}")

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary.

        Returns:
            Dictionary representation of the configuration
        """
        return {
            "azure": {
                "endpoint": self.azure.endpoint,
                "deployment_name": self.azure.deployment_name,
                "model_name": self.azure.model_name,
                "api_version": self.azure.api_version,
                "tenant_id": self.azure.tenant_id,
                "client_id": self.azure.client_id,
                "client_secret": self.azure.client_secret,
                "max_tokens": self.azure.max_tokens,
                "temperature": self.azure.temperature,
                "top_p": self.azure.top_p,
                "frequency_penalty": self.azure.frequency_penalty,
                "presence_penalty": self.azure.presence_penalty,
            },
            "sdk": {
                "max_batch_size": self.sdk.max_batch_size,
                "timeout_seconds": self.sdk.timeout_seconds,
                "retry_attempts": self.sdk.retry_attempts,
                "log_level": self.sdk.log_level,
            },
        }
