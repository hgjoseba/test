"""
Document parsing utilities for CV screening.

This module provides functionality for parsing CV documents in various formats
with both synchronous and asynchronous interfaces.
"""

import logging
import os
from io import BytesIO
from typing import Awaitable, Callable, Dict, Optional, Set

import aiofiles
from pypdf import PdfReader

from ..core.exceptions import ConfigurationError, DocumentParsingError
from ..core.interfaces import DocumentParserInterface


class DocumentParser(DocumentParserInterface):
    """
    Parser for CV documents with error handling and async support.

    This class handles parsing of PDF, TXT, and DOCX files, with both
    synchronous and asynchronous interfaces.
    """

    SUPPORTED_EXTENSIONS: Set[str] = {".pdf", ".txt", ".docx"}

    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Initialize the document parser.

        Args:
            logger: Optional logger instance to use
        """
        self.logger = logger or logging.getLogger(__name__)
        self._init_parser_methods()

    def _init_parser_methods(self) -> None:
        """Initialize parser method mappings."""
        self._sync_parsers: Dict[str, Callable[[str], str]] = {
            ".pdf": self._parse_pdf_sync,
            ".txt": self._parse_txt_sync,
            ".docx": self._parse_docx_sync,
        }

        self._async_parsers: Dict[str, Callable[[str], Awaitable[str]]] = {
            ".pdf": self._parse_pdf_async,
            ".txt": self._parse_txt_async,
            ".docx": self._parse_docx_async,
        }

    def _validate_file(self, file_path: str) -> str:
        """
        Validate file exists and has supported extension.

        Args:
            file_path: Path to the document file

        Returns:
            File extension

        Raises:
            DocumentParsingError: If file not found or format not supported
        """
        if not os.path.exists(file_path):
            raise DocumentParsingError(f"File not found: {file_path}")

        ext = os.path.splitext(file_path)[1].lower()
        if ext not in self.SUPPORTED_EXTENSIONS:
            raise DocumentParsingError(
                f"Unsupported file format: {ext}. "
                f"Supported formats: {', '.join(self.SUPPORTED_EXTENSIONS)}"
            )

        return ext

    def parse(self, file_path: str) -> str:
        """
        Parse a CV document and extract its content synchronously.

        Args:
            file_path: Path to the document file

        Returns:
            Extracted text content from the document

        Raises:
            DocumentParsingError: If file not found or format not supported
        """
        try:
            ext = self._validate_file(file_path)
            parser_method = self._sync_parsers[ext]
            return parser_method(file_path)

        except DocumentParsingError:
            # Re-raise DocumentParsingError without wrapping
            raise
        except Exception as e:
            self.logger.error(
                f"Failed to parse document {file_path}: {
                    str(e)}",
                exc_info=True,
            )
            raise DocumentParsingError(
                f"Failed to parse document: {
                    str(e)}"
            ) from e

    async def parse_async(self, file_path: str) -> str:
        """
        Asynchronously parse a CV document.

        Args:
            file_path: Path to the document file

        Returns:
            Extracted text content from the document

        Raises:
            DocumentParsingError: If file not found or format not supported
        """
        try:
            ext = self._validate_file(file_path)
            parser_method = self._async_parsers[ext]
            return await parser_method(file_path)

        except DocumentParsingError:
            # Re-raise DocumentParsingError without wrapping
            raise
        except Exception as e:
            self.logger.error(
                f"Failed to parse document {file_path}: {
                    str(e)}",
                exc_info=True,
            )
            raise DocumentParsingError(
                f"Failed to parse document: {
                    str(e)}"
            ) from e

    def _parse_pdf_sync(self, file_path: str) -> str:
        """
        Parse PDF document synchronously.

        Args:
            file_path: Path to PDF file

        Returns:
            Extracted text content

        Raises:
            DocumentParsingError: If parsing fails
        """
        try:
            with open(file_path, "rb") as file:
                reader = PdfReader(file)
                text = ""
                for page in reader.pages:
                    text += page.extract_text() + "\n"
                return text.strip()
        except Exception as e:
            raise DocumentParsingError(
                f"Failed to parse PDF file: {
                    str(e)}"
            ) from e

    def _parse_txt_sync(self, file_path: str) -> str:
        """
        Parse plain text document synchronously.

        Args:
            file_path: Path to text file

        Returns:
            Extracted text content

        Raises:
            DocumentParsingError: If parsing fails
        """
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return file.read().strip()
        except UnicodeDecodeError:
            # Try with different encoding if UTF-8 fails
            try:
                with open(file_path, "r", encoding="latin-1") as file:
                    return file.read().strip()
            except Exception as e:
                raise DocumentParsingError(
                    f"Failed to parse text file with alternative encoding: {
                        str(e)}"
                ) from e
        except Exception as e:
            raise DocumentParsingError(
                f"Failed to parse text file: {
                    str(e)}"
            ) from e

    def _parse_docx_sync(self, file_path: str) -> str:
        """
        Parse DOCX document synchronously.

        Args:
            file_path: Path to DOCX file

        Returns:
            Extracted text content

        Raises:
            DocumentParsingError: If parsing fails
            ConfigurationError: If required packages are missing
        """
        try:
            try:
                import docx
            except ImportError:
                raise ConfigurationError(
                    "python-docx package is required for DOCX support. "
                    "Install it with: pip install python-docx"
                )

            doc = docx.Document(file_path)
            paragraphs = [paragraph.text for paragraph in doc.paragraphs]

            # Also extract tables if present
            tables_text = []
            for table in doc.tables:
                for row in table.rows:
                    tables_text.append(" | ".join(cell.text for cell in row.cells))

            all_text = paragraphs + tables_text
            return "\n".join(all_text)
        except ConfigurationError:
            raise
        except Exception as e:
            raise DocumentParsingError(
                f"Failed to parse DOCX file: {
                    str(e)}"
            ) from e

    async def _parse_pdf_async(self, file_path: str) -> str:
        """
        Asynchronously parse PDF document.

        Args:
            file_path: Path to PDF file

        Returns:
            Extracted text content

        Raises:
            DocumentParsingError: If parsing fails
        """
        try:
            async with aiofiles.open(file_path, "rb") as file:
                content = await file.read()
                reader = PdfReader(BytesIO(content))
                text = ""
                for page in reader.pages:
                    text += page.extract_text() + "\n"
                extracted_text = text.strip()
                return extracted_text
        except Exception as e:
            raise DocumentParsingError(
                f"Failed to parse PDF file: {
                    str(e)}"
            ) from e

    async def _parse_txt_async(self, file_path: str) -> str:
        """
        Asynchronously parse plain text document.

        Args:
            file_path: Path to text file

        Returns:
            Extracted text content

        Raises:
            DocumentParsingError: If parsing fails
        """
        try:
            async with aiofiles.open(file_path, "r", encoding="utf-8") as file:
                content = await file.read()
                stripped_content = content.strip()
                return stripped_content
        except UnicodeDecodeError:
            # Try with different encoding if UTF-8 fails
            try:
                async with aiofiles.open(file_path, "r", encoding="latin-1") as file:
                    content = await file.read()
                    stripped_content = content.strip()
                    return stripped_content
            except Exception as e:
                raise DocumentParsingError(
                    f"Failed to parse text file with alternative encoding: {
                        str(e)}"
                ) from e
        except Exception as e:
            raise DocumentParsingError(
                f"Failed to parse text file: {
                    str(e)}"
            ) from e

    async def _parse_docx_async(self, file_path: str) -> str:
        """
        Asynchronously parse DOCX document.

        Args:
            file_path: Path to DOCX file

        Returns:
            Extracted text content

        Raises:
            DocumentParsingError: If parsing fails
            ConfigurationError: If required packages are missing
        """
        try:
            try:
                import docx
            except ImportError:
                raise ConfigurationError(
                    "python-docx package is required for DOCX support. "
                    "Install it with: pip install python-docx"
                )

            # python-docx doesn't support async operations
            # Handle file reading asynchronously
            async with aiofiles.open(file_path, "rb") as file:
                content = await file.read()
                doc = docx.Document(BytesIO(content))

                paragraphs = [paragraph.text for paragraph in doc.paragraphs]

                # Also extract tables if present
                tables_text = []
                for table in doc.tables:
                    for row in table.rows:
                        tables_text.append(" | ".join(cell.text for cell in row.cells))

                all_text = paragraphs + tables_text
                joined_text = "\n".join(all_text)
                return joined_text
        except ConfigurationError:
            raise
        except Exception as e:
            raise DocumentParsingError(
                f"Failed to parse DOCX file: {
                    str(e)}"
            ) from e
