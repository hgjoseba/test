"""
Validation utilities for the CV Screening SDK.

This module provides functions for validating inputs to the CV Screening SDK.
"""

import os
from typing import Any, Dict, Union

from ..core.exceptions import ValidationError
from ..models.criteria import JobCriteria


def validate_file_path(file_path: str) -> None:
    """
    Validate that a file path exists and is a file.

    Args:
        file_path: Path to validate

    Raises:
        ValidationError: If the path is invalid
    """
    if not file_path:
        raise ValidationError("File path cannot be empty")

    if not os.path.exists(file_path):
        raise ValidationError(f"File does not exist: {file_path}")

    if not os.path.isfile(file_path):
        raise ValidationError(f"Not a file: {file_path}")


def validate_criteria(criteria: Union[Dict[str, Any], JobCriteria]) -> None:
    """
    Validate job criteria for CV screening.

    Args:
        criteria: Job criteria to validate

    Raises:
        ValidationError: If criteria are invalid
    """
    if isinstance(criteria, JobCriteria):
        # JobCriteria performs validation in __post_init__
        return

    if not isinstance(criteria, dict):
        raise ValidationError(
            f"Criteria must be a dictionary or JobCriteria object, got {
                type(criteria)}"
        )

    # Validate required_skills if present
    if "required_skills" in criteria:
        if not isinstance(criteria["required_skills"], list):
            raise ValidationError("required_skills must be a list")

        for skill in criteria["required_skills"]:
            if not isinstance(skill, str):
                raise ValidationError(f"Skill must be a string: {skill}")

    # Validate preferred_skills if present
    if "preferred_skills" in criteria:
        if not isinstance(criteria["preferred_skills"], list):
            raise ValidationError("preferred_skills must be a list")

        for skill in criteria["preferred_skills"]:
            if not isinstance(skill, str):
                raise ValidationError(f"Skill must be a string: {skill}")

    # Validate min_years_experience if present
    if "min_years_experience" in criteria:
        if not isinstance(criteria["min_years_experience"], (int, float)):
            raise ValidationError("min_years_experience must be a number")

        if criteria["min_years_experience"] < 0:
            raise ValidationError("min_years_experience cannot be negative")

    # Validate preferred_years_experience if present
    if "preferred_years_experience" in criteria:
        if criteria["preferred_years_experience"] is not None:
            if not isinstance(criteria["preferred_years_experience"], (int, float)):
                raise ValidationError(
                    "preferred_years_experience must be a number or None"
                )

            if criteria["preferred_years_experience"] < 0:
                raise ValidationError("preferred_years_experience cannot be negative")

            if (
                "min_years_experience" in criteria
                and criteria["preferred_years_experience"]
                < criteria["min_years_experience"]
            ):
                raise ValidationError(
                    "preferred_years_experience must be >= min_years_experience"
                )

    # Validate education_level if present
    if "education_level" in criteria:
        if not isinstance(criteria["education_level"], str):
            raise ValidationError("education_level must be a string")

        valid_levels = {
            "any",
            "high school",
            "associate",
            "bachelors",
            "masters",
            "phd",
            "doctorate",
        }
        if criteria["education_level"].lower() not in valid_levels:
            raise ValidationError(
                f"education_level must be one of: {', '.join(valid_levels)}"
            )
