"""
Async utilities for the CV Screening SDK.

This module provides utilities for working with async code in the SDK.
"""

import asyncio
import functools
from typing import Any, Callable, Coroutine, TypeVar

T = TypeVar("T")
R = TypeVar("R")


def to_sync(async_func: Callable[..., Coroutine[Any, Any, R]]) -> Callable[..., R]:
    """
    Convert an async function to a sync function.

    Args:
        async_func: Async function to convert

    Returns:
        Synchronous version of the function
    """

    @functools.wraps(async_func)
    def wrapper(*args: Any, **kwargs: Any) -> R:
        """Run the async function synchronously."""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            # Create a new loop for this call
            new_loop = asyncio.new_event_loop()
            try:
                return new_loop.run_until_complete(async_func(*args, **kwargs))
            finally:
                new_loop.close()
        else:
            return loop.run_until_complete(async_func(*args, **kwargs))

    return wrapper


def run_async(coroutine: Coroutine[Any, Any, T]) -> T:
    """
    Run an async coroutine synchronously.

    Args:
        coroutine: Coroutine to run

    Returns:
        Result of the coroutine
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    if loop.is_running():
        # Create a new loop for this call
        new_loop = asyncio.new_event_loop()
        try:
            return new_loop.run_until_complete(coroutine)
        finally:
            new_loop.close()
    else:
        return loop.run_until_complete(coroutine)
