"""
Base classes for LLM providers.

This module defines abstract base classes for LLM providers
that can be used to analyze CVs.
"""

from abc import abstractmethod
from typing import Any, Dict, Optional

from ..core.interfaces import LLMAdapterInterface


class LLMProviderBase(LLMAdapterInterface):
    """Base class for LLM providers."""

    @abstractmethod
    def _get_system_prompt(self, prompt_system: Optional[str] = None) -> str:
        """
        Get the system prompt for CV analysis.

        Args:
            prompt_system: Optional custom system prompt

        Returns:
            System prompt for CV analysis
        """

    @abstractmethod
    def _build_screening_prompt(self, content: str, criteria: Dict[str, Any]) -> str:
        """
        Build the screening prompt with content and criteria.

        Args:
            content: CV content
            criteria: Job criteria

        Returns:
            Complete prompt for LLM
        """

    @abstractmethod
    def _parse_response(self, response: str) -> Dict[str, Any]:
        """
        Parse the LLM response into structured data.

        Args:
            response: Raw response from LLM

        Returns:
            Structured response data

        Raises:
            LLMError: If response cannot be parsed
        """
