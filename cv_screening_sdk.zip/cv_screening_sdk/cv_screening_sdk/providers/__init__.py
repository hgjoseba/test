"""
Service providers for CV Screening SDK.

This module provides service providers for CV analysis (Azure, etc.).
"""

from .azure import AzureProvider
from .base import LLMProviderBase

__all__ = [
    "LLMProviderBase",
    "AzureProvider",
] 