"""
Service providers for CV Screening SDK.

This module provides service providers for CV analysis (Azure, etc.).
"""

from .azure import AzureProvider
from .base import ServiceProvider

__all__ = [
    "ServiceProvider",
    "AzureProvider",
] 