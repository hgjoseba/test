"""
Azure OpenAI provider for CV screening.

This module implements the Azure OpenAI provider for CV screening operations.
"""

import json
import logging
from typing import Any, AsyncIterator, Dict, List, Optional, cast

from azure.core.credentials import TokenCredential
from azure.identity import DefaultAzureCredential
from openai import AsyncAzureOpenAI, AzureOpenAI

from ..auth.azure import AzureAuthProvider
from ..core.exceptions import LLMError, ProviderError, ProcessingError
from ..core.interfaces import ProviderInterface
from .base import LLMProviderBase

logger = logging.getLogger(__name__)


class AzureProvider(ProviderInterface, LLMProviderBase):
    def __init__(
        self,
        api_version: str,
        endpoint: str,
        deployment: str,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        logger: Optional[logging.Logger] = None,
        ssl_verify: bool = True,
        ssl_cert_path: Optional[str] = None,
    ) -> None:
        """
        Initialize the Azure OpenAI provider.

        Args:
            api_version: Azure OpenAI API version
            endpoint: Azure OpenAI endpoint URL
            deployment: Azure OpenAI deployment name
            tenant_id: Optional Azure tenant ID
            client_id: Optional Azure client ID
            client_secret: Optional Azure client secret
            logger: Optional logger instance
            ssl_verify: Whether to verify SSL certificates, default is True
            ssl_cert_path: Optional path to a custom SSL certificate

        Raises:
            ProviderError: If initialization fails
        """
        self.api_version = api_version
        self.endpoint = endpoint
        self.deployment = deployment
        self.logger = logger or logging.getLogger(__name__)
        self.ssl_verify = ssl_verify
        self.ssl_cert_path = ssl_cert_path

        try:
            self.auth_provider = AzureAuthProvider(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret,
                logger=self.logger,
            )
            self.client: Optional[AzureOpenAI] = None
        except Exception as e:
            self.logger.error(
                f"Failed to initialize Azure provider: {str(e)}",
                exc_info=True,
            )
            raise ProviderError(f"Failed to initialize Azure provider: {str(e)}") from e

    def initialize(self) -> None:
        """Initialize the Azure OpenAI client.

        Raises:
            ProviderError: If initialization fails
        """
        try:
            if self.client is None:
                credentials = self.auth_provider.get_credentials()
                
                # Manejo seguro de tokens con diferentes tipos de credenciales
                token = None
                try:
                    if hasattr(credentials, 'get_token'):
                        token = credentials.get_token("https://cognitiveservices.azure.com/.default").token
                    elif callable(getattr(credentials, '__call__', None)):
                        # Si es una función, intentar llamarla directamente
                        token_result = credentials()
                        token = token_result.token if hasattr(token_result, 'token') else token_result
                except Exception as token_error:
                    self.logger.warning(f"Error obteniendo token: {str(token_error)}. Continuando sin token explícito.")
                
                # Inicializar cliente con opciones necesarias
                client_args = {
                    "azure_endpoint": self.endpoint,
                    "api_version": self.api_version,
                    "azure_deployment": self.deployment,
                    "azure_ad_token_provider": credentials
                }
                
                # Agregar token solo si fue obtenido correctamente
                if token:
                    client_args["api_key"] = token
                
                # Configurar opciones SSL
                http_client_kwargs = {}
                if not self.ssl_verify:
                    http_client_kwargs["verify"] = False
                    self.logger.warning("La verificación SSL está desactivada. Esto puede representar un riesgo de seguridad.")
                
                if self.ssl_cert_path:
                    http_client_kwargs["verify"] = self.ssl_cert_path
                    self.logger.info(f"Usando certificado SSL personalizado: {self.ssl_cert_path}")
                
                if http_client_kwargs:
                    client_args["http_client"] = {"kwargs": http_client_kwargs}
                
                self.client = AzureOpenAI(**client_args)
                self.logger.info("Azure OpenAI client inicializado correctamente en modo síncrono")
        except Exception as e:
            self.logger.error(f"Error inicializando cliente: {str(e)}", exc_info=True)
            raise ProviderError(f"Failed to initialize Azure OpenAI client: {str(e)}")

    async def initialize_async(self) -> None:
        """Initialize the Azure OpenAI client asynchronously.

        Raises:
            ProviderError: If initialization fails
        """
        try:
            if self.client is None:
                credentials = await self.auth_provider.get_credentials_async()
                
                # Manejo seguro de tokens con diferentes tipos de credenciales
                token = None
                try:
                    if hasattr(credentials, 'get_token'):
                        token = credentials.get_token("https://cognitiveservices.azure.com/.default").token
                    elif callable(getattr(credentials, '__call__', None)):
                        # Si es una función, intentar llamarla directamente
                        token_result = credentials()
                        token = token_result.token if hasattr(token_result, 'token') else token_result
                except Exception as token_error:
                    self.logger.warning(f"Error obteniendo token asíncrono: {str(token_error)}. Continuando sin token explícito.")
                
                # Inicializar cliente con opciones necesarias
                client_args = {
                    "azure_endpoint": self.endpoint,
                    "api_version": self.api_version,
                    "azure_deployment": self.deployment,
                    "azure_ad_token_provider": credentials
                }
                
                # Agregar token solo si fue obtenido correctamente
                if token:
                    client_args["api_key"] = token
                
                # Configurar opciones SSL
                http_client_kwargs = {}
                if not self.ssl_verify:
                    http_client_kwargs["verify"] = False
                    self.logger.warning("La verificación SSL está desactivada. Esto puede representar un riesgo de seguridad.")
                
                if self.ssl_cert_path:
                    http_client_kwargs["verify"] = self.ssl_cert_path
                    self.logger.info(f"Usando certificado SSL personalizado: {self.ssl_cert_path}")
                
                if http_client_kwargs:
                    client_args["http_client"] = {"kwargs": http_client_kwargs}
                
                self.client = AsyncAzureOpenAI(**client_args)
                self.logger.info("Azure OpenAI client inicializado correctamente en modo asíncrono")
        except Exception as e:
            self.logger.error(f"Error inicializando cliente asíncrono: {str(e)}", exc_info=True)
            raise ProviderError(f"Failed to initialize Azure OpenAI client: {str(e)}")

    def _process_completion(self, completion_response: Any) -> Dict[str, Any]:
        """Process completion response from Azure OpenAI.

        Args:
            completion_response: Raw completion response

        Returns:
            Processed response dictionary

        Raises:
            LLMError: If response processing fails
        """
        try:
            # Extract content from completion
            if hasattr(completion_response, 'choices') and completion_response.choices:
                content = completion_response.choices[0].message.content
            else:
                # For test mocks that might be directly returning the response
                return completion_response

            try:
                # Parse JSON response
                response = json.loads(content)
            except json.JSONDecodeError:
                # Handle non-JSON responses (e.g. in tests)
                return {"content": content, "choices": [{"message": {"content": content}}]}

            # Ensure required fields are present
            if "skill_matches" not in response:
                response["skill_matches"] = {
                    "required_skills": {},
                    "preferred_skills": {},
                    "overall_score": 0.0,
                    "missing_required": [],
                    "missing_preferred": []
                }

            if "experience_match" not in response:
                response["experience_match"] = {
                    "years_of_experience": 0.0,
                    "relevance_score": 0.0,
                    "role_matches": [],
                    "meets_minimum": False,
                    "overall_score": 0.0
                }

            if "education_match" not in response:
                response["education_match"] = {
                    "level_match": False,
                    "field_relevance": 0.0,
                    "overall_score": 0.0,
                    "education_details": {
                        "highest_level": None,
                        "field": None,
                        "institution": None
                    }
                }

            # Convert scores to proper format
            if "match_score" in response:
                response["overall_score"] = float(response["match_score"]) * 100
            elif "overall_score" in response:
                response["overall_score"] = float(response["overall_score"])
            else:
                response["overall_score"] = 0.0

            # Normalize skill scores to 0-1 range
            for skill_dict in [response["skill_matches"]["required_skills"], 
                             response["skill_matches"]["preferred_skills"]]:
                for skill in skill_dict:
                    if isinstance(skill_dict[skill], (int, float)):
                        skill_dict[skill] = float(skill_dict[skill])
                        if skill_dict[skill] > 1:
                            skill_dict[skill] /= 100

            # Convert experience scores
            response["experience_match"]["relevance_score"] = float(response["experience_match"]["relevance_score"])
            if response["experience_match"]["relevance_score"] > 1:
                response["experience_match"]["relevance_score"] /= 100
            
            response["experience_match"]["overall_score"] = float(response["experience_match"]["overall_score"])
            if response["experience_match"]["overall_score"] > 1:
                response["experience_match"]["overall_score"] *= 100

            # Convert education scores
            response["education_match"]["field_relevance"] = float(response["education_match"]["field_relevance"])
            if response["education_match"]["field_relevance"] > 1:
                response["education_match"]["field_relevance"] /= 100
            
            response["education_match"]["overall_score"] = float(response["education_match"]["overall_score"])
            if response["education_match"]["overall_score"] > 1:
                response["education_match"]["overall_score"] *= 100

            return response

        except Exception as e:
            raise LLMError(f"Failed to process completion response: {str(e)}")

    def get_chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        try:
            if self.client is None:
                self.initialize()

            # Convert messages to the format expected by the OpenAI API
            # Use typing.Any to bypass mypy type checking for this part
            formatted_messages: List[Dict[str, Any]] = []
            for message in messages:
                formatted_messages.append(
                    {
                        "role": message.get("role", "user"),
                        "content": message.get("content", ""),
                    }
                )

            if self.client is None:
                raise ProviderError("Client not initialized")

            # Use a type cast to convince mypy this is the right type
            # In practice, the OpenAI client is duck-typed and will accept our
            # format
            completion_response = self.client.chat.completions.create(
                model=self.deployment,
                messages=cast(Any, formatted_messages),
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
            )

            processed_response = self._process_completion(completion_response)
            
            # Ensure processed_response has the required structure for downstream methods
            if not isinstance(processed_response, dict):
                processed_response = {"choices": [{"message": {"content": str(processed_response)}}]}
            elif "choices" not in processed_response:
                # Add the choices field if it doesn't exist
                processed_response["choices"] = [{"message": {"content": json.dumps(processed_response)}}]
                
            return processed_response
        except Exception as e:
            self.logger.error(
                f"Error getting chat completion: {str(e)}",
                exc_info=True,
            )
            raise LLMError(f"Failed to get chat completion: {str(e)}") from e

    async def get_chat_completion_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        try:
            if self.client is None:
                await self.initialize_async()

            # Convert messages to the format expected by the OpenAI API
            formatted_messages: List[Dict[str, Any]] = []
            for message in messages:
                formatted_messages.append(
                    {
                        "role": message.get("role", "user"),
                        "content": message.get("content", ""),
                    }
                )

            if self.client is None:
                raise ProviderError("Client not initialized")

            # Use a type cast to convince mypy this is the right type
            completion_response = await self.client.chat.completions.create(
                model=self.deployment,
                messages=cast(Any, formatted_messages),
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
            )

            processed_response = self._process_completion(completion_response)
            
            # Ensure processed_response has the required structure for downstream methods
            if not isinstance(processed_response, dict):
                processed_response = {"choices": [{"message": {"content": str(processed_response)}}]}
            elif "choices" not in processed_response:
                # Add the choices field if it doesn't exist
                processed_response["choices"] = [{"message": {"content": json.dumps(processed_response)}}]
                
            return processed_response
        except Exception as e:
            self.logger.error(
                f"Error getting chat completion: {str(e)}",
                exc_info=True,
            )
            raise LLMError(f"Failed to get chat completion: {str(e)}") from e

    def get_chat_completion_stream(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        # This is a placeholder to satisfy the interface
        # The actual implementation would need to be async
        raise NotImplementedError("Streaming is not supported yet")

    def _get_system_prompt(self, prompt_system: Optional[str] = None) -> str:
        """Get the system prompt for CV screening.

        Args:
            prompt_system: Optional custom system prompt

        Returns:
            System prompt for CV screening
        """
        if prompt_system:
            return prompt_system

        return """You are an expert CV screening assistant. Your task is to analyze CVs and determine if they match the given job criteria.
        Provide a detailed analysis including:
        1. Match score (0-1)
        2. Skills match
        3. Experience match
        4. Education match
        5. Overall analysis

        Format your response as a JSON object with these fields."""

    def _build_screening_prompt(self, content: str, criteria: Any) -> str:
        """Build screening prompt.

        Args:
            content: CV content
            criteria: Job criteria

        Returns:
            Screening prompt
        """
        from cv_screening_sdk.models.criteria import JobCriteria

        if isinstance(criteria, JobCriteria):
            criteria_dict = criteria.to_dict()
        else:
            criteria_dict = criteria

        return f"""You are an expert CV screening assistant. Your task is to analyze CVs and determine if they match the given job criteria.

CV Content:
{content}

Job Criteria:
{json.dumps(criteria_dict, indent=2)}

Please provide your analysis in JSON format."""

    def _parse_response(self, response: str) -> Dict[str, Any]:
        """Parse the response from the LLM.

        Args:
            response: Response from the LLM

        Returns:
            Parsed response

        Raises:
            ProcessingError: If parsing fails
        """
        try:
            # Try to parse as JSON
            result = json.loads(response)
        except json.JSONDecodeError:
            # If not JSON, try to extract JSON-like structure
            try:
                # Find the first { and last }
                start = response.find("{")
                end = response.rfind("}") + 1
                if start >= 0 and end > start:
                    json_str = response[start:end]
                    result = json.loads(json_str)
                else:
                    raise ValueError("No JSON structure found in response")
            except Exception as e:
                raise ProcessingError(
                    f"Failed to parse response as JSON: {str(e)}"
                ) from e

        # Validate required fields
        required_fields = ["match_score", "skill_matches", "experience_match"]
        missing_fields = [field for field in required_fields if field not in result]
        if missing_fields:
            # If fields are missing, try to construct them from available data
            if "match_score" not in result and "overall_score" in result:
                result["match_score"] = result["overall_score"]
            
            if "skill_matches" not in result and "matched_skills" in result:
                result["skill_matches"] = {
                    "required_skills": result["matched_skills"],
                    "preferred_skills": [],
                    "overall_score": result.get("match_score", 0)
                }
            
            if "experience_match" not in result:
                result["experience_match"] = {
                    "years_of_experience": 0,
                    "relevance_score": 0.0,
                    "role_matches": [],
                    "meets_minimum": False,
                    "overall_score": 0.0
                }

            # Check again after attempting to fix
            missing_fields = [field for field in required_fields if field not in result]
            if missing_fields:
                raise ProcessingError(
                    f"Response missing required fields: {', '.join(missing_fields)}"
                )

        return result

    def analyze_cv(
        self,
        content: str,
        criteria: Optional[Dict[str, Any]] = None,
        prompt_system: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Analyze a CV against job criteria.

        Args:
            content: CV content
            criteria: Job criteria
            prompt_system: Optional custom system prompt

        Returns:
            Analysis results

        Raises:
            ProcessingError: If analysis fails
        """
        try:
            if criteria is None:
                criteria = {}

            # Build messages
            messages = [
                {"role": "system", "content": self._get_system_prompt(prompt_system)},
                {
                    "role": "user",
                    "content": self._build_screening_prompt(content, criteria),
                },
            ]

            # Get completion
            completion = self.get_chat_completion(messages)
            if not completion.get("choices"):
                raise ProcessingError("No completion choices returned")

            # Parse response
            response = completion["choices"][0]["message"]["content"]
            return self._parse_response(response)
        except Exception as e:
            self.logger.error(
                f"Error analyzing CV: {str(e)}",
                exc_info=True,
            )
            raise ProcessingError(f"Failed to analyze CV: {str(e)}") from e

    async def analyze_cv_async(
        self,
        content: str,
        criteria: Optional[Dict[str, Any]] = None,
        prompt_system: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Analyze a CV against job criteria asynchronously.

        Args:
            content: CV content
            criteria: Job criteria
            prompt_system: Optional custom system prompt

        Returns:
            Analysis results

        Raises:
            ProcessingError: If analysis fails
        """
        try:
            if criteria is None:
                criteria = {}

            # Build messages
            messages = [
                {"role": "system", "content": self._get_system_prompt(prompt_system)},
                {
                    "role": "user",
                    "content": self._build_screening_prompt(content, criteria),
                },
            ]

            # Get completion
            completion = await self.get_chat_completion_async(messages)
            if not completion.get("choices"):
                raise ProcessingError("No completion choices returned")

            # Parse response
            response = completion["choices"][0]["message"]["content"]
            return self._parse_response(response)
        except Exception as e:
            self.logger.error(
                f"Error analyzing CV: {str(e)}",
                exc_info=True,
            )
            raise ProcessingError(f"Failed to analyze CV: {str(e)}") from e

    def _validate_llm_result(self, result: Dict[str, Any]) -> None:
        """Validate the LLM result has all required fields."""
        required_fields = ["match_score", "skill_matches", "experience_match"]
        missing_fields = [field for field in required_fields if field not in result]
        if missing_fields:
            # If fields are missing, try to construct them from available data
            if "match_score" not in result and "overall_score" in result:
                result["match_score"] = result["overall_score"]
            
            if "skill_matches" not in result and "matched_skills" in result:
                result["skill_matches"] = {
                    "required_skills": result["matched_skills"],
                    "preferred_skills": [],
                    "overall_score": result.get("match_score", 0)
                }
            
            if "experience_match" not in result:
                result["experience_match"] = {
                    "years_of_experience": 0,
                    "relevance_score": 0.0,
                    "role_matches": [],
                    "meets_minimum": False,
                    "overall_score": 0.0
                }

            # Check again after attempting to fix
            missing_fields = [field for field in required_fields if field not in result]
            if missing_fields:
                raise ProcessingError(
                    f"Response missing required fields: {', '.join(missing_fields)}"
                )
