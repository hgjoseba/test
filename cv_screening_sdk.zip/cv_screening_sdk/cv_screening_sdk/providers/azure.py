"""
Azure OpenAI provider implementation.
"""

# flake8: noqa E501

import json
import logging
from typing import Any, AsyncIterator, Dict, List, Optional, cast

from openai import AzureOpenAI

from ..auth.azure import AzureAuthProvider
from ..core.exceptions import LLMError, ProviderError
from ..core.interfaces import ProviderInterface
from .base import LLMProviderBase


class AzureProvider(ProviderInterface, LLMProviderBase):
    def __init__(
        self,
        api_version: str,
        endpoint: str,
        deployment: str,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        self.api_version = api_version
        self.endpoint = endpoint
        self.deployment = deployment
        self.logger = logger or logging.getLogger(__name__)

        self.auth_provider = AzureAuthProvider(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
            logger=self.logger,
        )
        self.client: Optional[AzureOpenAI] = None

    def initialize(self) -> None:
        try:
            credentials = self.auth_provider.get_credentials()
            self.client = AzureOpenAI(
                api_version=self.api_version,
                azure_endpoint=self.endpoint,
                azure_ad_token_provider=lambda: credentials.get_token(
                    "https://cognitiveservices.azure.com/.default"
                ).token,
            )
        except Exception as e:
            self.logger.error(
                f"Failed to initialize Azure OpenAI client: {
                    str(e)}",
                exc_info=True,
            )
            raise ProviderError(
                f"Failed to initialize Azure OpenAI client: {str(e)}"
            ) from e

    async def initialize_async(self) -> None:
        try:
            credentials = await self.auth_provider.get_credentials_async()
            self.client = AzureOpenAI(
                api_version=self.api_version,
                azure_endpoint=self.endpoint,
                azure_ad_token_provider=lambda: credentials.get_token(
                    "https://cognitiveservices.azure.com/.default"
                ).token,
            )
        except Exception as e:
            self.logger.error(
                f"Failed to initialize Azure OpenAI client: {
                    str(e)}",
                exc_info=True,
            )
            raise ProviderError(
                f"Failed to initialize Azure OpenAI client: {str(e)}"
            ) from e

    def _process_completion(self, response: Any) -> Dict[str, Any]:
        """Process different types of completion responses into a standard format."""
        try:
            # Basic structure
            result = {
                "id": getattr(response, "id", "unknown"),
                "model": getattr(response, "model", "unknown"),
                "created": getattr(response, "created", 0),
            }

            # Process choices
            choices_list = []
            if hasattr(response, "choices") and response.choices:
                for choice in response.choices:
                    choice_data = {"index": getattr(choice, "index", 0)}

                    # Handle message
                    if hasattr(choice, "message") and choice.message:
                        choice_data["message"] = {
                            "role": getattr(choice.message, "role", "assistant"),
                            "content": getattr(choice.message, "content", ""),
                        }
                    elif hasattr(choice, "delta") and choice.delta:
                        choice_data["message"] = {
                            "role": getattr(choice.delta, "role", "assistant"),
                            "content": getattr(choice.delta, "content", ""),
                        }
                    else:
                        choice_data["message"] = {
                            "role": "assistant",
                            "content": "",
                        }

                    # Handle finish reason
                    choice_data["finish_reason"] = getattr(
                        choice, "finish_reason", None
                    )

                    choices_list.append(choice_data)

            result["choices"] = choices_list

            # Handle usage
            if hasattr(response, "usage") and response.usage:
                result["usage"] = {
                    "prompt_tokens": getattr(response.usage, "prompt_tokens", 0),
                    "completion_tokens": getattr(
                        response.usage, "completion_tokens", 0
                    ),
                    "total_tokens": getattr(response.usage, "total_tokens", 0),
                }
            else:
                result["usage"] = {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0,
                }

            return result
        except Exception as e:
            self.logger.error(
                f"Error processing completion response: {
                    str(e)}"
            )
            # Return a minimal valid response
            return {
                "id": "error",
                "model": "unknown",
                "created": 0,
                "choices": [
                    {
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": "",
                        },
                        "finish_reason": "error",
                    }
                ],
                "usage": {
                    "prompt_tokens": 0,
                    "completion_tokens": 0,
                    "total_tokens": 0,
                },
            }

    def get_chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        try:
            if self.client is None:
                self.initialize()

            # Convert messages to the format expected by the OpenAI API
            # Use typing.Any to bypass mypy type checking for this part
            formatted_messages: List[Dict[str, Any]] = []
            for message in messages:
                formatted_messages.append(
                    {
                        "role": message.get("role", "user"),
                        "content": message.get("content", ""),
                    }
                )

            if self.client is None:
                raise ProviderError("Client not initialized")

            # Use a type cast to convince mypy this is the right type
            # In practice, the OpenAI client is duck-typed and will accept our
            # format
            completion_response = self.client.chat.completions.create(
                model=self.deployment,
                messages=cast(Any, formatted_messages),
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
            )

            return self._process_completion(completion_response)
        except Exception as e:
            self.logger.error(
                f"Chat completion failed: {
                    str(e)}",
                exc_info=True,
            )
            raise ProviderError(
                f"Failed to get chat completion: {
                    str(e)}"
            ) from e

    async def get_chat_completion_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        try:
            if self.client is None:
                await self.initialize_async()

            # Convert messages to the format expected by the OpenAI API
            # Use typing.Any to bypass mypy type checking for this part
            formatted_messages: List[Dict[str, Any]] = []
            for message in messages:
                formatted_messages.append(
                    {
                        "role": message.get("role", "user"),
                        "content": message.get("content", ""),
                    }
                )

            if self.client is None:
                raise ProviderError("Client not initialized")

            # The OpenAI Python client doesn't support acreate directly, use create instead
            # Use a type cast to convince mypy this is the right type
            completion_response = self.client.chat.completions.create(
                model=self.deployment,
                messages=cast(Any, formatted_messages),
                temperature=temperature,
                max_tokens=max_tokens,
                stream=stream,
            )

            return self._process_completion(completion_response)
        except Exception as e:
            self.logger.error(
                f"Async chat completion failed: {
                    str(e)}",
                exc_info=True,
            )
            raise ProviderError(
                f"Failed to get async chat completion: {
                    str(e)}"
            ) from e

    # This is a special case where we need to implement the interface,
    # but we can't return an AsyncIterator from a non-async method.
    # Instead, this is a wrapper that returns a generator.
    def get_chat_completion_stream(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        # This is a placeholder to satisfy the interface
        # The actual implementation would need to be async
        raise NotImplementedError(
            "Streaming is not supported in this implementation. Use get_chat_completion instead."
        )

    def _get_system_prompt(self, prompt_system: Optional[str] = None) -> str:
        """
        Get the system prompt for CV analysis.

        Args:
            prompt_system: Optional custom system prompt

        Returns:
            System prompt for CV analysis
        """
        return (
            prompt_system
            or "You are a CV/resume analysis assistant. Analyze the given CV against the job criteria and provide a structured assessment."
        )

    def _build_screening_prompt(self, content: str, criteria: Dict[str, Any]) -> str:
        """
        Build the screening prompt with content and criteria.

        Args:
            content: CV content
            criteria: Job criteria

        Returns:
            Complete prompt for LLM
        """
        criteria_str = json.dumps(criteria, indent=2)
        return f"Here are the job criteria to match against:\n\n{criteria_str}\n\nHere is the CV to analyze:\n\n{content}\n\nPlease analyze this CV and provide structured results."

    def _parse_response(self, response: str) -> Dict[str, Any]:
        """
        Parse the LLM response into structured data.

        Args:
            response: Raw response from LLM

        Returns:
            Structured response data

        Raises:
            LLMError: If response cannot be parsed
        """
        try:
            # The response might be structured or unstructured
            # First try to parse it as JSON
            try:
                parsed = json.loads(response)
                if isinstance(parsed, dict):
                    return parsed
            except (json.JSONDecodeError, TypeError):
                pass

            # If not JSON, return it as raw content
            return {"content": response}
        except Exception as e:
            self.logger.error(f"Failed to parse LLM response: {str(e)}")
            raise LLMError(f"Failed to parse LLM response: {str(e)}")

    def analyze_cv(
        self,
        content: str,
        criteria: Optional[Dict[str, Any]] = None,
        prompt_system: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Analyze CV content synchronously.

        Args:
            content: CV content as text
            criteria: Optional job criteria for matching
            prompt_system: Optional custom system prompt

        Returns:
            Analysis results as a dictionary

        Raises:
            LLMError: If analysis fails
        """
        try:
            # Create system message with default or custom prompt
            system_message = (
                prompt_system
                or "You are a CV/resume analysis assistant. Analyze the given CV against the job criteria and provide a structured assessment."
            )

            # Create messages array
            messages = [
                {"role": "system", "content": system_message},
            ]

            # Add criteria context if provided
            if criteria:
                criteria_str = json.dumps(criteria, indent=2)
                messages.append(
                    {
                        "role": "user",
                        "content": f"Here are the job criteria to match against:\n\n{criteria_str}",
                    }
                )

            # Add CV content
            messages.append(
                {
                    "role": "user",
                    "content": f"Here is the CV to analyze:\n\n{content}\n\nPlease analyze this CV and provide structured results.",
                }
            )

            # Get completion response
            completion = self.get_chat_completion(
                messages=messages,
                temperature=0.2,  # Lower temperature for more focused analysis
            )

            return completion

        except Exception as e:
            self.logger.error(f"CV analysis failed: {str(e)}", exc_info=True)
            raise LLMError(f"Failed to analyze CV: {str(e)}") from e

    async def analyze_cv_async(
        self,
        content: str,
        criteria: Optional[Dict[str, Any]] = None,
        prompt_system: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Analyze CV content asynchronously.

        Args:
            content: CV content as text
            criteria: Optional job criteria for matching
            prompt_system: Optional custom system prompt

        Returns:
            Analysis results as a dictionary

        Raises:
            LLMError: If analysis fails
        """
        try:
            # Create system message with default or custom prompt
            system_message = (
                prompt_system
                or "You are a CV/resume analysis assistant. Analyze the given CV against the job criteria and provide a structured assessment."
            )

            # Create messages array
            messages = [
                {"role": "system", "content": system_message},
            ]

            # Add criteria context if provided
            if criteria:
                criteria_str = json.dumps(criteria, indent=2)
                messages.append(
                    {
                        "role": "user",
                        "content": f"Here are the job criteria to match against:\n\n{criteria_str}",
                    }
                )

            # Add CV content
            messages.append(
                {
                    "role": "user",
                    "content": f"Here is the CV to analyze:\n\n{content}\n\nPlease analyze this CV and provide structured results.",
                }
            )

            # Get completion response
            completion = await self.get_chat_completion_async(
                messages=messages,
                temperature=0.2,  # Lower temperature for more focused analysis
            )

            return completion

        except Exception as e:
            self.logger.error(
                f"Async CV analysis failed: {
                    str(e)}",
                exc_info=True,
            )
            raise LLMError(
                f"Failed to analyze CV asynchronously: {
                    str(e)}"
            ) from e
