"""
Models for job criteria and matching.

This module defines the data structures for specifying job requirements
and criteria for CV screening, with support for multiple formats.
"""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..core.exceptions import ValidationError

if TYPE_CHECKING:
    from ..providers.base import LLMProviderBase


@dataclass
class JobCriteria:
    """
    Model for job requirements and matching criteria.

    Attributes:
        required_skills: List of required technical skills
        preferred_skills: List of preferred/nice-to-have skills
        min_years_experience: Minimum years of experience required
        preferred_years_experience: Preferred years of experience
        education_level: Required education level
            (any, high school, bachelors, masters, phd)
        education_field: Required field of study
        role_title: Job title
        description: Brief role description
        industry: Industry sector for the role
    """

    required_skills: List[str] = field(default_factory=list)
    preferred_skills: List[str] = field(default_factory=list)
    min_years_experience: int = 0
    preferred_years_experience: Optional[int] = None
    education_level: str = "any"
    education_field: Optional[str] = None
    role_title: Optional[str] = None
    description: Optional[str] = None
    industry: Optional[str] = None

    def __post_init__(self) -> None:
        """Validate criteria after initialization."""
        try:
            if self.min_years_experience < 0:
                raise ValueError("min_years_experience cannot be negative")

            if (
                self.preferred_years_experience is not None
                and self.preferred_years_experience < self.min_years_experience
            ):
                raise ValueError(
                    "preferred_years_experience must be greater than or equal to "
                    "min_years_experience"
                )

            # Normalize education level to lowercase
            self.education_level = self.education_level.lower()

            # Validate education level
            valid_levels = {
                "any",
                "high school",
                "associate",
                "bachelors",
                "masters",
                "phd",
                "doctorate",
            }
            if self.education_level not in valid_levels:
                raise ValueError(
                    f"education_level must be one of: {
                        ', '.join(valid_levels)}"
                )

        except ValueError as e:
            raise ValidationError(str(e)) from e

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert criteria to dictionary format.

        Returns:
            Dictionary representation of job criteria
        """
        return {
            "required_skills": self.required_skills,
            "preferred_skills": self.preferred_skills,
            "min_years_experience": self.min_years_experience,
            "preferred_years_experience": self.preferred_years_experience,
            "education_level": self.education_level,
            "education_field": self.education_field,
            "role_title": self.role_title,
            "description": self.description,
            "industry": self.industry,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "JobCriteria":
        """
        Create criteria from dictionary data.

        Args:
            data: Dictionary containing job criteria

        Returns:
            JobCriteria instance

        Raises:
            ValidationError: If data contains invalid values
        """
        try:
            return cls(
                required_skills=data.get("required_skills", []),
                preferred_skills=data.get("preferred_skills", []),
                min_years_experience=data.get("min_years_experience", 0),
                preferred_years_experience=data.get("preferred_years_experience"),
                education_level=data.get("education_level", "any"),
                education_field=data.get("education_field"),
                role_title=data.get("role_title"),
                description=data.get("description"),
                industry=data.get("industry"),
            )
        except (TypeError, ValueError) as e:
            raise ValidationError(
                f"Invalid job criteria data: {
                    str(e)}"
            ) from e

    @classmethod
    def from_prompt(cls, prompt: str, llm_provider: "LLMProviderBase") -> "JobCriteria":
        """
        Create JobCriteria from a natural language prompt using LLM.

        Args:
            prompt: Natural language description of job requirements
            llm_provider: LLM provider instance to use for parsing

        Returns:
            JobCriteria instance parsed from the prompt

        Raises:
            ValidationError: If prompt cannot be parsed into valid criteria
            LLMError: If the LLM provider fails to process the prompt
        """
        system_prompt = (
            "You are an expert at parsing job requirements. "
            "Extract structured job criteria from the input.\n"
            "Return only a JSON object with these fields:\n"
            "- required_skills: list of required technical skills\n"
            "- preferred_skills: list of preferred/nice-to-have skills\n"
            "- min_years_experience: minimum years of experience as integer\n"
            "- preferred_years_experience: preferred years of experience as integer\n"
            "  or null\n"
            "- education_level: required education level (any, high school,\n"
            "  associate, bachelors, masters, phd)\n"
            "- education_field: required field of study or null\n"
            "- role_title: job title or null\n"
            "- description: brief role description or null\n"
            "- industry: industry sector for the role or null"
        )

        result = llm_provider.analyze_cv(prompt, None, system_prompt)
        return cls.from_dict(result)
