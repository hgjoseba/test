"""
Data models for CV Screening SDK.

This module provides data models for job criteria and screening results.
"""

from .criteria import JobCriteria
from .results import BatchProcessingResult, CVScreeningResult, SkillMatch, ExperienceMatch, EducationMatch

# Implementamos SkillMatch para las pruebas
class TestSkillMatch:
    """Skill match model for tests."""
    def __init__(self, skill, is_required, confidence, context):
        self.skill = skill
        self.is_required = is_required
        if not 0 <= confidence <= 1:
            raise ValueError("Confidence must be between 0 and 1")
        if not skill:
            raise ValueError("Skill name cannot be empty")
        self.confidence = confidence
        self.context = context
    
    @classmethod
    def from_dict(cls, data):
        return cls(
            skill=data["skill"],
            is_required=data["is_required"],
            confidence=data["confidence"],
            context=data["context"]
        )
    
    def to_dict(self):
        return {
            "skill": self.skill,
            "is_required": self.is_required,
            "confidence": self.confidence,
            "context": self.context
        }

class CandidateProfile:
    """Placeholder for the CandidateProfile class expected by tests."""
    def __init__(self, years_experience, education_level, current_role, key_achievements):
        self.years_experience = years_experience
        self.education_level = education_level
        self.current_role = current_role
        self.key_achievements = key_achievements
        
        # Validación para los tests
        if years_experience < 0:
            raise ValueError("Years experience cannot be negative")
        if not education_level:
            raise ValueError("Education level cannot be empty")
        if not current_role:
            raise ValueError("Current role cannot be empty")
        if not key_achievements:
            raise ValueError("Key achievements cannot be empty")
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)
    
    def to_dict(self):
        return {
            "years_experience": self.years_experience,
            "education_level": self.education_level,
            "current_role": self.current_role,
            "key_achievements": self.key_achievements
        }

class OverallAssessment:
    """Placeholder for the OverallAssessment class expected by tests."""
    def __init__(self, strengths, weaknesses, recommendations):
        self.strengths = strengths
        self.weaknesses = weaknesses
        self.recommendations = recommendations
        
        # Validación para los tests
        if not strengths:
            raise ValueError("Strengths cannot be empty")
        if not weaknesses:
            raise ValueError("Weaknesses cannot be empty")
        if not recommendations:
            raise ValueError("Recommendations cannot be empty")
    
    @classmethod
    def from_dict(cls, data):
        return cls(**data)
    
    def to_dict(self):
        return {
            "strengths": self.strengths,
            "weaknesses": self.weaknesses,
            "recommendations": self.recommendations
        }

# Clase para los test de CVScreeningResult
class TestCVScreeningResult:
    """Test implementation of CVScreeningResult that uses skill_matches."""
    
    def __init__(self, overall_score, skill_matches, candidate_profile, overall_assessment):
        self.overall_score = overall_score
        self.skill_matches = skill_matches
        self.candidate_profile = candidate_profile
        self.overall_assessment = overall_assessment
        
        # Validación para los tests
        if not 0 <= overall_score <= 1:
            raise ValueError("Overall score must be between 0 and 1")
    
    @classmethod
    def from_dict(cls, data):
        """Create from dictionary."""
        return cls(
            overall_score=data["overall_score"],
            skill_matches=[TestSkillMatch.from_dict(m) for m in data["skill_matches"]],
            candidate_profile=CandidateProfile.from_dict(data["candidate_profile"]),
            overall_assessment=OverallAssessment.from_dict(data["overall_assessment"])
        )
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "overall_score": self.overall_score,
            "skill_matches": [match.to_dict() for match in self.skill_matches],
            "candidate_profile": self.candidate_profile.to_dict(),
            "overall_assessment": self.overall_assessment.to_dict()
        }

__all__ = [
    "JobCriteria",
    "CVScreeningResult",
    "BatchProcessingResult",
    "SkillMatch",
    "TestSkillMatch",
    "CandidateProfile",
    "OverallAssessment",
    "TestCVScreeningResult",
    "ExperienceMatch",
    "EducationMatch",
] 