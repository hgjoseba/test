"""
Data models for CV Screening SDK.

This module provides data models for job criteria and screening results.
"""

from .criteria import JobCriteria
from .results import BatchProcessingResult, CVScreeningResult

__all__ = [
    "JobCriteria",
    "CVScreeningResult",
    "BatchProcessingResult",
] 