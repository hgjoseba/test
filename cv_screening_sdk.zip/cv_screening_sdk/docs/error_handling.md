# Error Handling Guide

## Common Errors

### ValidationError
Thrown when input validation fails:
- Invalid file paths
- Invalid job criteria format
- Missing required fields

### DocumentParsingError
Thrown when CV document parsing fails:
- Unsupported file format 
- Corrupted document
- Permission issues

### LLMError 
Thrown when the AI analysis encounters issues:
- API connection failures
- Rate limiting
- Invalid responses

## Best Practices

### Input Validation
```python
try:
    result = client.screen_cv(cv_path, criteria)
except ValidationError as e:
    logging.error(f"Invalid input: {e}")
    # Handle validation error
```

### Document Handling
```python
try:
    results = client.batch_screen_cvs(cv_paths, criteria)
except DocumentParsingError as e:
    logging.error(f"Failed to parse document: {e}")
    # Handle parsing error
```

### API Error Handling
```python
try:
    result = await client._screen_cv_async(cv_path, criteria)
except LLMError as e:
    logging.error(f"AI analysis failed: {e}")
    # Handle API error
```