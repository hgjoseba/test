# Manejo de errores

Este documento describe cómo el CV Screening SDK maneja los errores y cómo puedes implementar tu propia estrategia de manejo de errores.

## Tipos de errores

El SDK define las siguientes excepciones personalizadas:

### Errores de configuración

- `ConfigurationError`: Error en la configuración del SDK.
  - Se lanza cuando hay problemas con los parámetros de configuración.
  - Ejemplo: valores de configuración inválidos, faltan parámetros obligatorios, etc.

### Errores de autenticación

- `AuthenticationError`: Error en el proceso de autenticación.
  - Se lanza cuando fallan las credenciales o hay problemas con el token.
  - Ejemplo: credenciales inválidas, token expirado, falta de permisos.

### Errores de conexión

- `ConnectionError`: Error en la conexión con la API de Azure.
  - Se lanza cuando hay problemas de red o timeout.
  - Ejemplo: endpoint no disponible, timeout de conexión, problemas SSL.

### Errores de API

- `ApiError`: Error en la respuesta de la API.
  - Se lanza cuando la API responde con un código de error.
  - Incluye detalles del error proporcionados por la API.

### Errores de procesamiento

- `ProcessingError`: Error en el procesamiento de documentos o datos.
  - Se lanza cuando hay problemas al analizar los datos.
  - Ejemplo: formato incorrecto, datos corruptos, problema en el análisis.

### Errores en la SDK

- `SDKError`: Clase base para todos los errores del SDK.
  - No se lanza directamente, sino que es la base para los tipos anteriores.
  - Puedes capturar esta excepción para manejar cualquier error del SDK.

## Manejo básico de errores

Puedes manejar los errores del SDK utilizando bloques try-except:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.exceptions import SDKError, ConfigurationError, AuthenticationError, ApiError

try:
    # Inicializar el cliente
    client = CVScreeningClient()
    
    # Analizar un CV
    result = client.analyze_cv_text("Contenido del CV...", job_criteria)
    
except ConfigurationError as e:
    print(f"Error de configuración: {e}")
    # Manejar error de configuración (ej. revisar variables de entorno)

except AuthenticationError as e:
    print(f"Error de autenticación: {e}")
    # Manejar error de autenticación (ej. verificar credenciales)

except ApiError as e:
    print(f"Error de API: {e}")
    print(f"Código de error: {e.error_code}")
    print(f"Detalles: {e.details}")
    # Manejar error de API (ej. reintentar o cambiar parámetros)

except SDKError as e:
    print(f"Error general del SDK: {e}")
    # Manejar cualquier otro error del SDK

except Exception as e:
    print(f"Error no controlado: {e}")
    # Manejar cualquier otro error no del SDK
```

## Manejo de errores de conexión

Los errores de conexión son comunes cuando se trabaja con APIs externas. El SDK incluye un mecanismo de reintento automático para problemas temporales:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import ClientConfig, SDKConfig

# Configurar reintentos para problemas de conexión
client_config = ClientConfig(
    max_retries=5,  # Aumentar el número de reintentos (predeterminado: 3)
    timeout=60      # Aumentar el timeout en segundos (predeterminado: 30)
)

# Inicializar cliente con la configuración personalizada
client = CVScreeningClient(
    config=SDKConfig(client=client_config)
)
```

### Errores SSL

Para entornos con configuraciones SSL personalizadas:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, SDKConfig

# Configurar opciones SSL
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    # Otros parámetros necesarios...
    
    # Opciones SSL
    ssl_verify=True,  # Verificar certificados SSL (predeterminado)
    ssl_cert_path="/ruta/a/certificado.pem"  # Certificado personalizado
)

# Inicializar cliente con la configuración personalizada
client = CVScreeningClient(
    config=SDKConfig(azure=azure_config)
)
```

## Errores de autenticación

Los errores de autenticación pueden ocurrir por varias razones:

1. **Credenciales incorrectas**: Verifica que `tenant_id`, `client_id` y `client_secret` sean correctos.
2. **Permisos insuficientes**: Asegúrate de que el Service Principal tenga los permisos necesarios.
3. **Token expirado**: El SDK renueva automáticamente los tokens, pero pueden surgir problemas.

Para diagnosticar problemas de autenticación:

```python
from cv_screening_sdk.auth.azure import AzureAuthProvider
from cv_screening_sdk.core.exceptions import AuthenticationError

try:
    # Crear proveedor de autenticación
    auth = AzureAuthProvider(
        tenant_id="tu-tenant-id",
        client_id="tu-client-id",
        client_secret="tu-client-secret",
        connection_verify=True  # Verificar conexiones SSL (predeterminado)
    )
    
    # Validar credenciales
    is_valid = auth.validate_credentials()
    
    if is_valid:
        print("✅ Credenciales válidas")
    else:
        print("❌ Credenciales inválidas")
        
except AuthenticationError as e:
    print(f"❌ Error de autenticación: {e}")
```

## Manejo avanzado de errores

### Personalización del registro (logging)

Puedes configurar el sistema de registro para obtener más información sobre los errores:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import LogConfig, SDKConfig

# Configurar logging detallado
log_config = LogConfig(
    level="DEBUG",  # Aumentar el nivel de detalle (predeterminado: INFO)
    file_path="logs/detallados.log"
)

# Inicializar cliente con la configuración personalizada
client = CVScreeningClient(
    config=SDKConfig(log=log_config)
)
```

### Implementación de callbacks para errores

Puedes implementar estrategias avanzadas de manejo de errores con callbacks:

```python
import logging
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.exceptions import ApiError, ConnectionError

# Configurar un logger personalizado
logger = logging.getLogger("cv_screening_app")

# Callback para errores
def error_handler(error, context):
    if isinstance(error, ConnectionError):
        logger.error(f"Error de conexión: {error} - Contexto: {context}")
        # Notificar al equipo de operaciones
        notify_ops_team(error, context)
        
    elif isinstance(error, ApiError) and error.error_code == "rate_limit_exceeded":
        logger.warning(f"Límite de tasa excedido: {error}")
        # Implementar retraso adaptativo
        wait_time = calculate_backoff(context.get("retry_count", 0))
        logger.info(f"Esperando {wait_time} segundos antes de reintentar")
        time.sleep(wait_time)
        return True  # Indicar que se debe reintentar
        
    # Registrar todos los errores para análisis
    log_error_for_analysis(error, context)
    
    return False  # No reintentar por defecto

# Función para procesar CVs con manejo de errores personalizado
def process_cvs_safely(client, cv_texts, job_criteria):
    results = []
    
    for i, cv_text in enumerate(cv_texts):
        retry_count = 0
        max_retries = 3
        
        while retry_count <= max_retries:
            try:
                result = client.analyze_cv_text(cv_text, job_criteria)
                results.append(result)
                break
                
            except Exception as e:
                context = {
                    "cv_index": i,
                    "retry_count": retry_count,
                    "job_criteria": job_criteria,
                    "cv_length": len(cv_text)
                }
                
                should_retry = error_handler(e, context)
                
                if should_retry and retry_count < max_retries:
                    retry_count += 1
                    continue
                else:
                    # Añadir resultado nulo o parcial
                    results.append({"error": str(e), "cv_index": i})
                    break
    
    return results
```

## Problemas comunes y soluciones

### Timeout durante el análisis de CVs largos

Si tienes problemas con timeout al analizar CVs largos:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import ClientConfig, SDKConfig

# Aumentar timeout para CVs grandes
client_config = ClientConfig(
    timeout=120  # 2 minutos en lugar de los 30 segundos predeterminados
)

client = CVScreeningClient(
    config=SDKConfig(client=client_config)
)
```

### Errores de conexión en entornos con proxy

Si estás en un entorno corporativo con proxy:

```python
# Configurar variables de entorno del proxy antes de importar el SDK
import os
os.environ["HTTP_PROXY"] = "http://proxy-corporativo:puerto"
os.environ["HTTPS_PROXY"] = "http://proxy-corporativo:puerto"

# Luego inicializar el SDK
from cv_screening_sdk import CVScreeningClient
client = CVScreeningClient()
```

### Problemas con firewalls corporativos

Para entornos con restricciones de firewall estrictas:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, SDKConfig

# Configurar timeout más largo y opciones SSL personalizadas
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    # Otros parámetros...
    connection_timeout=60,  # Timeout de conexión más largo
    ssl_verify=True,
    ssl_cert_path="/ruta/a/certificado/corporativo.pem"
)

# Inicializar cliente
client = CVScreeningClient(
    config=SDKConfig(azure=azure_config)
)
```

### Errores de límites de velocidad (Rate Limiting)

Para manejar límites de tasa de Azure OpenAI:

```python
import time
import random
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.exceptions import ApiError

def analyze_with_rate_limit_handling(client, cv_texts, job_criteria):
    results = []
    
    for cv_text in cv_texts:
        max_retries = 5
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                result = client.analyze_cv_text(cv_text, job_criteria)
                results.append(result)
                # Añadir pequeño retraso entre solicitudes para evitar límites
                time.sleep(1)
                break
                
            except ApiError as e:
                if "rate_limit" in str(e).lower():
                    retry_count += 1
                    # Implementar retraso exponencial con jitter
                    wait_time = (2 ** retry_count) + random.random()
                    print(f"Límite de tasa alcanzado. Esperando {wait_time:.2f} segundos...")
                    time.sleep(wait_time)
                else:
                    # No es un error de límite de tasa, relanzar
                    raise
    
    return results
```

## Depuración de problemas

Para casos donde necesitas mayor visibilidad en lo que está ocurriendo:

### Habilitar registro de solicitudes HTTP

Para ver las solicitudes HTTP detalladas:

```python
import logging

# Configurar logging para ver detalles HTTP
logging.basicConfig(level=logging.DEBUG)
logging.getLogger("httpx").setLevel(logging.DEBUG)
logging.getLogger("cv_screening_sdk").setLevel(logging.DEBUG)

# Ahora inicializa el cliente
from cv_screening_sdk import CVScreeningClient
client = CVScreeningClient()
```

### Validar configuración

Para validar la configuración antes de hacer solicitudes:

```python
from cv_screening_sdk.core.config import AzureConfig, SDKConfig
from cv_screening_sdk import CVScreeningClient

# Crear configuración
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    # Otros parámetros...
)

# Validar la configuración
try:
    azure_config.validate()  # Esto validará todos los campos
    print("Configuración válida")
except Exception as e:
    print(f"Configuración inválida: {e}")

# Si es válida, inicializar cliente
client = CVScreeningClient(
    config=SDKConfig(azure=azure_config)
)
```

## Mejores prácticas para el manejo de errores

1. **Capturar errores específicos primero**:
   ```python
   try:
       # Código que puede fallar
   except ConfigurationError:
       # Manejar errores de configuración
   except AuthenticationError:
       # Manejar errores de autenticación
   except SDKError:
       # Manejar otros errores del SDK
   except Exception:
       # Manejar cualquier otro error
   ```

2. **Registrar información contextual**:
   ```python
   try:
       result = client.analyze_cv_text(cv_text, job_criteria)
   except Exception as e:
       logger.error(f"Error al analizar CV: {e}", extra={
           "cv_length": len(cv_text),
           "job_criteria": job_criteria,
           "trace_id": generate_trace_id()
       })
   ```

3. **Implementar reintentos con retraso exponencial**:
   ```python
   def exponential_backoff(max_retries=5):
       for i in range(max_retries):
           try:
               # Operación que puede fallar
               return result
           except (ConnectionError, ApiError) as e:
               if i == max_retries - 1:
                   raise
               wait_time = (2 ** i) + random.random()
               time.sleep(wait_time)
   ```

4. **Proporcionar información útil al usuario**:
   ```python
   try:
       result = client.analyze_cv_text(cv_text, job_criteria)
   except AuthenticationError:
       print("Error de autenticación. Por favor, verifica tus credenciales.")
   except ConnectionError:
       print("No se pudo conectar al servicio. Por favor, verifica tu conexión.")
   except ApiError as e:
       if "rate_limit" in str(e).lower():
           print("Has excedido el límite de solicitudes. Inténtalo más tarde.")
       else:
           print(f"Error del servicio: {e}")
   ```

5. **Implementar circuit breaker para fallas persistentes**:
   ```python
   class CircuitBreaker:
       def __init__(self, failure_threshold=5, reset_timeout=60):
           self.failure_count = 0
           self.failure_threshold = failure_threshold
           self.reset_timeout = reset_timeout
           self.last_failure_time = None
           self.is_open = False
           
       def execute(self, func, *args, **kwargs):
           if self.is_open:
               current_time = time.time()
               if current_time - self.last_failure_time > self.reset_timeout:
                   # Intentar restablecer el circuito
                   self.is_open = False
                   self.failure_count = 0
               else:
                   raise Exception("Circuit breaker abierto. Intentar más tarde.")
           
           try:
               result = func(*args, **kwargs)
               # Éxito, reiniciar contador
               self.failure_count = 0
               return result
           except Exception as e:
               # Fallo, incrementar contador
               self.failure_count += 1
               self.last_failure_time = time.time()
               
               if self.failure_count >= self.failure_threshold:
                   self.is_open = True
                   
               raise e
   ```

## Envío de telemetría para análisis de errores

Para entornos de producción, considera implementar telemetría:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.exceptions import SDKError
import logging
import json
import requests

# Configurar logger
logger = logging.getLogger("cv_screening_app")

# Función para enviar telemetría
def send_telemetry(event_type, data):
    try:
        payload = {
            "event_type": event_type,
            "timestamp": time.time(),
            "data": data
        }
        requests.post(
            "https://tu-servicio-de-telemetria.com/api/events",
            json=payload,
            timeout=2  # Timeout corto para no bloquear
        )
    except Exception as e:
        # No fallar si la telemetría falla
        logger.warning(f"Error al enviar telemetría: {e}")

# Función para procesar con telemetría
def process_with_telemetry(client, cv_text, job_criteria):
    start_time = time.time()
    
    try:
        result = client.analyze_cv_text(cv_text, job_criteria)
        
        # Registrar éxito
        processing_time = time.time() - start_time
        send_telemetry("cv_analysis_success", {
            "processing_time": processing_time,
            "cv_length": len(cv_text),
            "job_criteria": job_criteria
        })
        
        return result
        
    except SDKError as e:
        # Registrar error
        processing_time = time.time() - start_time
        send_telemetry("cv_analysis_error", {
            "error_type": type(e).__name__,
            "error_message": str(e),
            "processing_time": processing_time,
            "cv_length": len(cv_text),
            "job_criteria": job_criteria
        })
        
        # Relanzar la excepción
        raise
```

## Códigos de error comunes

### Errores de API de Azure OpenAI

| Código de error | Descripción | Resolución recomendada |
|----------------|------------|------------------------|
| `invalid_request_error` | Solicitud mal formada | Verifica los parámetros de la solicitud |
| `authentication_error` | Problemas de autenticación | Verifica las credenciales de Azure |
| `permission_error` | Permisos insuficientes | Verifica los permisos del Service Principal |
| `rate_limit_exceeded` | Límite de tasa alcanzado | Implementa retraso y reintentos |
| `server_error` | Error del servidor | Reintenta después de un tiempo |
| `model_not_found` | Modelo no encontrado | Verifica el nombre del modelo y despliegue |
| `content_filter` | Contenido bloqueado por filtro | Verifica el contenido enviado |

### Errores de configuración

| Código de error | Descripción | Resolución recomendada |
|----------------|------------|------------------------|
| `missing_required_parameter` | Falta parámetro obligatorio | Proporciona el parámetro requerido |
| `invalid_parameter_type` | Tipo de parámetro incorrecto | Corrige el tipo del parámetro |
| `parameter_out_of_range` | Valor fuera de rango | Ajusta el valor al rango válido |
| `invalid_endpoint_url` | URL de endpoint inválida | Verifica el formato y accesibilidad de la URL |