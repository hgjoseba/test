# Guía de Manejo de Errores

El CV Screening SDK proporciona un sistema robusto de manejo de errores para facilitar la identificación y resolución de problemas durante el uso de la biblioteca.

## Jerarquía de Excepciones

El SDK utiliza la siguiente jerarquía de excepciones:

```
SDKError (base)
├── ValidationError (errores de validación)
├── DocumentParsingError (errores al analizar documentos)
├── LLMError (errores del modelo de lenguaje)
├── AuthenticationError (errores de autenticación)
├── ConfigurationError (errores de configuración)
├── ProcessingError (errores generales de procesamiento)
├── RateLimitError (errores de límite de tasa)
├── TimeoutError (errores de tiempo de espera)
├── InputError (errores de entrada)
└── APIError (errores de API externa)
```

## Descripción de Excepciones

### SDKError
Clase base para todas las excepciones del SDK. Todas las excepciones específicas heredan de esta clase.

```python
# Atributos
message: str  # Mensaje descriptivo del error
details: Optional[Dict[str, Any]]  # Detalles adicionales del error
```

### ValidationError
Lanzada cuando falla la validación de los datos de entrada, como criterios incorrectos o rutas de archivo inválidas.

```python
# Ejemplos comunes
"Invalid job criteria format"
"Required field 'required_skills' is missing"
"Value for 'min_years_experience' must be a positive integer"
```

### DocumentParsingError
Lanzada cuando hay problemas al leer o analizar un documento CV.

```python
# Ejemplos comunes
"Failed to read file: file not found"
"Unsupported file format: .xyz"
"PDF parsing error: encrypted document"
"Document is empty or contains no extractable text"
```

### LLMError
Lanzada cuando hay problemas con el modelo de lenguaje o la conexión a Azure OpenAI.

```python
# Ejemplos comunes
"Failed to connect to Azure OpenAI service"
"Model response timeout"
"Invalid response format from model"
"Token limit exceeded"
```

### AuthenticationError
Lanzada cuando hay problemas con la autenticación en Azure.

```python
# Ejemplos comunes
"Invalid credentials"
"Authentication token expired"
"Missing required authentication parameters"
"Service principal does not have access to resource"
```

### ConfigurationError
Lanzada cuando hay problemas con la configuración del SDK.

```python
# Ejemplos comunes
"Missing required configuration parameter 'endpoint'"
"Invalid value for 'temperature': must be between 0 and 2"
"Invalid URL format for 'endpoint'"
```

### ProcessingError
Lanzada cuando hay problemas generales durante el procesamiento de CVs.

```python
# Ejemplos comunes
"Failed to process CV"
"Error during batch processing"
```

### RateLimitError
Lanzada cuando se excede el límite de tasa de la API.

```python
# Ejemplos comunes
"Azure OpenAI rate limit exceeded"
"Too many requests, please try again later"
```

### TimeoutError
Lanzada cuando una operación excede el tiempo máximo de espera.

```python
# Ejemplos comunes
"Operation timed out after 30 seconds"
"Request to Azure OpenAI timed out"
```

### InputError
Lanzada cuando hay problemas con los datos de entrada que no son específicamente errores de validación.

```python
# Ejemplos comunes
"Input text exceeds maximum allowed size"
"Invalid input format"
```

### APIError
Lanzada cuando hay problemas con APIs externas utilizadas por el SDK.

```python
# Ejemplos comunes
"API returned error code 500"
"External service unavailable"
```

## Estrategias de Manejo de Errores

### Manejo Básico

Para un manejo de errores básico:

```python
from cv_screening_sdk.core.exceptions import (
    SDKError,
    ValidationError,
    DocumentParsingError,
    LLMError
)

try:
    result = client.screen_cv("path/to/resume.pdf", criteria)
except ValidationError as e:
    print(f"Error de validación: {e}")
    # Corregir los criterios o la ruta
except DocumentParsingError as e:
    print(f"Error de documento: {e}")
    # Verificar que el documento existe y tiene formato soportado
except LLMError as e:
    print(f"Error del modelo: {e}")
    # Verificar la conectividad o ajustar configuración
except SDKError as e:
    print(f"Error general del SDK: {e}")
    # Manejar cualquier otro error del SDK
```

### Manejo Avanzado con Contexto

```python
try:
    result = client.screen_cv("path/to/resume.pdf", criteria)
except SDKError as e:
    error_context = {
        "operation": "screen_cv",
        "cv_path": "path/to/resume.pdf",
        "timestamp": datetime.now().isoformat()
    }
    
    if hasattr(e, 'details') and e.details:
        error_context.update(e.details)
    
    print(f"Error: {e}")
    print(f"Contexto: {error_context}")
    
    # Opcional: registrar el error
    logger.error(f"SDK Error: {e}", extra={"context": error_context})
```

### Manejo de Excepciones en Procesamiento por Lotes

```python
try:
    batch_result = client.batch_screen_cvs(cv_paths, criteria)
    
    # Comprobar errores en resultados individuales
    if batch_result.failed_results:
        print(f"Advertencia: {len(batch_result.failed_results)} CVs fallaron")
        for failure in batch_result.failed_results:
            print(f"- CV: {failure.cv_path}")
            print(f"  Error: {failure.error}")
            print(f"  Tipo: {failure.error_type}")
            
    # Continuar procesando resultados exitosos
    for result in batch_result.successful_results:
        process_result(result)
        
except SDKError as e:
    print(f"Error crítico en procesamiento por lotes: {e}")
    # Manejar error global que afecta todo el lote
```

## Implementando Reintentos

```python
from cv_screening_sdk.core.exceptions import (
    LLMError, 
    RateLimitError,
    TimeoutError
)
import time

def screen_cv_with_retry(client, cv_path, criteria, max_retries=3, base_delay=2):
    """Analiza un CV con reintentos automáticos para errores transitorios."""
    retry_count = 0
    last_error = None
    
    # Lista de errores considerados transitorios (que pueden resolverse reintentando)
    transient_errors = (LLMError, RateLimitError, TimeoutError)
    
    while retry_count <= max_retries:
        try:
            return client.screen_cv(cv_path, criteria)
        except transient_errors as e:
            last_error = e
            retry_count += 1
            
            if retry_count > max_retries:
                print(f"Máximo de reintentos alcanzado ({max_retries})")
                raise
                
            # Exponential backoff
            delay = base_delay * (2 ** (retry_count - 1))
            print(f"Error: {e}. Reintentando en {delay} segundos...")
            time.sleep(delay)
        except SDKError as e:
            # Para errores no transitorios, fallar inmediatamente
            print(f"Error no recuperable: {e}")
            raise
    
    # Si llegamos aquí, todos los reintentos fallaron
    raise last_error
```

## Mejores Prácticas

### 1. Captura Específica

Captura las excepciones específicas primero y las más generales después:

```python
try:
    # Código que puede lanzar excepciones
except DocumentParsingError as e:
    # Primero manejar errores específicos
except ValidationError as e:
    # ...
except SDKError as e:
    # Luego manejar la excepción base para cualquier otro error del SDK
except Exception as e:
    # Finalmente manejar cualquier otra excepción no prevista
```

### 2. Proporcionar Contexto

Añade contexto adicional a los mensajes de error para facilitar la depuración:

```python
try:
    result = client.screen_cv(cv_path, criteria)
except SDKError as e:
    raise SDKError(f"Error procesando CV {cv_path}: {str(e)}") from e
```

### 3. Centralizar el Manejo de Errores

Crea una función centralizada para manejar errores:

```python
def handle_sdk_error(error, context=None):
    """Maneja errores del SDK de forma centralizada."""
    if context is None:
        context = {}
        
    error_type = type(error).__name__
    error_message = str(error)
    
    # Registrar el error
    logger.error(f"{error_type}: {error_message}", extra={"context": context})
    
    # Personalizar respuesta según el tipo de error
    if isinstance(error, ValidationError):
        return {"status": "error", "code": "VALIDATION_ERROR", "message": error_message}
    elif isinstance(error, DocumentParsingError):
        return {"status": "error", "code": "DOCUMENT_ERROR", "message": error_message}
    elif isinstance(error, AuthenticationError):
        return {"status": "error", "code": "AUTH_ERROR", "message": "Error de autenticación"}
    elif isinstance(error, RateLimitError):
        return {"status": "error", "code": "RATE_LIMIT", "message": "Límite de tasa excedido, intente más tarde"}
    else:
        return {"status": "error", "code": "GENERAL_ERROR", "message": "Error interno del sistema"}
```

### 4. Registro Detallado

Implementa un registro detallado de errores:

```python
import logging

# Configurar logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='cv_screening.log'
)
logger = logging.getLogger('cv_screening')

try:
    # Código que puede fallar
except SDKError as e:
    # Registrar con diferentes niveles según el error
    if isinstance(e, ValidationError):
        logger.warning(f"Error de validación: {e}")
    elif isinstance(e, AuthenticationError):
        logger.error(f"Error de autenticación: {e}")
    else:
        logger.critical(f"Error crítico: {e}", exc_info=True)
    
    # Propagar o manejar el error
    raise
```

## Prevención de Errores

### 1. Validación Preventiva

Valida los datos antes de enviarlos al SDK:

```python
def validate_cv_path(cv_path):
    """Valida que la ruta del CV sea correcta antes de procesarla."""
    import os
    
    # Verificar que el archivo existe
    if not os.path.exists(cv_path):
        raise ValidationError(f"El archivo no existe: {cv_path}")
        
    # Verificar extensión
    _, ext = os.path.splitext(cv_path)
    if ext.lower() not in ['.pdf', '.docx', '.txt']:
        raise ValidationError(f"Formato no soportado: {ext}")
        
    # Verificar tamaño
    if os.path.getsize(cv_path) > 10 * 1024 * 1024:  # 10 MB
        raise ValidationError(f"El archivo es demasiado grande: {cv_path}")
        
    return True
```

### 2. Monitoreo y Alertas

Implementa un sistema de monitoreo y alertas para detectar patrones de errores:

```python
class ErrorMonitor:
    def __init__(self):
        self.error_counts = {}
        self.alert_threshold = 5
        
    def record_error(self, error_type, error_message):
        """Registra un error y alerta si se supera un umbral."""
        key = error_type.__name__
        
        if key not in self.error_counts:
            self.error_counts[key] = {"count": 0, "examples": []}
            
        self.error_counts[key]["count"] += 1
        
        # Guardar ejemplo del error
        if len(self.error_counts[key]["examples"]) < 3:
            self.error_counts[key]["examples"].append(error_message)
            
        # Verificar umbral
        if self.error_counts[key]["count"] == self.alert_threshold:
            self._send_alert(key, self.error_counts[key])
            
    def _send_alert(self, error_type, error_data):
        """Envía una alerta cuando se supera el umbral de errores."""
        print(f"ALERTA: Se han detectado {error_data['count']} errores de tipo {error_type}")
        print(f"Ejemplos: {error_data['examples']}")
        # Implementar envío de alerta real (email, Slack, etc.)
```

## Solución de Problemas Comunes

| Error | Posible Causa | Solución |
|-------|---------------|----------|
| `DocumentParsingError: Failed to extract text` | PDF protegido o con formato complejo | Convertir a un formato más simple o verificar que no esté protegido |
| `ValidationError: Invalid criteria format` | Formato incorrecto de los criterios | Verificar estructura y tipos de datos en el objeto de criterios |
| `LLMError: Request timed out` | Timeout en la API | Aumentar el valor de timeout en la configuración o revisar problemas de red |
| `AuthenticationError: Invalid credentials` | Credenciales incorrectas o expiradas | Verificar y actualizar las credenciales del Service Principal |
| `RateLimitError: Rate limit exceeded` | Demasiadas peticiones a la API | Implementar limitación de velocidad o backoff exponencial |
| `TimeoutError: Operation timed out` | Operación demasiado lenta | Aumentar timeout o revisar complejidad del documento |
| `ConfigurationError: Missing required parameter` | Falta parámetro obligatorio | Revisar la configuración y asegurar que todos los parámetros requeridos estén presentes |