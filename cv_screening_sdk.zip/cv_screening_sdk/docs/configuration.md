# Guía de Configuración

Esta guía detalla todas las opciones de configuración disponibles en el CV Screening SDK y las mejores prácticas para configurarlo correctamente.

## Estructura de Configuración

El SDK utiliza un modelo de configuración jerárquico con las siguientes clases principales:

- **AzureConfig**: Configuración específica de Azure OpenAI
- **ClientConfig**: Configuración del cliente (timeouts, reintentos, etc.)
- **SDKConfig**: Configuración general del SDK que contiene las anteriores

## Configuración con Variables de Entorno

La forma más segura de configurar el SDK, especialmente en entornos de producción, es mediante variables de entorno:

### Variables de Entorno para Autenticación (Obligatorias)
```bash
# Credenciales de Azure AD (Service Principal)
export AZURE_TENANT_ID="your-tenant-id"
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"
```

### Variables de Entorno de Azure OpenAI (Obligatorias)
```bash
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="your-deployment-name"
```

### Variables de Entorno de Azure OpenAI (Opcionales)
```bash
export AZURE_OPENAI_MODEL_NAME="gpt-4"  # Predeterminado: gpt-4
export AZURE_OPENAI_API_VERSION="2023-05-15"  # Predeterminado: 2023-05-15
export AZURE_OPENAI_MAX_TOKENS="4000"  # Predeterminado: 4000
export AZURE_OPENAI_TEMPERATURE="0.7"  # Predeterminado: 0.7
export AZURE_OPENAI_TOP_P="1.0"  # Predeterminado: 1.0
export AZURE_OPENAI_FREQUENCY_PENALTY="0.0"  # Predeterminado: 0.0
export AZURE_OPENAI_PRESENCE_PENALTY="0.0"  # Predeterminado: 0.0
```

### Variables de Entorno del Cliente (Opcionales)
```bash
export CV_SCREENING_CLIENT_TIMEOUT="30"  # Segundos, predeterminado: 30
export CV_SCREENING_CLIENT_MAX_RETRIES="3"  # Predeterminado: 3
export CV_SCREENING_CLIENT_BATCH_SIZE="5"  # Predeterminado: 5
```

### Variables de Entorno de Logging (Opcionales)
```bash
export CV_SCREENING_LOG_LEVEL="INFO"  # Predeterminado: INFO
export CV_SCREENING_LOG_FILE="logs/cv_screening.log"  # Predeterminado: logs/cv_screening.log
export CV_SCREENING_LOG_FORMAT="%(asctime)s - %(name)s - %(levelname)s - %(message)s"  # Formato predeterminado
```

## Configuración Programática

También puedes configurar el SDK directamente en el código. Esta opción es útil para desarrollo y pruebas, pero no se recomienda para entornos de producción donde las credenciales deben manejarse de forma segura.

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk import AzureConfig, ClientConfig, SDKConfig, LogConfig

# Configuración de logging
log_config = LogConfig(
    file_path="logs/custom_log.log",
    level="DEBUG",
    format="%(asctime)s - [%(levelname)s] - %(name)s - %(message)s"
)

# Configuración de Azure OpenAI
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com/",
    deployment_name="your-deployment-name",
    model_name="gpt-4",
    api_version="2023-05-15",
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret",
    max_tokens=4000,
    temperature=0.7,
    top_p=1.0,
    frequency_penalty=0.0,
    presence_penalty=0.0
)

# Configuración del cliente
client_config = ClientConfig(
    timeout=30,
    max_retries=3,
    batch_size=5
)

# Configuración completa del SDK
sdk_config = SDKConfig(
    azure=azure_config,
    client=client_config,
    log=log_config
)

# Inicializar cliente con configuración personalizada
client = CVScreeningClient(config=sdk_config)
```

## Parámetros Detallados

### AzureConfig

| Parámetro | Tipo | Obligatorio | Predeterminado | Descripción |
|-----------|------|-------------|----------------|-------------|
| `endpoint` | str | Sí | - | URL del endpoint de Azure OpenAI |
| `deployment_name` | str | Sí | - | Nombre del despliegue en Azure OpenAI |
| `model_name` | str | No | "gpt-4" | Nombre del modelo a utilizar |
| `api_version` | str | No | "2023-05-15" | Versión de la API |
| `tenant_id` | str | Sí | - | ID del tenant de Azure AD |
| `client_id` | str | Sí | - | ID de cliente del Service Principal |
| `client_secret` | str | Sí | - | Secreto del Service Principal |
| `max_tokens` | int | No | 4000 | Máximo número de tokens para respuestas |
| `temperature` | float | No | 0.7 | Controla la aleatoriedad (0-2) |
| `top_p` | float | No | 1.0 | Muestreo de núcleo (0-1) |
| `frequency_penalty` | float | No | 0.0 | Penalización de frecuencia (-2 a 2) |
| `presence_penalty` | float | No | 0.0 | Penalización de presencia (-2 a 2) |

### ClientConfig

| Parámetro | Tipo | Obligatorio | Predeterminado | Descripción |
|-----------|------|-------------|----------------|-------------|
| `timeout` | int | No | 30 | Tiempo límite para operaciones en segundos |
| `max_retries` | int | No | 3 | Número máximo de reintentos para operaciones |
| `batch_size` | int | No | 5 | Tamaño del lote para procesamiento por lotes |

### LogConfig

| Parámetro | Tipo | Obligatorio | Predeterminado | Descripción |
|-----------|------|-------------|----------------|-------------|
| `file_path` | str | No | "logs/cv_screening.log" | Ruta del archivo de logs |
| `level` | str | No | "INFO" | Nivel de logging (DEBUG, INFO, WARNING, ERROR, CRITICAL) |
| `format` | str | No | "%(asctime)s - %(name)s - %(levelname)s - %(message)s" | Formato de los mensajes de log |

## Validación de Configuración

El SDK realiza validación automática de la configuración:

1. **Validación de tipo**: Comprueba que los valores son del tipo correcto.
2. **Validación de rango**: Comprueba que los valores numéricos están dentro del rango permitido.
3. **Validación de obligatoriedad**: Comprueba que están presentes todos los campos obligatorios.
4. **Validación de URL**: Comprueba que las URLs tienen un formato válido.

Si hay algún error en la configuración, el SDK lanzará una excepción `ConfigurationError` con un mensaje descriptivo.

## Configuración por Entorno

Es una buena práctica adaptar la configuración según el entorno (desarrollo, pruebas, producción):

```python
import os

# Determinar el entorno actual
environment = os.environ.get("ENVIRONMENT", "development")

# Crear configuración base
client_config = ClientConfig()

# Ajustar según el entorno
if environment == "production":
    client_config.timeout = 60
    client_config.max_retries = 5
    log_level = "WARNING"
elif environment == "testing":
    client_config.timeout = 10
    log_level = "INFO"
else:  # development
    client_config.timeout = 30
    log_level = "DEBUG"

# Aplicar configuración de logging
log_config = LogConfig(level=log_level)
```

## Validación de Credenciales

Para verificar que las credenciales son válidas antes de utilizarlas:

```python
from cv_screening_sdk.auth.azure import AzureAuthProvider
from cv_screening_sdk.core.exceptions import AuthenticationError

def validate_credentials(tenant_id, client_id, client_secret):
    try:
        # Crear proveedor de autenticación
        auth_provider = AzureAuthProvider(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        # Validar credenciales (esto intentará obtener un token)
        is_valid = auth_provider.validate_credentials()
        
        if is_valid:
            print("✅ Credenciales válidas")
            return True
        else:
            print("❌ Credenciales inválidas")
            return False
            
    except AuthenticationError as e:
        print(f"❌ Error de autenticación: {e}")
        return False
```

## Mejores Prácticas de Configuración

### Seguridad

1. **No guardar credenciales en código**: Nunca incluyas credenciales directamente en el código.
2. **Variables de entorno**: Utiliza variables de entorno o servicios de gestión de secretos (como Azure Key Vault).
3. **Rotación de credenciales**: Rota regularmente los secretos del Service Principal.
4. **Mínimo privilegio**: Aplica el principio de mínimo privilegio al Service Principal.

### Optimización

1. **Ajustar `max_tokens`**: Ajusta este valor según la longitud esperada de las respuestas.
2. **Ajustar `temperature`**: Valores más bajos (0.1-0.3) para respuestas más determinísticas, valores más altos (0.7-1.0) para respuestas más creativas.
3. **Ajustar `batch_size`**: Ajusta según la capacidad del sistema y la API.
4. **Ajustar `timeout`**: Ajusta según la complejidad de los documentos procesados.

### Solución de Problemas

Si encuentras problemas de configuración:

1. Verifica que todas las variables de entorno obligatorias están configuradas.
2. Comprueba que las credenciales del Service Principal son válidas y tienen los permisos necesarios.
3. Verifica que el endpoint y el nombre del despliegue son correctos.
4. Establece el nivel de logging a `DEBUG` para obtener más información.

## Opciones de configuración SSL para Azure OpenAI

Cuando se trabaja con Azure OpenAI, es posible que encuentres problemas relacionados con certificados SSL, especialmente en entornos corporativos o cuando se utilizan proxies. El SDK proporciona opciones para gestionar estos escenarios.

### Deshabilitar la verificación SSL

Si estás experimentando errores SSL al conectar con Azure, puedes deshabilitar la verificación SSL completamente:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, SDKConfig

# Configurar Azure sin verificación SSL
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com/",
    deployment_name="your-deployment",
    api_version="2023-05-15",
    ssl_verify=False  # Deshabilitar verificación SSL
)

# Crear configuración del SDK
config = SDKConfig(azure=azure_config)

# Inicializar el cliente
client = CVScreeningClient(config=config)
```

> **Advertencia**: Deshabilitar la verificación SSL puede representar un riesgo de seguridad, ya que expone la comunicación a potenciales ataques de intermediario (man-in-the-middle). Utiliza esta opción solo en entornos de desarrollo o cuando sea absolutamente necesario.

### Especificar un certificado SSL personalizado

Si tu organización utiliza un certificado SSL personalizado o autofirmado, puedes especificar la ruta al archivo del certificado:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, SDKConfig

# Configurar Azure con certificado personalizado
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com/",
    deployment_name="your-deployment",
    api_version="2023-05-15",
    ssl_cert_path="/ruta/al/certificado.pem"  # Ruta al certificado personalizado
)

# Crear configuración del SDK
config = SDKConfig(azure=azure_config)

# Inicializar el cliente
client = CVScreeningClient(config=config)
```

### Configuración a través de variables de entorno

También puedes configurar estas opciones mediante variables de entorno:

```bash
# Deshabilitar verificación SSL (establecer a "False")
export AZURE_OPENAI_SSL_VERIFY=False

# Especificar ruta de certificado personalizado
export AZURE_OPENAI_SSL_CERT_PATH=/ruta/al/certificado.pem
```

Estas opciones solo se aplican a las conexiones con Azure OpenAI, y no afectan a otras partes del SDK.