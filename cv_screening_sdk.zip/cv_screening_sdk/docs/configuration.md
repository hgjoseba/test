# Configuration Guide

## SDK Configuration

### Basic Setup
```python
from cv_screening_sdk import ClientConfig, SDKConfig, AzureConfig

# Azure-specific configuration
azure_config = AzureConfig(
    endpoint="https://your-azure-endpoint.openai.azure.com/",
    deployment_name="your-deployment",
    model_name="gpt-4",
    api_version="2023-05-15",
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret",
    max_tokens=4000,
    temperature=0.7,
    top_p=1.0,
    frequency_penalty=0.0,
    presence_penalty=0.0
)

# SDK-specific configuration
sdk_config = SDKConfig(
    max_batch_size=10,
    timeout_seconds=30,
    retry_attempts=3,
    log_level="INFO"
)

# Client configuration
config = ClientConfig(
    azure=azure_config,
    sdk=sdk_config
)
```

## Environment Variables

### Required Azure Credentials
```bash
export AZURE_OPENAI_ENDPOINT="your_endpoint"
export AZURE_OPENAI_DEPLOYMENT_NAME="your_deployment_name"
export AZURE_OPENAI_MODEL_NAME="gpt-4"
export AZURE_OPENAI_API_VERSION="2023-05-15"
export AZURE_TENANT_ID="your_tenant_id"
export AZURE_CLIENT_ID="your_client_id"
export AZURE_CLIENT_SECRET="your_client_secret"
```

### Optional Azure Configuration
```bash
export AZURE_OPENAI_MAX_TOKENS="4000"
export AZURE_OPENAI_TEMPERATURE="0.7"
export AZURE_OPENAI_TOP_P="1.0"
export AZURE_OPENAI_FREQUENCY_PENALTY="0.0"
export AZURE_OPENAI_PRESENCE_PENALTY="0.0"
```

### SDK Configuration
```bash
export CV_SCREENING_MAX_BATCH_SIZE="10"
export CV_SCREENING_TIMEOUT="30"
export CV_SCREENING_RETRY_ATTEMPTS="3"
export CV_SCREENING_LOG_LEVEL="INFO"
```

## Advanced Configuration

### Model Parameters
```python
azure_config = AzureConfig(
    # ... other settings ...
    max_tokens=4000,        # Maximum tokens for completions
    temperature=0.7,        # Controls randomness (0-2)
    top_p=1.0,             # Nucleus sampling (0-1)
    frequency_penalty=0.0,  # Reduces repetition (-2 to 2)
    presence_penalty=0.0    # Encourages diversity (-2 to 2)
)
```

### Validation Rules
- `endpoint`: Must be a valid URL starting with http:// or https://
- `deployment_name`: Must be provided and non-empty
- `model_name`: Must be provided and non-empty
- `api_version`: Must be provided and non-empty
- `tenant_id`, `client_id`, `client_secret`: All must be provided if using Service Principal authentication
- `max_tokens`: Must be positive
- `temperature`: Must be between 0 and 2
- `top_p`: Must be between 0 and 1
- `frequency_penalty`: Must be between -2 and 2
- `presence_penalty`: Must be between -2 and 2

### Error Handling
The configuration system includes comprehensive error handling:
- Type validation for numeric values
- Range validation for parameters
- URL format validation
- Required field validation
- Service Principal credential validation
- Environment variable parsing

### Configuration from Dictionary
```python
config_dict = {
    "endpoint": "https://your-endpoint.openai.azure.com/",
    "deployment_name": "your-deployment",
    "model_name": "gpt-4",
    "api_version": "2023-05-15",
    "tenant_id": "your-tenant-id",
    "client_id": "your-client-id",
    "client_secret": "your-client-secret",
    "max_tokens": 4000,
    "temperature": 0.7
}

azure_config = AzureConfig.from_dict(config_dict)
```

### Configuration to Dictionary
```python
config_dict = azure_config.to_dict()
```

## Best Practices

1. **Security**
   - Never commit credentials to version control
   - Use environment variables for sensitive data
   - Rotate credentials regularly
   - Use the minimum required permissions
   - Keep Service Principal credentials secure

2. **Performance**
   - Adjust `max_tokens` based on your needs
   - Use appropriate `temperature` for your use case
   - Consider using `frequency_penalty` and `presence_penalty` for better results
   - Monitor API usage and costs

3. **Error Handling**
   - Always validate configuration before use
   - Handle configuration errors gracefully
   - Log configuration changes
   - Monitor for invalid settings

4. **Maintenance**
   - Keep API versions up to date
   - Review and update model parameters regularly
   - Monitor Azure service status
   - Keep dependencies updated