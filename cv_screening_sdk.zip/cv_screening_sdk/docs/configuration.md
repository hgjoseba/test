# Guía de configuración

Esta guía proporciona información detallada sobre las opciones de configuración disponibles en el CV Screening SDK.

## Opciones de configuración

El SDK se compone de varias clases de configuración:

1. `AzureConfig`: Configuración para Azure OpenAI
2. `ClientConfig`: Configuración para el cliente del SDK
3. `LogConfig`: Configuración para el registro (logging)
4. `SDKConfig`: Configuración completa del SDK, que contiene las anteriores

## Estructura de configuración

### AzureConfig

```python
AzureConfig(
    # Requerido
    endpoint: str,
    deployment_name: str,
    
    # Opcional - Configuración de Azure OpenAI
    model_name: str = "gpt-4",
    api_version: str = "2023-05-15",
    tenant_id: Optional[str] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    max_tokens: int = 4000,
    temperature: float = 0.7,
    top_p: float = 1.0,
    frequency_penalty: float = 0.0,
    presence_penalty: float = 0.0,
    
    # Opcional - Configuración SSL
    ssl_verify: bool = True,
    ssl_cert_path: Optional[str] = None,
    
    # Opcional - Configuración de conexión
    connection_verify: bool = True,
    connection_timeout: int = 30,
    max_keepalive_connections: int = 5,
    max_connections: int = 10
)
```

| Parámetro | Tipo | Predeterminado | Variable de entorno | Descripción |
|-----------|------|---------------|---------------------|-------------|
| `endpoint` | str | *Requerido* | `AZURE_OPENAI_ENDPOINT` | URL del endpoint de Azure OpenAI |
| `deployment_name` | str | *Requerido* | `AZURE_OPENAI_DEPLOYMENT_NAME` | Nombre del despliegue de Azure OpenAI |
| `model_name` | str | "gpt-4" | `AZURE_OPENAI_MODEL_NAME` | Nombre del modelo a utilizar |
| `api_version` | str | "2023-05-15" | `AZURE_OPENAI_API_VERSION` | Versión de la API de Azure OpenAI |
| `tenant_id` | str | None | `AZURE_TENANT_ID` | ID del inquilino de Azure |
| `client_id` | str | None | `AZURE_CLIENT_ID` | ID del cliente de Azure |
| `client_secret` | str | None | `AZURE_CLIENT_SECRET` | Secreto del cliente de Azure |
| `max_tokens` | int | 4000 | `AZURE_OPENAI_MAX_TOKENS` | Máximo de tokens para generar |
| `temperature` | float | 0.7 | `AZURE_OPENAI_TEMPERATURE` | Temperatura para el muestreo (0-2) |
| `top_p` | float | 1.0 | `AZURE_OPENAI_TOP_P` | Muestreo de núcleo (nucleus sampling) (0-1) |
| `frequency_penalty` | float | 0.0 | `AZURE_OPENAI_FREQUENCY_PENALTY` | Penalización por frecuencia (-2 a 2) |
| `presence_penalty` | float | 0.0 | `AZURE_OPENAI_PRESENCE_PENALTY` | Penalización por presencia (-2 a 2) |
| `ssl_verify` | bool | True | `AZURE_OPENAI_SSL_VERIFY` | Verificar certificados SSL |
| `ssl_cert_path` | str | None | `AZURE_OPENAI_SSL_CERT_PATH` | Ruta a un certificado SSL personalizado |
| `connection_verify` | bool | True | `AZURE_OPENAI_CONNECTION_VERIFY` | Verificar conexiones SSL en autenticación Azure |
| `connection_timeout` | int | 30 | `AZURE_OPENAI_CONNECTION_TIMEOUT` | Tiempo de espera de conexión en segundos |
| `max_keepalive_connections` | int | 5 | `AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS` | Máximo de conexiones keepalive |
| `max_connections` | int | 10 | `AZURE_OPENAI_MAX_CONNECTIONS` | Máximo total de conexiones |

### ClientConfig

```python
ClientConfig(
    timeout: int = 30,
    max_retries: int = 3,
    batch_size: int = 5
)
```

| Parámetro | Tipo | Predeterminado | Variable de entorno | Descripción |
|-----------|------|---------------|---------------------|-------------|
| `timeout` | int | 30 | `CV_SCREENING_CLIENT_TIMEOUT` | Tiempo de espera para operaciones del cliente (segundos) |
| `max_retries` | int | 3 | `CV_SCREENING_CLIENT_MAX_RETRIES` | Número máximo de reintentos para operaciones |
| `batch_size` | int | 5 | `CV_SCREENING_CLIENT_BATCH_SIZE` | Tamaño del lote para procesamiento por lotes |

### LogConfig

```python
LogConfig(
    file_path: str = "logs/cv_screening.log",
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level: str = "INFO"
)
```

| Parámetro | Tipo | Predeterminado | Variable de entorno | Descripción |
|-----------|------|---------------|---------------------|-------------|
| `file_path` | str | "logs/cv_screening.log" | `CV_SCREENING_LOG_FILE` | Ruta al archivo de registro |
| `format` | str | "%(asctime)s - %(name)s - %(levelname)s - %(message)s" | `CV_SCREENING_LOG_FORMAT` | Formato del mensaje de registro |
| `level` | str | "INFO" | `CV_SCREENING_LOG_LEVEL` | Nivel de registro (DEBUG, INFO, WARNING, ERROR, CRITICAL) |

### SDKConfig

```python
SDKConfig(
    azure: AzureConfig = AzureConfig(...),  # Usa valores por defecto
    client: ClientConfig = ClientConfig(),  # Usa valores por defecto
    log: LogConfig = LogConfig()  # Usa valores por defecto
)
```

## Métodos de configuración

### Configuración a través de variables de entorno

El método más seguro y recomendado para configurar el SDK es mediante variables de entorno:

```bash
# Configuración de autenticación de Azure (requerida)
export AZURE_TENANT_ID="tu-tenant-id"
export AZURE_CLIENT_ID="tu-client-id"
export AZURE_CLIENT_SECRET="tu-client-secret"

# Configuración de Azure OpenAI (requerida)
export AZURE_OPENAI_ENDPOINT="https://tu-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="tu-deployment-name"
export AZURE_OPENAI_MODEL_NAME="gpt-4"  # Opcional, predeterminado: gpt-4
export AZURE_OPENAI_API_VERSION="2023-05-15"  # Opcional, predeterminado: 2023-05-15

# Configuración SSL
export AZURE_OPENAI_SSL_VERIFY="True"  # Opcional, predeterminado: True
export AZURE_OPENAI_SSL_CERT_PATH="/ruta/a/certificado.pem"  # Opcional

# Configuración de conexión
export AZURE_OPENAI_CONNECTION_VERIFY="True"  # Opcional, predeterminado: True
export AZURE_OPENAI_CONNECTION_TIMEOUT="30"  # Opcional, predeterminado: 30
export AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS="5"  # Opcional, predeterminado: 5
export AZURE_OPENAI_MAX_CONNECTIONS="10"  # Opcional, predeterminado: 10

# Configuración del cliente
export CV_SCREENING_CLIENT_TIMEOUT="30"  # Opcional, predeterminado: 30
export CV_SCREENING_CLIENT_MAX_RETRIES="3"  # Opcional, predeterminado: 3
export CV_SCREENING_CLIENT_BATCH_SIZE="5"  # Opcional, predeterminado: 5

# Configuración de registro
export CV_SCREENING_LOG_FILE="logs/cv_screening.log"  # Opcional
export CV_SCREENING_LOG_FORMAT="%(asctime)s - %(name)s - %(levelname)s - %(message)s"  # Opcional
export CV_SCREENING_LOG_LEVEL="INFO"  # Opcional, predeterminado: INFO
```

Con estas variables de entorno configuradas, puedes inicializar el cliente sin proporcionar configuración explícita:

```python
from cv_screening_sdk import CVScreeningClient

# La configuración se cargará automáticamente desde las variables de entorno
client = CVScreeningClient()
```

### Configuración programática

También puedes configurar el SDK programáticamente:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, LogConfig, SDKConfig

# Configuración de Azure
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    tenant_id="tu-tenant-id",
    client_id="tu-client-id",
    client_secret="tu-client-secret",
    ssl_verify=True,
    connection_verify=True,
    connection_timeout=30,
    max_keepalive_connections=5,
    max_connections=10
)

# Configuración del cliente
client_config = ClientConfig(
    timeout=30,
    max_retries=3,
    batch_size=5
)

# Configuración de registro
log_config = LogConfig(
    file_path="logs/cv_screening.log",
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level="INFO"
)

# Configuración completa del SDK
sdk_config = SDKConfig(
    azure=azure_config,
    client=client_config,
    log=log_config
)

# Inicializar cliente con configuración personalizada
client = CVScreeningClient(config=sdk_config)
```

### Configuración mixta

Puedes combinar la configuración desde variables de entorno y código:

```python
# Cargar configuración básica desde variables de entorno
azure_config = AzureConfig.from_env()

# Sobrescribir valores específicos
azure_config.max_tokens = 2000
azure_config.temperature = 0.8
azure_config.connection_timeout = 60

# Inicializar el cliente
client = CVScreeningClient(
    config=SDKConfig(azure=azure_config)
)
```

## Configuración SSL para entornos corporativos

Si trabajas en un entorno corporativo con configuraciones de proxy o certificados SSL personalizados, puedes ajustar las opciones SSL:

### Desactivar verificación SSL (solo para desarrollo)

```python
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    # Otros parámetros...
    ssl_verify=False  # ¡Usar con precaución! Solo para entornos de desarrollo
)
```

### Usar un certificado SSL personalizado

```python
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    # Otros parámetros...
    ssl_verify=True,
    ssl_cert_path="/ruta/a/tu/certificado.pem"  # Ruta al archivo del certificado SSL
)
```

### Configurar verificación de conexión en Azure Credentials

La verificación de conexión se utiliza específicamente en las credenciales de Azure:

```python
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    tenant_id="tu-tenant-id",
    client_id="tu-client-id",
    client_secret="tu-client-secret",
    # Otros parámetros...
    connection_verify=True  # Verifica conexiones SSL en la autenticación de Azure
)
```

## Configuración de conexión HTTP avanzada

Para entornos con requisitos específicos de red, puedes ajustar los parámetros de conexión HTTP:

```python
azure_config = AzureConfig(
    # Parámetros básicos...
    connection_timeout=60,  # Aumentar el tiempo de espera para redes lentas (segundos)
    max_keepalive_connections=10,  # Aumentar para alto rendimiento
    max_connections=20  # Aumentar para alto rendimiento
)
```

Estos parámetros afectan a la biblioteca HTTPX utilizada internamente para las conexiones HTTP a Azure OpenAI.

## Mejores prácticas de configuración

1. **Usa variables de entorno para credenciales**
   - Las credenciales son más seguras cuando se almacenan como variables de entorno
   - Evita codificar credenciales directamente en el código

2. **Archivos de entorno (.env)**
   - Usa un archivo `.env` con `python-dotenv` para gestionar variables de entorno
   - Mantén los archivos `.env` fuera del control de versiones (agrega a `.gitignore`)

3. **Configuración adaptada al entorno**
   - Utiliza diferentes configuraciones para desarrollo, pruebas y producción
   - Configura tiempos de espera más cortos en entornos de desarrollo y más largos en producción

4. **Validación de configuración**
   - La clase `AzureConfig` valida automáticamente los parámetros al inicializarse
   - Captura las excepciones `ConfigurationError` para manejar errores de configuración

5. **Rotación de credenciales**
   - Implementa un sistema para rotar regularmente las credenciales de Azure
   - Usa sistemas de gestión de secretos como Azure Key Vault o HashiCorp Vault