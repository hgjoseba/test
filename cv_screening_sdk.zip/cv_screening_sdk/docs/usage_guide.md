# CV Screening SDK Usage Guide

## Installation

```bash
pip install cv-screening-sdk
```

## Basic Configuration

### 1. Azure OpenAI Configuration

The SDK requires Azure OpenAI credentials to function. There are two ways to configure the credentials:

#### A. Using environment variables

```bash
# Required configuration
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="your-deployment-name"
export AZURE_TENANT_ID="your-tenant-id"
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"

# Optional configuration
export AZURE_OPENAI_MODEL_NAME="gpt-4"  # Default: gpt-4
export AZURE_OPENAI_API_VERSION="2023-05-15"  # Default: 2023-05-15
export AZURE_OPENAI_MAX_TOKENS="4000"  # Default: 4000
export AZURE_OPENAI_TEMPERATURE="0.7"  # Default: 0.7
export AZURE_OPENAI_TOP_P="1.0"  # Default: 1.0
export AZURE_OPENAI_FREQUENCY_PENALTY="0.0"  # Default: 0.0
export AZURE_OPENAI_PRESENCE_PENALTY="0.0"  # Default: 0.0
```

#### B. Using Python code

```python
from cv_screening_sdk import AzureConfig, SDKConfig, ClientConfig

# Azure configuration
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com/",
    deployment_name="your-deployment-name",
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret",
    model_name="gpt-4",  # Optional
    api_version="2023-05-15",  # Optional
    max_tokens=4000,  # Optional
    temperature=0.7,  # Optional
    top_p=1.0,  # Optional
    frequency_penalty=0.0,  # Optional
    presence_penalty=0.0  # Optional
)

# SDK configuration
sdk_config = SDKConfig(
    max_batch_size=10,  # Optional
    timeout_seconds=30,  # Optional
    retry_attempts=3,  # Optional
    log_level="INFO"  # Optional
)

# Client configuration
client_config = ClientConfig(
    azure=azure_config,
    sdk=sdk_config
)
```

## Basic Usage

### 1. Initialize the client

```python
from cv_screening_sdk import CVScreeningClient

# Initialize with default configuration (using environment variables)
client = CVScreeningClient()

# Or initialize with custom configuration
client = CVScreeningClient(config=client_config)
```

### 2. Analyze a CV

```python
# Analyze a single CV
cv_path = "path/to/cv.pdf"
job_criteria = {
    "title": "Software Engineer",
    "required_skills": ["Python", "Docker", "AWS"],
    "experience_years": 3,
    "education": "Bachelor's degree in Computer Science or related field",
    "location": "Remote",
    "employment_type": "Full-time"
}

result = client.analyze_cv(cv_path, job_criteria)
print(result.summary)
print(result.match_score)
print(result.skill_matches)
```

### 3. Process multiple CVs

```python
# Process multiple CVs in batch
cv_paths = ["cv1.pdf", "cv2.pdf", "cv3.pdf"]
results = client.analyze_cvs_batch(cv_paths, job_criteria)

for cv_path, result in results.items():
    print(f"\nResults for {cv_path}:")
    print(f"Match Score: {result.match_score}")
    print(f"Summary: {result.summary}")
```

### 4. Asynchronous Processing

```python
import asyncio

async def process_cvs():
    # Process CVs asynchronously
    cv_paths = ["cv1.pdf", "cv2.pdf", "cv3.pdf"]
    async for result in client.analyze_cvs_async(cv_paths, job_criteria):
        print(f"CV processed: {result.cv_path}")
        print(f"Match Score: {result.match_score}")

# Run asynchronous processing
asyncio.run(process_cvs())
```

### 5. Plain Text Processing

The SDK also allows processing CV content directly as plain text, without needing to parse documents:

```python
from cv_screening_sdk import CVScreeningClient, JobCriteria
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig

# Initialize the client
client = CVScreeningClient(config)

# Define evaluation criteria
criteria = JobCriteria(
    required_skills=["Python", "AWS", "Docker"],
    preferred_skills=["Kubernetes", "CI/CD"],
    min_years_experience=3,
    education_level="Bachelor's",
    role_title="Software Engineer"
)

# Process CV as plain text
cv_text = """
Name: John Doe
Experience: 5 years as Python developer
Education: Bachelor's in Computer Science
Skills: Python, AWS, Docker, Kubernetes
"""

# Analyze CV in plain text
result = client.analyze_cv(cv_text, criteria)

# Process and display results
print("\n=== CV Analysis Results ===")
print(f"Match Score: {result.overall_score}/100")

# Skills analysis
print("\n=== Skills Analysis ===")
print("\nRequired Skills Found:")
for skill in result.skills_found:
    print(f"✓ {skill}")

print("\nMissing Required Skills:")
for skill in result.missing_skills:
    print(f"✗ {skill}")

print("\n=== Candidate Profile ===")
print(f"Experience: {result.experience_years} years")
print(f"Education Level: {result.education_level}")
print(f"Key Strengths: {', '.join(result.key_strengths)}")
print(f"Areas for Improvement: {', '.join(result.areas_for_improvement)}")

print("\n=== Overall Assessment ===")
print(result.summary)
```

This functionality is particularly useful when:
- You already have the CV content in text format
- You don't need the PDF or DOCX text extraction functionality
- You want to process CVs that are already in plain text format
- You need to integrate the SDK with systems that already handle CV text

## Error Handling

```python
from cv_screening_sdk.core.exceptions import (
    ConfigurationError,
    AuthenticationError,
    ProcessingError
)

try:
    result = client.analyze_cv(cv_path, job_criteria)
except ConfigurationError as e:
    print(f"Configuration error: {e}")
except AuthenticationError as e:
    print(f"Authentication error: {e}")
except ProcessingError as e:
    print(f"Processing error: {e}")
```

## Advanced Configuration

### 1. SDK Configuration via Environment Variables

```bash
export CV_SCREENING_MAX_BATCH_SIZE="10"
export CV_SCREENING_TIMEOUT="30"
export CV_SCREENING_RETRY_ATTEMPTS="3"
export CV_SCREENING_LOG_LEVEL="INFO"
```

### 2. Credential Validation

```python
# Validate current credentials
if client.auth_provider.validate_credentials():
    print("Credentials are valid")

# Refresh credentials if needed
client.auth_provider.refresh_credentials()
```

### 3. Configuration via YAML File

```yaml
# config.yml
sdk:
  max_batch_size: 10
  timeout_seconds: 30
  retry_attempts: 3
  log_level: "INFO"

azure:
  endpoint: "https://your-endpoint.openai.azure.com/"
  deployment_name: "your-deployment"
  model_name: "gpt-4"
  api_version: "2023-05-15"
  tenant_id: "your-tenant-id"
  client_id: "your-client-id"
  client_secret: "your-client-secret"
  max_tokens: 4000
  temperature: 0.7
  top_p: 1.0
  frequency_penalty: 0.0
  presence_penalty: 0.0
```

```python
import yaml

# Load configuration from YAML file
with open("config.yml") as f:
    config_dict = yaml.safe_load(f)

# Create client configuration
client_config = ClientConfig.from_dict(config_dict)
client = CVScreeningClient(config=client_config)
```

## Best Practices

1. **Security**
   - Never include credentials in code
   - Use environment variables or secure configuration files
   - Rotate credentials regularly
   - Use minimum required permissions
   - Keep Service Principal credentials secure

2. **Performance**
   - Adjust `max_tokens` according to your needs
   - Use appropriate `temperature` for your use case
   - Consider using `frequency_penalty` and `presence_penalty` for better results
   - Monitor API usage and costs

3. **Error Handling**
   - Always validate configuration before use
   - Handle errors appropriately
   - Log configuration changes
   - Monitor invalid configurations

4. **Maintenance**
   - Keep API versions updated
   - Regularly review and update model parameters
   - Monitor Azure service status
   - Keep dependencies updated 