# Usage Guide for CV Screening SDK

## Installation

```bash
pip install cv-screening-sdk
```

## Configuration

### Configuration with Environment Variables

The safest way to configure the SDK is by using environment variables:

```bash
# Azure AD Authentication Configuration (required)
export AZURE_TENANT_ID="your-tenant-id"
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"

# Azure OpenAI Configuration (required)
export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="your-deployment-name"

# Optional Azure OpenAI Configuration
export AZURE_OPENAI_MODEL_NAME="gpt-4"  # Default: gpt-4
export AZURE_OPENAI_API_VERSION="2023-05-15"  # Default: 2023-05-15
export AZURE_OPENAI_MAX_TOKENS="4000"  # Default: 4000
export AZURE_OPENAI_TEMPERATURE="0.7"  # Default: 0.7

# Optional SSL Configuration for Azure
export AZURE_OPENAI_SSL_VERIFY="True"  # Set to "False" to disable SSL verification
export AZURE_OPENAI_SSL_CERT_PATH="/path/to/cert.pem"  # Path to custom SSL certificate

# Optional SDK Configuration
export CV_SCREENING_CLIENT_TIMEOUT="30"  # Default: 30 seconds
export CV_SCREENING_CLIENT_MAX_RETRIES="3"  # Default: 3 retries
export CV_SCREENING_CLIENT_BATCH_SIZE="5"  # Default: 5 CVs per batch
export CV_SCREENING_LOG_LEVEL="INFO"  # Default: INFO
```

### Configuration through Code

You can also configure the SDK directly in your code:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk import AzureConfig, ClientConfig, SDKConfig

# Azure OpenAI Configuration
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com/",
    deployment_name="your-deployment-name",
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret",
    model_name="gpt-4",  # Optional
    max_tokens=4000,  # Optional
    temperature=0.7,  # Optional
    ssl_verify=True,  # Optional, set to False to disable SSL verification
    ssl_cert_path=None  # Optional, path to custom SSL certificate
)

# Client Configuration
client_config = ClientConfig(
    timeout=30,  # Optional
    max_retries=3,  # Optional
    batch_size=5  # Optional
)

# Complete SDK Configuration
sdk_config = SDKConfig(
    azure=azure_config,
    client=client_config
)

# Initialize the client with configuration
client = CVScreeningClient(config=sdk_config)
```

### SSL Configuration for Corporate Environments

If you're working in a corporate environment with custom SSL certificates or proxy setups, you might need to adjust SSL settings:

```python
# Disable SSL verification (use with caution, only in development)
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com/",
    deployment_name="your-deployment-name",
    # Other parameters...
    ssl_verify=False
)

# Or use a custom SSL certificate
azure_config = AzureConfig(
    endpoint="https://your-endpoint.openai.azure.com/",
    deployment_name="your-deployment-name",
    # Other parameters...
    ssl_cert_path="/path/to/your/certificate.pem"
)
```

## Basic Usage

### 1. Initialize the Client

```python
from cv_screening_sdk import CVScreeningClient

# Initialize with environment variables (recommended)
client = CVScreeningClient()

# Or with custom configuration
client = CVScreeningClient(config=sdk_config)
```

### 2. Analyze CV Text

The most basic method allows you to directly analyze CV text:

```python
# CV content as text
cv_text = """
Name: John Smith
Experience: 5 years as Python Developer
Education: Bachelor's in Computer Science
Skills: Python, AWS, Docker, Kubernetes
"""

# Evaluation criteria
criteria = {
    "required_skills": ["Python", "AWS"],
    "preferred_skills": ["Docker", "Kubernetes"],
    "min_years_experience": 3,
    "education_level": "bachelors",
    "role_title": "Senior Developer"
}

# Analyze the CV
result = client.analyze_cv(cv_text, criteria)

# Process results
print(f"Score: {result.overall_match}/100")
print(f"Skills found: {result.skills_found}")
print(f"Experience: {result.experience_years} years")
print(f"Education: {result.education_level}")
```

### 3. Evaluate CV File

You can evaluate a CV file (PDF, DOCX, TXT) using the `screen_cv` method:

```python
# Evaluate a CV file
result = client.screen_cv("path/to/resume.pdf", criteria)

# Display detailed results
print("\n=== Evaluation Results ===")
print(f"Overall score: {result.overall_match}/100")

print("\n=== Skills Analysis ===")
print(f"Skills score: {result.skill_matches.overall_score}/100")
print("\nRequired Skills Found:")
for skill, score in result.skill_matches.required_skills.items():
    print(f"✓ {skill}: {score*100:.0f}%")

print("\nMissing Required Skills:")
for skill in result.skill_matches.missing_required:
    print(f"✗ {skill}")

print("\n=== Candidate Profile ===")
print(f"Experience: {result.experience_match.years_of_experience} years")
print(f"Experience relevance: {result.experience_match.relevance_score*100:.0f}%")
print(f"Meets minimum requirements: {'Yes' if result.experience_match.meets_minimum else 'No'}")

print(f"Education: {result.education_level}")
print(f"Field relevance: {result.education_match.field_relevance*100:.0f}%")

print("\n=== Summary ===")
print(result.summary)
```

### 4. Create Structured Criteria

You can use the `JobCriteria` class to define criteria in a structured way:

```python
from cv_screening_sdk import JobCriteria

# Create a criteria object
criteria = JobCriteria(
    required_skills=["Python", "AWS", "Docker"],
    preferred_skills=["Kubernetes", "CI/CD"],
    min_years_experience=3,
    preferred_years_experience=5,
    education_level="bachelors",  # options: any, high school, associate, bachelors, masters, phd
    education_field="Computer Science",
    role_title="Senior Software Engineer",
    description="Responsible for backend development and cloud infrastructure",
    industry="Technology"
)

# Evaluate CV with these criteria
result = client.screen_cv("path/to/resume.pdf", criteria)
```

### 5. Batch Processing

To process multiple CVs at once:

```python
# List of CV file paths
cv_paths = [
    "path/to/resume1.pdf",
    "path/to/resume2.docx",
    "path/to/resume3.txt"
]

# Load CV content
cv_contents = []
for path in cv_paths:
    cv_contents.append(client.load_cv_content(path))

# Process all CVs with the same criteria
batch_result = client.batch_screen_cvs(cv_contents, criteria, cv_paths)

# Get general statistics
print(f"Total CVs processed: {batch_result.total_items}")
print(f"Success rate: {batch_result.success_rate()*100:.2f}%")
print(f"Average score: {batch_result.average_score():.2f}/100")

# Process individual results
print("\n=== Top Candidates ===")
# Sort by score
sorted_results = sorted(
    batch_result.successful_results, 
    key=lambda x: x.overall_match, 
    reverse=True
)

for i, result in enumerate(sorted_results[:3]):  # Top 3
    print(f"\n{i+1}. CV: {result.cv_id}")
    print(f"   Score: {result.overall_match:.2f}/100")
    print(f"   Skills: {', '.join(list(result.skill_matches.required_skills.keys())[:5])}")
    print(f"   Experience: {result.experience_years} years")
    print(f"   Education: {result.education_level}")

# Check processing failures
if batch_result.failed_results:
    print("\n=== Processing Errors ===")
    for failure in batch_result.failed_results:
        print(f"Error in {failure.cv_path}: {failure.error}")
```

### 6. Asynchronous Processing

For asynchronous CV processing:

```python
import asyncio

async def process_cvs_async():
    # Process a CV asynchronously
    result = await client.screen_cv_async("path/to/resume.pdf", criteria)
    print(f"Score: {result.overall_match}/100")
    
    # Process multiple CVs concurrently
    cv_paths = ["cv1.pdf", "cv2.pdf", "cv3.pdf"]
    
    # Load CV content
    cv_contents = []
    for path in cv_paths:
        cv_contents.append(client.load_cv_content(path))
    
    # Create asynchronous tasks
    tasks = [client.screen_cv_async(content, criteria, path) for content, path in zip(cv_contents, cv_paths)]
    
    # Run all tasks and get results
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Process results
    for i, result in enumerate(results):
        if isinstance(result, Exception):
            print(f"Error processing {cv_paths[i]}: {result}")
        else:
            print(f"CV {cv_paths[i]} score: {result.overall_match:.2f}/100")

# Run asynchronous function
asyncio.run(process_cvs_async())
```

### 7. Using analyze_cvs_batch for Sequential Processing

For processing multiple CVs in sequence with asynchronous calls:

```python
import asyncio

async def analyze_multiple_cvs():
    # List of CV contents
    cv_contents = [cv1_text, cv2_text, cv3_text]
    
    # Define criteria
    criteria = {
        "required_skills": ["Python", "AWS"],
        "min_years_experience": 3
    }
    
    # Process batch
    results = await client.analyze_cvs_batch(cv_contents, criteria)
    
    # Process results
    for i, result in enumerate(results):
        print(f"CV {i+1} match score: {result['overall_match']}%")

# Run asynchronous function
asyncio.run(analyze_multiple_cvs())
```

## Advanced Usage

### Custom Prompts

You can provide custom prompts for more specific analysis:

```python
# Define a custom prompt
custom_prompt = """
This CV is for a Senior Machine Learning Engineer position.
Please evaluate the candidate's experience with TensorFlow and PyTorch,
and assess their research publications in the field of deep learning.
"""

# Use the prompt as criteria
result = client.analyze_cv(cv_text, custom_prompt)
```

### Integrating with Other Tools

You can integrate the SDK with other tools in your recruitment workflow:

```python
import pandas as pd

# Process a batch of CVs
batch_result = client.batch_screen_cvs(cv_contents, criteria, cv_paths)

# Convert to DataFrame for further analysis
data = []
for result in batch_result.successful_results:
    data.append({
        "CV": result.cv_id,
        "Score": result.overall_match,
        "Experience": result.experience_years,
        "Education": result.education_level,
        "Skills": ", ".join(result.skills_found),
        "Summary": result.summary
    })

df = pd.DataFrame(data)

# Sort, filter, or further process
qualified = df[df["Score"] > 70].sort_values("Score", ascending=False)

# Export to CSV
qualified.to_csv("qualified_candidates.csv", index=False)
```

## Supported Document Formats and Dependencies

The SDK supports processing various document formats, but requires specific dependencies for each:

### Document Format Support

| Format | Extension | Required Dependency | Installation |
|--------|-----------|---------------------|-------------|
| Plain Text | `.txt` | Built-in | No additional dependencies |
| PDF | `.pdf` | PyPDF2 | `pip install PyPDF2>=3.0.0` |
| Microsoft Word | `.docx` | python-docx | `pip install python-docx>=0.8.11` |

### Installing Document Processing Dependencies

You can install all document processing dependencies at once using the wheel package:

```bash
# Build the wheel package
python setup.py bdist_wheel

# Install with document processing support
pip install dist/cv_screening_sdk-*.whl[document_processing]

# Install with all dependencies
pip install dist/cv_screening_sdk-*.whl[all]

# Or install individual dependencies after installing the base package
pip install PyPDF2>=3.0.0 python-docx>=0.8.11
```

### Development Installation

For developers working on the SDK, you can install it in development mode:

```bash
# Clone the repository
git clone https://github.com/yourusername/cv-screening-sdk.git
cd cv-screening-sdk

# Install in development mode with all dependencies
pip install -e .[document_processing,dev,test]

# Or with specific dependency groups
pip install -e .[document_processing,dev,test]
```

This creates a link to your source code, so changes will take effect immediately without reinstalling.

### Loading CV Content From Files

The SDK provides a helper method to load CV content from files:

```python
# Load content from a PDF file
pdf_content = client.load_cv_content("path/to/resume.pdf")

# Load content from a DOCX file
docx_content = client.load_cv_content("path/to/resume.docx")

# Load content from a text file
text_content = client.load_cv_content("path/to/resume.txt")
```

### Error Handling for Document Processing

```python
from cv_screening_sdk.core.exceptions import DocumentParsingError, FileNotFoundError

try:
    content = client.load_cv_content("path/to/resume.pdf")
    result = client.screen_cv(content, criteria, "path/to/resume.pdf")
except FileNotFoundError:
    print("The CV file could not be found.")
except DocumentParsingError as e:
    print(f"Failed to parse the CV document: {str(e)}")
    # You might fall back to a different parser or notify the user
except Exception as e:
    print(f"An unexpected error occurred: {str(e)}")
```

## Performance Best Practices

1. **Batch Processing**
   - Use `batch_screen_cvs` for processing multiple CVs
   - Consider using a reasonable batch size (5-10 CVs per batch) to balance throughput and resource usage
   
2. **Asynchronous Processing**
   - For interactive applications, use the async methods (`analyze_cv_async`, `screen_cv_async`)
   - For backend processing, use batch processing with appropriate batch sizes
   
3. **Document Caching**
   - Consider caching parsed document content when processing the same CV multiple times
   - Remember that PDF and DOCX parsing is CPU-intensive
   
4. **Error Handling**
   - Always implement appropriate error handling, especially for document parsing
   - Provide meaningful error messages to users
   - Consider implementing retry logic for transient errors 