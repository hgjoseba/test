# Guía de uso para CV Screening SDK

## Instalación

```bash
pip install cv-screening-sdk
```

## Configuración

### Configuración con variables de entorno

La forma más segura de configurar el SDK es utilizando variables de entorno:

```bash
# Configuración de autenticación de Azure AD (requerida)
export AZURE_TENANT_ID="tu-tenant-id"
export AZURE_CLIENT_ID="tu-client-id"
export AZURE_CLIENT_SECRET="tu-client-secret"

# Configuración de Azure OpenAI (requerida)
export AZURE_OPENAI_ENDPOINT="https://tu-endpoint.openai.azure.com/"
export AZURE_OPENAI_DEPLOYMENT_NAME="tu-deployment-name"

# Configuración opcional de Azure OpenAI
export AZURE_OPENAI_MODEL_NAME="gpt-4"  # Por defecto: gpt-4
export AZURE_OPENAI_API_VERSION="2023-05-15"  # Por defecto: 2023-05-15
export AZURE_OPENAI_MAX_TOKENS="4000"  # Por defecto: 4000
export AZURE_OPENAI_TEMPERATURE="0.7"  # Por defecto: 0.7

# Configuración SSL para Azure
export AZURE_OPENAI_SSL_VERIFY="True"  # Establecer en "False" para desactivar la verificación SSL
export AZURE_OPENAI_SSL_CERT_PATH="/ruta/a/certificado.pem"  # Ruta al certificado SSL personalizado

# Configuración de conexión para Azure
export AZURE_OPENAI_CONNECTION_VERIFY="True"  # Establecer en "False" para desactivar la verificación de conexión
export AZURE_OPENAI_CONNECTION_TIMEOUT="30"  # Tiempo de espera de conexión en segundos
export AZURE_OPENAI_MAX_KEEPALIVE_CONNECTIONS="5"  # Número máximo de conexiones keepalive
export AZURE_OPENAI_MAX_CONNECTIONS="10"  # Número máximo total de conexiones

# Configuración opcional del SDK
export CV_SCREENING_CLIENT_TIMEOUT="30"  # Por defecto: 30 segundos
export CV_SCREENING_CLIENT_MAX_RETRIES="3"  # Por defecto: 3 reintentos
export CV_SCREENING_CLIENT_BATCH_SIZE="5"  # Por defecto: 5 CVs por lote
export CV_SCREENING_LOG_LEVEL="INFO"  # Por defecto: INFO
```

### Configuración a través del código

También puedes configurar el SDK directamente en tu código:

```python
from cv_screening_sdk import CVScreeningClient
from cv_screening_sdk.core.config import AzureConfig, ClientConfig, SDKConfig

# Configuración de Azure OpenAI
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    tenant_id="tu-tenant-id",
    client_id="tu-client-id",
    client_secret="tu-client-secret",
    model_name="gpt-4",  # Opcional
    max_tokens=4000,  # Opcional
    temperature=0.7,  # Opcional
    
    # Configuración SSL
    ssl_verify=True,  # Opcional, establecer en False para desactivar la verificación SSL
    ssl_cert_path=None,  # Opcional, ruta al certificado SSL personalizado
    
    # Configuración de conexión
    connection_verify=True,  # Opcional, para verificación SSL en conexiones de autenticación
    connection_timeout=30,  # Opcional, tiempo de espera en segundos
    max_keepalive_connections=5,  # Opcional, máximo de conexiones keepalive
    max_connections=10  # Opcional, máximo total de conexiones
)

# Configuración del cliente
client_config = ClientConfig(
    timeout=30,  # Opcional
    max_retries=3,  # Opcional
    batch_size=5  # Opcional
)

# Configuración completa del SDK
sdk_config = SDKConfig(
    azure=azure_config,
    client=client_config
)

# Inicializar el cliente con la configuración
client = CVScreeningClient(config=sdk_config)
```

### Configuración SSL para entornos corporativos

Si estás trabajando en un entorno corporativo con certificados SSL personalizados o configuraciones de proxy, es posible que necesites ajustar la configuración SSL:

```python
# Desactivar la verificación SSL (usar con precaución, solo en desarrollo)
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    # Otros parámetros...
    ssl_verify=False
)

# O usar un certificado SSL personalizado
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    # Otros parámetros...
    ssl_cert_path="/ruta/a/tu/certificado.pem"
)
```

## Uso básico

### 1. Inicializar el cliente

```python
from cv_screening_sdk import CVScreeningClient

# Inicializar con variables de entorno (recomendado)
client = CVScreeningClient()

# O con configuración personalizada
client = CVScreeningClient(config=sdk_config)
```

### 2. Analizar texto de CV

El método más básico te permite analizar directamente el texto de un CV:

```python
from cv_screening_sdk import JobCriteria

# Contenido del CV como texto
cv_text = """
Nombre: John Smith
Experiencia: 5 años como Desarrollador Python
Educación: Licenciatura en Ciencias de la Computación
Habilidades: Python, AWS, Docker, Kubernetes
"""

# Criterios de evaluación
criteria = JobCriteria(
    required_skills=["Python", "AWS"],
    preferred_skills=["Docker", "Kubernetes"],
    min_years_experience=3,
    education_level="bachelors",
    role_title="Desarrollador Senior"
)

# Analizar el CV
result = client.analyze_cv(cv_text, criteria)

# Procesar resultados
print(f"Puntuación: {result.overall_score}/100")
print(f"Habilidades encontradas: {result.skills_found}")
print(f"Experiencia: {result.experience_years} años")
print(f"Educación: {result.education_level}")
```

### 3. Evaluar archivo de CV

Puedes evaluar un archivo de CV (PDF, DOCX, TXT) utilizando el método `screen_cv`:

```python
# Evaluar un archivo de CV
result = client.screen_cv("ruta/al/cv.pdf", criteria)

# Mostrar resultados detallados
print("\n=== Resultados de evaluación ===")
print(f"Puntuación general: {result.overall_score}/100")

print("\n=== Análisis de habilidades ===")
print(f"Puntuación de habilidades: {result.skill_matches.overall_score}/100")
print("\nHabilidades requeridas encontradas:")
for skill, score in result.skill_matches.required_skills.items():
    print(f"✓ {skill}: {score*100:.0f}%")

print("\nHabilidades requeridas faltantes:")
for skill in result.skill_matches.missing_required:
    print(f"✗ {skill}")

print("\n=== Perfil del candidato ===")
print(f"Experiencia: {result.experience_match.years_of_experience} años")
print(f"Relevancia de experiencia: {result.experience_match.relevance_score*100:.0f}%")
print(f"Cumple requisitos mínimos: {'Sí' if result.experience_match.meets_minimum else 'No'}")

print(f"Educación: {result.education_level}")
print(f"Relevancia del campo: {result.education_match.field_relevance*100:.0f}%")

print("\n=== Resumen ===")
print(result.summary)
```

### 4. Crear criterios estructurados

Puedes utilizar la clase `JobCriteria` para definir criterios de manera estructurada:

```python
from cv_screening_sdk import JobCriteria

# Crear un objeto de criterios
criteria = JobCriteria(
    required_skills=["Python", "AWS", "Docker"],
    preferred_skills=["Kubernetes", "CI/CD"],
    min_years_experience=3,
    preferred_years_experience=5,
    education_level="bachelors",  # opciones: any, high school, associate, bachelors, masters, phd
    education_field="Ciencias de la Computación",
    role_title="Ingeniero de Software Senior",
    description="Responsable del desarrollo backend y la infraestructura en la nube",
    industry="Tecnología"
)

# Evaluar CV con estos criterios
result = client.screen_cv("ruta/al/cv.pdf", criteria)
```

### 5. Procesamiento por lotes

Para procesar varios CV a la vez:

```python
# Lista de rutas de archivos CV
cv_paths = [
    "ruta/al/cv1.pdf",
    "ruta/al/cv2.docx",
    "ruta/al/cv3.txt"
]

# Cargar contenido de los CV
cv_contents = []
for path in cv_paths:
    cv_contents.append(client.load_cv_content(path))

# Procesar todos los CV con los mismos criterios
batch_result = client.batch_screen_cvs(cv_contents, criteria, cv_paths)

# Obtener estadísticas generales
print(f"Total de CV procesados: {batch_result.total_items}")
print(f"Tasa de éxito: {batch_result.success_rate()*100:.2f}%")
print(f"Puntuación promedio: {batch_result.average_score():.2f}/100")

# Procesar resultados individuales
print("\n=== Mejores candidatos ===")
for result in batch_result.get_top_results(3):
    print(f"ID: {result.cv_id}")
    print(f"Puntuación: {result.overall_score}/100")
    print(f"Habilidades: {', '.join(result.skills_found)}")
    print(f"Experiencia: {result.experience_years} años")
    print(f"Fortalezas clave: {', '.join(result.key_strengths)}")
    print("-" * 40)
```

### 6. Procesamiento asíncrono

Para procesar CV de forma asíncrona:

```python
import asyncio

async def process_cvs_async():
    # Crear cliente
    client = CVScreeningClient()
    
    # Definir criterios
    criteria = JobCriteria(
        required_skills=["Python", "AWS"],
        preferred_skills=["Docker", "Kubernetes"],
        min_years_experience=3
    )
    
    # Lista de textos de CV
    cv_texts = [
        "CV 1 contenido...",
        "CV 2 contenido...",
        "CV 3 contenido..."
    ]
    
    # Procesar CVs de forma asíncrona
    results = []
    for i, cv_text in enumerate(cv_texts):
        result = await client.analyze_cv_async(cv_text, criteria)
        results.append((f"CV_{i+1}", result))
    
    # Mostrar resultados
    for cv_id, result in results:
        print(f"\n{cv_id}: {result.overall_score}/100")

# Ejecutar función asíncrona
asyncio.run(process_cvs_async())
```

## Funcionalidades avanzadas

### Personalización de prompts

Puedes personalizar el prompt del sistema para el análisis:

```python
# Definir un prompt de sistema personalizado
custom_prompt = """
Eres un experto en recursos humanos especializado en análisis de CVs para el sector tecnológico.
Tu tarea es evaluar el CV del candidato para el puesto especificado, centrándote en:
1. Relevancia de la experiencia específica en el sector de desarrollo web
2. Profundidad de conocimiento en las tecnologías requeridas
3. Historial de proyectos escalables
"""

# Analizar CV con prompt personalizado
result = client.analyze_cv(cv_text, criteria, prompt_system=custom_prompt)
```

### Generación de informes detallados

Puedes crear informes estructurados a partir de los resultados:

```python
def generate_detailed_report(result, output_path):
    """Generar un informe detallado de los resultados."""
    with open(output_path, "w") as f:
        f.write("===== INFORME DE EVALUACIÓN DE CV =====\n\n")
        f.write(f"Puntuación general: {result.overall_score}/100\n\n")
        
        f.write("=== ANÁLISIS DE HABILIDADES ===\n")
        f.write("Habilidades requeridas encontradas:\n")
        for skill, score in result.skill_matches.required_skills.items():
            f.write(f"- {skill}: {score*100:.0f}%\n")
        
        f.write("\nHabilidades preferidas encontradas:\n")
        for skill, score in result.skill_matches.preferred_skills.items():
            f.write(f"- {skill}: {score*100:.0f}%\n")
        
        f.write("\nHabilidades faltantes:\n")
        for skill in result.skill_matches.missing_required:
            f.write(f"- {skill} (requerida)\n")
        for skill in result.skill_matches.missing_preferred:
            f.write(f"- {skill} (preferida)\n")
        
        f.write("\n=== ANÁLISIS DE EXPERIENCIA ===\n")
        f.write(f"Años de experiencia: {result.experience_match.years_of_experience}\n")
        f.write(f"Relevancia: {result.experience_match.relevance_score*100:.0f}%\n")
        
        f.write("\nRoles relevantes:\n")
        for role in result.experience_match.role_matches:
            f.write(f"- {role['title']} ({role['years']} años) - Relevancia: {role['relevance']*100:.0f}%\n")
        
        f.write("\n=== ANÁLISIS DE EDUCACIÓN ===\n")
        f.write(f"Nivel educativo: {result.education_match.education_details.highest_level}\n")
        f.write(f"Campo: {result.education_match.education_details.field}\n")
        f.write(f"Relevancia: {result.education_match.field_relevance*100:.0f}%\n")
        
        f.write("\n=== RESUMEN DE EVALUACIÓN ===\n")
        f.write(result.summary)

# Generar informe
generate_detailed_report(result, "informe_candidato.txt")
```

### Configuración de conexión avanzada

Para entornos con requisitos específicos de conexión:

```python
# Configuración avanzada de conexión
azure_config = AzureConfig(
    endpoint="https://tu-endpoint.openai.azure.com/",
    deployment_name="tu-deployment-name",
    tenant_id="tu-tenant-id",
    client_id="tu-client-id",
    client_secret="tu-client-secret",
    
    # Configuración SSL personalizada
    ssl_verify=True,
    ssl_cert_path="/ruta/opcional/a/certificado.pem",
    
    # Configuración de conexión avanzada
    connection_verify=True,  # Verificación SSL para conexiones de autenticación
    connection_timeout=60,  # Tiempo de espera extendido para redes lentas
    max_keepalive_connections=10,  # Más conexiones keepalive para alto rendimiento
    max_connections=20  # Más conexiones totales para alto rendimiento
)

# Inicializar cliente con configuración avanzada
client = CVScreeningClient(config=SDKConfig(azure=azure_config))
```

## Manejo de errores

El SDK proporciona excepciones específicas para diferentes situaciones:

```python
from cv_screening_sdk.core.exceptions import (
    SDKError,
    ConfigurationError,
    AuthenticationError,
    ProviderError,
    ProcessingError,
    LLMError
)

try:
    result = client.analyze_cv(cv_text, criteria)
except ConfigurationError as e:
    print(f"Error de configuración: {e}")
except AuthenticationError as e:
    print(f"Error de autenticación: {e}")
except LLMError as e:
    print(f"Error del modelo de lenguaje: {e}")
except ProcessingError as e:
    print(f"Error de procesamiento: {e}")
except ProviderError as e:
    print(f"Error del proveedor: {e}")
except SDKError as e:
    print(f"Error general del SDK: {e}")
except Exception as e:
    print(f"Error inesperado: {e}")
```

Consulta la [Guía de Manejo de Errores](error_handling.md) para obtener más información sobre las excepciones y cómo manejarlas. 