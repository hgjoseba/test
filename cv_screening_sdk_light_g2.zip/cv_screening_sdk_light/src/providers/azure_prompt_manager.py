"""
Manages prompts for Azure OpenAI provider.
"""
import json
from typing import List, Dict, Optional, Any


class AzurePromptManager:
    """Handles prompt generation and management for Azure OpenAI provider."""

    def __init__(self, system_prompt: Optional[str] = None):
        self.system_prompt = system_prompt

    def get_system_prompt(self) -> str:
        """Get the system prompt for single CV analysis."""
        return self.system_prompt or """You are an expert CV screening assistant. Your task is to analyze CVs and determine if they match the given job criteria.

Your response should be a JSON object with the following structure:
{
    "overall_match": 75,
    "skills_match": {
        "required_skills": {"python": 0.9},
        "preferred_skills": {"docker": 0.7},
        "missing_required": [],
        "missing_preferred": []
    },
    "experience_match": {
        "years_of_experience": 5,
        "relevant_experience": 0.8,
        "meets_minimum": true
    },
    "education_match": {
        "has_required_education": true,
        "education_details": {
            "highest_level": "Master's",
            "field": "Computer Science"
        }
    },
    "summary": "Brief evaluation of the candidate"
}"""

    def get_system_prompt_for_multiple_cvs(self, cv_count: int) -> str:
        """Get the system prompt for analyzing multiple CVs."""
        return self.system_prompt or f"""You are an expert CV screening assistant. Your task is to analyze {cv_count} CVs and determine if they match the given job criteria.

Your response should be a JSON array with {cv_count} objects, each with the following structure:
{{
    "cv_index": 0,
    "overall_match": 75,
    "skills_match": {{
        "required_skills": {{"python": 0.9}},
        "preferred_skills": {{"docker": 0.7}},
        "missing_required": [],
        "missing_preferred": []
    }},
    "experience_match": {{
        "years_of_experience": 5,
        "relevant_experience": 0.8,
        "meets_minimum": true
    }},
    "education_match": {{
        "has_required_education": true,
        "education_details": {{
            "highest_level": "Master's",
            "field": "Computer Science"
        }}
    }},
    "summary": "Brief evaluation of the candidate"
}}"""

    def build_screening_prompt(self, content: str, criteria: Dict[str, Any]) -> str:
        """Build the prompt for analyzing a single CV."""
        return f"""Please analyze the following CV against the job criteria.

CV Content:
{content}

Job Criteria:
{json.dumps(criteria, indent=2)}

Provide your analysis as a JSON object that follows the exact structure specified in the system prompt."""

    def build_multiple_screening_prompt(
        self,
        contents: List[str],
        criteria: Dict[str, Any],
        start_index: int = 0,
    ) -> str:
        """Build the prompt for analyzing multiple CVs."""
        cv_texts = "\n\n".join(
            f"CV #{start_index + i + 1} (index {start_index + i}):\n{content}"
            for i, content in enumerate(contents)
        )
        return f"""Please analyze the following {len(contents)} CVs against the job criteria.

{cv_texts}

Job Criteria:
{json.dumps(criteria, indent=2)}

Provide your analysis as a JSON array with one object per CV, where each object contains the analysis for that CV.
Each object MUST include a 'cv_index' field with the exact index shown above (starting from {start_index}) to identify which CV it refers to.
Ensure your response is valid JSON and follows the exact structure specified in the system prompt."""