"""
Pytest configuration file for CV Screening SDK Light.

This file contains pytest fixtures and configuration for the test suite.
"""
import os
import sys
import pytest
import logging
import json
from unittest.mock import patch, MagicMock, PropertyMock

# Add the project root directory to Python path
# This ensures imports work correctly regardless of how tests are run
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Import common SDK components needed in tests
from src.auth.azure import AzureCredentials, AzureAuthProvider
from src.core.exceptions import AuthenticationError, OpenAIError
from src.providers.azure_provider import AzureOpenAIProvider
from src.providers.azure_prompt_manager import AzurePromptManager
from src.providers.azure_response_handler import AzureResponseHandler
from src.client import CVScreeningClient
from src.core.config import Config
from src.core.types import ContentType
from src.utils.document import load_cv_content, load_cv_from_base64, is_base64
from src.models.criteria import JobCriteria

# Configure pytest path discovery
def pytest_configure(config):
    """Configure pytest."""
    # Add src to the pythonpath
    config.addinivalue_line("pythonpath", os.path.join(project_root, "src"))
    config.addinivalue_line("pythonpath", os.path.join(project_root, "tests"))
    
    # Make sure pytest can discover test modules
    config.addinivalue_line("python_files", "test_*.py")
    config.addinivalue_line("python_classes", "Test*")
    config.addinivalue_line("python_functions", "test_*")


@pytest.fixture
def mock_logger():
    """Fixture for a mock logger."""
    return MagicMock(spec=logging.Logger)


@pytest.fixture
def azure_credentials():
    """Fixture for AzureCredentials with test values."""
    return AzureCredentials(
        tenant_id="test-tenant",
        client_id="test-client",
        client_secret="test-secret",
        connection_verify=True
    )


@pytest.fixture
def azure_auth_provider(mock_logger):
    """Fixture for AzureAuthProvider with test values."""
    with patch('src.auth.azure.AzureCredentials'):
        provider = AzureAuthProvider(
            tenant_id="test-tenant",
            client_id="test-client",
            client_secret="test-secret",
            connection_verify=True,
            logger=mock_logger
        )
        yield provider


@pytest.fixture
def azure_openai_provider():
    """Fixture for AzureOpenAIProvider with test values."""
    with patch('src.providers.azure_provider.AzureOpenAI') as mock_azure_openai:
        provider = AzureOpenAIProvider(
            endpoint="https://test-endpoint.com",
            api_key="test-api-key",
            deployment_name="test-deployment"
        )
        yield provider


@pytest.fixture
def azure_prompt_manager():
    """Fixture for AzurePromptManager."""
    return AzurePromptManager()


@pytest.fixture
def azure_response_handler():
    """Fixture for AzureResponseHandler."""
    return AzureResponseHandler()


@pytest.fixture
def sample_cv_content():
    """Fixture for sample CV content."""
    return """
    John Doe
    Software Engineer
    
    Experience:
    - 5 years of Python development
    - 3 years of SQL database design
    - 2 years of Docker and Kubernetes
    
    Education:
    - Bachelor's in Computer Science
    """


@pytest.fixture
def sample_job_criteria():
    """Fixture for sample job criteria."""
    return {
        "required_skills": ["Python", "SQL"],
        "preferred_skills": ["Docker", "Kubernetes"],
        "min_years_experience": 3,
        "education_level": "bachelor's",
        "job_title": "Senior Software Engineer"
    }


@pytest.fixture
def sample_openai_response():
    """Fixture for a sample OpenAI API response."""
    mock_response = MagicMock()
    mock_response.choices = [MagicMock()]
    mock_response.choices[0].message.content = json.dumps({
        "overall_match": 85,
        "skills_match": 90,
        "experience_match": 80,
        "education_match": 100,
        "comments": "Strong candidate with relevant skills and experience."
    })
    return mock_response 