"""
Prompt Management SDK.

A Python SDK for managing prompt templates with versioning support,
integrated with Azure Cosmos DB storage and Azure OpenAI endpoints.
"""

__version__ = "0.1.0"

from prompt_management.client import PromptManagementClient
from prompt_management.models.prompt import (
    PromptTemplate, 
    PromptVersion, 
    PromptCategory, 
    AzureOpenAISettings,
    PromptEvaluation,
    PromptUsageStats,
    PromptParameter
)
from prompt_management.core.prompt_engine import PromptEngine
from prompt_management.auth.azure import AzureCredential
from prompt_management.utils.errors import (
    PromptManagementError,
    PromptNotFoundError,
    VersionNotFoundError,
    CategoryNotFoundError,
    ValidationError,
    PromptVersionConflictError
)
from prompt_management.utils.logging import setup_sdk_logging

# Configure default logging
setup_sdk_logging()

__all__ = [
    'PromptManagementClient',
    'PromptEngine',
    'PromptTemplate',
    'PromptVersion',
    'PromptCategory',
    'AzureOpenAISettings',
    'PromptEvaluation',
    'PromptUsageStats',
    'PromptParameter',
    'AzureCredential',
    'PromptManagementError',
    'PromptNotFoundError',
    'VersionNotFoundError',
    'CategoryNotFoundError',
    'ValidationError',
    'PromptVersionConflictError',
    'setup_sdk_logging',
]
