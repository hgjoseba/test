"""
Client module for the Prompt Management SDK.

This module provides the main client class for interacting with 
Azure Cosmos DB to store and retrieve prompt templates.
"""

import os
from typing import Dict, List, Optional, Union, Any
import uuid
from datetime import datetime

from azure.cosmos import CosmosClient, PartitionKey, exceptions

from .models.prompt import PromptTemplate, PromptVersion, PromptCategory, AzureOpenAISettings
from .auth.azure import AzureCredential
from .utils.errors import PromptManagementError, PromptNotFoundError, VersionNotFoundError, PromptVersionConflictError
from .utils.logging import get_logger

logger = get_logger(__name__)

class PromptManagementClient:
    """
    Client for managing prompt templates using Azure Cosmos DB.
    
    This client provides methods for creating, retrieving, updating,
    and deleting prompt templates and their versions.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        key: str = None,
        database_name: str = "prompt-management",
        container_name: str = "prompts",
        credential: AzureCredential = None,
        connection_verify: Union[bool, str] = True,
    ):
        """
        Initialize the Prompt Management client.
        
        Args:
            endpoint: Azure Cosmos DB endpoint URL.
                Can also be set via AZURE_COSMOS_ENDPOINT environment variable.
            key: Azure Cosmos DB key.
                Can also be set via AZURE_COSMOS_KEY environment variable.
            database_name: Name of the database to use. Defaults to "prompt-management".
            container_name: Name of the container to use. Defaults to "prompts".
            credential: An AzureCredential object for authentication.
                If not provided, will use key if available.
            connection_verify: Controls SSL certificate verification. Set to False to disable verification,
                or provide a path to a CA bundle to use. Defaults to True.
        """
        self.endpoint = endpoint or os.getenv("AZURE_COSMOS_ENDPOINT")
        self.key = key or os.getenv("AZURE_COSMOS_KEY")
        self.database_name = database_name
        self.container_name = container_name
        self.credential = credential
        self.connection_verify = connection_verify
        
        if not self.endpoint:
            raise ValueError("Endpoint must be provided either directly or via environment variable")
        
        if not self.key and not self.credential:
            raise ValueError("Either key or credential must be provided for authentication")
        
        # Initialize Azure Cosmos DB client
        if self.key:
            self._cosmos_client = CosmosClient(
                url=self.endpoint,
                credential=self.key,
                connection_verify=self.connection_verify
            )
        else:
            # Get token credential from AzureCredential wrapper
            azure_credential = self.credential.get_azure_credential()
            self._cosmos_client = CosmosClient(
                url=self.endpoint,
                credential=azure_credential,
                connection_verify=self.connection_verify
            )
        
        # Initialize database and container
        self._init_database_and_container()
    
    def _init_database_and_container(self):
        """Initialize database and container if they don't exist."""
        try:
            # Create database if it doesn't exist
            self._database = self._cosmos_client.create_database_if_not_exists(
                id=self.database_name
            )
            
            # Create container if it doesn't exist
            self._container = self._database.create_container_if_not_exists(
                id=self.container_name,
                partition_key=PartitionKey(path="/categoryId"),
                offer_throughput=400  # Minimum throughput
            )
            
            logger.info(f"Initialized database {self.database_name} and container {self.container_name}")
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error initializing Cosmos DB: {str(e)}")
            raise PromptManagementError(f"Error initializing Cosmos DB: {str(e)}")
    
    def create_prompt_template(
        self, 
        prompt_template: PromptTemplate,
        azure_openai_settings: Optional[AzureOpenAISettings] = None
    ) -> PromptTemplate:
        """
        Create a new prompt template.
        
        Args:
            prompt_template: The prompt template to create.
            azure_openai_settings: Optional Azure OpenAI settings to associate with the template.
                If provided, will be set as the default for the template.
            
        Returns:
            PromptTemplate: The created prompt template with ID.
            
        Raises:
            PromptManagementError: If creation fails.
        """
        try:
            # Generate ID if not provided
            if not prompt_template.id:
                prompt_template.id = str(uuid.uuid4())
            
            # Set timestamps
            now = datetime.utcnow().isoformat()
            prompt_template.created_at = now
            prompt_template.updated_at = now
            
            # Set Azure OpenAI settings if provided
            if azure_openai_settings:
                prompt_template.default_azure_openai = azure_openai_settings
            
            # Ensure required fields are present
            if not prompt_template.category_id:
                raise PromptManagementError("category_id is required")
            if not prompt_template.use_case:
                raise PromptManagementError("use_case is required")
            
            # Insert into Cosmos DB
            prompt_dict = prompt_template.dict(exclude_none=True)
            
            # Map snake_case to camelCase for Cosmos DB
            prompt_dict["categoryId"] = prompt_dict.pop("category_id")
            prompt_dict["useCase"] = prompt_dict.pop("use_case")
            prompt_dict["documentType"] = "prompt_template"
            
            self._container.create_item(body=prompt_dict)
            
            logger.info(f"Created prompt template with ID: {prompt_template.id}")
            return prompt_template
            
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error creating prompt template: {str(e)}")
            raise PromptManagementError(f"Error creating prompt template: {str(e)}")
    
    def get_prompt_template(self, template_id: str) -> PromptTemplate:
        """
        Get a prompt template by ID.
        
        Args:
            template_id: ID of the prompt template to retrieve.
            
        Returns:
            PromptTemplate: The retrieved prompt template.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            PromptManagementError: If retrieval fails.
        """
        try:
            # Query Cosmos DB for the prompt template
            query = f"SELECT * FROM c WHERE c.id = '{template_id}'"
            items = list(self._container.query_items(
                query=query,
                enable_cross_partition_query=True
            ))
            
            if not items:
                raise PromptNotFoundError(f"Prompt template with ID {template_id} not found")
            
            # Convert to PromptTemplate model
            return PromptTemplate.parse_obj(items[0])
            
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error retrieving prompt template: {str(e)}")
            raise PromptManagementError(f"Error retrieving prompt template: {str(e)}")
    
    def update_prompt_template(self, template_id: str, updates: Dict[str, Any]) -> PromptTemplate:
        """
        Update a prompt template.
        
        Args:
            template_id: ID of the prompt template to update.
            updates: Dictionary of fields to update.
            
        Returns:
            PromptTemplate: The updated prompt template.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            PromptManagementError: If update fails.
        """
        try:
            # Get the existing prompt template
            prompt_template = self.get_prompt_template(template_id)
            
            # Update fields
            for key, value in updates.items():
                if hasattr(prompt_template, key):
                    setattr(prompt_template, key, value)
            
            # Update timestamp
            prompt_template.updated_at = datetime.utcnow().isoformat()
            
            # Update in Cosmos DB
            prompt_dict = prompt_template.dict()
            self._container.replace_item(item=prompt_template.id, body=prompt_dict)
            
            logger.info(f"Updated prompt template with ID: {template_id}")
            return prompt_template
            
        except PromptNotFoundError:
            raise
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error updating prompt template: {str(e)}")
            raise PromptManagementError(f"Error updating prompt template: {str(e)}")
    
    def delete_prompt_template(self, template_id: str) -> bool:
        """
        Delete a prompt template.
        
        Args:
            template_id: ID of the prompt template to delete.
            
        Returns:
            bool: True if deleted successfully.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            PromptManagementError: If deletion fails.
        """
        try:
            # Get the prompt template to ensure it exists
            prompt_template = self.get_prompt_template(template_id)
            
            # Delete from Cosmos DB
            self._container.delete_item(item=template_id, partition_key=prompt_template.category_id)
            
            logger.info(f"Deleted prompt template with ID: {template_id}")
            return True
            
        except PromptNotFoundError:
            raise
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error deleting prompt template: {str(e)}")
            raise PromptManagementError(f"Error deleting prompt template: {str(e)}")
    
    def list_prompt_templates(
        self,
        category_id: Optional[str] = None,
        azure_openai_endpoint: Optional[str] = None,
        limit: int = 100
    ) -> List[PromptTemplate]:
        """
        List prompt templates, optionally filtered by category or Azure OpenAI endpoint.
        
        Args:
            category_id: Optional category ID to filter by.
            azure_openai_endpoint: Optional Azure OpenAI endpoint to filter by.
            limit: Maximum number of results to return. Defaults to 100.
            
        Returns:
            List[PromptTemplate]: List of prompt templates.
            
        Raises:
            PromptManagementError: If listing fails.
        """
        try:
            # Build query based on parameters
            query_parts = []
            
            if category_id:
                query_parts.append(f"c.categoryId = '{category_id}'")
                
            if azure_openai_endpoint:
                # Search for the endpoint in default_azure_openai
                query_parts.append(f"(c.default_azure_openai.endpoint = '{azure_openai_endpoint}' OR EXISTS(SELECT VALUE v FROM v IN c.versions WHERE v.azure_openai.endpoint = '{azure_openai_endpoint}'))")
            
            if query_parts:
                query = f"SELECT * FROM c WHERE {' AND '.join(query_parts)} OFFSET 0 LIMIT {limit}"
            else:
                query = f"SELECT * FROM c OFFSET 0 LIMIT {limit}"
            
            # Query Cosmos DB
            items = list(self._container.query_items(
                query=query,
                enable_cross_partition_query=True if not category_id else False
            ))
            
            # Convert to PromptTemplate models
            return [PromptTemplate.parse_obj(item) for item in items]
            
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error listing prompt templates: {str(e)}")
            raise PromptManagementError(f"Error listing prompt templates: {str(e)}")
    
    def add_prompt_version(
        self,
        template_id: str,
        version: PromptVersion,
        azure_openai_settings: Optional[AzureOpenAISettings] = None,
        force_update: bool = False
    ) -> PromptTemplate:
        """
        Add a new version to a prompt template.
        
        Args:
            template_id: ID of the prompt template.
            version: The prompt version to add.
            azure_openai_settings: Optional Azure OpenAI settings for this version.
            force_update: If True, will update an existing version with the same number.
                Otherwise, raises PromptVersionConflictError if version exists.
            
        Returns:
            PromptTemplate: The updated prompt template.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            PromptVersionConflictError: If the version number already exists and force_update is False.
            PromptManagementError: If adding the version fails.
        """
        try:
            # Get the existing prompt template
            prompt_template = self.get_prompt_template(template_id)
            
            # Check for existing version with the same number
            existing_version = prompt_template.get_version(version.version_number)
            if existing_version and not force_update:
                raise PromptVersionConflictError(template_id, version.version_number)
            
            # Generate version ID if not provided
            if not version.id:
                version.id = str(uuid.uuid4())
            
            # Set timestamps
            now = datetime.utcnow().isoformat()
            version.created_at = now
            
            # Set Azure OpenAI settings if provided
            if azure_openai_settings:
                version.azure_openai = azure_openai_settings
            
            # Add or update the version
            if existing_version:
                # Replace the existing version
                for i, v in enumerate(prompt_template.versions):
                    if v.version_number == version.version_number:
                        prompt_template.versions[i] = version
                        break
            else:
                # Add as a new version
                if not prompt_template.versions:
                    prompt_template.versions = []
                
                prompt_template.versions.append(version)
            
            prompt_template.updated_at = now
            
            # Update in Cosmos DB
            prompt_dict = prompt_template.dict()
            self._container.replace_item(item=prompt_template.id, body=prompt_dict)
            
            if existing_version:
                logger.info(f"Updated version {version.version_number} for prompt template {template_id}")
            else:
                logger.info(f"Added version {version.version_number} to prompt template {template_id}")
                
            return prompt_template
            
        except PromptNotFoundError:
            raise
        except PromptVersionConflictError:
            raise
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error adding prompt version: {str(e)}")
            raise PromptManagementError(f"Error adding prompt version: {str(e)}")
    
    def get_prompt_version(self, template_id: str, version_number: str) -> PromptVersion:
        """
        Get a specific version of a prompt template.
        
        Args:
            template_id: ID of the prompt template.
            version_number: Version number to retrieve.
            
        Returns:
            PromptVersion: The prompt version.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            VersionNotFoundError: If the version is not found.
            PromptManagementError: If retrieval fails.
        """
        try:
            # Get the prompt template
            template = self.get_prompt_template(template_id)
            
            # Find the requested version
            version = template.get_version(version_number)
            if not version:
                raise VersionNotFoundError(template_id, version_number)
                
            return version
            
        except PromptNotFoundError:
            raise
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error retrieving prompt version: {str(e)}")
            raise PromptManagementError(f"Error retrieving prompt version: {str(e)}")
    
    def delete_prompt_version(self, template_id: str, version_number: str) -> PromptTemplate:
        """
        Delete a specific version of a prompt template.
        
        Args:
            template_id: ID of the prompt template.
            version_number: Version number to delete.
            
        Returns:
            PromptTemplate: The updated prompt template.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            VersionNotFoundError: If the version is not found.
            PromptManagementError: If deletion fails.
        """
        try:
            # Get the prompt template
            template = self.get_prompt_template(template_id)
            
            # Find the version to delete
            version_found = False
            new_versions = []
            for v in template.versions:
                if v.version_number != version_number:
                    new_versions.append(v)
                else:
                    version_found = True
            
            if not version_found:
                raise VersionNotFoundError(template_id, version_number)
            
            # Update the prompt template
            template.versions = new_versions
            template.updated_at = datetime.utcnow().isoformat()
            
            # Update in Cosmos DB
            prompt_dict = template.dict()
            self._container.replace_item(item=template.id, body=prompt_dict)
            
            logger.info(f"Deleted version {version_number} from prompt template {template_id}")
            return template
            
        except PromptNotFoundError:
            raise
        except VersionNotFoundError:
            raise
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error deleting prompt version: {str(e)}")
            raise PromptManagementError(f"Error deleting prompt version: {str(e)}")
    
    def list_prompt_versions(self, template_id: str) -> List[PromptVersion]:
        """
        List all versions of a prompt template.
        
        Args:
            template_id: ID of the prompt template.
            
        Returns:
            List[PromptVersion]: List of versions.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            PromptManagementError: If listing fails.
        """
        try:
            # Get the prompt template
            template = self.get_prompt_template(template_id)
            
            # Return the versions
            return template.versions or []
            
        except PromptNotFoundError:
            raise
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error listing prompt versions: {str(e)}")
            raise PromptManagementError(f"Error listing prompt versions: {str(e)}")
    
    def create_category(
        self,
        category: PromptCategory,
        azure_openai_settings: Optional[AzureOpenAISettings] = None
    ) -> PromptCategory:
        """
        Create a new prompt category.
        
        Args:
            category: The prompt category to create.
            azure_openai_settings: Optional Azure OpenAI settings for this category.
            
        Returns:
            PromptCategory: The created category with ID.
            
        Raises:
            PromptManagementError: If creation fails.
        """
        try:
            # Generate ID if not provided
            if not category.id:
                category.id = str(uuid.uuid4())
            
            # Set timestamps
            now = datetime.utcnow().isoformat()
            category.created_at = now
            category.updated_at = now
            
            # Set Azure OpenAI settings if provided
            if azure_openai_settings:
                category.default_azure_openai = azure_openai_settings
            
            # Insert into Cosmos DB with a special document type
            category_dict = category.dict()
            category_dict["documentType"] = "category"
            category_dict["categoryId"] = category.id  # For partition key
            
            self._container.create_item(body=category_dict)
            
            logger.info(f"Created category with ID: {category.id}")
            return category
            
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error creating category: {str(e)}")
            raise PromptManagementError(f"Error creating category: {str(e)}")
    
    def list_categories(
        self,
        azure_openai_endpoint: Optional[str] = None,
        limit: int = 100
    ) -> List[PromptCategory]:
        """
        List all prompt categories, optionally filtered by Azure OpenAI endpoint.
        
        Args:
            azure_openai_endpoint: Optional Azure OpenAI endpoint to filter by.
            limit: Maximum number of results to return. Defaults to 100.
            
        Returns:
            List[PromptCategory]: List of categories.
            
        Raises:
            PromptManagementError: If listing fails.
        """
        try:
            # Build query based on parameters
            if azure_openai_endpoint:
                query = f"SELECT * FROM c WHERE c.documentType = 'category' AND c.default_azure_openai.endpoint = '{azure_openai_endpoint}' OFFSET 0 LIMIT {limit}"
            else:
                query = f"SELECT * FROM c WHERE c.documentType = 'category' OFFSET 0 LIMIT {limit}"
            
            # Query Cosmos DB
            items = list(self._container.query_items(
                query=query,
                enable_cross_partition_query=True
            ))
            
            # Convert to PromptCategory models
            return [PromptCategory.parse_obj(item) for item in items]
            
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error listing categories: {str(e)}")
            raise PromptManagementError(f"Error listing categories: {str(e)}")
            
    def find_prompts_by_endpoint(
        self,
        endpoint: str,
        category_id: Optional[str] = None,
        limit: int = 100
    ) -> List[PromptTemplate]:
        """
        Find prompt templates by Azure OpenAI endpoint.
        
        This searches for templates that have the specified endpoint
        in either their default settings or any version settings.
        
        Args:
            endpoint: Azure OpenAI endpoint URL to search for.
            category_id: Optional category ID to further filter results.
            limit: Maximum number of results to return. Defaults to 100.
            
        Returns:
            List[PromptTemplate]: List of matching prompt templates.
            
        Raises:
            PromptManagementError: If the search fails.
        """
        try:
            # Build query
            query_parts = [
                f"(c.default_azure_openai.endpoint = '{endpoint}' OR EXISTS(SELECT VALUE v FROM v IN c.versions WHERE v.azure_openai.endpoint = '{endpoint}'))"
            ]
            
            if category_id:
                query_parts.append(f"c.categoryId = '{category_id}'")
                
            query = f"SELECT * FROM c WHERE {' AND '.join(query_parts)} OFFSET 0 LIMIT {limit}"
            
            # Query Cosmos DB
            items = list(self._container.query_items(
                query=query,
                enable_cross_partition_query=True if not category_id else False
            ))
            
            # Convert to PromptTemplate models
            return [PromptTemplate.parse_obj(item) for item in items]
            
        except exceptions.CosmosHttpResponseError as e:
            logger.error(f"Error searching prompts by endpoint: {str(e)}")
            raise PromptManagementError(f"Error searching prompts by endpoint: {str(e)}") 