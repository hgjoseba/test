"""
Prompt model classes for Prompt Management SDK.

This module defines data models representing prompt templates,
versions, and categories.
"""

from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel, Field, validator
from datetime import datetime


class AzureOpenAISettings(BaseModel):
    """
    Represents Azure OpenAI API settings for a prompt.
    
    This includes the endpoint, deployment name, and other
    Azure OpenAI specific configuration.
    """
    endpoint: str
    deployment_name: str
    api_version: str = "2023-05-15"
    model_name: Optional[str] = None  # e.g., gpt-4, gpt-35-turbo
    resource_group: Optional[str] = None
    subscription_id: Optional[str] = None
    tenant_id: Optional[str] = None
    instance_name: Optional[str] = None  # For differentiating between different instances
    region: Optional[str] = None
    json_schema: Optional[Dict[str, Any]] = Field(default_factory=dict)


    
    @validator('endpoint')
    def validate_endpoint(cls, v):
        """Validate endpoint format."""
        if not v.startswith(('https://', 'http://')):
            raise ValueError('Endpoint must be a valid URL starting with https:// or http://')
        return v


class PromptVersion(BaseModel):
    """
    Represents a version of a prompt template.
    
    Each version contains the actual prompt text and optional
    parameters for controlling generation.
    """
    id: Optional[str] = None
    version_number: str
    system_prompt: str 
    validation_prompt: Optional[str] = None      
    created_at: Optional[str] = None
    created_by: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = Field(default_factory=dict)
    model_settings: Optional[Dict[str, Any]] = Field(default_factory=dict)
    is_active: bool = True
    description: Optional[str] = None
    # Azure OpenAI specific settings
    azure_openai: Optional[AzureOpenAISettings] = None
    
    @validator('version_number')
    def validate_version_number(cls, v):
        """Validate version number format (semantic versioning)."""
        import re
        if not re.match(r'^\d+\.\d+\.\d+$', v):
            raise ValueError('Version number must be in format X.Y.Z (semantic versioning)')
        return v


class PromptTemplate(BaseModel):
    """
    Represents a prompt template.
    
    A prompt template is a collection of versioned prompts for a specific
    use case or application.
    """
    id: Optional[str] = None
    name: str
    description: Optional[str] = None
    category_id: Optional[str] = Field(None, description="ID of the category this template belongs to")
    use_case: Optional[str] = Field(None, description="The use case this template is designed for")
    tags: List[str] = Field(default_factory=list)
    versions: List[PromptVersion] = Field(default_factory=list)
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    created_by: Optional[str] = None
    is_active: bool = True
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)
    # Default Azure OpenAI settings for all versions
    default_azure_openai: Optional[AzureOpenAISettings] = None
    
    @property
    def active_version(self) -> Optional[PromptVersion]:
        """Get the active version of the prompt template."""
        if not self.versions:
            return None
        
        # First try to find a version marked as active
        active_versions = [v for v in self.versions if v.is_active]
        if active_versions:
            # Return the latest active version based on semantic versioning
            return sorted(
                active_versions,
                key=lambda v: [int(x) for x in v.version_number.split('.')],
                reverse=True
            )[0]
        
        # If no version is marked as active, return the latest version
        return sorted(
            self.versions,
            key=lambda v: [int(x) for x in v.version_number.split('.')],
            reverse=True
        )[0]
    
    def get_version(self, version_number: str) -> Optional[PromptVersion]:
        """Get a specific version of the prompt template."""
        for version in self.versions:
            if version.version_number == version_number:
                return version
        return None
    
    def get_latest_version(self) -> Optional[PromptVersion]:
        """Get the latest version of the prompt template based on semantic versioning."""
        if not self.versions:
            return None
        
        return sorted(
            self.versions,
            key=lambda v: [int(x) for x in v.version_number.split('.')],
            reverse=True
        )[0]
    
    def get_azure_openai_settings(self, version_number: Optional[str] = None) -> Optional[AzureOpenAISettings]:
        """
        Get Azure OpenAI settings for a specific version or active version.
        
        Version-specific settings take precedence over template default settings.
        
        Args:
            version_number: Optional version number to get settings for.
                If not provided, uses the active version.
                
        Returns:
            AzureOpenAISettings if available, None otherwise.
        """
        # Get the version
        version = None
        if version_number:
            version = self.get_version(version_number)
        else:
            version = self.active_version
            
        if not version:
            return self.default_azure_openai
            
        # Return version-specific settings if available, otherwise template default
        return version.azure_openai or self.default_azure_openai


class PromptCategory(BaseModel):
    """
    Represents a category for organizing prompt templates.
    
    Categories help organize prompts by domain, application, or any
    other grouping criteria.
    """
    id: Optional[str] = None
    name: str
    description: Optional[str] = None
    parent_id: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    created_by: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict)
    # Default Azure OpenAI settings for the entire category
    default_azure_openai: Optional[AzureOpenAISettings] = None


class PromptEvaluation(BaseModel):
    """
    Represents an evaluation of a prompt version.
    
    This stores metrics and feedback about a specific prompt version's performance.
    """
    id: Optional[str] = None
    template_id: str
    version_id: str
    evaluator: Optional[str] = None
    evaluation_date: Optional[str] = None
    metrics: Dict[str, Any] = Field(default_factory=dict)
    feedback: Optional[str] = None
    samples: List[Dict[str, Any]] = Field(default_factory=list)
    rating: Optional[float] = None  # e.g., 1-5 rating
    # Record which Azure OpenAI endpoint was used for evaluation
    azure_openai_endpoint: Optional[str] = None


class PromptUsageStats(BaseModel):
    """
    Represents usage statistics for a prompt template.
    
    This tracks how often a prompt is used and basic performance metrics.
    """
    template_id: str
    version_id: Optional[str] = None
    usage_count: int = 0
    last_used: Optional[str] = None
    avg_token_count: Optional[float] = None
    avg_response_time: Optional[float] = None
    success_rate: Optional[float] = None
    error_counts: Dict[str, int] = Field(default_factory=dict)
    # Track usage by endpoint
    usage_by_endpoint: Dict[str, int] = Field(default_factory=dict)
    
    
class PromptParameter(BaseModel):
    """
    Represents a parameter that can be used in prompt templates.
    
    Parameters are placeholders that get replaced with actual values
    when the prompt is used.
    """
    name: str
    description: Optional[str] = None
    data_type: str = "string"  # string, number, boolean, array, object
    required: bool = False
    default_value: Optional[Any] = None
    allowed_values: Optional[List[Any]] = None
    validation_regex: Optional[str] = None 