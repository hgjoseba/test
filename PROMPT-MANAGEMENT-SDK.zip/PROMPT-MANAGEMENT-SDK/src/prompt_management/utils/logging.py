"""
Logging utility for Prompt Management SDK.

This module provides logging functions and configuration
for the SDK.
"""

import logging
import os
import sys
from typing import Optional

# Configure default logging format
DEFAULT_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"


def get_logger(
    name: str,
    level: int = logging.INFO,
    log_format: str = DEFAULT_FORMAT,
    log_file: Optional[str] = None,
) -> logging.Logger:
    """
    Get a configured logger instance.
    
    Args:
        name: Name of the logger, typically the module name.
        level: Logging level. Defaults to INFO.
        log_format: Format string for log messages.
        log_file: Optional file path to write logs to.
        
    Returns:
        logging.Logger: Configured logger instance.
    """
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Create formatter
    formatter = logging.Formatter(log_format)
    
    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Create file handler if log_file is specified
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # Prevent log propagation to avoid duplicate logs
    logger.propagate = False
    
    return logger


def setup_sdk_logging(
    level: int = logging.INFO,
    log_format: str = DEFAULT_FORMAT,
    log_file: Optional[str] = None,
) -> None:
    """
    Set up logging for the entire SDK.
    
    Args:
        level: Logging level. Defaults to INFO.
        log_format: Format string for log messages.
        log_file: Optional file path to write logs to.
    """
    # Configure root logger for the SDK
    root_logger = get_logger("prompt_management_sdk", level, log_format, log_file)
    
    # Set log level from environment variable if present
    log_level_env = os.getenv("PROMPT_SDK_LOG_LEVEL")
    if log_level_env:
        try:
            level = getattr(logging, log_level_env.upper())
            root_logger.setLevel(level)
        except AttributeError:
            root_logger.warning(f"Invalid log level in environment: {log_level_env}")
    
    # Log the start of the SDK
    root_logger.debug("Prompt Management SDK logging initialized") 