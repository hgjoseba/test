"""
Error classes for Prompt Management SDK.

This module defines custom error classes used throughout the SDK.
"""

class PromptManagementError(Exception):
    """Base exception for all Prompt Management SDK errors."""
    def __init__(self, message: str, *args, **kwargs):
        self.message = message
        super().__init__(message, *args, **kwargs)
        
    def __str__(self):
        return self.message


class PromptNotFoundError(PromptManagementError):
    """Exception raised when a prompt template is not found."""
    def __init__(self, prompt_id: str, *args, **kwargs):
        message = f"Prompt template with ID {prompt_id} not found"
        super().__init__(message, *args, **kwargs)
        self.prompt_id = prompt_id


class VersionNotFoundError(PromptManagementError):
    """Exception raised when a prompt version is not found."""
    def __init__(self, template_id: str, version_id: str, *args, **kwargs):
        message = f"Version {version_id} not found for prompt template {template_id}"
        super().__init__(message, *args, **kwargs)
        self.template_id = template_id
        self.version_id = version_id


class CategoryNotFoundError(PromptManagementError):
    """Exception raised when a category is not found."""
    def __init__(self, category_id: str, *args, **kwargs):
        message = f"Category with ID {category_id} not found"
        super().__init__(message, *args, **kwargs)
        self.category_id = category_id


class ValidationError(PromptManagementError):
    """Exception raised when validation fails for a model."""
    def __init__(self, message: str, model_type: str = None, *args, **kwargs):
        if model_type:
            message = f"Validation error for {model_type}: {message}"
        super().__init__(message, *args, **kwargs)
        self.model_type = model_type


class PromptVersionConflictError(PromptManagementError):
    """Exception raised when there's a version conflict."""
    def __init__(self, template_id: str, version_number: str, *args, **kwargs):
        message = f"Version {version_number} already exists for prompt template {template_id}"
        super().__init__(message, *args, **kwargs)
        self.template_id = template_id
        self.version_number = version_number


class DatabaseError(PromptManagementError):
    """Exception raised for database-related errors."""
    def __init__(self, message: str, status_code: int = None, *args, **kwargs):
        if status_code:
            message = f"Database error ({status_code}): {message}"
        super().__init__(message, *args, **kwargs)
        self.status_code = status_code


class AuthenticationError(PromptManagementError):
    """Exception raised for authentication-related errors."""
    def __init__(self, message: str, *args, **kwargs):
        message = f"Authentication error: {message}"
        super().__init__(message, *args, **kwargs) 