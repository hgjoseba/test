"""
Prompt Engine module for Prompt Management SDK.

This module provides utilities for retrieving and formatting prompts
from the database for immediate use with Azure OpenAI.
"""

from typing import Dict, Any, Optional, Union, List
import re
import json

from ..client import PromptManagementClient
from ..models.prompt import PromptTemplate, PromptVersion, AzureOpenAISettings
from ..utils.errors import PromptNotFoundError, VersionNotFoundError, ValidationError
from ..utils.logging import get_logger

logger = get_logger(__name__)


class PromptEngine:
    """
    Engine for retrieving and formatting prompts for use with Azure OpenAI.
    
    This class provides methods to retrieve prompts from the database,
    fill in template variables, and prepare them for use with Azure OpenAI.
    """
    
    def __init__(self, client: PromptManagementClient):
        """
        Initialize the PromptEngine.
        
        Args:
            client: PromptManagementClient instance for database access.
        """
        self.client = client
    
    def get_prompt(
        self,
        template_id: str,
        version_number: Optional[str] = None,
        variables: Optional[Dict[str, Any]] = None,
        validate_variables: bool = True
    ) -> Dict[str, Any]:
        """
        Get a prompt template with variables filled in and ready to use.
        
        Args:
            template_id: ID of the prompt template to retrieve.
            version_number: Optional specific version to retrieve.
                If not provided, the active version will be used.
            variables: Dictionary of variables to fill in the prompt template.
            validate_variables: Whether to validate the variables against
                the prompt's parameter definitions.
                
        Returns:
            Dict containing the formatted prompt text and Azure OpenAI settings.
            
        Raises:
            PromptNotFoundError: If the prompt template is not found.
            VersionNotFoundError: If the specified version is not found.
            ValidationError: If variable validation fails.
        """
        # Get the prompt template
        template = self.client.get_prompt_template(template_id)
        
        # Get the prompt version
        version = None
        if version_number:
            version = template.get_version(version_number)
            if not version:
                raise VersionNotFoundError(template_id, version_number)
        else:
            version = template.active_version
            if not version:
                raise VersionNotFoundError(template_id, "active")
        
        # Get Azure OpenAI settings
        azure_openai = version.azure_openai or template.default_azure_openai
        
        # Format the prompt text with variables
        prompt_text = version.prompt_text
        if variables:
            # Validate variables if required
            if validate_variables and version.parameters:
                self._validate_variables(variables, version.parameters)
                
            # Replace variables in the prompt text
            prompt_text = self._fill_prompt_template(prompt_text, variables)
        
        # Prepare the result
        result = {
            "prompt_text": prompt_text,
            "model_settings": version.model_settings or {},
            "template_name": template.name,
            "version_number": version.version_number,
            "id": version.id,
        }
        
        # Add Azure OpenAI settings if available
        if azure_openai:
            result["azure_openai"] = {
                "endpoint": azure_openai.endpoint,
                "deployment_name": azure_openai.deployment_name,
                "api_version": azure_openai.api_version,
                "model_name": azure_openai.model_name,
            }
        
        return result
    
    def _fill_prompt_template(self, prompt_text: str, variables: Dict[str, Any]) -> str:
        """
        Fill a prompt template with variables.
        
        Replaces {{variable_name}} in the prompt text with the 
        corresponding values from the variables dictionary.
        
        Args:
            prompt_text: The prompt text with variable placeholders.
            variables: Dictionary of variables to insert.
            
        Returns:
            Formatted prompt text with variables replaced.
        """
        # Define regex for finding variables in the format {{variable_name}}
        var_pattern = r"\{\{([^}]+)\}\}"
        
        def replace_var(match):
            var_name = match.group(1).strip()
            if var_name in variables:
                # Convert non-string values to JSON strings
                value = variables[var_name]
                if not isinstance(value, str):
                    if isinstance(value, (dict, list)):
                        value = json.dumps(value, ensure_ascii=False, indent=2)
                    else:
                        value = str(value)
                return value
            # If variable not found, leave the placeholder
            return match.group(0)
        
        # Replace all variables
        return re.sub(var_pattern, replace_var, prompt_text)
    
    def _validate_variables(self, variables: Dict[str, Any], parameters: Dict[str, Any]) -> None:
        """
        Validate that the provided variables match the required parameters.
        
        Args:
            variables: Dictionary of variables to validate.
            parameters: Dictionary of parameter definitions.
            
        Raises:
            ValidationError: If validation fails.
        """
        # Check for missing required parameters
        missing = []
        for param_name, param_def in parameters.items():
            if isinstance(param_def, dict) and param_def.get("required", False):
                if param_name not in variables:
                    missing.append(param_name)
        
        if missing:
            raise ValidationError(
                f"Missing required variables: {', '.join(missing)}",
                model_type="PromptVersion"
            )
        
        # Check for type mismatches (basic validation)
        type_errors = []
        for var_name, var_value in variables.items():
            if var_name in parameters and isinstance(parameters[var_name], dict):
                param_def = parameters[var_name]
                data_type = param_def.get("data_type", "string")
                
                # Perform basic type checking
                if data_type == "string" and not isinstance(var_value, str):
                    type_errors.append(f"{var_name} should be a string")
                elif data_type == "number" and not isinstance(var_value, (int, float)):
                    type_errors.append(f"{var_name} should be a number")
                elif data_type == "boolean" and not isinstance(var_value, bool):
                    type_errors.append(f"{var_name} should be a boolean")
                elif data_type == "array" and not isinstance(var_value, list):
                    type_errors.append(f"{var_name} should be an array")
                elif data_type == "object" and not isinstance(var_value, dict):
                    type_errors.append(f"{var_name} should be an object")
                
                # Check allowed values if specified
                if "allowed_values" in param_def and var_value not in param_def["allowed_values"]:
                    allowed = ", ".join(str(v) for v in param_def["allowed_values"])
                    type_errors.append(f"{var_name} must be one of: {allowed}")
                
                # Check regex validation if specified
                if "validation_regex" in param_def and isinstance(var_value, str):
                    import re
                    if not re.match(param_def["validation_regex"], var_value):
                        type_errors.append(f"{var_name} does not match required format")
        
        if type_errors:
            raise ValidationError(
                f"Variable validation errors: {'; '.join(type_errors)}",
                model_type="PromptVersion"
            )
    
    def get_prompts_by_tag(self, tag: str) -> List[Dict[str, Any]]:
        """
        Get all prompt templates with a specific tag.
        
        Args:
            tag: Tag to search for.
            
        Returns:
            List of prompt metadata dictionaries.
        """
        # This would require adding a search method to the client
        # For now, we'll retrieve all prompts and filter in-memory
        all_prompts = self.client.list_prompt_templates()
        
        result = []
        for prompt in all_prompts:
            if tag in prompt.tags:
                # Add basic metadata about this prompt
                result.append({
                    "id": prompt.id,
                    "name": prompt.name,
                    "description": prompt.description,
                    "use_case": prompt.use_case,
                    "active_version": prompt.active_version.version_number if prompt.active_version else None,
                    "versions_count": len(prompt.versions),
                    "tags": prompt.tags,
                })
        
        return result
    
    def get_prompt_by_name(
        self, 
        name: str, 
        variables: Optional[Dict[str, Any]] = None,
        category_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get a prompt template by name.
        
        Args:
            name: Name of the prompt template to retrieve.
            variables: Optional dictionary of variables to fill in.
            category_name: Optional category name to narrow the search.
            
        Returns:
            Formatted prompt dictionary.
            
        Raises:
            PromptNotFoundError: If the prompt is not found.
        """
        # This would require adding a search method to the client
        # For now, we'll retrieve all prompts and find the first match
        all_prompts = self.client.list_prompt_templates()
        
        for prompt in all_prompts:
            if prompt.name == name:
                if not category_name or self._get_category_name(prompt.category_id) == category_name:
                    return self.get_prompt(prompt.id, variables=variables)
        
        raise PromptNotFoundError(f"No prompt found with name '{name}'")
    
    def _get_category_name(self, category_id: str) -> str:
        """Get category name by ID."""
        # This is a helper method to get a category's name
        try:
            categories = self.client.list_categories()
            for category in categories:
                if category.id == category_id:
                    return category.name
        except Exception:
            pass
        return "Unknown" 