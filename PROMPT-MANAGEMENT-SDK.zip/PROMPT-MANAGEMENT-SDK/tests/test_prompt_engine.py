import pytest
from prompt_management.core.prompt_engine import PromptEngine
from prompt_management.models.prompt import PromptTemplate, PromptVersion
from unittest.mock import MagicMock

@pytest.fixture
def mock_engine():
    mock_client = MagicMock()
    return PromptEngine(mock_client)

def test_get_prompt_by_name_found(mock_engine):
    # Crear mock version
    mock_version = MagicMock()
    mock_version.system_prompt = 'Hi'
    mock_version.version_number = '1.0.0'
    mock_version.is_active = True
    
    # Crear mock template con name como atributo directo
    mock_template = MagicMock()
    mock_template.name = 'Test'  # ← Importante: name como atributo
    mock_template.id = 'template_123'
    mock_template.active_version = mock_version
    
    # Configurar el mock para que devuelva este template
    mock_engine.client.list_prompt_templates.return_value = [mock_template]
    
    # También mockear get_prompt_template por si lo usa después
    mock_engine.client.get_prompt_template.return_value = mock_template
    
    result = mock_engine.get_prompt_by_name('Test')
    assert result['system_prompt'] == 'Hi'

def test_get_prompt_by_name_not_found(mock_engine):
    mock_engine.client.list_prompt_templates.return_value = []
    with pytest.raises(Exception):
        mock_engine.get_prompt_by_name('NotExist')

def test_fill_prompt_template(mock_engine):
    prompt = 'Hello {{name}}!'
    variables = {'name': 'World'}
    result = mock_engine._fill_prompt_template(prompt, variables)
    assert result == 'Hello World!'

def test_validate_variables_success(mock_engine):
    variables = {'a': 'x', 'b': 2}
    params = {'a': {'data_type': 'string', 'required': True}, 'b': {'data_type': 'number', 'required': True}}
    mock_engine._validate_variables(variables, params)  # Should not raise

def test_validate_variables_missing(mock_engine):
    variables = {'a': 'x'}
    params = {'a': {'data_type': 'string', 'required': True}, 'b': {'data_type': 'number', 'required': True}}
    with pytest.raises(Exception):
        mock_engine._validate_variables(variables, params)

def test_validate_variables_type_error(mock_engine):
    variables = {'a': 1, 'b': 2}
    params = {'a': {'data_type': 'string', 'required': True}, 'b': {'data_type': 'number', 'required': True}}
    with pytest.raises(Exception):
        mock_engine._validate_variables(variables, params)
