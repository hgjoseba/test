import pytest
from prompt_management.models.prompt import PromptTemplate, PromptVersion, AzureOpenAISettings, PromptCategory
from prompt_management.utils.errors import ValidationError

def test_prompt_template_active_version():
    v1 = PromptVersion(version_number='1.0.0', system_prompt='A', is_active=False)
    v2 = PromptVersion(version_number='2.0.0', system_prompt='B', is_active=True)
    template = PromptTemplate(name='T', category_id='cat', use_case='u', versions=[v1, v2])
    assert template.active_version.version_number == '2.0.0'

def test_prompt_template_get_version():
    v1 = PromptVersion(version_number='1.0.0', system_prompt='A')
    template = PromptTemplate(name='T', category_id='cat', use_case='u', versions=[v1])
    assert template.get_version('1.0.0') == v1
    assert template.get_version('2.0.0') is None

def test_prompt_template_get_latest_version():
    v1 = PromptVersion(version_number='1.0.0', system_prompt='A')
    v2 = PromptVersion(version_number='2.0.0', system_prompt='B')
    template = PromptTemplate(name='T', category_id='cat', use_case='u', versions=[v1, v2])
    assert template.get_latest_version().version_number == '2.0.0'

def test_azure_openai_settings_validator():
    with pytest.raises(ValueError):
        AzureOpenAISettings(endpoint='invalid-url', deployment_name='d')
    s = AzureOpenAISettings(endpoint='https://valid.com', deployment_name='d')
    assert s.endpoint.startswith('https://')

def test_prompt_category_fields():
    cat = PromptCategory(name='cat')
    assert cat.name == 'cat'
    assert cat.default_azure_openai is None

def test_prompt_version_semver():
    with pytest.raises(ValueError):
        PromptVersion(version_number='bad', system_prompt='x')
    v = PromptVersion(version_number='1.2.3', system_prompt='x')
    assert v.version_number == '1.2.3'

def test_prompt_parameter_allowed_values():
    from prompt_management.models.prompt import PromptParameter
    param = PromptParameter(name='p', allowed_values=['a', 'b'])
    assert 'a' in param.allowed_values
