import pytest
from prompt_management.auth.azure import AzureCredential
from unittest.mock import patch, MagicMock

def test_api_key_priority():
    cred = AzureCredential(api_key='key')
    assert cred.get_token() == 'key'
    assert cred.get_azure_credential() == 'key'

def test_service_principal_credential():
    with patch('prompt_management.auth.azure.ClientSecretCredential') as mock_cred:
        mock_cred.return_value.get_token.return_value.token = 'tok'
        cred = AzureCredential(tenant_id='tid', client_id='cid', client_secret='sec')
        cred._credential = mock_cred.return_value
        cred._token_cache = None
        cred._token_expiry = None
        assert cred.get_token() == 'tok'

def test_default_credential_classmethod():
    cred = AzureCredential.default_credential()
    assert isinstance(cred, AzureCredential)

def test_from_service_principal_classmethod():
    cred = AzureCredential.from_service_principal('tid', 'cid', 'sec')
    assert isinstance(cred, AzureCredential)
