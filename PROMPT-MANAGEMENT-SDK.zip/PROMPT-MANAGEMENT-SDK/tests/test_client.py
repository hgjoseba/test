import pytest
from prompt_management.client import PromptManagementClient
from prompt_management.models.prompt import PromptTemplate, PromptVersion, AzureOpenAISettings
from prompt_management.utils.errors import PromptManagementError, PromptNotFoundError, VersionNotFoundError
from unittest.mock import MagicMock
import uuid

@pytest.fixture
def mock_client(monkeypatch):
    # Mock CosmosClient and container
    mock_container = MagicMock()
    mock_cosmos_client = MagicMock()
    mock_cosmos_client.create_database_if_not_exists.return_value.create_container_if_not_exists.return_value = mock_container
    monkeypatch.setattr('prompt_management.client.CosmosClient', lambda *a, **kw: mock_cosmos_client)
    return PromptManagementClient(endpoint='http://localhost', key='fake-key')

def test_create_prompt_template(mock_client):
    template = PromptTemplate(name='Test', category_id='cat1', use_case='test')
    result = mock_client.create_prompt_template(template)
    assert result.id is not None
    assert result.name == 'Test'

def test_get_prompt_template_not_found(mock_client):
    mock_client._container.query_items.return_value = []
    with pytest.raises(PromptNotFoundError):
        mock_client.get_prompt_template('notfound')

def test_update_prompt_template(mock_client):
    template = PromptTemplate(id='1', name='Test', category_id='cat1', use_case='test')
    mock_client.get_prompt_template = MagicMock(return_value=template)
    updated = mock_client.update_prompt_template('1', {'name': 'Updated'})
    assert updated.name == 'Updated'

def test_delete_prompt_template(mock_client):
    template = PromptTemplate(id='1', name='Test', category_id='cat1', use_case='test')
    mock_client.get_prompt_template = MagicMock(return_value=template)
    mock_client._container.delete_item = MagicMock()
    assert mock_client.delete_prompt_template('1') is True

def test_add_prompt_version(mock_client):
    template = PromptTemplate(id='1', name='Test', category_id='cat1', use_case='test', versions=[])
    mock_client.get_prompt_template = MagicMock(return_value=template)
    version = PromptVersion(version_number='1.0.0', system_prompt='prompt')
    updated = mock_client.add_prompt_version('1', version)
    assert len(updated.versions) == 1
    assert updated.versions[0].version_number == '1.0.0'

def test_get_prompt_version_not_found(mock_client):
    template = PromptTemplate(id='1', name='Test', category_id='cat1', use_case='test', versions=[])
    mock_client.get_prompt_template = MagicMock(return_value=template)
    with pytest.raises(VersionNotFoundError):
        mock_client.get_prompt_version('1', '1.0.0')

def test_delete_prompt_version(mock_client):
    version = PromptVersion(version_number='1.0.0', system_prompt='prompt')
    template = PromptTemplate(id='1', name='Test', category_id='cat1', use_case='test', versions=[version])
    mock_client.get_prompt_template = MagicMock(return_value=template)
    updated = mock_client.delete_prompt_version('1', '1.0.0')
    assert updated.versions == []

def test_list_prompt_versions(mock_client):
    version = PromptVersion(version_number='1.0.0', system_prompt='prompt')
    template = PromptTemplate(id='1', name='Test', category_id='cat1', use_case='test', versions=[version])
    mock_client.get_prompt_template = MagicMock(return_value=template)
    versions = mock_client.list_prompt_versions('1')
    assert len(versions) == 1
    assert versions[0].version_number == '1.0.0'
