import logging
from prompt_management.utils.logging import get_logger, setup_sdk_logging

def test_get_logger_basic():
    logger = get_logger('test_logger')
    assert isinstance(logger, logging.Logger)
    logger.info('test')

def test_get_logger_file(tmp_path):
    log_file = tmp_path / 'log.txt'
    logger = get_logger('file_logger', log_file=str(log_file))
    logger.warning('file test')
    with open(log_file) as f:
        content = f.read()
    assert 'file test' in content

def test_setup_sdk_logging():
    setup_sdk_logging(level=logging.DEBUG)
    logger = logging.getLogger('prompt_management_sdk')
    logger.debug('debug test')
