import pytest
from prompt_management.utils.errors import (
    PromptManagementError, PromptNotFoundError, VersionNotFoundError,
    CategoryNotFoundError, ValidationError, PromptVersionConflictError, DatabaseError, AuthenticationError
)

def test_prompt_management_error():
    e = PromptManagementError('msg')
    assert str(e) == 'msg'

def test_prompt_not_found_error():
    e = PromptNotFoundError('id')
    assert 'not found' in str(e)
    assert e.prompt_id == 'id'

def test_version_not_found_error():
    e = VersionNotFoundError('tid', 'vid')
    assert 'Version vid not found' in str(e)
    assert e.template_id == 'tid'
    assert e.version_id == 'vid'

def test_category_not_found_error():
    e = CategoryNotFoundError('cid')
    assert 'Category with ID cid not found' in str(e)
    assert e.category_id == 'cid'

def test_validation_error():
    e = ValidationError('fail', model_type='Prompt')
    assert 'Validation error for Prompt' in str(e)

def test_prompt_version_conflict_error():
    e = PromptVersionConflictError('tid', '1.0.0')
    assert 'already exists' in str(e)
    assert e.template_id == 'tid'
    assert e.version_number == '1.0.0'

def test_database_error():
    e = DatabaseError('db', status_code=500)
    assert 'Database error (500)' in str(e)
    assert e.status_code == 500

def test_authentication_error():
    e = AuthenticationError('fail')
    assert 'Authentication error' in str(e)
