#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import uuid
import yaml
import json
from pathlib import Path

# Add parent directory to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent))

from prompt_management.client import PromptManagementClient
from prompt_management.models.prompt import PromptTemplate, PromptVersion, PromptCategory, AzureOpenAISettings
from prompt_management.core.prompt_engine import PromptEngine

# Process logic mappings
PROCESS_LOGIC_NAMES = {
    "cv_screening": "CV Screening",
    "job_profile": "Job Profile Analysis", 
    "candidate_profile": "Candidate Profile Management",
    "affinity": "Candidate-Job Affinity Matching",
    "json_parser": "JSON Parser"
}

def yaml_to_json():
    """Convert prompt.yaml to prompt.json"""
    with open("prompt.yaml", 'r', encoding='utf-8') as yaml_file:
        yaml_content = yaml.safe_load(yaml_file)
    
    with open("prompt.json", 'w', encoding='utf-8') as json_file:
        json.dump(yaml_content, json_file, indent=2, ensure_ascii=False)
    
    print("Converted prompt.yaml → prompt.json")

def load_json(file_path):
    """Load JSON content."""
    with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)

def create_azure_settings(process_data, include_schema=True):
    """Create Azure OpenAI settings with specific json_schema if available."""
    azure_settings = {
        "endpoint": "https://openai-endpoint.openai.azure.com",
        "deployment_name": "gpt-4-deployment",
        "model_name": "gpt-4",
        "region": "eastus",
        "instance_name": "production"
    }
    
    # Add json_schema only if requested and it exists in the process data
    if include_schema:
        json_schema = process_data.get('json_schema')
        if json_schema:
            azure_settings["json_schema"] = json_schema
    
    return AzureOpenAISettings(**azure_settings)

def get_or_create_category(client, name, openai_settings):
    """Get existing category or create new one."""
    for cat in client.list_categories():
        if cat.name == name:
            return cat
    
    category = PromptCategory(
        id=str(uuid.uuid4()),
        name=name,
        description=f"Category for {name.lower()} processes",
        default_azure_openai=openai_settings
    )
    return client.create_category(category)

def get_or_create_template(client, name, category_id, process_key, json_path, openai_settings):
    """Get existing template or create new one."""
    for tmpl in client.list_prompt_templates():
        if tmpl.name == name and tmpl.category_id == category_id:
            return tmpl
    
    template = PromptTemplate(
        id=str(uuid.uuid4()),
        name=name,
        description=f"Prompt template for {process_key}",
        category_id=category_id,
        use_case=process_key,
        tags=["process", "logistics", "workflow", process_key, "json-loaded"],
        metadata={"source": "json_file", "file": json_path, "category": process_key},
        default_azure_openai=openai_settings
    )
    return client.create_prompt_template(template)

def add_version_always(client, template, process_data, json_path, openai_settings):
    """Always add a new version with incremented version number."""
    system_prompt = process_data["system_prompt"]
    
    # Always create new version with incremented number
    version_num = f"1.{len(template.versions)}.0"
    
    new_version = PromptVersion(
        id=str(uuid.uuid4()),
        version_number=version_num,
        system_prompt=system_prompt,
        validation_prompt=process_data.get("validation_prompt"),
        parameters={"loaded_from": "json_file", "file_path": json_path},
        model_settings={"temperature": 0.3, "max_tokens": 1000},
        is_active=True,
        description=f"Version {version_num} from JSON",
        azure_openai=openai_settings
    )
    
    client.add_prompt_version(template.id, new_version)
    return new_version

def test_engine_functions(engine):
    """Test get_prompts_by_tag and get_prompt_by_name functions."""
    print("\nTesting PromptEngine functions:")
    print("-" * 40)
    
    # Test get_prompts_by_tag
    print("Testing get_prompts_by_tag:")
    prompts_by_tag = engine.get_prompts_by_tag("process")
    print(f"Found {len(prompts_by_tag)} prompts with tag 'process'")
    for prompt in prompts_by_tag:
        print(f"  - {prompt['name']}")
    
    # Test get_prompt_by_name
    print("\nTesting get_prompt_by_name:")
    if prompts_by_tag:
        first_prompt_name = prompts_by_tag[0]['name']
        try:
            prompt_result = engine.get_prompt_by_name(first_prompt_name)
            print(f"Successfully retrieved prompt: {prompt_result['template_name']}")
        except Exception as e:
            print(f"Error retrieving prompt by name: {e}")

def test_client_functions(client, created_items):
    """Test client functions: get_prompt_template, get_prompt_version, list_prompt_versions."""
    print("\nTesting Client functions:")
    print("-" * 40)
    
    if not created_items:
        print("No created items to test with")
        return
    
    # Get test data
    test_template = created_items[0]['template']
    test_version = created_items[0]['version']
    
    # Test 1: get_prompt_template
    print("Testing get_prompt_template:")
    try:
        retrieved_template = client.get_prompt_template(test_template.id)
        print(f"SUCCESS: Retrieved template '{retrieved_template.name}'")
        print(f"  - ID: {retrieved_template.id}")
        print(f"  - Category: {retrieved_template.category_id}")
        print(f"  - Versions: {len(retrieved_template.versions)}")
    except Exception as e:
        print(f"ERROR in get_prompt_template: {e}")
    
    # Test 2: get_prompt_version
    print("\nTesting get_prompt_version:")
    try:
        retrieved_version = client.get_prompt_version(test_template.id, test_version.version_number)
        print(f"SUCCESS: Retrieved version '{retrieved_version.version_number}'")
        print(f"  - Version ID: {retrieved_version.id}")
        print(f"  - System prompt length: {len(retrieved_version.system_prompt)} characters")
        print(f"  - Is active: {retrieved_version.is_active}")
    except Exception as e:
        print(f"ERROR in get_prompt_version: {e}")
    
    # Test 3: list_prompt_versions
    print("\nTesting list_prompt_versions:")
    try:
        versions_list = client.list_prompt_versions(test_template.id)
        print(f"SUCCESS: Found {len(versions_list)} versions")
        for version in versions_list:
            print(f"  - Version {version.version_number} (ID: {version.id})")
    except Exception as e:
        print(f"ERROR in list_prompt_versions: {e}")

def main():
    """Main execution."""
    # Convert YAML to JSON
    yaml_to_json()
    
    # Setup
    client = PromptManagementClient(
        endpoint=os.getenv("AZURE_COSMOS_ENDPOINT", "https://azcdb-prompt-mgmt.documents.azure.com:443/"),
        key=os.getenv("AZURE_COSMOS_KEY", "IgV3udk5LTl7Bj93ZWxETTlDAf4OFGOLUYnXBI821qe3oh0kR4yn2VuPe4U7MtfnSpjF1FvyrWONACDbFGkRMA=="),
        database_name="azcdb-prompt-mgmt",
        container_name="talent_match"
    )
    
    # Initialize PromptEngine
    engine = PromptEngine(client)
    
    # Load and process
    json_content = load_json("prompt.json")
    created_items = []
    
    for process_key, process_data in json_content["process_logics"].items():
        category_name = PROCESS_LOGIC_NAMES.get(process_key, process_key.replace('_', ' ').title())
        template_name = f"{category_name} Template"
        
        print(f"Processing: {process_key} -> {category_name}")
        
        # Create Azure OpenAI settings without json_schema for template/category
        template_openai_settings = create_azure_settings(process_data, include_schema=False)
        
        # Create version settings with json_schema (specific for each version)
        version_openai_settings = create_azure_settings(process_data, include_schema=True)
        
        # Get/create category and template
        category = get_or_create_category(client, category_name, template_openai_settings)
        template = get_or_create_template(client, template_name, category.id, process_key, "prompt.json", template_openai_settings)
        version = add_version_always(client, template, process_data, "prompt.json", version_openai_settings)
        
        created_items.append({"category": category, "template": template, "version": version})
    
    # Summary
    print(f"\nProcessed {len(created_items)} workflows:")
    for item in created_items:
        print(f"  {item['category'].name} - {item['template'].name}")
    
    # Test the PromptEngine functions
    test_engine_functions(engine)
    
    # Test the Client functions
    test_client_functions(client, created_items)
    
    # Cleanup option
    if input("\nDelete created resources? (y/n): ").lower() == 'y':
        for item in created_items:
            client.delete_prompt_template(item['template'].id)
            print(f"Deleted: {item['template'].name}")

if __name__ == "__main__":
    try:
        main()
        print("Completed successfully!")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)