#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Example showing how to use the Prompt Management SDK with Azure Cosmos DB.

This example demonstrates how to:
1. Connect to Cosmos DB using access key
2. Create and manage prompt templates
3. Use Azure OpenAI settings
"""

import os
import sys
from pathlib import Path
import uuid
from pprint import pprint

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

from prompt_management.client import PromptManagementClient
from prompt_management.models.prompt import (
    PromptTemplate, 
    PromptVersion, 
    PromptCategory,
    AzureOpenAISettings
)

def main():
    """Run the example."""
    # Check for required environment variables
    cosmos_endpoint = os.getenv("AZURE_COSMOS_ENDPOINT", "https://azcdb-prompt-mgmt.documents.azure.com:443/")
    cosmos_key = os.getenv("AZURE_COSMOS_KEY", "vUC0yRMnQGdYqOzu85npxvIYBFotsw0sJzOcFX3Axh1OCBl3nRbsFwKkH7881Sm7PbVjSdXeh0H5ACDbcOSlAQ==")
    
    if not cosmos_endpoint or not cosmos_key:
        print("Error: Please set the following environment variables:")
        print("  AZURE_COSMOS_ENDPOINT - Your Cosmos DB endpoint")
        print("  AZURE_COSMOS_KEY - Your Cosmos DB access key")
        print("\nYou can set them using:")
        print("  export AZURE_COSMOS_ENDPOINT='your-cosmos-endpoint'")
        print("  export AZURE_COSMOS_KEY='your-cosmos-key'")
        return 1
    
    # Create a client with access key authentication
    client = PromptManagementClient(
        endpoint=cosmos_endpoint,
        key=cosmos_key,
        database_name="azcdb-prompt-mgmt",
        container_name="prompts"
    )
    
    print("=== Cosmos DB Example ===")
    
    # Define Azure OpenAI settings
    openai_settings = AzureOpenAISettings(
        endpoint="https://openai-endpoint.openai.azure.com",
        deployment_name="gpt-4-deployment",
        model_name="gpt-4",
        region="eastus",
        instance_name="production"
    )
    
    try:
        # Create a category for technical documentation
        tech_docs_category = PromptCategory(
            id=str(uuid.uuid4()),  # Generar un ID único
            name="Technical Documentation",
            description="Prompts for generating technical documentation",
            default_azure_openai=openai_settings
        )
        
        # Create the category
        category = client.create_category(tech_docs_category)
        print(f"\nCreated category: {category.name} (ID: {category.id})")
        
        # Create a prompt template for API documentation
        api_docs_template = PromptTemplate(
            id=str(uuid.uuid4()),  # Generar un ID único
            name="API Documentation Generator",
            description="Prompt for generating API documentation",
            category_id=category.id,  # Usar el ID de la categoría creada
            use_case="api_documentation",  # Campo requerido
            tags=["api", "docs", "technical"],
            versions=[],  # Inicializar la lista de versiones vacía
            is_active=True,
            metadata={},  # Inicializar metadata vacía
            default_azure_openai=openai_settings  # Usar la configuración de Azure OpenAI
        )
        
        # Create the prompt template
        template = client.create_prompt_template(api_docs_template)
        print(f"\nCreated prompt template: {template.name} (ID: {template.id})")
        
        # Add initial version
        initial_version = PromptVersion(
            id=str(uuid.uuid4()),  # Generar un ID único
            version_number="1.0.0",
            prompt_text="""
You are a technical documentation expert. Generate comprehensive API documentation for the following endpoint:

Endpoint: {{endpoint}}
Method: {{method}}
Parameters: {{parameters}}
Response Format: {{response_format}}

Please provide:
1. Endpoint description
2. Authentication requirements
3. Request parameters
4. Response format
5. Example requests and responses
6. Error handling
            """.strip(),
            parameters={
                "endpoint": "The API endpoint URL",
                "method": "HTTP method (GET, POST, etc.)",
                "parameters": "Request parameters and their types",
                "response_format": "Expected response format"
            },
            model_settings={
                "temperature": 0.3,
                "max_tokens": 1000
            },
            is_active=True,
            description="Initial version of API documentation generator",
            azure_openai=openai_settings  # Usar la configuración de Azure OpenAI
        )
        
        # Add the version to the template
        template = client.add_prompt_version(template.id, initial_version)
        print(f"Added version 1.0.0 to prompt template")
        
        # List all prompts in the category
        print("\n=== Listing prompts in category ===")
        prompts = client.list_prompt_templates(category_id=category.id)
        for prompt in prompts:
            print(f"- {prompt.name} (ID: {prompt.id})")
            for version in prompt.versions:
                print(f"  - Version {version.version_number}: {version.description}")
        
        # Clean up by deleting the created resources
        if input("\nDelete created resources? (y/n): ").lower() == 'y':
            client.delete_prompt_template(template.id)
            print("Deleted prompt template")
        
        print("\nExample completed successfully!")
        return 0
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return 1

if __name__ == "__main__":
    main()