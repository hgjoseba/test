#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Example showing how to retrieve and use prompts with Azure OpenAI.

This example demonstrates how to:
1. Retrieve a prompt from the database
2. Fill in template variables
3. Use the prompt with Azure OpenAI API
"""

import os
import sys
import json
from pathlib import Path
import time

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

from prompt_management_sdk.client import PromptManagementClient
from prompt_management_sdk.core.prompt_engine import PromptEngine
from prompt_management_sdk.models.prompt import (
    PromptTemplate, 
    PromptVersion, 
    PromptCategory,
    AzureOpenAISettings
)

# Optional: for directly using the prompt with Azure OpenAI
try:
    from openai import AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    print("Note: openai package not available. Will show prompt but not execute it.")


def create_sample_prompt(client):
    """Create a sample prompt for demonstration purposes."""
    # Create a category
    category = client.create_category(
        PromptCategory(
            name="Example Category",
            description="Category for example prompts"
        )
    )
    
    # Create a prompt template
    template = client.create_prompt_template(
        PromptTemplate(
            name="Customer Information Summary",
            description="Summarizes customer information into a concise format",
            category_id=category.id,
            use_case="customer_data",
            tags=["customer", "summary", "example"]
        ),
        AzureOpenAISettings(
            endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", "https://example.openai.azure.com"),
            deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-35-turbo"),
            model_name="gpt-3.5-turbo"
        )
    )
    
    # Add a version with parameters
    version = client.add_prompt_version(
        template.id,
        PromptVersion(
            version_number="1.0.0",
            prompt_text="""
You are a helpful assistant that summarizes customer information.

Customer Profile:
- Name: {{customer_name}}
- Age: {{customer_age}}
- Account Type: {{account_type}}
- Purchase History: {{purchase_history}}

Please provide a concise summary of this customer in a professional tone.
Include their key characteristics and potential product recommendations based on their purchase history.
            """.strip(),
            parameters={
                "customer_name": {
                    "description": "Customer's full name",
                    "data_type": "string",
                    "required": True
                },
                "customer_age": {
                    "description": "Customer's age",
                    "data_type": "number",
                    "required": True
                },
                "account_type": {
                    "description": "Type of customer account",
                    "data_type": "string",
                    "required": True,
                    "allowed_values": ["Basic", "Premium", "VIP"]
                },
                "purchase_history": {
                    "description": "List of recent purchases",
                    "data_type": "array",
                    "required": True
                }
            },
            model_settings={
                "temperature": 0.7,
                "max_tokens": 500,
                "top_p": 0.95
            }
        )
    )
    
    return template.id


def main():
    """Run the prompt retrieval and use example."""
    # Check for required environment variables
    cosmos_endpoint = os.getenv("AZURE_COSMOS_ENDPOINT")
    cosmos_key = os.getenv("AZURE_COSMOS_KEY")
    
    if not cosmos_endpoint or not cosmos_key:
        print("Error: Please set the AZURE_COSMOS_ENDPOINT and AZURE_COSMOS_KEY environment variables.")
        print("You can set them using:")
        print("  export AZURE_COSMOS_ENDPOINT='your-cosmos-endpoint'")
        print("  export AZURE_COSMOS_KEY='your-cosmos-key'")
        return 1
    
    # Create a client
    client = PromptManagementClient(
        endpoint=cosmos_endpoint,
        key=cosmos_key,
        database_name="prompt-management",
        container_name="prompts"
    )
    
    print("=== Prompt Retrieval and Use Example ===")
    
    # Create a PromptEngine
    engine = PromptEngine(client)
    
    # Option 1: Create a sample prompt and then retrieve it
    try:
        # Check if we already have prompts
        existing_prompts = client.list_prompt_templates()
        if existing_prompts:
            template_id = existing_prompts[0].id
            print(f"Using existing prompt template: {existing_prompts[0].name}")
        else:
            # Create a sample prompt
            template_id = create_sample_prompt(client)
            print("Created new sample prompt template")
        
        # Prepare example variables
        variables = {
            "customer_name": "Jane Smith",
            "customer_age": 34,
            "account_type": "Premium",
            "purchase_history": [
                "Smartphone - $899",
                "Wireless Headphones - $249",
                "Laptop Case - $59",
                "Screen Protector - $25"
            ]
        }
        
        # Get the formatted prompt
        print("\nRetrieving prompt with variables...")
        prompt_data = engine.get_prompt(template_id, variables=variables)
        
        # Print the prompt details
        print("\n=== Prompt Details ===")
        print(f"Template: {prompt_data['template_name']}")
        print(f"Version: {prompt_data['version_number']}")
        
        if "azure_openai" in prompt_data:
            print("\n=== Azure OpenAI Settings ===")
            for key, value in prompt_data["azure_openai"].items():
                print(f"{key}: {value}")
        
        print("\n=== Model Settings ===")
        for key, value in prompt_data["model_settings"].items():
            print(f"{key}: {value}")
        
        print("\n=== Formatted Prompt ===")
        print(prompt_data["prompt_text"])
        
        # Use the prompt with Azure OpenAI if available
        if OPENAI_AVAILABLE and "azure_openai" in prompt_data:
            openai_settings = prompt_data["azure_openai"]
            api_key = os.getenv("AZURE_OPENAI_KEY")
            
            if api_key and input("\nSend this prompt to Azure OpenAI? (y/n): ").lower() == 'y':
                print("\nSending to Azure OpenAI...")
                
                # Initialize the client
                client = AzureOpenAI(
                    azure_endpoint=openai_settings["endpoint"],
                    api_key=api_key,
                    api_version=openai_settings["api_version"]
                )
                
                # Prepare model settings
                model_settings = prompt_data["model_settings"].copy()
                if "max_tokens" in model_settings:
                    model_settings["max_tokens"] = int(model_settings["max_tokens"])
                
                # Send the request
                start_time = time.time()
                response = client.chat.completions.create(
                    model=openai_settings["deployment_name"],
                    messages=[
                        {"role": "system", "content": prompt_data["prompt_text"]}
                    ],
                    **model_settings
                )
                
                # Print the response
                print(f"\n=== Azure OpenAI Response (took {time.time() - start_time:.2f}s) ===")
                print(response.choices[0].message.content)
        
        # Option 2: Get a prompt by name
        try:
            print("\n\n=== Retrieving Prompt by Name ===")
            print("Fetching 'Customer Information Summary' prompt...")
            
            prompt_by_name = engine.get_prompt_by_name(
                "Customer Information Summary",
                variables={
                    "customer_name": "John Doe",
                    "customer_age": 42,
                    "account_type": "VIP",
                    "purchase_history": [
                        "4K TV - $1499",
                        "Home Theater System - $899",
                        "Game Console - $499"
                    ]
                }
            )
            
            print(f"\nFound prompt: {prompt_by_name['template_name']} (version {prompt_by_name['version_number']})")
            print("\nFormatted Prompt:")
            print(prompt_by_name["prompt_text"])
            
        except Exception as e:
            print(f"Error retrieving prompt by name: {e}")
        
        print("\nExample completed successfully!")
        return 0
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(main()) 