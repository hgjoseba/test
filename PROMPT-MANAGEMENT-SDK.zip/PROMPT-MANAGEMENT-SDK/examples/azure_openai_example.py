#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Example showing how to use the Prompt Management SDK with Azure OpenAI.

This example demonstrates how to:
1. Create prompt templates linked to Azure OpenAI endpoints
2. Add versioned prompts
3. Retrieve prompts by Azure OpenAI endpoint
"""

import os
import sys
from pathlib import Path
import uuid
from pprint import pprint

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

from prompt_management_sdk.client import PromptManagementClient
from prompt_management_sdk.models.prompt import (
    PromptTemplate, 
    PromptVersion, 
    PromptCategory,
    AzureOpenAISettings
)
from prompt_management_sdk.auth.azure import AzureCredential


def main():
    """Run the Azure OpenAI example."""
    # Check for required environment variables
    cosmos_endpoint = os.getenv("AZURE_COSMOS_ENDPOINT")
    cosmos_key = os.getenv("AZURE_COSMOS_KEY")
    
    if not cosmos_endpoint or not cosmos_key:
        print("Error: Please set the AZURE_COSMOS_ENDPOINT and AZURE_COSMOS_KEY environment variables.")
        print("You can set them using:")
        print("  export AZURE_COSMOS_ENDPOINT='your-cosmos-endpoint'")
        print("  export AZURE_COSMOS_KEY='your-cosmos-key'")
        return 1
    
    # Create a client
    client = PromptManagementClient(
        endpoint=cosmos_endpoint,
        key=cosmos_key,
        database_name="prompt-management",
        container_name="prompts"
    )
    
    print("=== Azure OpenAI Prompt Management Example ===")
    
    # Define Azure OpenAI settings for different environments
    production_openai = AzureOpenAISettings(
        endpoint="https://prod-openai-eastus.openai.azure.com",
        deployment_name="gpt-4-deployment",
        model_name="gpt-4",
        region="eastus",
        instance_name="production"
    )
    
    staging_openai = AzureOpenAISettings(
        endpoint="https://staging-openai-westus.openai.azure.com",
        deployment_name="gpt-35-turbo-deployment",
        model_name="gpt-35-turbo",
        region="westus",
        instance_name="staging"
    )
    
    # Create a category for customer service prompts
    customer_service_category = PromptCategory(
        name="Customer Service",
        description="Prompts for customer service applications",
        default_azure_openai=production_openai  # Default to production for this category
    )
    
    try:
        # Create the category
        category = client.create_category(customer_service_category)
        print(f"\nCreated category: {category.name} (ID: {category.id})")
        category_id = category.id
        
        # Create a prompt template for order inquiries
        order_inquiry_template = PromptTemplate(
            name="Order Status Inquiry",
            description="Prompt for handling customer order status inquiries",
            category_id=category_id,
            use_case="customer_support",
            tags=["order", "inquiry", "status"]
        )
        
        # Create the prompt template with default Azure OpenAI settings
        template = client.create_prompt_template(order_inquiry_template, production_openai)
        print(f"\nCreated prompt template: {template.name} (ID: {template.id})")
        
        # Add initial version
        initial_version = PromptVersion(
            version_number="1.0.0",
            prompt_text="""
You are a helpful customer service assistant for our company.
The customer is inquiring about their order status.

Order information: {{order_info}}
Customer information: {{customer_info}}

Please provide a helpful response that addresses their inquiry.
            """.strip(),
            parameters={
                "order_info": "Information about the customer's order",
                "customer_info": "Basic information about the customer"
            },
            model_settings={
                "temperature": 0.7,
                "max_tokens": 500
            },
            is_active=True,
            description="Initial version of order status inquiry prompt"
        )
        
        # Add the version to the template
        template = client.add_prompt_version(template.id, initial_version)
        print(f"Added version 1.0.0 to prompt template")
        
        # Add another version with different wording, using staging environment
        improved_version = PromptVersion(
            version_number="1.1.0",
            prompt_text="""
You are a friendly and efficient customer service assistant for our e-commerce company.
A customer has asked about the status of their order.

Available order details: {{order_info}}
Customer profile: {{customer_info}}

Please respond with:
1. A personalized greeting
2. Information about their order status
3. Next steps or expected delivery
4. An offer to help with anything else
            """.strip(),
            parameters={
                "order_info": "Information about the customer's order",
                "customer_info": "Basic information about the customer"
            },
            model_settings={
                "temperature": 0.5,
                "max_tokens": 600
            },
            is_active=True,
            description="Improved version with better structure and personalization"
        )
        
        # Add the version with specific Azure OpenAI settings
        template = client.add_prompt_version(template.id, improved_version, staging_openai)
        print(f"Added version 1.1.0 to prompt template (using staging environment)")
        
        # Now create another prompt template for a different use case
        refund_request_template = PromptTemplate(
            name="Refund Request Handler",
            description="Prompt for handling customer refund requests",
            category_id=category_id,
            use_case="customer_support",
            tags=["refund", "request", "return"],
            default_azure_openai=staging_openai  # Default to staging for this template
        )
        
        # Create the prompt template
        refund_template = client.create_prompt_template(refund_request_template)
        print(f"\nCreated prompt template: {refund_template.name} (ID: {refund_template.id})")
        
        # Add version for refund requests
        refund_version = PromptVersion(
            version_number="1.0.0",
            prompt_text="""
You are a customer service assistant handling a refund request.

Order details: {{order_info}}
Return reason: {{return_reason}}
Customer history: {{customer_history}}

Please help process this refund request appropriately based on company policy.
            """.strip(),
            parameters={
                "order_info": "Information about the order being returned",
                "return_reason": "Reason for the return/refund",
                "customer_history": "Customer's purchase and return history"
            },
            model_settings={
                "temperature": 0.3,
                "max_tokens": 800
            }
        )
        
        # Add the version
        refund_template = client.add_prompt_version(refund_template.id, refund_version)
        print(f"Added version 1.0.0 to refund request template")
        
        # Now demonstrate retrieving prompts by Azure OpenAI endpoint
        print("\n=== Finding prompts by endpoint ===")
        
        # Find prompts for production endpoint
        production_prompts = client.find_prompts_by_endpoint(production_openai.endpoint)
        print(f"\nFound {len(production_prompts)} prompts for production endpoint:")
        for prompt in production_prompts:
            print(f"- {prompt.name} (ID: {prompt.id})")
            # Show which versions use this endpoint
            for version in prompt.versions:
                if version.azure_openai and version.azure_openai.endpoint == production_openai.endpoint:
                    print(f"  - Version {version.version_number} (explicit production endpoint)")
                elif prompt.default_azure_openai and prompt.default_azure_openai.endpoint == production_openai.endpoint and not version.azure_openai:
                    print(f"  - Version {version.version_number} (inherits production endpoint)")
        
        # Find prompts for staging endpoint
        staging_prompts = client.find_prompts_by_endpoint(staging_openai.endpoint)
        print(f"\nFound {len(staging_prompts)} prompts for staging endpoint:")
        for prompt in staging_prompts:
            print(f"- {prompt.name} (ID: {prompt.id})")
            # Show which versions use this endpoint
            for version in prompt.versions:
                if version.azure_openai and version.azure_openai.endpoint == staging_openai.endpoint:
                    print(f"  - Version {version.version_number} (explicit staging endpoint)")
                elif prompt.default_azure_openai and prompt.default_azure_openai.endpoint == staging_openai.endpoint and not version.azure_openai:
                    print(f"  - Version {version.version_number} (inherits staging endpoint)")
        
        # Clean up by deleting the created resources to keep the database clean
        if input("\nDelete created resources? (y/n): ").lower() == 'y':
            client.delete_prompt_template(template.id)
            client.delete_prompt_template(refund_template.id)
            print("Deleted prompt templates")
        
        print("\nExample completed successfully!")
        return 0
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(main()) 