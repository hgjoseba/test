"""
Tests for the Azure Prompt Manager.
"""
import unittest
from unittest.mock import patch, MagicMock
import pytest
from datetime import datetime

from src.providers.azure_prompt_manager import AzurePromptManager


class TestAzurePromptManager(unittest.TestCase):
    """Tests for the AzurePromptManager class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.prompt_manager = AzurePromptManager()
    
    def test_get_system_prompt(self):
        """Test get_system_prompt method."""
        system_prompt = self.prompt_manager.get_system_prompt()
        
        # Verify the system prompt contains expected text
        self.assertIsInstance(system_prompt, str)
        self.assertIn("You are an HR recruiter specialized in CV", system_prompt)
        self.assertIn("Work Experience", system_prompt)
        self.assertIn("Official Degree Studies", system_prompt)
        self.assertIn("Languages", system_prompt)
        
        # Verify the prompt includes the current date
        current_date = datetime.now().strftime('%B %Y')
        self.assertIn(current_date, system_prompt)
    
    def test_get_secondary_system_prompt(self):
        """Test get_secondary_system_prompt method."""
        secondary_prompt = self.prompt_manager.get_secondary_system_prompt()
        
        # Verify the secondary system prompt contains expected text
        self.assertIsInstance(secondary_prompt, str)
        self.assertIn("expert auditor", secondary_prompt)
        self.assertIn("human resources", secondary_prompt)
        
        # Verify the prompt includes the current date
        current_date = datetime.now().strftime('%B %Y')
        self.assertIn(current_date, secondary_prompt)
    
    def test_get_secondary_jsonparsed_prompt(self):
        """Test get_secondary_jsonparsed_prompt method."""
        json_prompt = self.prompt_manager.get_secondary_jsonparsed_prompt()
        
        # Verify the JSON parsed prompt contains expected text
        self.assertIsInstance(json_prompt, str)
        self.assertIn("Parse the same content into JSON format", json_prompt)
        self.assertIn("process and include both in the output", json_prompt)
        self.assertIn("CV (Curriculum Vitae)", json_prompt)
    
    def test_get_json_schema(self):
        """Test get_json_schema method."""
        schema = self.prompt_manager.get_json_schema()
        
        # Verify schema is a dictionary with expected structure
        self.assertIsInstance(schema, dict)
        self.assertIn("type", schema)
        self.assertIn("properties", schema)
        self.assertIn("results", schema["properties"])
        
        # Verify schema includes expected fields for CV analysis
        results_items = schema["properties"]["results"]["items"]
        self.assertIn("work_experience", results_items["properties"])
        self.assertIn("educational_level", results_items["properties"])
        self.assertIn("languages", results_items["properties"])
        self.assertIn("soft_skills", results_items["properties"])
        self.assertIn("hard_skills", results_items["properties"])
    
    def test_build_multiple_screening_prompt(self):
        """Test build_multiple_screening_prompt method."""
        # Sample contents
        contents = [
            {"document_id": "doc1", "content_md": "CV content 1"},
            {"document_id": "doc2", "content_md": "CV content 2"}
        ]
        
        prompt = self.prompt_manager.build_multiple_screening_prompt(contents)
        
        # Verify prompt contains expected structure and content
        self.assertIsInstance(prompt, str)
        self.assertIn("Process each document individually", prompt)
        
        # Verify each document is included
        self.assertIn("document ID 'doc1'", prompt)
        self.assertIn("CV content 1", prompt)
        self.assertIn("document ID 'doc2'", prompt)
        self.assertIn("CV content 2", prompt)
        
        # Verify documents are separated properly
        self.assertIn("Start of content", prompt)
        self.assertIn("End of document", prompt)
    
    def test_build_multiple_screening_prompt_empty(self):
        """Test build_multiple_screening_prompt with empty content."""
        prompt = self.prompt_manager.build_multiple_screening_prompt([])
        
        # Verify empty prompt structure
        self.assertIsInstance(prompt, str)
        self.assertIn("Process each document individually", prompt)
        
        # No documents should be included
        self.assertNotIn("Start of content", prompt)
        self.assertNotIn("End of document", prompt)


if __name__ == '__main__':
    unittest.main() 