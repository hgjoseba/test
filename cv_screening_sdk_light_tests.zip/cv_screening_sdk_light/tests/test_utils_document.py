"""
Tests for document utility functions.
"""
import unittest
from unittest.mock import patch, MagicMock, mock_open
import pytest
import os
import base64

from src.utils.document import (
    load_cv_content,
    load_cv_from_base64,
    is_base64,
    analyze_document
)
from src.core.exceptions import DocumentParsingError
from src.auth.azure import AzureCredential


class TestDocumentUtils(unittest.TestCase):
    """Tests for document utility functions."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_credential = MagicMock(spec=AzureCredential)
        
    @patch('os.path.exists')
    @patch('src.utils.document.analyze_document')
    def test_load_cv_content_txt(self, mock_analyze, mock_exists):
        """Test load_cv_content with text file."""
        # Setup
        mock_exists.return_value = True
        mock_analyze.return_value = ("Sample CV text content", {"type": "txt"})
        
        # Test
        result = load_cv_content("test.txt")
        
        # Assert
        self.assertEqual(result, "Sample CV text content")
        mock_analyze.assert_called_once_with("test.txt")
    
    @patch('os.path.exists')
    @patch('src.utils.document.analyze_document')
    def test_load_cv_content_pdf(self, mock_analyze, mock_exists):
        """Test load_cv_content with PDF file."""
        # Setup
        mock_exists.return_value = True
        mock_analyze.return_value = ("Extracted PDF content", {"type": "pdf"})
        
        # Test
        result = load_cv_content("test.pdf")
        
        # Assert
        self.assertEqual(result, "Extracted PDF content")
        mock_analyze.assert_called_once_with("test.pdf")
    
    @patch('os.path.exists')
    def test_load_cv_content_unsupported(self, mock_exists):
        """Test load_cv_content with unsupported file format."""
        # Setup
        mock_exists.return_value = True
        
        # Test & Assert
        with self.assertRaises(DocumentParsingError):
            load_cv_content("test.xyz")
    
    @patch('os.path.exists')
    def test_load_cv_content_file_not_found(self, mock_exists):
        """Test load_cv_content with non-existent file."""
        # Setup
        mock_exists.return_value = False
        
        # Test & Assert
        with self.assertRaises(FileNotFoundError):
            load_cv_content("nonexistent.txt")
    
    @patch('src.utils.document.analyze_document_from_base64')
    def test_load_cv_from_base64_string(self, mock_analyze):
        """Test load_cv_from_base64 with string input."""
        # Setup
        mock_analyze.return_value = ("Decoded CV content", {"type": "pdf"})
        base64_str = "U2FtcGxlIENWIGNvbnRlbnQ="  # "Sample CV content" in base64
        
        # Test
        result = load_cv_from_base64(base64_str, self.mock_credential)
        
        # Assert
        self.assertEqual(result, "Decoded CV content")
        mock_analyze.assert_called_once()
        # Check that the first argument is bytes
        self.assertIsInstance(mock_analyze.call_args[1]['base64_string'], bytes)
    
    @patch('src.utils.document.analyze_document_from_base64')
    def test_load_cv_from_base64_bytes(self, mock_analyze):
        """Test load_cv_from_base64 with bytes input."""
        # Setup
        mock_analyze.return_value = ("Decoded CV content", {"type": "pdf"})
        base64_bytes = b"U2FtcGxlIENWIGNvbnRlbnQ="  # "Sample CV content" in base64
        
        # Test
        result = load_cv_from_base64(base64_bytes, self.mock_credential)
        
        # Assert
        self.assertEqual(result, "Decoded CV content")
        mock_analyze.assert_called_once()
    
    def test_load_cv_from_base64_empty(self):
        """Test load_cv_from_base64 with empty input."""
        # Test & Assert
        with self.assertRaises(DocumentParsingError):
            load_cv_from_base64("", self.mock_credential)
    
    def test_is_base64_valid_string(self):
        """Test is_base64 with valid base64 string."""
        # Valid base64 string
        base64_str = "SGVsbG8gV29ybGQ="  # "Hello World" in base64
        
        # Test
        result = is_base64(base64_str)
        
        # Assert
        self.assertTrue(result)
    
    def test_is_base64_valid_bytes(self):
        """Test is_base64 with valid base64 bytes."""
        # Valid base64 bytes
        base64_bytes = b"SGVsbG8gV29ybGQ="  # "Hello World" in base64
        
        # Test
        result = is_base64(base64_bytes)
        
        # Assert
        self.assertTrue(result)
    
    def test_is_base64_invalid(self):
        """Test is_base64 with invalid input."""
        # Invalid base64 input (contains invalid characters)
        invalid_input = "This is not base64!"
        
        # Test
        result = is_base64(invalid_input)
        
        # Assert
        self.assertFalse(result)
    
    def test_is_base64_empty(self):
        """Test is_base64 with empty input."""
        # Test
        result = is_base64("")
        
        # Assert
        self.assertFalse(result)
    
    @patch('src.utils.document._safe_open')
    def test_analyze_document_txt(self, mock_safe_open):
        """Test analyze_document with text file."""
        # Setup
        mock_file = MagicMock()
        mock_file.read.return_value = "Sample text content"
        mock_safe_open.return_value.__enter__.return_value = mock_file
        
        # Test
        content, metadata = analyze_document("test.txt")
        
        # Assert
        self.assertEqual(content, "Sample text content")
        self.assertEqual(metadata["type"], "txt")
    
    @patch('src.utils.document._safe_open')
    def test_analyze_document_pdf(self, mock_safe_open):
        """Test analyze_document with PDF file."""
        # Setup
        mock_file = MagicMock()
        mock_file.read.return_value = b"PDF binary content"
        mock_safe_open.return_value.__enter__.return_value = mock_file
        
        # Test
        content, metadata = analyze_document("test.pdf")
        
        # Assert
        self.assertEqual(content, "Extracted PDF content")
        self.assertEqual(metadata["type"], "pdf")
    
    @patch('src.utils.document._safe_open')
    def test_analyze_document_docx(self, mock_safe_open):
        """Test analyze_document with DOCX file."""
        # Setup
        mock_file = MagicMock()
        mock_file.read.return_value = b"DOCX binary content"
        mock_safe_open.return_value.__enter__.return_value = mock_file
        
        # Test
        content, metadata = analyze_document("test.docx")
        
        # Assert
        self.assertEqual(content, "Extracted DOCX content")
        self.assertEqual(metadata["type"], "docx")
    
    def test_analyze_document_unsupported(self):
        """Test analyze_document with unsupported file format."""
        # Test & Assert
        with self.assertRaises(DocumentParsingError):
            analyze_document("test.xyz")
    
    @patch('src.utils.document._safe_open')
    def test_analyze_document_txt_error(self, mock_safe_open):
        """Test analyze_document with text file error."""
        # Setup
        mock_safe_open.return_value.__enter__.side_effect = Exception("Read error")
        
        # Test & Assert
        with self.assertRaises(DocumentParsingError):
            analyze_document("test.txt")


if __name__ == '__main__':
    unittest.main() 