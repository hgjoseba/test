"""
Tests for the configuration module.
"""
import unittest
from unittest.mock import patch
import pytest
import os

from src.core.config import AzureConfig, OpenAIConfig, Config


class TestAzureConfig(unittest.TestCase):
    """Tests for the AzureConfig class."""
    
    def test_default_values(self):
        """Test default values."""
        config = AzureConfig()
        
        self.assertEqual(config.endpoint, "")
        self.assertEqual(config.api_version, "2023-05-15")
    
    def test_custom_values(self):
        """Test custom values."""
        config = AzureConfig(
            endpoint="https://custom-endpoint.openai.azure.com",
            api_version="2023-12-01"
        )
        
        self.assertEqual(config.endpoint, "https://custom-endpoint.openai.azure.com")
        self.assertEqual(config.api_version, "2023-12-01")


class TestOpenAIConfig(unittest.TestCase):
    """Tests for the OpenAIConfig class."""
    
    def test_default_values(self):
        """Test default values."""
        config = OpenAIConfig()
        
        self.assertEqual(config.api_key, "")
        self.assertEqual(config.model_name, "gpt-4")
        self.assertEqual(config.temperature, 0.1)
        self.assertIsNone(config.max_tokens)
        self.assertTrue(config.connection_verify)
        self.assertIsNone(config.system_prompt)
        self.assertIsNone(config.http_proxy)
        self.assertIsNone(config.https_proxy)
    
    def test_custom_values(self):
        """Test custom values."""
        config = OpenAIConfig(
            api_key="test-api-key",
            model_name="gpt-4-turbo",
            temperature=0.5,
            max_tokens=2000,
            connection_verify=False,
            system_prompt="Custom prompt",
            http_proxy="http://proxy:8080",
            https_proxy="https://proxy:8443"
        )
        
        self.assertEqual(config.api_key, "test-api-key")
        self.assertEqual(config.model_name, "gpt-4-turbo")
        self.assertEqual(config.temperature, 0.5)
        self.assertEqual(config.max_tokens, 2000)
        self.assertFalse(config.connection_verify)
        self.assertEqual(config.system_prompt, "Custom prompt")
        self.assertEqual(config.http_proxy, "http://proxy:8080")
        self.assertEqual(config.https_proxy, "https://proxy:8443")
    
    def test_temperature_validation(self):
        """Test temperature validation."""
        # Valid temperatures
        OpenAIConfig(temperature=0.0)
        OpenAIConfig(temperature=0.5)
        OpenAIConfig(temperature=1.0)
        
        # Invalid temperatures
        with self.assertRaises(ValueError):
            OpenAIConfig(temperature=-0.1)
        
        with self.assertRaises(ValueError):
            OpenAIConfig(temperature=1.1)


class TestConfig(unittest.TestCase):
    """Tests for the Config class."""
    
    def test_default_values(self):
        """Test default values."""
        config = Config()
        
        # Check OpenAI config defaults
        self.assertEqual(config.openai.api_key, "")
        self.assertEqual(config.openai.model_name, "gpt-4")
        self.assertEqual(config.openai.temperature, 0.1)
        
        # Check Azure config defaults
        self.assertEqual(config.azure.endpoint, "")
        self.assertEqual(config.azure.api_version, "2023-05-15")
    
    def test_custom_values(self):
        """Test custom values."""
        config = Config(
            openai=OpenAIConfig(
                api_key="test-api-key",
                model_name="gpt-4-turbo",
                temperature=0.5
            ),
            azure=AzureConfig(
                endpoint="https://custom-endpoint.openai.azure.com",
                api_version="2023-12-01"
            )
        )
        
        # Check OpenAI custom values
        self.assertEqual(config.openai.api_key, "test-api-key")
        self.assertEqual(config.openai.model_name, "gpt-4-turbo")
        self.assertEqual(config.openai.temperature, 0.5)
        
        # Check Azure custom values
        self.assertEqual(config.azure.endpoint, "https://custom-endpoint.openai.azure.com")
        self.assertEqual(config.azure.api_version, "2023-12-01")
    
    @patch.dict('os.environ', {
        'AZURE_OPENAI_API_KEY': 'env-api-key',
        'AZURE_OPENAI_DEPLOYMENT': 'env-gpt-4',
        'OPENAI_TEMPERATURE': '0.7',
        'OPENAI_MAX_TOKENS': '1500',
        'OPENAI_CONNECTION_VERIFY': 'false',
        'OPENAI_SYSTEM_PROMPT': 'Env system prompt',
        'OPENAI_HTTP_PROXY': 'http://env-proxy:8080',
        'OPENAI_HTTPS_PROXY': 'https://env-proxy:8443',
        'AZURE_OPENAI_ENDPOINT': 'https://env-endpoint.openai.azure.com',
        'AZURE_OPENAI_API_VERSION': '2023-11-01'
    })
    def test_environment_variables(self):
        """Test configuration from environment variables."""
        config = Config()
        
        # Check OpenAI values from environment
        self.assertEqual(config.openai.api_key, 'env-api-key')
        self.assertEqual(config.openai.model_name, 'env-gpt-4')
        self.assertEqual(config.openai.temperature, 0.7)
        self.assertEqual(config.openai.max_tokens, 1500)
        self.assertFalse(config.openai.connection_verify)
        self.assertEqual(config.openai.system_prompt, 'Env system prompt')
        self.assertEqual(config.openai.http_proxy, 'http://env-proxy:8080')
        self.assertEqual(config.openai.https_proxy, 'https://env-proxy:8443')
        
        # Check Azure values from environment
        self.assertEqual(config.azure.endpoint, 'https://env-endpoint.openai.azure.com')
        self.assertEqual(config.azure.api_version, '2023-11-01')
    
    @patch.dict('os.environ', {
        'OPENAI_MAX_TOKENS': '0'
    })
    def test_max_tokens_zero(self):
        """Test max_tokens is None when env var is 0."""
        config = Config()
        self.assertIsNone(config.openai.max_tokens)


if __name__ == '__main__':
    unittest.main() 