"""
Tests for exception classes.
"""
import unittest
import pytest

from src.core.exceptions import (
    SDKError,
    ConfigurationError,
    OpenAIError,
    RateLimitError,
    DocumentParsingError,
    ValidationError,
    AuthenticationError,
)


class TestExceptions(unittest.TestCase):
    """Tests for exception classes."""
    
    def test_sdk_error(self):
        """Test SDKError base exception."""
        # Test inheritance
        self.assertTrue(issubclass(SDKError, Exception))
        
        # Test raising
        with self.assertRaises(SDKError):
            raise SDKError("Test error")
        
        # Test message
        try:
            raise SDKError("Test error message")
        except SDKError as e:
            self.assertEqual(str(e), "Test error message")
    
    def test_configuration_error(self):
        """Test ConfigurationError."""
        # Test inheritance
        self.assertTrue(issubclass(ConfigurationError, SDKError))
        
        # Test raising
        with self.assertRaises(ConfigurationError):
            raise ConfigurationError("Test error")
        
        # Test message
        try:
            raise ConfigurationError("Configuration test error")
        except ConfigurationError as e:
            self.assertEqual(str(e), "Configuration test error")
    
    def test_openai_error(self):
        """Test OpenAIError."""
        # Test inheritance
        self.assertTrue(issubclass(OpenAIError, SDKError))
        
        # Test raising
        with self.assertRaises(OpenAIError):
            raise OpenAIError("Test error")
        
        # Test message
        try:
            raise OpenAIError("OpenAI test error")
        except OpenAIError as e:
            self.assertEqual(str(e), "OpenAI test error")
    
    def test_rate_limit_error(self):
        """Test RateLimitError."""
        # Test inheritance
        self.assertTrue(issubclass(RateLimitError, OpenAIError))
        
        # Test raising
        with self.assertRaises(RateLimitError):
            raise RateLimitError("Test error")
        
        # Test message
        try:
            raise RateLimitError("Rate limit test error")
        except RateLimitError as e:
            self.assertEqual(str(e), "Rate limit test error")
    
    def test_document_parsing_error(self):
        """Test DocumentParsingError."""
        # Test inheritance
        self.assertTrue(issubclass(DocumentParsingError, SDKError))
        
        # Test raising
        with self.assertRaises(DocumentParsingError):
            raise DocumentParsingError("Test error")
        
        # Test message
        try:
            raise DocumentParsingError("Document parsing test error")
        except DocumentParsingError as e:
            self.assertEqual(str(e), "Document parsing test error")
    
    def test_validation_error(self):
        """Test ValidationError."""
        # Test inheritance
        self.assertTrue(issubclass(ValidationError, SDKError))
        
        # Test raising
        with self.assertRaises(ValidationError):
            raise ValidationError("Test error")
        
        # Test message
        try:
            raise ValidationError("Validation test error")
        except ValidationError as e:
            self.assertEqual(str(e), "Validation test error")
    
    def test_authentication_error(self):
        """Test AuthenticationError."""
        # Test inheritance
        self.assertTrue(issubclass(AuthenticationError, SDKError))
        
        # Test raising
        with self.assertRaises(AuthenticationError):
            raise AuthenticationError("Test error")
        
        # Test message
        try:
            raise AuthenticationError("Authentication test error")
        except AuthenticationError as e:
            self.assertEqual(str(e), "Authentication test error")
    
    def test_error_hierarchy(self):
        """Test exception hierarchy."""
        # Specific exceptions should be caught by base exception
        with self.assertRaises(SDKError):
            raise ConfigurationError("Test")
        
        with self.assertRaises(SDKError):
            raise OpenAIError("Test")
        
        with self.assertRaises(SDKError):
            raise DocumentParsingError("Test")
        
        # RateLimitError should be caught by OpenAIError
        with self.assertRaises(OpenAIError):
            raise RateLimitError("Test")


if __name__ == '__main__':
    unittest.main() 