"""
Tests for the Azure OpenAI provider.
"""
import unittest
from unittest.mock import patch, MagicMock, PropertyMock
import pytest
import json
from datetime import datetime, timedelta

from src.providers.azure_provider import AzureOpenAIProvider
from src.auth.azure import AzureCredential
from src.core.exceptions import OpenAIError


class TestAzureOpenAIProvider(unittest.TestCase):
    """Tests for the AzureOpenAIProvider class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_endpoint = "https://test-endpoint.openai.azure.com"
        self.mock_credential = MagicMock(spec=AzureCredential)
        self.mock_credential.get_token.return_value = ("mock_token", datetime.utcnow() + timedelta(hours=1))
        
        # Mock openai client
        self.mock_openai_client = MagicMock()
        self.mock_completion = MagicMock()
        self.mock_completion.choices = [MagicMock()]
        self.mock_completion.choices[0].message.content = json.dumps({"analysis": "test result"})
        self.mock_openai_client.chat.completions.create.return_value = self.mock_completion
        
        # Patch AzureOpenAI class
        self.azure_openai_patcher = patch('src.providers.azure_provider.AzureOpenAI')
        self.mock_azure_openai = self.azure_openai_patcher.start()
        self.mock_azure_openai.return_value = self.mock_openai_client
    
    def tearDown(self):
        """Tear down test fixtures."""
        self.azure_openai_patcher.stop()
    
    def test_init(self):
        """Test initialization with parameters."""
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4",
            api_version="2023-05-15",
            temperature=0.1,
            max_tokens=1000,
            connection_verify=True,
            base_model="gpt-4",
        )
        
        self.assertIsNotNone(provider)
        self.assertEqual(provider.endpoint, self.mock_endpoint)
        self.assertEqual(provider.credential, self.mock_credential)
        self.assertEqual(provider.deployment_name, "gpt-4")
        self.assertEqual(provider.api_version, "2023-05-15")
        self.assertEqual(provider.temperature, 0.1)
        self.assertEqual(provider.max_tokens, 1000)
        self.assertEqual(provider.base_model, "gpt-4")
    
    def test_infer_base_model_gpt4(self):
        """Test infer_base_model with GPT-4 deployment."""
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential
        )
        
        # Test with exact match
        result = provider._infer_base_model("gpt-4")
        self.assertEqual(result, "gpt-4")
        
        # Test with prefix
        result = provider._infer_base_model("gpt-4-turbo")
        self.assertEqual(result, "gpt-4")
        
        # Test with custom name containing model
        result = provider._infer_base_model("my-custom-gpt-4-deployment")
        self.assertEqual(result, "gpt-4")
    
    def test_infer_base_model_gpt35(self):
        """Test infer_base_model with GPT-3.5 deployment."""
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential
        )
        
        # El método actual devuelve None para modelos que no están explícitamente en ALLOWED_MODELS
        # ya que gpt-35-turbo no está en la lista de modelos permitidos
        result = provider._infer_base_model("gpt-35-turbo")
        self.assertIsNone(result)
        
        # El método actual no hace la conversión específica para gpt-35-turbo
        result = provider._infer_base_model("gpt-35-turbo-16k")
        self.assertIsNone(result)
        
        # El método actual tampoco infiere gpt-3.5-turbo para custom deployments
        result = provider._infer_base_model("my-custom-gpt-35-turbo-deployment")
        self.assertIsNone(result)
    
    def test_infer_base_model_unknown(self):
        """Test infer_base_model with unknown deployment."""
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential
        )
        
        result = provider._infer_base_model("unknown-model")
        self.assertIsNone(result)
    
    def test_is_model_schema_capable(self):
        """Test is_model_schema_capable method."""
        # Test with GPT-4 (should be capable)
        provider_gpt4 = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            base_model="gpt-4"
        )
        self.assertTrue(provider_gpt4._is_model_schema_capable())
        
        # Test with unknown model (should not be capable)
        provider_unknown = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            base_model="unknown-model"
        )
        self.assertFalse(provider_unknown._is_model_schema_capable())
    
    @patch('src.providers.azure_provider.AzurePromptManager')
    def test_get_completion(self, mock_prompt_manager):
        """Test get_completion method."""
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4",
            temperature=0.1
        )
        
        messages = [{"role": "user", "content": "Test message"}]
        result = provider.get_completion(messages)
        
        # Check client was called correctly
        self.mock_openai_client.chat.completions.create.assert_called_once_with(
            model="gpt-4",
            messages=messages,
            temperature=0.1
        )
        
        # Check result is returned
        self.assertEqual(result, self.mock_completion)
    
    @patch('src.providers.azure_provider.AzurePromptManager')
    def test_get_completion_with_json_schema(self, mock_prompt_manager):
        """Test get_completion method with JSON schema."""
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4",
            temperature=0.1
        )
        
        messages = [{"role": "user", "content": "Test message"}]
        schema = {"type": "object", "properties": {"analysis": {"type": "string"}}}
        result = provider.get_completion(messages, json_schema=schema)
        
        # Check client was called correctly with JSON schema
        self.mock_openai_client.chat.completions.create.assert_called_once_with(
            model="gpt-4",
            messages=messages,
            temperature=0.1,
            response_format={"type": "json_schema",
                            "json_schema": {
                                "name": "cvscreening",
                                "strict": True,
                                "schema": schema
                            }
                        }
        )
        
        # Check result is returned
        self.assertEqual(result, self.mock_completion)
    
    @patch('src.providers.azure_provider.AzurePromptManager')
    @patch('src.providers.azure_provider.AzureResponseHandler')
    def test_analyze_cv(self, mock_response_handler, mock_prompt_manager):
        """Test analyze_cv method."""
        # Setup
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4"
        )
        
        # Configure mocks
        mock_prompt_manager_instance = mock_prompt_manager.return_value
        mock_prompt_manager_instance.get_system_prompt.return_value = "System prompt"
        mock_prompt_manager_instance.get_json_schema.return_value = {"type": "object"}
        
        mock_response_handler_instance = mock_response_handler.return_value
        mock_response_handler_instance.process_single_response.return_value = {"analysis": "test result"}
        
        # Call method
        content = {"content_md": "CV content", "document_id": "doc123"}
        result = provider.analyze_cv(content)
        
        # Check correct calls were made
        mock_prompt_manager_instance.get_system_prompt.assert_called_once()
        mock_prompt_manager_instance.get_json_schema.assert_called_once()
        self.mock_openai_client.chat.completions.create.assert_called_once()
        mock_response_handler_instance.process_single_response.assert_called_once()
        
        # Check result
        self.assertEqual(result, {"analysis": "test result"})
    
    @patch('src.providers.azure_provider.AzurePromptManager')
    @patch('src.providers.azure_provider.AzureResponseHandler')
    def test_analyze_cv_error(self, mock_response_handler, mock_prompt_manager):
        """Test analyze_cv method with error."""
        # Setup
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4"
        )
        
        # Configure mocks
        mock_prompt_manager_instance = mock_prompt_manager.return_value
        mock_prompt_manager_instance.get_system_prompt.return_value = "System prompt"
        mock_prompt_manager_instance.get_json_schema.return_value = {"type": "object"}
        
        # Set error on OpenAI call
        self.mock_openai_client.chat.completions.create.side_effect = Exception("API error")
        
        # Call method & check exception
        content = {"content_md": "CV content", "document_id": "doc123"}
        with self.assertRaises(OpenAIError):
            provider.analyze_cv(content)
    
    @patch('src.providers.azure_provider.AzurePromptManager')
    @patch('src.providers.azure_provider.AzureResponseHandler')
    def test_analyze_multiple_cvs(self, mock_response_handler, mock_prompt_manager):
        """Test analyze_multiple_cvs method."""
        # Setup
        provider = AzureOpenAIProvider(
            endpoint=self.mock_endpoint,
            credential=self.mock_credential,
            deployment_name="gpt-4"
        )
        
        # Configure mocks
        mock_prompt_manager_instance = mock_prompt_manager.return_value
        mock_prompt_manager_instance.get_system_prompt.return_value = "System prompt"
        mock_prompt_manager_instance.get_json_schema.return_value = {"type": "object"}
        mock_prompt_manager_instance.build_multiple_screening_prompt.return_value = "Multiple screening prompt"
        
        # Configurar el valor de retorno para chat.completions.create
        self.mock_completion.choices[0].message.content = json.dumps({
            "results": [
                {"document_id": "doc1", "analysis": "result 1"},
                {"document_id": "doc2", "analysis": "result 2"}
            ]
        })
        
        # Call method con document_id en cada entrada
        contents = [
            {"content_md": "CV content 1", "document_id": "doc1"},
            {"content_md": "CV content 2", "document_id": "doc2"}
        ]
        results = provider.analyze_multiple_cvs(contents)
        
        # Check results
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["document_id"], "doc1")
        self.assertEqual(results[1]["document_id"], "doc2")
        
        # Check correct number of calls
        mock_prompt_manager_instance.get_system_prompt.assert_called_once()
        mock_prompt_manager_instance.build_multiple_screening_prompt.assert_called_once_with(contents)
        self.mock_openai_client.chat.completions.create.assert_called_once()


if __name__ == '__main__':
    unittest.main() 