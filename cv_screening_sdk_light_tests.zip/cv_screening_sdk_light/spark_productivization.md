# Productivización del CV Screening SDK en Cluster Spark

Este documento proporciona una guía para implementar el CV Screening SDK en un entorno de producción utilizando Apache Spark, lo que permitirá el procesamiento eficiente y escalable de currículums a gran escala.

## Índice
1. [Requisitos previos](#requisitos-previos)
2. [Arquitectura propuesta](#arquitectura-propuesta)
3. [Preparación del SDK](#preparación-del-sdk)
4. [Implementación en Spark](#implementación-en-spark)
5. [Optimización de rendimiento](#optimización-de-rendimiento)
6. [Monitoreo y logging](#monitoreo-y-logging)
7. [Seguridad](#seguridad)
8. [Ejemplos de código](#ejemplos-de-código)

## Requisitos previos

- Cluster Spark configurado (Databricks, EMR, o instalación propia)
- Python 3.8+ (para compatibilidad con el SDK)
- Acceso al servicio Azure OpenAI
- Permisos para instalar paquetes en el clúster

## Arquitectura propuesta

La arquitectura recomendada se basa en tres componentes principales:

1. **Capa de almacenamiento**: Donde se almacenan los CVs (HDFS, S3, Azure Blob Storage)
2. **Capa de procesamiento**: Clúster Spark para el procesamiento paralelo
3. **Capa de API**: Opcional para exponer funcionalidades como servicio REST

![Arquitectura](https://via.placeholder.com/800x400?text=Arquitectura+Spark+CV+Screening)

## Preparación del SDK

### 1. Empaquetar como Wheel

Para facilitar la distribución en un cluster Spark, es recomendable empaquetar el SDK como un archivo wheel:

```bash
# Generar archivo wheel
python setup.py bdist_wheel

# El archivo .whl se generará en la carpeta dist/
```

### 2. Configuración de dependencias

Asegúrate de que todas las dependencias estén correctamente especificadas en el `setup.py`. Considera mover algunas dependencias opcionales (como PyPDF2 y python-docx) a requisitos principales si planeas procesar esos formatos.

## Implementación en Spark

### 1. Instalación del SDK en el clúster

#### En Databricks:

```python
%pip install /dbfs/path/to/cv_screening_sdk-0.1.0-py3-none-any.whl
```

#### En EMR o clúster Spark independiente:

```bash
# Instalar en todos los nodos
spark-submit --packages cv_screening_sdk-0.1.0-py3-none-any.whl
```

### 2. Procesamiento en paralelo

El patrón recomendado es utilizar una función aplicada mediante `mapPartitions` para procesar varios CVs en cada executor:

```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf
from pyspark.sql.types import StringType, StructType, StructField
import json
from src import CVScreeningClient
from src.core.types import ContentType

# Inicializar SparkSession
spark = SparkSession.builder \
    .appName("CV Screening") \
    .getOrCreate()

# Configurar criterios de trabajo
job_criteria = {
    "required_skills": ["Python", "Spark", "Data Engineering"],
    "preferred_skills": ["AWS", "Azure", "Docker"],
    "min_years_experience": 3,
    "education": "Ingeniería o similar"
}

# Función para procesar un lote de CVs
def process_cv_batch(partition):
    # Inicializar cliente en el executor (evita serialización)
    client = CVScreeningClient(
        endpoint="https://your-azure-openai.openai.azure.com",
        api_key="your-api-key",
        deployment_name="gpt-4",
        temperature=0.1
    )
    
    # Procesar cada CV en la partición
    for row in partition:
        cv_content = row.cv_content
        try:
            result = client.analyze_cv(
                content=cv_content,
                criteria=job_criteria,
                content_type=ContentType.TEXT
            )
            yield (row.cv_id, json.dumps(result))
        except Exception as e:
            yield (row.cv_id, json.dumps({"error": str(e)}))

# Leer datos (ejemplo con DataFrame)
cvs_df = spark.read.parquet("s3://your-bucket/cvs/")

# Aplicar procesamiento en paralelo
results_rdd = cvs_df.rdd.mapPartitions(process_cv_batch)
results_df = results_rdd.toDF(["cv_id", "analysis_result"])

# Guardar resultados
results_df.write.parquet("s3://your-bucket/results/")
```

## Optimización de rendimiento

### 1. Configuración de particiones

Ajusta el número de particiones para equilibrar la carga entre ejecutores:

```python
# Repartir datos para mejor distribución
cvs_df = cvs_df.repartition(num_executors * cores_per_executor)
```

### 2. Gestión de conexiones

Usa una instancia de cliente por executor para evitar problemas de conexión:

```python
def analyze_cv_partition(iterator):
    # Crear un solo cliente por partición
    client = CVScreeningClient(...)
    for record in iterator:
        # Procesar con el mismo cliente
        yield client.analyze_cv(...)
```

### 3. Control de tasas de peticiones

Implementa un mecanismo de control para evitar sobrecargar la API de Azure:

```python
import time

def analyze_with_rate_limit(client, cv, criteria, max_retries=3, delay=1):
    for attempt in range(max_retries):
        try:
            return client.analyze_cv(cv, criteria)
        except Exception as e:
            if "rate limit" in str(e).lower():
                time.sleep(delay * (2 ** attempt))  # Retroceso exponencial
            else:
                raise
    raise Exception(f"Failed after {max_retries} attempts")
```

## Monitoreo y logging

### 1. Configuración de métricas

Utiliza Spark UI o herramientas de monitoreo como Prometheus:

```python
# Contadores personalizados
from pyspark.accumulators import AccumulatorParam

class DictParam(AccumulatorParam):
    def zero(self, value):
        return dict()
    
    def addInPlace(self, v1, v2):
        v1.update(v2)
        return v1

# Crear acumulador
metrics = spark.sparkContext.accumulator({}, DictParam())

# Actualizar métricas durante el procesamiento
def process_with_metrics(partition):
    success = 0
    errors = 0
    
    for row in partition:
        try:
            # Procesamiento
            success += 1
        except:
            errors += 1
    
    # Actualizar métricas
    metrics.add({"success": success, "errors": errors})
```

### 2. Configuración de logging

Configura un sistema de logging centralizado:

```python
import logging

# Configurar en el driver
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("cv_screening")

# En cada executor
def process_with_logging(partition):
    local_logger = logging.getLogger("cv_screening.executor")
    
    for row in partition:
        local_logger.info(f"Processing CV ID: {row.cv_id}")
        # Procesamiento
```

## Seguridad

### 1. Gestión de claves

Utiliza servicios de administración de secretos:

```python
# Ejemplo con Azure Key Vault
from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

def get_api_key():
    credential = DefaultAzureCredential()
    secret_client = SecretClient(
        vault_url="https://your-keyvault.vault.azure.net/",
        credential=credential
    )
    return secret_client.get_secret("azure-openai-api-key").value
```

### 2. Enmascaramiento de datos sensibles

```python
# Implementar enmascaramiento de datos PII en los logs
def mask_pii(text):
    # Implementa tu lógica de enmascaramiento
    return masked_text
```

## Ejemplos de código

### Ejemplo 1: Procesamiento por lotes con DataFrame API

```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType
import pandas as pd

# Definir UDF con Pandas
@pandas_udf(StringType())
def analyze_cv_pandas(cvs: pd.Series) -> pd.Series:
    client = CVScreeningClient(...)
    
    results = []
    for cv in cvs:
        try:
            result = client.analyze_cv(cv, job_criteria)
            results.append(json.dumps(result))
        except Exception as e:
            results.append(json.dumps({"error": str(e)}))
    
    return pd.Series(results)

# Aplicar a DataFrame
df = spark.read.parquet("hdfs:///cvs/")
result_df = df.withColumn("analysis", analyze_cv_pandas(df.content))
```

### Ejemplo 2: Procesamiento en streaming

```python
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, to_json, struct
from pyspark.sql.types import StructType, StructField, StringType

# Esquema para los mensajes de entrada
schema = StructType([
    StructField("cv_id", StringType(), True),
    StructField("cv_content", StringType(), True)
])

# Iniciar sesión de streaming
spark = SparkSession.builder.appName("CV Screening Stream").getOrCreate()

# Leer desde Kafka
stream_df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker:9092") \
    .option("subscribe", "cvs_to_process") \
    .load()

# Parsear mensajes
parsed_df = stream_df \
    .select(from_json(col("value").cast("string"), schema).alias("data")) \
    .select("data.*")

# UDF para análisis
@udf(StringType())
def analyze_cv_streaming(cv_content):
    client = CVScreeningClient(...)
    try:
        result = client.analyze_cv(cv_content, job_criteria)
        return json.dumps(result)
    except Exception as e:
        return json.dumps({"error": str(e)})

# Aplicar análisis
result_df = parsed_df \
    .withColumn("analysis_result", analyze_cv_streaming(col("cv_content")))

# Escribir resultados a Kafka
query = result_df \
    .select(col("cv_id").alias("key"), to_json(struct("analysis_result")).alias("value")) \
    .writeStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "broker:9092") \
    .option("topic", "cv_analysis_results") \
    .option("checkpointLocation", "/tmp/checkpoints") \
    .start()

# Esperar terminación
query.awaitTermination()
```

## Conclusión

La productivización del CV Screening SDK en un cluster Spark permite escalarlo para procesar grandes volúmenes de CVs de manera eficiente. Siguiendo las recomendaciones de este documento, puedes implementar una solución robusta que aproveche las capacidades de procesamiento distribuido de Spark junto con la potencia del análisis de CVs mediante Azure OpenAI.

Recuerda monitorear constantemente el rendimiento y ajustar la configuración según sea necesario para optimizar los recursos y reducir los costes. 