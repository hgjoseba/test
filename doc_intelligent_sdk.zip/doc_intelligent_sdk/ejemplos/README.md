# Ejemplos de Document Intelligence SDK

Este directorio contiene ejemplos de uso del Document Intelligence SDK.

## Ejemplos para conexión a endpoints privados

### 1. Usando `connection_verify=False` (para pruebas)

El archivo `spn_endpoint_privado.py` muestra cómo:

1. Conectarse a un endpoint privado de Azure Document Intelligence 
2. Usar autenticación con Service Principal (SPN)
3. Desactivar la verificación SSL (`connection_verify=False`)
4. Procesar documentos tanto desde archivos como desde datos base64

#### Uso

```bash
# Usando argumentos de línea de comandos
python spn_endpoint_privado.py \
  --tenant-id "tu-tenant-id" \
  --client-id "tu-client-id" \
  --client-secret "tu-client-secret" \
  --endpoint "https://tu-endpoint.cognitiveservices.azure.com/" \
  --document "ruta/al/documento.pdf" \
  --output-dir "resultados"

# O usando variables de entorno
export AZURE_TENANT_ID="tu-tenant-id"
export AZURE_CLIENT_ID="tu-client-id"
export AZURE_CLIENT_SECRET="tu-client-secret"
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT="https://tu-endpoint.cognitiveservices.azure.com/"

python spn_endpoint_privado.py --document "ruta/al/documento.pdf"
```

### 2. Usando certificado CA personalizado (recomendado para producción)

El archivo `custom_ca_certificate.py` muestra cómo:

1. Conectarse a un endpoint privado usando un certificado CA personalizado
2. Configurar la verificación SSL segura con un bundle de certificados de confianza
3. Usar autenticación con Service Principal (SPN)

#### Uso

```bash
# Usando argumentos de línea de comandos
python custom_ca_certificate.py \
  --tenant-id "tu-tenant-id" \
  --client-id "tu-client-id" \
  --client-secret "tu-client-secret" \
  --endpoint "https://tu-endpoint.cognitiveservices.azure.com/" \
  --ca-cert "/ruta/al/certificado-ca.pem" \
  --document "ruta/al/documento.pdf" \
  --output-dir "resultados"
```

### 3. Procesamiento de PDFs con bypass de proxy (nuevo!)

El archivo `endpoint_privado_pdf.py` muestra cómo:

1. Configurar excepciones de proxy para endpoints privados
2. Analizar documentos PDF con Document Intelligence
3. Extraer texto, tablas y pares clave-valor de los PDFs
4. Guardar los resultados en varios formatos (texto, CSV, JSON)

Este ejemplo es especialmente útil en entornos corporativos donde:
- Se utilizan proxies para el tráfico saliente
- Se necesita configurar excepciones para endpoints privados mediante `no_proxy`
- Se procesan documentos PDF para extraer su contenido estructurado

#### Uso

```bash
# Ejemplo básico (con bypass de proxy activado)
python endpoint_privado_pdf.py \
  --tenant-id "tu-tenant-id" \
  --client-id "tu-client-id" \
  --client-secret "tu-client-secret" \
  --endpoint "https://tu-endpoint.cognitiveservices.azure.com/" \
  --pdf "ruta/al/documento.pdf" \
  --bypass-proxy

# Para pruebas en entornos con certificados problemáticos
python endpoint_privado_pdf.py \
  --tenant-id "tu-tenant-id" \
  --client-id "tu-client-id" \
  --client-secret "tu-client-secret" \
  --endpoint "https://tu-endpoint.cognitiveservices.azure.com/" \
  --pdf "ruta/al/documento.pdf" \
  --bypass-proxy \
  --disable-ssl

# Con variables de entorno
export AZURE_TENANT_ID="tu-tenant-id"
export AZURE_CLIENT_ID="tu-client-id"
export AZURE_CLIENT_SECRET="tu-client-secret"
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT="https://tu-endpoint.cognitiveservices.azure.com/"

python endpoint_privado_pdf.py --pdf "ruta/al/documento.pdf" --bypass-proxy
```

#### Resultados generados

El ejemplo generará los siguientes archivos en el directorio de salida:

- `{nombre_pdf}_texto_completo.txt`: Todo el texto extraído del PDF
- `{nombre_pdf}_key_values.json`: Pares clave-valor en formato JSON
- `{nombre_pdf}_metadata.json`: Metadatos del documento (páginas, tablas, etc.)
- `{nombre_pdf}_tabla_{N}.csv`: Cada tabla encontrada en formato CSV

## Configuración de bypass de proxy para endpoints privados

El ejemplo `endpoint_privado_pdf.py` incluye una función específica para configurar excepciones de proxy:

```python
def configurar_proxy_y_excepciones(endpoint_url):
    # Extraer el hostname del endpoint
    hostname = urlparse(endpoint_url).netloc
    
    # Configurar no_proxy para el hostname
    current_no_proxy = os.environ.get('no_proxy', '')
    if hostname not in current_no_proxy:
        if current_no_proxy:
            os.environ['no_proxy'] = f"{current_no_proxy},{hostname}"
        else:
            os.environ['no_proxy'] = hostname
            
    print(f"Configurado bypass de proxy para: {hostname}")
```

Esta función permite que las conexiones al endpoint privado se realicen directamente, sin pasar por el proxy corporativo.

## Requisitos comunes

- Python 3.7 o superior
- Document Intelligence SDK instalado (`pip install doc-intelligent-sdk`)
- Un endpoint de Azure Document Intelligence (puede ser un Private Link endpoint)
- Credenciales de Service Principal con acceso al recurso

## Explicación del parámetro `connection_verify`

El parámetro `connection_verify` se utiliza en dos lugares:

1. **En el objeto de credencial** (`AzureCredential`):
   ```python
   credential = AzureCredential.from_service_principal(
       tenant_id=tenant_id,
       client_id=client_id,
       client_secret=client_secret,
       connection_verify=False  # Afecta a la autenticación con Azure AD
   )
   ```

2. **En el cliente Document Intelligence**:
   ```python
   client = DocIntelligenceClient(
       endpoint=endpoint,
       credential=credential,
       connection_verify=False  # Afecta a las llamadas a la API de Document Intelligence
   )
   ```

### Opciones de `connection_verify`

- `True` (predeterminado): Verificación SSL estándar
- `False`: Desactiva la verificación de certificados SSL (no recomendado para producción)
- `"/ruta/al/certificado.pem"`: Usa un bundle de certificados CA personalizado

## FQDN de endpoints privados y proxies

El Fully Qualified Domain Name (FQDN) de un endpoint privado no se salta automáticamente el proxy. El proceso funciona así:

1. **Resolución DNS**: 
   - El FQDN del endpoint privado resuelve a una IP privada dentro de tu red
   - Esta resolución ocurre a nivel de infraestructura, no a nivel de aplicación

2. **Comportamiento con proxies**:
   - Las aplicaciones siguen usando el proxy configurado a menos que configures excepciones
   - Necesitas configurar variables como `no_proxy` para indicar qué hostnames deben saltarse el proxy

3. **Solución implementada**:
   - El ejemplo `endpoint_privado_pdf.py` incluye la función `configurar_proxy_y_excepciones()` que configura la variable de entorno `no_proxy` automáticamente para el endpoint

## Advertencia de seguridad

Desactivar la verificación SSL (`connection_verify=False`) no es recomendado para entornos de producción ya que expone la aplicación a ataques de intermediario (MITM). En su lugar, se recomienda:

1. Configurar correctamente los certificados en el sistema
2. Proporcionar un bundle de certificados CA personalizado si es necesario
3. Solo usar `connection_verify=False` para pruebas o depuración

## Creación de un certificado CA para pruebas

Si necesitas crear un certificado CA para pruebas, puedes usar OpenSSL:

```bash
# Generar clave privada para la CA
openssl genrsa -out ca-key.pem 2048

# Crear certificado CA autofirmado
openssl req -x509 -new -nodes -key ca-key.pem -sha256 -days 365 -out ca-cert.pem

# Verificar el contenido del certificado
openssl x509 -in ca-cert.pem -text
``` 