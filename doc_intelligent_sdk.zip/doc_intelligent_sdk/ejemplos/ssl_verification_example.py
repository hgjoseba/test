#!/usr/bin/env python
"""
Ejemplo simplificado para demostrar cómo deshabilitar la verificación SSL.

Este script muestra la forma correcta de deshabilitar la verificación de certificados SSL
cuando se trabaja con el Document Intelligence SDK.
"""

import os
import sys
import argparse
from pathlib import Path

from doc_intelligent_sdk import DocIntelligenceClient
from doc_intelligent_sdk.auth.azure import AzureCredential
from doc_intelligent_sdk.utils.errors import DocumentIntelligenceError


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Ejemplo de cómo deshabilitar verificación SSL"
    )
    parser.add_argument(
        "--endpoint", 
        help="URL del endpoint de Azure Document Intelligence",
        required=True
    )
    parser.add_argument(
        "--document", 
        help="Ruta al documento a analizar",
        required=True
    )
    parser.add_argument(
        "--auth-mode",
        help="Modo de autenticación: 'key', 'spn', o 'default'",
        choices=["key", "spn", "default"],
        default="default"
    )
    parser.add_argument(
        "--api-key",
        help="Clave API para autenticación directa (para --auth-mode=key)"
    )
    parser.add_argument(
        "--tenant-id", 
        help="Azure tenant ID para autenticación SPN (para --auth-mode=spn)"
    )
    parser.add_argument(
        "--client-id", 
        help="Azure client ID para autenticación SPN (para --auth-mode=spn)"
    )
    parser.add_argument(
        "--client-secret", 
        help="Azure client secret para autenticación SPN (para --auth-mode=spn)"
    )
    
    return parser.parse_args()


def main():
    """Función principal."""
    args = parse_arguments()
    
    # Validar argumentos
    document_path = Path(args.document)
    if not document_path.exists():
        print(f"Error: El documento '{document_path}' no existe.")
        return 1
    
    # Obtener credenciales según el modo de autenticación
    try:
        print("\n=== Configuración sin verificación SSL ===")
        print(f"- Endpoint: {args.endpoint}")
        print(f"- Documento: {document_path}")
        print(f"- Modo de autenticación: {args.auth_mode}")
        
        if args.auth_mode == "key":
            api_key = args.api_key or os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_KEY")
            if not api_key:
                print("Error: Se requiere una clave API para el modo 'key'")
                return 1
                
            print("Creando credencial con clave API y SSL deshabilitado...")
            credential = AzureCredential(
                api_key=api_key,
                # Para deshabilitar verificación SSL (para credenciales con clave API):
                connection_verify=False
            )
            
        elif args.auth_mode == "spn":
            tenant_id = args.tenant_id or os.environ.get("AZURE_TENANT_ID")
            client_id = args.client_id or os.environ.get("AZURE_CLIENT_ID")
            client_secret = args.client_secret or os.environ.get("AZURE_CLIENT_SECRET")
            
            if not all([tenant_id, client_id, client_secret]):
                print("Error: Se requieren tenant_id, client_id y client_secret para el modo 'spn'")
                return 1
                
            print("Creando credencial SPN con SSL deshabilitado...")
            credential = AzureCredential.from_service_principal(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret,
                # Para deshabilitar verificación SSL (para SPN):
                connection_verify=False
            )
            
        else:  # default
            print("Creando credencial por defecto con SSL deshabilitado...")
            credential = AzureCredential.default_credential(
                # Para deshabilitar verificación SSL (para DEFAULT):
                connection_verify=False
            )
        
        # Crear cliente con SSL deshabilitado
        print("Creando cliente Document Intelligence con SSL deshabilitado...")
        client = DocIntelligenceClient(
            endpoint=args.endpoint,
            credential=credential,
            # Para deshabilitar verificación SSL (para las llamadas API):
            connection_verify=False
        )
        
        # Analizar documento
        print(f"Analizando documento: {document_path}...")
        result = client.analyze_document(
            file_path=document_path,
            model_id="prebuilt-document"
        )
        
        # Mostrar resultados básicos
        document = result.get_analyzed_document()
        print(f"\n¡Análisis completado!")
        print(f"- Páginas: {len(document.pages)}")
        text = document.get_text()
        print(f"- Extracto de texto: {text[:100]}...")
        
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Error de Document Intelligence: {e}")
        return 1
    except Exception as e:
        print(f"Error inesperado: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 