#!/usr/bin/env python
"""
Ejemplo de uso del Document Intelligence SDK con:
- Certificado CA personalizado para verificación SSL
- Autenticación mediante Service Principal (SPN)
- Conexión a un endpoint privado

Este ejemplo muestra cómo usar un certificado CA personalizado para conectarse
de forma segura a un endpoint privado de Azure Document Intelligence.
"""

import os
import sys
from pathlib import Path
import argparse
import base64

from doc_intelligent_sdk import DocIntelligenceClient
from doc_intelligent_sdk.auth.azure import AzureCredential
from doc_intelligent_sdk.utils.errors import DocumentIntelligenceError


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Analizar un documento usando Azure Document Intelligence con certificado CA personalizado"
    )
    parser.add_argument(
        "--tenant-id", 
        help="Azure tenant ID para autenticación SPN"
    )
    parser.add_argument(
        "--client-id", 
        help="Azure client ID para autenticación SPN"
    )
    parser.add_argument(
        "--client-secret", 
        help="Azure client secret para autenticación SPN"
    )
    parser.add_argument(
        "--endpoint", 
        help="URL del endpoint de Azure Document Intelligence"
    )
    parser.add_argument(
        "--ca-cert", 
        help="Ruta al archivo de certificado CA personalizado",
        required=True
    )
    parser.add_argument(
        "--document", 
        help="Ruta al documento a analizar", 
        default="documento.pdf"
    )
    parser.add_argument(
        "--output-dir", 
        help="Directorio para guardar los resultados", 
        default="resultados"
    )
    
    return parser.parse_args()


def main():
    """Función principal."""
    args = parse_arguments()
    
    # Usar argumentos CLI o variables de entorno
    tenant_id = args.tenant_id or os.environ.get("AZURE_TENANT_ID")
    client_id = args.client_id or os.environ.get("AZURE_CLIENT_ID")
    client_secret = args.client_secret or os.environ.get("AZURE_CLIENT_SECRET")
    endpoint = args.endpoint or os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    ca_cert_path = args.ca_cert
    document_path = Path(args.document)
    output_dir = Path(args.output_dir)
    
    # Validar parámetros requeridos
    if not all([tenant_id, client_id, client_secret, endpoint]):
        print("Error: Se requieren tenant_id, client_id, client_secret y endpoint.")
        print("Proporciona estos valores como argumentos o variables de entorno.")
        return 1
    
    if not Path(ca_cert_path).exists():
        print(f"Error: El archivo de certificado CA '{ca_cert_path}' no existe.")
        return 1
        
    if not document_path.exists():
        print(f"Error: El documento '{document_path}' no existe.")
        return 1
    
    # Crear directorio de salida si no existe
    output_dir.mkdir(exist_ok=True)
    
    try:
        print("\n=== Configuración de autenticación y cliente ===")
        print(f"- Endpoint: {endpoint}")
        print(f"- Certificado CA: {ca_cert_path}")
        print(f"- Documento a analizar: {document_path}")
        
        # 1. Crear credencial SPN con certificado CA personalizado
        print("\nCreando credencial con Service Principal y certificado CA personalizado...")
        credential = AzureCredential.from_service_principal(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
            connection_verify=ca_cert_path  # Ruta al certificado CA para autenticación
        )
        
        # 2. Crear cliente con la credencial y certificado CA personalizado
        print("Creando cliente Document Intelligence con certificado CA personalizado...")
        client = DocIntelligenceClient(
            endpoint=endpoint,
            credential=credential,
            connection_verify=ca_cert_path  # Ruta al certificado CA para las API calls
        )
        
        # 3. Analizar el documento
        print(f"\n=== Analizando documento: {document_path} ===")
        result = client.analyze_document(
            file_path=document_path,
            model_id="prebuilt-document"  # Modelo general de documento
        )
        
        # 4. Obtener resultados del análisis
        document = result.get_analyzed_document()
        if not document:
            print("Error: El análisis del documento falló o no devolvió resultados.")
            return 1
        
        # 5. Imprimir información del documento
        print("\n=== Resultados del análisis ===")
        print(f"- Modelo utilizado: {document.model_id}")
        print(f"- Número de páginas: {len(document.pages)}")
        
        # 6. Extraer texto
        text = document.get_text()
        print("\n=== Texto del documento (primeros 300 caracteres) ===")
        print(f"{text[:300]}...")
        
        # 7. Extraer pares clave-valor
        key_values = document.get_key_value_pairs()
        print(f"\n=== Pares clave-valor ({len(key_values)}) ===")
        for kv in key_values:
            print(f"{kv.key}: {kv.value}")
        
        # 8. Guardar texto a archivo
        text_path = output_dir / f"{document_path.stem}_texto.txt"
        print(f"\nGuardando texto en: {text_path}")
        with open(text_path, "w", encoding="utf-8") as f:
            f.write(text)
        
        print("\n¡Análisis completado con éxito usando certificado CA personalizado!")
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Error de Document Intelligence: {e}")
        return 1
    except Exception as e:
        print(f"Error inesperado: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 