#!/usr/bin/env python
"""
Ejemplo de procesamiento de PDFs con Document Intelligence SDK:
- Configuración de excepciones de proxy para endpoints privados
- Procesamiento de archivos PDF desde una ruta
- Extracción y análisis de texto, tablas y pares clave-valor
- Manejo de resultados completos del análisis

Este ejemplo es ideal para entornos corporativos que utilizan
proxies y endpoints privados de Azure vía Private Link.
"""

import os
import sys
from pathlib import Path
import argparse
from urllib.parse import urlparse
import json
import csv

from doc_intelligent_sdk import DocIntelligenceClient
from doc_intelligent_sdk.auth.azure import AzureCredential
from doc_intelligent_sdk.utils.errors import DocumentIntelligenceError


def configurar_proxy_y_excepciones(endpoint_url):
    """
    Configura variables de entorno para omitir proxy en endpoints privados.
    
    Args:
        endpoint_url: URL completa del endpoint de Document Intelligence
    """
    # Extraer el hostname del endpoint
    hostname = urlparse(endpoint_url).netloc
    
    # Configurar las variables de entorno para excepciones de proxy
    current_no_proxy = os.environ.get('no_proxy', '')
    if hostname not in current_no_proxy:
        if current_no_proxy:
            os.environ['no_proxy'] = f"{current_no_proxy},{hostname}"
        else:
            os.environ['no_proxy'] = hostname
            
    print(f"Configurado bypass de proxy para: {hostname}")
    
    # También puedes configurar explícitamente los proxies si es necesario
    # Descomenta estas líneas y ajusta según tu entorno
    # os.environ['http_proxy'] = "http://proxy.corporativo:8080"
    # os.environ['https_proxy'] = "http://proxy.corporativo:8080"


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Analizar PDFs con Document Intelligence en entornos con proxy/endpoints privados"
    )
    parser.add_argument(
        "--tenant-id", 
        help="Azure tenant ID para autenticación SPN"
    )
    parser.add_argument(
        "--client-id", 
        help="Azure client ID para autenticación SPN"
    )
    parser.add_argument(
        "--client-secret", 
        help="Azure client secret para autenticación SPN"
    )
    parser.add_argument(
        "--api-key",
        help="Clave API para autenticación directa"
    )
    parser.add_argument(
        "--auth-mode",
        help="Modo de autenticación: 'key', 'spn', o 'default'",
        choices=["key", "spn", "default"],
        default="spn"
    )
    parser.add_argument(
        "--endpoint", 
        help="URL del endpoint de Azure Document Intelligence"
    )
    parser.add_argument(
        "--pdf", 
        help="Ruta al archivo PDF a analizar",
        required=True
    )
    parser.add_argument(
        "--bypass-proxy", 
        help="Configurar automáticamente excepciones de proxy para el endpoint",
        action="store_true"
    )
    parser.add_argument(
        "--disable-ssl", 
        help="Desactivar verificación SSL (solo para pruebas)",
        action="store_true"
    )
    parser.add_argument(
        "--output-dir", 
        help="Directorio para guardar los resultados", 
        default="resultados_pdf"
    )
    
    return parser.parse_args()


def guardar_tablas_csv(document, output_dir, base_name):
    """
    Guarda las tablas extraídas como archivos CSV.
    
    Args:
        document: Documento analizado
        output_dir: Directorio donde guardar los archivos
        base_name: Nombre base para los archivos
    
    Returns:
        Lista de rutas a los archivos CSV generados
    """
    csv_paths = []
    tables = document.get_tables()
    
    for i, table in enumerate(tables):
        csv_path = output_dir / f"{base_name}_tabla_{i+1}.csv"
        
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            
            # Escribir encabezados si están disponibles
            if table.has_header_row:
                header_row = [cell.content for cell in table.cells if cell.row_index == 0]
                writer.writerow(header_row)
            
            # Escribir datos por fila
            current_row = -1
            row_data = []
            
            # Ordenar las celdas por posición de fila y columna
            sorted_cells = sorted(table.cells, key=lambda c: (c.row_index, c.column_index))
            
            for cell in sorted_cells:
                if table.has_header_row and cell.row_index == 0:
                    continue  # Saltamos las celdas de encabezado si ya las escribimos
                
                if cell.row_index != current_row:
                    if row_data:  # Si hay datos de la fila anterior, escribirlos
                        writer.writerow(row_data)
                    # Iniciar nueva fila
                    current_row = cell.row_index
                    row_data = []
                
                # Añadir contenido de la celda a la fila actual
                row_data.append(cell.content)
            
            # Escribir la última fila si quedan datos
            if row_data:
                writer.writerow(row_data)
        
        csv_paths.append(csv_path)
    
    return csv_paths


def guardar_resultados_completos(document, output_dir, base_name):
    """
    Guarda los resultados completos del análisis en varios formatos útiles.
    
    Args:
        document: Documento analizado
        output_dir: Directorio donde guardar los archivos
        base_name: Nombre base para los archivos
    """
    # 1. Guardar todo el texto
    text_path = output_dir / f"{base_name}_texto_completo.txt"
    with open(text_path, "w", encoding="utf-8") as f:
        f.write(document.get_text())
    
    # 2. Guardar pares clave-valor como JSON
    kv_pairs = document.get_key_value_pairs()
    kv_dict = {kv.key: kv.value for kv in kv_pairs}
    kv_path = output_dir / f"{base_name}_key_values.json"
    with open(kv_path, "w", encoding="utf-8") as f:
        json.dump(kv_dict, f, indent=2, ensure_ascii=False)
    
    # 3. Guardar tablas como CSV
    csv_paths = guardar_tablas_csv(document, output_dir, base_name)
    
    # 4. Guardar metadatos del documento
    meta_path = output_dir / f"{base_name}_metadata.json"
    metadata = {
        "modelo": document.model_id,
        "num_paginas": len(document.pages),
        "num_tablas": len(document.get_tables()),
        "num_pares_clave_valor": len(kv_pairs),
        "idioma_detectado": document.locale if hasattr(document, "locale") else "desconocido"
    }
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    # 5. Crear un resumen
    return {
        "texto": text_path,
        "key_values": kv_path,
        "tablas_csv": csv_paths,
        "metadata": meta_path
    }


def main():
    """Función principal."""
    args = parse_arguments()
    
    # Usar argumentos CLI o variables de entorno
    tenant_id = args.tenant_id or os.environ.get("AZURE_TENANT_ID")
    client_id = args.client_id or os.environ.get("AZURE_CLIENT_ID")
    client_secret = args.client_secret or os.environ.get("AZURE_CLIENT_SECRET")
    api_key = args.api_key or os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    endpoint = args.endpoint or os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    pdf_path = Path(args.pdf)
    output_dir = Path(args.output_dir)
    
    # Validar parámetros requeridos
    if args.auth_mode == "key" and not api_key:
        print("Error: Se requiere api_key para el modo de autenticación 'key'.")
        return 1
    elif args.auth_mode == "spn" and not all([tenant_id, client_id, client_secret]):
        print("Error: Se requieren tenant_id, client_id y client_secret para el modo de autenticación 'spn'.")
        return 1
    
    if not endpoint:
        print("Error: Se requiere el endpoint de Document Intelligence.")
        return 1
    
    if not pdf_path.exists():
        print(f"Error: El archivo PDF '{pdf_path}' no existe.")
        return 1
    
    if pdf_path.suffix.lower() != '.pdf':
        print(f"Error: El archivo '{pdf_path}' no parece ser un PDF.")
        return 1
    
    # Configurar bypass de proxy si se solicita
    if args.bypass_proxy:
        configurar_proxy_y_excepciones(endpoint)
    
    # Crear directorio de salida si no existe
    output_dir.mkdir(exist_ok=True)
    
    # Determinar configuración de verificación SSL
    connection_verify = not args.disable_ssl  # True por defecto, False si disable_ssl=True
    if args.disable_ssl:
        print("⚠️ ADVERTENCIA: Verificación SSL desactivada. No recomendado para producción.")
    
    try:
        print("\n=== Configuración de autenticación y cliente ===")
        print(f"- Endpoint: {endpoint}")
        print(f"- PDF a analizar: {pdf_path}")
        print(f"- Bypass proxy: {'Activado' if args.bypass_proxy else 'Desactivado'}")
        print(f"- Verificación SSL: {'Desactivada' if args.disable_ssl else 'Activada'}")
        
        # 1. Crear credencial adecuada según el modo de autenticación
        if args.auth_mode == "key":
            print("Usando autenticación con clave API...")
            credential = AzureCredential(
                api_key=api_key,
                connection_verify=connection_verify
            )
        elif args.auth_mode == "spn":
            print("Usando autenticación con Service Principal...")
            credential = AzureCredential.from_service_principal(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret,
                connection_verify=connection_verify
            )
        else:  # default
            print("Usando cadena de autenticación por defecto...")
            credential = AzureCredential.default_credential(
                connection_verify=connection_verify
            )
        
        # 2. Crear cliente con la credencial
        print("Creando cliente Document Intelligence...")
        client = DocIntelligenceClient(
            endpoint=endpoint,
            credential=credential,
            connection_verify=connection_verify
        )
        
        # 3. Analizar el documento PDF
        print(f"\n=== Analizando documento PDF: {pdf_path} ===")
        result = client.analyze_document(
            file_path=pdf_path,
            model_id="prebuilt-document",  # Modelo general para documentos
            locale="es"  # Puedes ajustar el idioma según necesites
        )
        
        # 4. Obtener documento analizado
        document = result.get_analyzed_document()
        if not document:
            print("Error: El análisis del documento falló o no devolvió resultados.")
            return 1
        
        # 5. Mostrar información general
        print("\n=== Información general del documento ===")
        print(f"- Modelo utilizado: {document.model_id}")
        print(f"- Número de páginas: {len(document.pages)}")
        
        # 6. Mostrar extracto de texto
        texto = document.get_text()
        print("\n=== Extracto de texto (primeros 300 caracteres) ===")
        print(f"{texto[:300]}..." if len(texto) > 300 else texto)
        
        # 7. Mostrar tablas encontradas
        tablas = document.get_tables()
        print(f"\n=== Tablas encontradas: {len(tablas)} ===")
        for i, tabla in enumerate(tablas[:2]):  # Mostrar solo las primeras 2 tablas
            print(f"\nTabla {i+1}: {len(tabla.cells)} celdas, {tabla.row_count} filas, {tabla.column_count} columnas")
            
        # 8. Mostrar pares clave-valor
        key_values = document.get_key_value_pairs()
        print(f"\n=== Pares clave-valor ({len(key_values)}) ===")
        for i, kv in enumerate(key_values[:10]):  # Mostrar solo los primeros 10 pares
            print(f"{kv.key}: {kv.value}")
        
        # 9. Guardar todos los resultados
        print("\n=== Guardando resultados del análisis ===")
        base_name = pdf_path.stem
        resultados = guardar_resultados_completos(document, output_dir, base_name)
        
        # 10. Mostrar resumen de archivos generados
        print("\n=== Archivos generados ===")
        print(f"- Texto completo: {resultados['texto']}")
        print(f"- Pares clave-valor: {resultados['key_values']}")
        print(f"- Metadatos: {resultados['metadata']}")
        print("- Tablas CSV:")
        for csv_path in resultados['tablas_csv']:
            print(f"  * {csv_path}")
        
        print(f"\n¡Análisis del PDF completado con éxito! Resultados guardados en: {output_dir}")
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Error de Document Intelligence: {e}")
        return 1
    except Exception as e:
        print(f"Error inesperado: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 