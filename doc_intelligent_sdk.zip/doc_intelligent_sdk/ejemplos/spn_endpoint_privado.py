#!/usr/bin/env python
"""
Ejemplo de uso del Document Intelligence SDK con:
- Autenticación mediante Service Principal (SPN)
- connection_verify=False para desactivar la verificación SSL
- Conexión a un endpoint privado

Este ejemplo muestra cómo analizar un documento PDF utilizando
el SDK con autenticación SPN y desactivación de verificación SSL.

Nota: Desactivar la verificación SSL (connection_verify=False) no es 
recomendado para entornos de producción. Es preferible usar un 
certificado CA personalizado.
"""

import os
import sys
from pathlib import Path
import argparse
import base64

from doc_intelligent_sdk import DocIntelligenceClient
from doc_intelligent_sdk.auth.azure import AzureCredential
from doc_intelligent_sdk.utils.errors import DocumentIntelligenceError


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Analizar un documento usando Azure Document Intelligence con SPN"
    )
    parser.add_argument(
        "--tenant-id", 
        help="Azure tenant ID para autenticación SPN"
    )
    parser.add_argument(
        "--client-id", 
        help="Azure client ID para autenticación SPN"
    )
    parser.add_argument(
        "--client-secret", 
        help="Azure client secret para autenticación SPN"
    )
    parser.add_argument(
        "--endpoint", 
        help="URL del endpoint de Azure Document Intelligence"
    )
    parser.add_argument(
        "--document", 
        help="Ruta al documento a analizar", 
        default="documento.pdf"
    )
    parser.add_argument(
        "--output-dir", 
        help="Directorio para guardar los resultados", 
        default="resultados"
    )
    
    return parser.parse_args()


def main():
    """Función principal."""
    args = parse_arguments()
    
    # Usar argumentos CLI o variables de entorno
    tenant_id = args.tenant_id or os.environ.get("AZURE_TENANT_ID")
    client_id = args.client_id or os.environ.get("AZURE_CLIENT_ID")
    client_secret = args.client_secret or os.environ.get("AZURE_CLIENT_SECRET")
    endpoint = args.endpoint or os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    document_path = Path(args.document)
    output_dir = Path(args.output_dir)
    
    # Validar parámetros requeridos
    if not all([tenant_id, client_id, client_secret, endpoint]):
        print("Error: Se requieren tenant_id, client_id, client_secret y endpoint.")
        print("Proporciona estos valores como argumentos o variables de entorno.")
        return 1
    
    if not document_path.exists():
        print(f"Error: El documento '{document_path}' no existe.")
        return 1
    
    # Crear directorio de salida si no existe
    output_dir.mkdir(exist_ok=True)
    
    try:
        print("\n=== Configuración de autenticación y cliente ===")
        print(f"- Endpoint: {endpoint}")
        print(f"- Documento a analizar: {document_path}")
        print("- Desactivando verificación SSL (no recomendado para producción)")
        
        # 1. Crear credencial SPN con connection_verify=False
        print("\nCreando credencial con Service Principal...")
        credential = AzureCredential.from_service_principal(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
            connection_verify=False  # Desactiva verificación SSL para autenticación
        )
        
        # 2. Crear cliente con la credencial y connection_verify=False
        print("Creando cliente Document Intelligence...")
        client = DocIntelligenceClient(
            endpoint=endpoint,
            credential=credential,
            connection_verify=False  # Desactiva verificación SSL para las API calls
        )
        
        # 3. Analizar el documento
        print(f"\n=== Analizando documento: {document_path} ===")
        result = client.analyze_document(
            file_path=document_path,
            model_id="prebuilt-document"  # Modelo general de documento
        )
        
        # 4. Obtener resultados del análisis
        document = result.get_analyzed_document()
        if not document:
            print("Error: El análisis del documento falló o no devolvió resultados.")
            return 1
        
        # 5. Imprimir información del documento
        print("\n=== Resultados del análisis ===")
        print(f"- Modelo utilizado: {document.model_id}")
        print(f"- Número de páginas: {len(document.pages)}")
        
        # 6. Extraer texto
        text = document.get_text()
        print("\n=== Texto del documento (primeros 300 caracteres) ===")
        print(f"{text[:300]}...")
        
        # 7. Extraer pares clave-valor
        key_values = document.get_key_value_pairs()
        print(f"\n=== Pares clave-valor ({len(key_values)}) ===")
        for kv in key_values:
            print(f"{kv.key}: {kv.value}")
        
        # 8. Guardar texto a archivo
        text_path = output_dir / f"{document_path.stem}_texto.txt"
        print(f"\nGuardando texto en: {text_path}")
        with open(text_path, "w", encoding="utf-8") as f:
            f.write(text)
        
        # 9. También podemos analizar el mismo documento usando base64
        print("\n=== Demostración de análisis con base64 ===")
        with open(document_path, "rb") as f:
            file_content = f.read()
            base64_content = base64.b64encode(file_content).decode('utf-8')
        
        # Determinar content_type basado en la extensión
        content_types = {
            ".pdf": "application/pdf",
            ".jpeg": "image/jpeg",
            ".jpg": "image/jpeg",
            ".png": "image/png",
            ".tiff": "image/tiff",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }
        content_type = content_types.get(document_path.suffix.lower(), "application/octet-stream")
        
        print(f"- Content type: {content_type}")
        print(f"- Longitud base64: {len(base64_content)} caracteres")
        
        # Analizar usando datos base64
        result_base64 = client.analyze_document_from_base64(
            base64_string=base64_content,
            content_type=content_type,
            model_id="prebuilt-document"
        )
        
        # Verificar que obtuvimos resultados similares
        document_base64 = result_base64.get_analyzed_document()
        text_base64 = document_base64.get_text() if document_base64 else ""
        print(f"\nVerificando análisis base64: {'✓ OK' if text_base64 else '✗ Error'}")
        
        # Guardar resultados base64
        if text_base64:
            text_path_base64 = output_dir / f"{document_path.stem}_texto_base64.txt"
            with open(text_path_base64, "w", encoding="utf-8") as f:
                f.write(text_base64)
            print(f"Texto base64 guardado en: {text_path_base64}")
            
        print("\n¡Análisis completado con éxito!")
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Error de Document Intelligence: {e}")
        return 1
    except Exception as e:
        print(f"Error inesperado: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 