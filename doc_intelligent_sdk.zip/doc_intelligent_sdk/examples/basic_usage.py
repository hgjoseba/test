#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Basic usage example for Document Intelligence SDK.

This example demonstrates how to use the Document Intelligence SDK
to analyze a document and extract information from it.

This version uses the direct HTTP requests implementation.
"""

import os
import sys
import base64
from pathlib import Path

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the SDK
from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.core.converter import DocumentConverter
from doc_intelligent.utils.errors import DocumentIntelligenceError


def main():
    """Run the Document Intelligence example."""
    # Check for required environment variables
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    api_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    
    if not endpoint or not api_key:
        print("Error: Please set the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and AZURE_DOCUMENT_INTELLIGENCE_KEY environment variables.")
        print("You can set them using:")
        print("  export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT='your-endpoint'")
        print("  export AZURE_DOCUMENT_INTELLIGENCE_KEY='your-api-key'")
        return 1
    
    # Get document path from command line argument or use default
    if len(sys.argv) > 1:
        document_path = sys.argv[1]
    else:
        print("No document path provided. Please provide a path to a document as a command line argument.")
        print(f"Usage: python {Path(__file__).name} path/to/document.pdf")
        return 1
    
    # Verify document exists
    document_path = Path(document_path)
    if not document_path.exists():
        print(f"Error: Document not found at {document_path}")
        return 1
    
    try:
        # Create a client
        # Optional: Set connection_verify to False or a path to a CA bundle if needed
        connection_verify = True  # Default is True, set to False or path to CA bundle if needed
        
        print(f"Creating client with endpoint: {endpoint}")
        print("Using Document Intelligence SDK with direct HTTP requests")
        client = DocIntelligenceClient(
            endpoint=endpoint, 
            api_key=api_key,
            connection_verify=connection_verify
        )
        
        # Analyze the document using file path
        print(f"Analyzing document from file: {document_path}")
        result = client.analyze_document(
            file_path=document_path,
            model_id="prebuilt-document",
            # Nuevos parámetros disponibles ahora:
            poll_interval=5,  # Intervalo de polling en segundos
            timeout=300       # Tiempo máximo de espera en segundos
        )
        
        # Get the analyzed document
        document = result.get_analyzed_document()
        if not document:
            print("Document analysis failed or returned no results.")
            return 1
        
        # Print document information
        print("\n==== Document Analysis Results ====")
        print(f"Model ID: {document.model_id}")
        print(f"Number of pages: {len(document.pages)}")
        
        # Extract and print text
        text = document.get_text()
        print("\n==== Document Text ====")
        print(f"{text[:300]}...")
        
        # Extract and print tables
        tables = document.get_tables()
        print(f"\n==== Tables ({len(tables)}) ====")
        for i, table in enumerate(tables):
            print(f"Table {i+1}: {table.row_count} rows x {table.column_count} columns")
            
        # Extract and print key-value pairs
        key_values = document.get_key_value_pairs()
        print(f"\n==== Key-Value Pairs ({len(key_values)}) ====")
        for kv in key_values:
            print(f"{kv.key}: {kv.value}")
        
        # Save outputs using the converter
        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)
        
        converter = DocumentConverter()
        
        # Save as JSON
        json_path = output_dir / f"{document_path.stem}.json"
        print(f"\nSaving JSON to {json_path}")
        converter.to_json(document, json_path)
        
        # Save as text
        text_path = output_dir / f"{document_path.stem}.txt"
        print(f"Saving text to {text_path}")
        converter.to_text(document, text_path)
        
        # Save tables as CSV if any exist
        if tables:
            csv_path = output_dir / f"{document_path.stem}.csv"
            print(f"Saving tables to CSV: {csv_path}")
            csv_files = converter.to_csv(document, csv_path)
            if isinstance(csv_files, list):
                print(f"Saved {len(csv_files)} table files")
            else:
                print(f"Saved table to {csv_files}")
                
        print("\nDocument analysis complete!")
        
        # Now demonstrate the base64 functionality
        print("\n==== Base64 Document Analysis Example ====")
        
        # Read the document and convert to base64
        with open(document_path, "rb") as f:
            file_content = f.read()
            base64_content = base64.b64encode(file_content).decode('utf-8')
        
        # Determine content type based on file extension
        content_types = {
            ".pdf": "application/pdf",
            ".jpeg": "image/jpeg",
            ".jpg": "image/jpeg",
            ".png": "image/png",
            ".bmp": "image/bmp",
            ".tiff": "image/tiff",
            ".tif": "image/tiff",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }
        content_type = content_types.get(document_path.suffix.lower(), "application/octet-stream")
        
        print(f"Analyzing document from base64 data")
        print(f"Content type: {content_type}")
        print(f"Base64 length: {len(base64_content)} characters")
        
        # Analyze document from base64
        result_base64 = client.analyze_document_from_base64(
            base64_string=base64_content,
            content_type=content_type,
            model_id="prebuilt-document",
            # Nuevos parámetros disponibles:
            poll_interval=5,
            timeout=300
        )
        
        # Get the analyzed document
        document_base64 = result_base64.get_analyzed_document()
        if not document_base64:
            print("Base64 document analysis failed or returned no results.")
            return 1
        
        # Extract and print text from base64 analysis
        text_base64 = document_base64.get_text()
        print("\n==== Document Text from Base64 Analysis ====")
        print(f"{text_base64[:300]}...")
        
        print("\nBase64 document analysis complete!")
        
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Document Intelligence Error: {e}")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main()) 