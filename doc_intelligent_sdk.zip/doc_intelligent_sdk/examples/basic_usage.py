#!/usr/bin/env python
"""
Ejemplo básico de uso del SDK de Document Intelligence para analizar un documento.
"""

from doc_intelligent import DocumentIntelligence
from doc_intelligent.providers import AzureDocumentProvider

def main():
    # Inicializar el SDK con un proveedor específico (Azure en este ejemplo)
    # Nota: Reemplaza los valores con tus propias credenciales
    provider = AzureDocumentProvider(
        endpoint="https://your-azure-endpoint.cognitiveservices.azure.com/",
        api_key="your_api_key_here"
    )
    
    doc_intelligence = DocumentIntelligence(provider=provider)
    
    # Analizar un documento desde un archivo
    file_path = "samples/invoice.pdf"
    model_id = "prebuilt-document"  # ID del modelo a usar
    
    # Realizar el análisis
    response = doc_intelligence.analyze_document(
        file_path=file_path,
        model_id=model_id,
        locale="es"  # Especificar el idioma si es necesario
    )
    
    # Trabajar con los resultados
    print(f"Análisis completado con éxito. Estado: {response.status}")
    
    # Acceder al contenido extraído
    print("\nTexto extraído del documento:")
    for page in response.pages:
        print(f"\n--- Página {page.page_number} ---")
        print(page.text)
    
    # Acceder a los campos clave-valor detectados
    print("\nInformación clave extraída:")
    for field_name, field_value in response.fields.items():
        print(f"{field_name}: {field_value.value} (confianza: {field_value.confidence:.2f})")

if __name__ == "__main__":
    main() 