#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Credential and Base64 example for Document Intelligence SDK.

This example demonstrates how to:
1. Use Azure credentials instead of API key
2. Disable SSL verification with connection_verify=False
3. Analyze a document from Base64 encoded data

This version uses the direct HTTP requests implementation.
"""

import os
import sys
import base64
from pathlib import Path

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the SDK
from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.auth.azure import AzureCredential
from doc_intelligent.utils.errors import DocumentIntelligenceError


def main():
    """Run the credential and base64 example."""
    # Check for required environment variables
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    tenant_id = os.getenv("AZURE_TENANT_ID")
    client_id = os.getenv("AZURE_CLIENT_ID")
    client_secret = os.getenv("AZURE_CLIENT_SECRET")
    
    if not endpoint:
        print("Error: Please set the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT environment variable.")
        return 1
    
    if not tenant_id or not client_id or not client_secret:
        print("Error: Please set the AZURE_TENANT_ID, AZURE_CLIENT_ID, and AZURE_CLIENT_SECRET environment variables.")
        print("You can use service principal authentication with:")
        print("  export AZURE_TENANT_ID='your-tenant-id'")
        print("  export AZURE_CLIENT_ID='your-client-id'")
        print("  export AZURE_CLIENT_SECRET='your-client-secret'")
        return 1
    
    # Get document path from command line argument
    if len(sys.argv) > 1:
        document_path = sys.argv[1]
    else:
        print("No document path provided. Please provide a path to a document as a command line argument.")
        print(f"Usage: python {Path(__file__).name} path/to/document.pdf")
        return 1
    
    # Verify document exists
    document_path = Path(document_path)
    if not document_path.exists():
        print(f"Error: Document not found at {document_path}")
        return 1
    
    try:
        # Create a credential object using service principal authentication
        print("Creating credential with service principal...")
        credential = AzureCredential.from_service_principal(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        # Create a client with credential and SSL verification disabled
        print(f"Creating client with endpoint: {endpoint}")
        print("Using Document Intelligence SDK with direct HTTP requests")
        print("SSL verification is disabled (not recommended for production)")
        client = DocIntelligenceClient(
            endpoint=endpoint,
            credential=credential,
            connection_verify=False  # Disable SSL verification
        )
        
        # Convert document to base64
        print(f"Reading document and converting to base64: {document_path}")
        with open(document_path, "rb") as f:
            file_content = f.read()
            base64_content = base64.b64encode(file_content).decode('utf-8')
        
        # Determine content type based on file extension
        content_types = {
            ".pdf": "application/pdf",
            ".jpeg": "image/jpeg",
            ".jpg": "image/jpeg",
            ".png": "image/png",
            ".bmp": "image/bmp",
            ".tiff": "image/tiff",
            ".tif": "image/tiff",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }
        content_type = content_types.get(document_path.suffix.lower(), "application/octet-stream")
        
        print(f"Analyzing document from base64 data")
        print(f"Content type: {content_type}")
        print(f"Base64 length: {len(base64_content)} characters")
        
        # Analyze document from base64 data
        result = client.analyze_document_from_base64(
            base64_string=base64_content,
            content_type=content_type,
            model_id="prebuilt-document",
            # Nuevos parámetros disponibles:
            poll_interval=5,     # Intervalo de polling en segundos
            timeout=300          # Tiempo máximo de espera en segundos
        )
        
        # Get the analyzed document
        document = result.get_analyzed_document()
        if not document:
            print("Document analysis failed or returned no results.")
            return 1
        
        # Print document information
        print("\n==== Document Analysis Results ====")
        print(f"Model ID: {document.model_id}")
        print(f"Number of pages: {len(document.pages)}")
        
        # Extract and print text
        text = document.get_text()
        print("\n==== Document Text ====")
        print(f"{text[:300]}...")
        
        # Extract and print key-value pairs
        key_values = document.get_key_value_pairs()
        print(f"\n==== Key-Value Pairs ({len(key_values)}) ====")
        for kv in key_values:
            print(f"{kv.key}: {kv.value}")
        
        # Save outputs to file
        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)
        
        # Save text content to file
        text_path = output_dir / f"{document_path.stem}_from_base64.txt"
        print(f"\nSaving text to {text_path}")
        with open(text_path, "w", encoding="utf-8") as f:
            f.write(text)
        
        print("\nDocument analysis complete!")
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Document Intelligence Error: {e}")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 