#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Invoice analysis example for Document Intelligence SDK.

This example demonstrates how to use the Document Intelligence SDK
to analyze invoices and extract invoice-specific information.
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime
from pprint import pprint

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the SDK
from src.doc_intelligent.client import DocIntelligenceClient
from src.doc_intelligent.core.converter import DocumentConverter
from src.doc_intelligent.utils.errors import DocumentIntelligenceError


def extract_invoice_data(document):
    """
    Extract key information from an invoice document.
    
    Args:
        document: The analyzed document object.
        
    Returns:
        dict: Dictionary containing structured invoice data.
    """
    # Extract key-value pairs into a dictionary
    kv_dict = {}
    for kv in document.key_value_pairs:
        kv_dict[kv.key.lower()] = kv.value
    
    # Build a structured invoice object
    invoice = {
        "vendor": {
            "name": kv_dict.get("vendor name") or kv_dict.get("supplier") or kv_dict.get("company"),
            "address": kv_dict.get("vendor address") or kv_dict.get("address"),
            "phone": kv_dict.get("phone") or kv_dict.get("phone number") or kv_dict.get("tel"),
            "email": kv_dict.get("email"),
            "website": kv_dict.get("website"),
            "tax_id": kv_dict.get("tax id") or kv_dict.get("vat number") or kv_dict.get("vat"),
        },
        "customer": {
            "name": kv_dict.get("customer name") or kv_dict.get("bill to") or kv_dict.get("client"),
            "address": kv_dict.get("customer address") or kv_dict.get("billing address"),
            "account": kv_dict.get("account number") or kv_dict.get("customer id"),
        },
        "invoice": {
            "number": kv_dict.get("invoice number") or kv_dict.get("invoice no") or kv_dict.get("invoice #"),
            "date": kv_dict.get("invoice date") or kv_dict.get("date"),
            "due_date": kv_dict.get("due date"),
            "po_number": kv_dict.get("purchase order") or kv_dict.get("po number") or kv_dict.get("po #"),
            "terms": kv_dict.get("terms") or kv_dict.get("payment terms"),
        },
        "payment": {
            "subtotal": kv_dict.get("subtotal"),
            "tax": kv_dict.get("tax") or kv_dict.get("vat amount") or kv_dict.get("sales tax"),
            "tax_rate": kv_dict.get("tax rate") or kv_dict.get("vat rate"),
            "shipping": kv_dict.get("shipping") or kv_dict.get("delivery"),
            "discount": kv_dict.get("discount"),
            "total": kv_dict.get("total") or kv_dict.get("amount due") or kv_dict.get("balance due"),
            "currency": kv_dict.get("currency"),
        },
        "items": []
    }
    
    # Extract line items from tables
    tables = document.get_tables()
    if tables:
        # Assume the largest table contains line items
        largest_table = max(tables, key=lambda t: t.row_count * t.column_count)
        
        # Try to identify header row and column meanings
        headers = {}
        for cell in largest_table.cells:
            if cell.row_index == 0:
                text = cell.text.lower()
                if "description" in text or "item" in text:
                    headers["description"] = cell.column_index
                elif "quantity" in text or "qty" in text:
                    headers["quantity"] = cell.column_index
                elif "price" in text or "rate" in text or "unit" in text:
                    headers["price"] = cell.column_index
                elif "amount" in text or "total" in text:
                    headers["amount"] = cell.column_index
                
        # Extract items with identified headers
        items = []
        for row_idx in range(1, largest_table.row_count):
            item = {}
            for cell in [c for c in largest_table.cells if c.row_index == row_idx]:
                for header_name, col_idx in headers.items():
                    if cell.column_index == col_idx:
                        item[header_name] = cell.text.strip()
            
            if item and any(item.values()):  # Only add non-empty items
                items.append(item)
                
        invoice["items"] = items
    
    return invoice


def main():
    """Run the invoice analysis example."""
    # Check for required environment variables
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    api_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    
    if not endpoint or not api_key:
        print("Error: Please set the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and AZURE_DOCUMENT_INTELLIGENCE_KEY environment variables.")
        return 1
    
    # Get invoice path from command line argument or use default
    if len(sys.argv) > 1:
        invoice_path = sys.argv[1]
    else:
        print("No invoice path provided. Please provide a path to an invoice as a command line argument.")
        print(f"Usage: python {Path(__file__).name} path/to/invoice.pdf")
        return 1
    
    # Verify invoice exists
    invoice_path = Path(invoice_path)
    if not invoice_path.exists():
        print(f"Error: Invoice not found at {invoice_path}")
        return 1
    
    try:
        # Create a client
        print(f"Creating client with endpoint: {endpoint}")
        client = DocIntelligenceClient(endpoint=endpoint, api_key=api_key)
        
        # Analyze the invoice
        print(f"Analyzing invoice: {invoice_path}")
        result = client.analyze_document(
            file_path=invoice_path,
            model_id="prebuilt-invoice",  # Use the invoice-specific model
            locale="en"
        )
        
        # Get the analyzed document
        document = result.get_analyzed_document()
        if not document:
            print("Invoice analysis failed or returned no results.")
            return 1
        
        # Extract structured invoice data
        invoice_data = extract_invoice_data(document)
        
        # Print invoice information
        print("\n==== Invoice Analysis Results ====")
        print(f"Vendor: {invoice_data['vendor']['name']}")
        print(f"Invoice #: {invoice_data['invoice']['number']}")
        print(f"Date: {invoice_data['invoice']['date']}")
        print(f"Total: {invoice_data['payment']['total']}")
        
        # Print line items
        print("\n==== Invoice Items ====")
        for idx, item in enumerate(invoice_data['items']):
            print(f"Item {idx+1}: {item.get('description', 'N/A')} - {item.get('amount', 'N/A')}")
        
        # Save the structured invoice data as JSON
        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)
        
        json_path = output_dir / f"{invoice_path.stem}_structured.json"
        print(f"\nSaving structured invoice data to {json_path}")
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(invoice_data, f, indent=2, default=str)
        
        # Save the full analysis result
        converter = DocumentConverter()
        full_json_path = output_dir / f"{invoice_path.stem}_full.json"
        print(f"Saving full analysis result to {full_json_path}")
        converter.to_json(document, full_json_path)
        
        print("\nInvoice analysis complete!")
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Document Intelligence Error: {e}")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 