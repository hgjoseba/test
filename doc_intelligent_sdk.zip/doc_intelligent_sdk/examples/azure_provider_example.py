#!/usr/bin/env python
"""
Ejemplo completo de uso del proveedor de Azure con el SDK de Document Intelligence.

Este ejemplo muestra cómo utilizar las capacidades específicas de Azure Document Intelligence
incluyendo modelos preconfigurados, modelos personalizados y análisis de diferentes tipos
de documentos.
"""

import os
import json
from pprint import pprint
from doc_intelligent import DocumentIntelligence
from doc_intelligent.providers import AzureDocumentProvider

def main():
    # Inicializar el proveedor de Azure
    # Opciones de autenticación: clave API o credencial (Service Principal)
    provider = AzureDocumentProvider(
        endpoint=os.environ.get("AZURE_DOC_ENDPOINT", "https://your-resource.cognitiveservices.azure.com/"),
        api_key=os.environ.get("AZURE_DOC_API_KEY", "your_api_key")
    )
    
    # Inicializar el SDK con el proveedor de Azure
    doc_intelligence = DocumentIntelligence(provider=provider)
    
    # Listar modelos disponibles en Azure
    print("=== Modelos disponibles en Azure Document Intelligence ===")
    try:
        models = doc_intelligence.list_models()
        print(f"Modelos disponibles: {len(models)}")
        for model in models[:5]:  # Mostrar solo los primeros 5 modelos
            print(f"- {model.get('modelId', 'Desconocido')}: {model.get('description', 'Sin descripción')}")
    except Exception as e:
        print(f"Error al listar modelos: {e}")
        print("Continuando con modelos predefinidos...")
    
    print("\n=== Análisis de diferentes tipos de documentos ===")
    
    # 1. Análisis de factura con modelo preconfigurado
    print("\n--- Análisis de factura ---")
    invoice_file = "samples/invoice.pdf"
    
    try:
        invoice_response = doc_intelligence.analyze_document(
            file_path=invoice_file,
            model_id="prebuilt-invoice",  # Modelo preconfigurado para facturas
            locale="es"
        )
        
        print(f"Factura analizada. Estado: {invoice_response.status}")
        print(f"Campos detectados: {len(invoice_response.fields)}")
        
        # Mostrar campos específicos de facturas
        invoice_fields = [
            "InvoiceId", "InvoiceDate", "DueDate", "VendorName",
            "CustomerName", "TotalTax", "InvoiceTotal"
        ]
        
        print("\nInformación de la factura:")
        for field in invoice_fields:
            if field in invoice_response.fields:
                value = invoice_response.fields[field].value
                confidence = invoice_response.fields[field].confidence
                print(f"  {field}: {value} (confianza: {confidence:.2f})")
    
    except Exception as e:
        print(f"Error al analizar factura: {e}")
    
    # 2. Análisis de recibo con modelo preconfigurado
    print("\n--- Análisis de recibo ---")
    receipt_file = "samples/receipt.pdf"
    
    try:
        receipt_response = doc_intelligence.analyze_document(
            file_path=receipt_file,
            model_id="prebuilt-receipt",  # Modelo preconfigurado para recibos
            locale="es"
        )
        
        print(f"Recibo analizado. Estado: {receipt_response.status}")
        
        # Mostrar estructura de tablas en recibos (productos/artículos)
        if "Items" in receipt_response.fields:
            items = receipt_response.fields["Items"].value
            print("\nArtículos en el recibo:")
            for i, item in enumerate(items):
                name = item.get("Description", {}).get("value", "Desconocido")
                quantity = item.get("Quantity", {}).get("value", "1")
                price = item.get("Price", {}).get("value", "0.00")
                amount = item.get("TotalPrice", {}).get("value", "0.00")
                print(f"  {i+1}. {name} - Cantidad: {quantity}, Precio: {price}, Total: {amount}")
                
        # Mostrar totales
        total_field = receipt_response.fields.get("Total", None)
        if total_field:
            print(f"\nTotal del recibo: {total_field.value}")
    
    except Exception as e:
        print(f"Error al analizar recibo: {e}")
    
    # 3. Análisis de documentos de identidad
    print("\n--- Análisis de documento de identidad ---")
    id_file = "samples/id_document.jpg"
    
    try:
        id_response = doc_intelligence.analyze_document(
            file_path=id_file,
            model_id="prebuilt-idDocument",  # Modelo para documentos de identidad
            locale="es"
        )
        
        print(f"Documento de identidad analizado. Estado: {id_response.status}")
        
        # Campos típicos de documentos de identidad
        id_fields = [
            "DocumentNumber", "FirstName", "LastName", "DateOfBirth",
            "DateOfExpiration", "DocumentType", "CountryRegion"
        ]
        
        print("\nInformación del documento de identidad:")
        for field in id_fields:
            if field in id_response.fields:
                value = id_response.fields[field].value
                confidence = id_response.fields[field].confidence
                print(f"  {field}: {value} (confianza: {confidence:.2f})")
    
    except Exception as e:
        print(f"Error al analizar documento de identidad: {e}")
    
    # 4. Uso de parámetros específicos de Azure
    print("\n--- Usando características específicas de Azure ---")
    custom_file = "samples/document.pdf"
    
    try:
        # Ejemplo con parámetros específicos de Azure pasados a través de kwargs
        custom_response = doc_intelligence.analyze_document(
            file_path=custom_file,
            model_id="prebuilt-document",
            locale="es",
            # Parámetros específicos de Azure pasados a través de kwargs
            pages=["1", "3"],  # Analizar solo páginas específicas
            reading_order="natural",  # Orden de lectura natural vs. impreso
            features=["style", "language"]  # Habilitar detección de estilo y lenguaje
        )
        
        print(f"Documento analizado con parámetros personalizados. Estado: {custom_response.status}")
        
        # Acceder a información de estilo si está disponible
        if hasattr(custom_response, "styles") and custom_response.styles:
            print("\nEstilos detectados en el documento:")
            for style in custom_response.styles[:3]:  # Mostrar solo los primeros 3 estilos
                print(f"  - Estilo: {style.name}, Confianza: {style.confidence:.2f}")
        
        # Acceder a información de idioma si está disponible
        if hasattr(custom_response, "languages") and custom_response.languages:
            print("\nIdiomas detectados en el documento:")
            for lang in custom_response.languages[:3]:  # Mostrar solo los primeros 3 idiomas
                print(f"  - Idioma: {lang.name}, Confianza: {lang.confidence:.2f}")
    
    except Exception as e:
        print(f"Error al analizar documento con parámetros personalizados: {e}")
    
    print("\n=== Recomendaciones para usar Azure Document Intelligence ===")
    print("1. Utiliza modelos preconfigurados para tipos comunes de documentos")
    print("2. Entrena modelos personalizados para documentos específicos de tu negocio")
    print("3. Aprovecha las capacidades específicas como detección de idioma y estilo")
    print("4. Utiliza Service Principal para autenticación en entornos de producción")
    print("5. Configura diferentes endpoints según tus necesidades regionales")

if __name__ == "__main__":
    main() 