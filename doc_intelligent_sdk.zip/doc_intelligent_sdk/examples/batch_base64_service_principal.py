#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Batch processing with base64 and Service Principal example.

This example demonstrates how to:
1. Use Azure Service Principal credentials for authentication
2. Process multiple documents in batch using base64 encoded data
3. Disable SSL verification for testing environments (not recommended for production)
"""

import os
import sys
import json
import time
import base64
from pathlib import Path

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the SDK
from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.auth.azure import AzureCredential
from doc_intelligent.utils.errors import DocumentIntelligenceError


def main():
    """Run the batch processing with base64 and Service Principal example."""
    # Check for required environment variables
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    tenant_id = os.getenv("AZURE_TENANT_ID")
    client_id = os.getenv("AZURE_CLIENT_ID")
    client_secret = os.getenv("AZURE_CLIENT_SECRET")
    
    if not endpoint:
        print("Error: Please set the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT environment variable.")
        return 1
    
    if not tenant_id or not client_id or not client_secret:
        print("Error: Please set the AZURE_TENANT_ID, AZURE_CLIENT_ID, and AZURE_CLIENT_SECRET environment variables for Service Principal auth.")
        print("You can set them using:")
        print("  export AZURE_TENANT_ID='your-tenant-id'")
        print("  export AZURE_CLIENT_ID='your-client-id'")
        print("  export AZURE_CLIENT_SECRET='your-client-secret'")
        return 1
    
    # Get documents directory from command line argument
    if len(sys.argv) > 1:
        docs_dir = sys.argv[1]
    else:
        print("No documents directory provided. Please provide a path to a directory containing documents.")
        print(f"Usage: python {Path(__file__).name} path/to/docs_directory [model_id] [max_workers]")
        return 1
    
    # Get optional model_id parameter (default: prebuilt-document)
    model_id = "prebuilt-document"
    if len(sys.argv) > 2:
        model_id = sys.argv[2]
    
    # Get optional max_workers parameter (default: 4)
    max_workers = 4
    if len(sys.argv) > 3:
        try:
            max_workers = int(sys.argv[3])
        except ValueError:
            print(f"Error: max_workers must be an integer. Using default: {max_workers}")
    
    # Verify directory exists
    docs_dir = Path(docs_dir)
    if not docs_dir.exists() or not docs_dir.is_dir():
        print(f"Error: Directory not found or not a directory: {docs_dir}")
        return 1
    
    # Get list of document paths for later use
    document_paths = []
    for ext in ['.pdf', '.jpg', '.jpeg', '.png']:
        document_paths.extend(list(docs_dir.glob(f'**/*{ext}')))
    
    if not document_paths:
        print(f"Error: No supported documents found in {docs_dir}")
        return 1
    
    print(f"Found {len(document_paths)} documents to process")
    
    try:
        # Create credential object using service principal
        print("Setting up Service Principal authentication...")
        credential = AzureCredential.from_service_principal(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        # Create a client with service principal authentication
        print(f"Creating client with endpoint: {endpoint}")
        # You can set connection_verify=False to disable SSL verification for testing environments
        # This is not recommended for production environments
        client = DocIntelligenceClient(
            endpoint=endpoint,
            credential=credential,
            connection_verify=True  # Set to False to disable SSL verification if needed
        )
        
        # Create output directory
        output_dir = Path("output/batch_base64_sp")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Convert documents to base64
        print("\n==== Converting documents to base64 ====")
        documents = []
        
        for path in document_paths:
            print(f"Reading {path}")
            try:
                # Read file content
                with open(path, "rb") as f:
                    file_content = f.read()
                
                # Encode to base64
                base64_content = base64.b64encode(file_content).decode('utf-8')
                
                # Determine content type based on file extension
                content_types = {
                    ".pdf": "application/pdf",
                    ".jpeg": "image/jpeg",
                    ".jpg": "image/jpeg",
                    ".png": "image/png",
                    ".bmp": "image/bmp",
                    ".tiff": "image/tiff",
                    ".tif": "image/tiff",
                    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                }
                content_type = content_types.get(path.suffix.lower(), "application/octet-stream")
                
                # Add to documents list with custom metadata for demonstration
                documents.append({
                    'id': str(path),  # Use path as ID for easy identification
                    'base64_string': base64_content,
                    'content_type': content_type,
                    'metadata': {  # This is ignored by the API but can be useful for your application
                        'filename': path.name,
                        'size_bytes': len(file_content),
                        'processed_time': time.strftime('%Y-%m-%d %H:%M:%S')
                    }
                })
                
                print(f"  Converted {path} to base64 ({len(base64_content)//1024} KB)")
                
            except Exception as e:
                print(f"  Error reading {path}: {e}")
        
        if not documents:
            print("Error: Failed to convert any documents to base64")
            return 1
        
        print(f"\nSuccessfully converted {len(documents)} documents to base64")
        
        # Analyze documents in batch using base64
        print("\n==== Starting batch analysis with base64 and Service Principal auth ====")
        start_time = time.time()
        
        # Call the batch analysis method
        results = client.analyze_documents_batch_from_base64(
            documents=documents,
            model_id=model_id,
            max_concurrent_requests=max_workers,
            # You can add additional parameters here such as:
            # pages=[1, 2, 3],  # to analyze specific pages
            # poll_interval=10,  # to change polling interval
            # timeout=600,       # to increase timeout for large documents
        )
        
        end_time = time.time()
        total_time = end_time - start_time
        
        print(f"\nBatch Processing Results:")
        print(f"Total documents: {len(documents)}")
        print(f"Successfully processed: {len(results)}")
        print(f"Time taken: {total_time:.2f} seconds")
        print(f"Average time per document: {total_time / len(documents):.2f} seconds")
        
        # Print details about each processed document
        print("\n==== Document Analysis Results ====")
        for doc_id, result in results.items():
            doc = result.get_analyzed_document()
            if doc:
                print(f"\nDocument: {doc_id}")
                print(f"  Pages: {len(doc.pages)}")
                print(f"  Tables: {len(doc.tables)}")
                print(f"  Key-Value Pairs: {len(doc.key_value_pairs)}")
                
                # Save extracted text to output directory
                text = doc.get_text()
                output_path = output_dir / f"{Path(doc_id).stem}.txt"
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(text)
                print(f"  Text saved to: {output_path}")
                
                # Save full JSON analysis result
                json_path = output_dir / f"{Path(doc_id).stem}.json"
                with open(json_path, 'w', encoding='utf-8') as f:
                    # Use the private raw data for complete results
                    # Caution: This is an internal implementation detail and may change
                    json.dump(result._raw_data, f, indent=2)
                print(f"  Full analysis saved to: {json_path}")
        
        # Print summary
        success_rate = (len(results) / len(documents)) * 100 if documents else 0
        print(f"\nBatch processing summary:")
        print(f"  Success rate: {success_rate:.1f}%")
        print(f"  Processing speed: {len(results) / total_time:.2f} documents per second")
        print(f"  Total documents processed: {len(results)}/{len(documents)}")
        
        print("\nBatch processing with Service Principal auth completed successfully!")
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Document Intelligence Error: {e}")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 