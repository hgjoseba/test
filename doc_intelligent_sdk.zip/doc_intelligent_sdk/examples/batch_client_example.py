#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Batch processing with client example for Document Intelligence SDK.

This example demonstrates how to use the batch processing functionality
that is directly integrated into the DocIntelligenceClient class.
"""

import os
import sys
import json
from pathlib import Path

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the SDK
from src.doc_intelligent.client import DocIntelligenceClient
from src.doc_intelligent.utils.errors import DocumentIntelligenceError


def on_document_success(file_path, document):
    """Callback function for successful document processing."""
    print(f"✅ SUCCESS: {file_path} - {len(document.pages)} pages")


def on_document_error(file_path, error_message):
    """Callback function for failed document processing."""
    print(f"❌ ERROR: {file_path} - {error_message}")


def main():
    """Run the batch client example."""
    # Check for required environment variables
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    api_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    
    if not endpoint or not api_key:
        print("Error: Please set the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and AZURE_DOCUMENT_INTELLIGENCE_KEY environment variables.")
        return 1
    
    # Get documents directory from command line argument
    if len(sys.argv) > 1:
        docs_dir = sys.argv[1]
    else:
        print("No documents directory provided. Please provide a path to a directory containing documents.")
        print(f"Usage: python {Path(__file__).name} path/to/docs_directory [model_id]")
        return 1
    
    # Get optional model_id parameter (default: prebuilt-document)
    model_id = "prebuilt-document"
    if len(sys.argv) > 2:
        model_id = sys.argv[2]
    
    # Verify directory exists
    docs_dir = Path(docs_dir)
    if not docs_dir.exists() or not docs_dir.is_dir():
        print(f"Error: Directory not found or not a directory: {docs_dir}")
        return 1
    
    try:
        # Create a client
        print(f"Creating client with endpoint: {endpoint}")
        client = DocIntelligenceClient(endpoint=endpoint, api_key=api_key)
        
        # Create output directory
        output_dir = Path("output/client_batch")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"\n=== Method 1: Using batch_analyze_directory ===")
        print(f"Processing documents in directory: {docs_dir}")
        
        # Analyze all documents in the directory
        results = client.batch_analyze_directory(
            directory_path=docs_dir,
            extensions=['.pdf', '.jpg', '.jpeg', '.png'],
            recursive=True,  # Search subdirectories too
            parallel=True,   # Process documents in parallel
            max_workers=3,   # Use 3 parallel workers
            model_id=model_id
        )
        
        # Save results to file
        result_path = output_dir / "directory_results.json"
        # Remove the document objects from results before saving as they're not JSON serializable
        serializable_results = {
            **results,
            "results": {k: {"page_count": len(v.pages)} for k, v in results["results"].items()}
        }
        with open(result_path, 'w', encoding='utf-8') as f:
            json.dump(serializable_results, f, indent=2)
        
        print(f"\nProcessed {results['total_documents']} documents")
        print(f"Successful: {results['successful_count']}, Failed: {results['failed_count']}")
        print(f"Total processing time: {results['processing_time_seconds']:.2f} seconds")
        print(f"Results saved to: {result_path}")
        
        print(f"\n=== Method 2: Using create_batch_processor with callbacks ===")
        
        # Create a batch processor with custom callbacks
        batch_processor = client.create_batch_processor(
            max_workers=4,
            model_id=model_id,
            on_success_callback=on_document_success,
            on_error_callback=on_document_error
        )
        
        # Find all documents in the directory
        document_paths = list(docs_dir.glob('**/*.pdf')) + list(docs_dir.glob('**/*.jpg')) + list(docs_dir.glob('**/*.png'))
        
        print(f"Processing {len(document_paths)} documents with custom callbacks...")
        
        # Process the documents in parallel
        results = batch_processor.process_parallel(document_paths)
        
        # Save results to file
        processor_result_path = output_dir / "processor_results.json"
        # Remove the document objects from results before saving
        serializable_results = {
            **results,
            "results": {k: {"page_count": len(v.pages)} for k, v in results["results"].items()}
        }
        with open(processor_result_path, 'w', encoding='utf-8') as f:
            json.dump(serializable_results, f, indent=2)
        
        print(f"\nProcessed {results['total_documents']} documents")
        print(f"Successful: {results['successful_count']}, Failed: {results['failed_count']}")
        print(f"Total processing time: {results['processing_time_seconds']:.2f} seconds")
        print(f"Results saved to: {processor_result_path}")
        
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Document Intelligence Error: {e}")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 