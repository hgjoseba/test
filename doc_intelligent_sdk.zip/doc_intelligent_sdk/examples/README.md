# Document Intelligence SDK Examples

This directory contains examples of using the Document Intelligence SDK to analyze different types of documents.

## Setup

Before running the examples, make sure to configure the necessary environment variables:

```bash
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT='your-azure-endpoint'
export AZURE_DOCUMENT_INTELLIGENCE_KEY='your-azure-key'
```

## Available Examples

### basic_usage.py

This example shows the basic usage of the SDK to analyze a generic document:

```bash
python basic_usage.py path/to/your/document.pdf
```

### invoice_analysis.py

This example shows how to use the specific model for invoices:

```bash
python invoice_analysis.py path/to/your/invoice.pdf
```

### credential_base64_example.py

This example demonstrates:
1. Using Azure Service Principal credentials instead of API key
2. Disabling SSL verification with `connection_verify=False`
3. Analyzing a document from Base64 encoded data

```bash
# First set the service principal environment variables
export AZURE_TENANT_ID='your-tenant-id'
export AZURE_CLIENT_ID='your-client-id'
export AZURE_CLIENT_SECRET='your-client-secret'

# Then run the example
python credential_base64_example.py path/to/your/document.pdf
```

### batch_processing_example.py

This example demonstrates our custom implementation of batch processing:
1. Processing documents in a directory both sequentially and in parallel
2. Comparing performance between sequential and parallel processing
3. Handling errors and tracking progress for each document

```bash
# Basic usage with default settings
python batch_processing_example.py path/to/documents_directory

# Advanced usage with custom model and worker count
python batch_processing_example.py path/to/documents_directory prebuilt-layout 10
```

### batch_client_example.py

This example demonstrates the built-in batch processing functionality that's integrated directly in the client:
1. Using the `batch_analyze_directory` method to process all documents in a directory
2. Creating a custom `BatchProcessor` with callback functions for success/error handling
3. Using parallel processing for efficient document analysis

```bash
# Process all documents in a directory
python batch_client_example.py path/to/documents_directory

# Process using a specific model
python batch_client_example.py path/to/documents_directory prebuilt-layout
```

### batch_base64_example.py

This example demonstrates how to process multiple documents in batch mode using base64 encoded data:
1. Reading documents from a directory and converting them to base64
2. Processing multiple documents in parallel using the `analyze_documents_batch_from_base64` method
3. Handling results and saving extracted text for each document

```bash
# Process documents from a directory using base64 encoding
python batch_base64_example.py path/to/documents_directory

# With custom model and worker count
python batch_base64_example.py path/to/documents_directory prebuilt-layout 8
```

## Batch Base64 Example

El archivo `batch_base64_example.py` demuestra cómo utilizar el procesamiento por lotes para analizar múltiples documentos usando cadenas base64. Este enfoque es útil cuando ya tienes los documentos en memoria o necesitas preprocesarlos antes del análisis.

### Uso:
```bash
python batch_base64_example.py path/to/docs_directory [model_id] [max_workers]
```

## Batch Base64 Service Principal Example

El archivo `batch_base64_service_principal.py` muestra cómo usar autenticación con Service Principal de Azure para procesar múltiples documentos en base64. Este ejemplo es particularmente útil para escenarios empresariales o automatizaciones donde no se recomienda usar credenciales de clave API directas.

### Requisitos:
- Service Principal con acceso a Document Intelligence
- Variables de entorno configuradas:
  ```
  AZURE_TENANT_ID
  AZURE_CLIENT_ID  
  AZURE_CLIENT_SECRET
  AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT
  ```

### Uso:
```bash
python batch_base64_service_principal.py path/to/docs_directory [model_id] [max_workers]
```

El ejemplo incluye:
- Autenticación usando credenciales de Service Principal
- Conversión de documentos a base64
- Procesamiento por lotes con manejo de concurrencia
- Guardado de resultados en formato texto y JSON
- Estadísticas de rendimiento

## Important Notes

- These examples are designed to work directly from this folder, without needing to install the package.
- If you want to run the examples with the package installed, modify the imports to use `import doc_intelligent` instead of `from src.doc_intelligent`.
- Results will be saved in an `output` folder in the directory from where you run the example. 