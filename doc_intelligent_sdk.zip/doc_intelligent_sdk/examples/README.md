# Document Intelligence SDK Examples

This directory contains examples of using the Document Intelligence SDK to analyze different types of documents.

## Setup

Before running the examples, make sure to configure the necessary environment variables:

```bash
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT='your-azure-endpoint'
export AZURE_DOCUMENT_INTELLIGENCE_KEY='your-azure-key'
```

## Available Examples

### basic_usage.py

This example shows the basic usage of the SDK to analyze a generic document:

```bash
python basic_usage.py path/to/your/document.pdf
```

### invoice_analysis.py

This example shows how to use the specific model for invoices:

```bash
python invoice_analysis.py path/to/your/invoice.pdf
```

### credential_base64_example.py

This example demonstrates:
1. Using Azure Service Principal credentials instead of API key
2. Disabling SSL verification with `connection_verify=False`
3. Analyzing a document from Base64 encoded data

```bash
# First set the service principal environment variables
export AZURE_TENANT_ID='your-tenant-id'
export AZURE_CLIENT_ID='your-client-id'
export AZURE_CLIENT_SECRET='your-client-secret'

# Then run the example
python credential_base64_example.py path/to/your/document.pdf
```

### batch_processing_example.py

This example demonstrates our custom implementation of batch processing:
1. Processing documents in a directory both sequentially and in parallel
2. Comparing performance between sequential and parallel processing
3. Handling errors and tracking progress for each document

```bash
# Basic usage with default settings
python batch_processing_example.py path/to/documents_directory

# Advanced usage with custom model and worker count
python batch_processing_example.py path/to/documents_directory prebuilt-layout 10
```

### batch_client_example.py

This example demonstrates the built-in batch processing functionality that's integrated directly in the client:
1. Using the `batch_analyze_directory` method to process all documents in a directory
2. Creating a custom `BatchProcessor` with callback functions for success/error handling
3. Using parallel processing for efficient document analysis

```bash
# Process all documents in a directory
python batch_client_example.py path/to/documents_directory

# Process using a specific model
python batch_client_example.py path/to/documents_directory prebuilt-layout
```

## Important Notes

- These examples are designed to work directly from this folder, without needing to install the package.
- If you want to run the examples with the package installed, modify the imports to use `import doc_intelligent` instead of `from src.doc_intelligent`.
- Results will be saved in an `output` folder in the directory from where you run the example. 