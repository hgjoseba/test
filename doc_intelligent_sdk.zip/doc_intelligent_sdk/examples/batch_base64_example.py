#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Batch processing with base64 example for Document Intelligence SDK.

This example demonstrates how to process multiple documents using base64 encoded data,
which is useful in scenarios where documents are already in memory or coming from 
sources other than the filesystem.
"""

import os
import sys
import json
import time
import base64
from pathlib import Path

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the SDK
from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.utils.errors import DocumentIntelligenceError


def main():
    """Run the batch processing with base64 example."""
    # Check for required environment variables
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    api_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    
    if not endpoint or not api_key:
        print("Error: Please set the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and AZURE_DOCUMENT_INTELLIGENCE_KEY environment variables.")
        return 1
    
    # Get documents directory from command line argument
    if len(sys.argv) > 1:
        docs_dir = sys.argv[1]
    else:
        print("No documents directory provided. Please provide a path to a directory containing documents.")
        print(f"Usage: python {Path(__file__).name} path/to/docs_directory [model_id] [max_workers]")
        return 1
    
    # Get optional model_id parameter (default: prebuilt-document)
    model_id = "prebuilt-document"
    if len(sys.argv) > 2:
        model_id = sys.argv[2]
    
    # Get optional max_workers parameter (default: 4)
    max_workers = 4
    if len(sys.argv) > 3:
        try:
            max_workers = int(sys.argv[3])
        except ValueError:
            print(f"Error: max_workers must be an integer. Using default: {max_workers}")
    
    # Verify directory exists
    docs_dir = Path(docs_dir)
    if not docs_dir.exists() or not docs_dir.is_dir():
        print(f"Error: Directory not found or not a directory: {docs_dir}")
        return 1
    
    # Get list of document paths for later use
    document_paths = []
    for ext in ['.pdf', '.jpg', '.jpeg', '.png']:
        document_paths.extend(list(docs_dir.glob(f'**/*{ext}')))
    
    if not document_paths:
        print(f"Error: No supported documents found in {docs_dir}")
        return 1
    
    print(f"Found {len(document_paths)} documents to process")
    
    try:
        # Create a client
        print(f"Creating client with endpoint: {endpoint}")
        client = DocIntelligenceClient(endpoint=endpoint, api_key=api_key)
        
        # Create output directory
        output_dir = Path("output/batch_base64")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Convert documents to base64
        print("\n==== Converting documents to base64 ====")
        documents = []
        
        for path in document_paths:
            print(f"Reading {path}")
            try:
                # Read file content
                with open(path, "rb") as f:
                    file_content = f.read()
                
                # Encode to base64
                base64_content = base64.b64encode(file_content).decode('utf-8')
                
                # Determine content type based on file extension
                content_types = {
                    ".pdf": "application/pdf",
                    ".jpeg": "image/jpeg",
                    ".jpg": "image/jpeg",
                    ".png": "image/png",
                    ".bmp": "image/bmp",
                    ".tiff": "image/tiff",
                    ".tif": "image/tiff",
                    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                }
                content_type = content_types.get(path.suffix.lower(), "application/octet-stream")
                
                # Add to documents list
                documents.append({
                    'id': str(path),  # Use path as ID for easy identification
                    'base64_string': base64_content,
                    'content_type': content_type
                })
                
                print(f"  Converted {path} to base64 ({len(base64_content)//1024} KB)")
                
            except Exception as e:
                print(f"  Error reading {path}: {e}")
        
        if not documents:
            print("Error: Failed to convert any documents to base64")
            return 1
        
        print(f"\nSuccessfully converted {len(documents)} documents to base64")
        
        # Analyze documents in batch using base64
        print("\n==== Starting batch analysis with base64 ====")
        start_time = time.time()
        
        results = client.analyze_documents_batch_from_base64(
            documents=documents,
            model_id=model_id,
            max_concurrent_requests=max_workers
        )
        
        end_time = time.time()
        total_time = end_time - start_time
        
        print(f"\nBatch Processing Results:")
        print(f"Total documents: {len(documents)}")
        print(f"Successfully processed: {len(results)}")
        print(f"Time taken: {total_time:.2f} seconds")
        print(f"Average time per document: {total_time / len(documents):.2f} seconds")
        
        # Print details about each processed document
        print("\n==== Document Analysis Results ====")
        for doc_id, result in results.items():
            doc = result.get_analyzed_document()
            if doc:
                print(f"\nDocument: {doc_id}")
                print(f"  Pages: {len(doc.pages)}")
                print(f"  Tables: {len(doc.tables)}")
                print(f"  Key-Value Pairs: {len(doc.key_value_pairs)}")
                
                # Save extracted text to output directory
                text = doc.get_text()
                output_path = output_dir / f"{Path(doc_id).stem}.txt"
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(text)
                print(f"  Text saved to: {output_path}")
        
        print("\nBatch processing with base64 example completed successfully!")
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Document Intelligence Error: {e}")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 