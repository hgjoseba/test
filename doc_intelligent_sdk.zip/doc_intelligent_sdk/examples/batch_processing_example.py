#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Batch processing example for Document Intelligence SDK.

This example demonstrates how to process multiple documents using the new 
batch processing capabilities integrated into the DocIntelligenceClient.
"""

import os
import sys
import json
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

# Add the parent directory to sys.path to import the SDK
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import the SDK
from src.doc_intelligent.client import DocIntelligenceClient
from src.doc_intelligent.utils.errors import DocumentIntelligenceError


def on_document_success(file_path, document):
    """Callback function for successful document processing."""
    print(f"✅ SUCCESS: {file_path} - {len(document.pages)} pages")


def on_document_error(file_path, error_message):
    """Callback function for failed document processing."""
    print(f"❌ ERROR: {file_path} - {error_message}")


def main():
    """Run the batch processing example."""
    # Check for required environment variables
    endpoint = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    api_key = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    
    if not endpoint or not api_key:
        print("Error: Please set the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT and AZURE_DOCUMENT_INTELLIGENCE_KEY environment variables.")
        return 1
    
    # Get documents directory from command line argument
    if len(sys.argv) > 1:
        docs_dir = sys.argv[1]
    else:
        print("No documents directory provided. Please provide a path to a directory containing documents.")
        print(f"Usage: python {Path(__file__).name} path/to/docs_directory [model_id] [max_workers]")
        return 1
    
    # Get optional model_id parameter (default: prebuilt-document)
    model_id = "prebuilt-document"
    if len(sys.argv) > 2:
        model_id = sys.argv[2]
    
    # Get optional max_workers parameter (default: 4)
    max_workers = 4
    if len(sys.argv) > 3:
        try:
            max_workers = int(sys.argv[3])
        except ValueError:
            print(f"Error: max_workers must be an integer. Using default: {max_workers}")
    
    # Verify directory exists
    docs_dir = Path(docs_dir)
    if not docs_dir.exists() or not docs_dir.is_dir():
        print(f"Error: Directory not found or not a directory: {docs_dir}")
        return 1
    
    # Get list of document paths for later use
    document_paths = []
    for ext in ['.pdf', '.jpg', '.jpeg', '.png']:
        document_paths.extend(list(docs_dir.glob(f'**/*{ext}')))
    
    if not document_paths:
        print(f"Error: No supported documents found in {docs_dir}")
        return 1
    
    print(f"Found {len(document_paths)} documents to process")
    
    try:
        # Create a client
        print(f"Creating client with endpoint: {endpoint}")
        client = DocIntelligenceClient(endpoint=endpoint, api_key=api_key)
        
        # Create output directory
        output_dir = Path("output/batch")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Method 1: Using batch_analyze_directory
        print(f"\n=== Method 1: Using batch_analyze_directory ===")
        print(f"Processing documents in directory: {docs_dir}")
        
        # Start timing
        sequential_start = time.time()
        
        # Analyze all documents in the directory sequentially
        sequential_results = client.batch_analyze_directory(
            directory_path=docs_dir,
            extensions=['.pdf', '.jpg', '.jpeg', '.png'],
            recursive=True,
            parallel=False,  # Process documents sequentially
            model_id=model_id
        )
        
        # Calculate processing time
        sequential_time = time.time() - sequential_start
        
        # Save sequential results
        sequential_path = output_dir / "sequential_results.json"
        # Remove the document objects from results before saving as they're not JSON serializable
        serializable_sequential = {
            **sequential_results,
            "results": {k: {"page_count": len(v.pages)} for k, v in sequential_results["results"].items()},
            "processing_time_seconds": sequential_time,
            "avg_time_per_document": sequential_time / len(document_paths) if document_paths else 0
        }
        with open(sequential_path, 'w', encoding='utf-8') as f:
            json.dump(serializable_sequential, f, indent=2)
        
        print(f"\nSequential processing complete! Results saved to {sequential_path}")
        print(f"Sequential stats: {sequential_results['successful_count']} successful, {sequential_results['failed_count']} failed")
        print(f"Total time: {sequential_time:.2f} seconds")
        print(f"Average time per document: {sequential_time / len(document_paths):.2f} seconds")
        
        # Method 2: Using create_batch_processor with parallel processing
        print(f"\n=== Method 2: Using create_batch_processor with parallel processing ===")
        
        # Create a batch processor with custom callbacks
        batch_processor = client.create_batch_processor(
            max_workers=max_workers,
            model_id=model_id,
            on_success_callback=on_document_success,
            on_error_callback=on_document_error
        )
        
        # Start timing
        parallel_start = time.time()
        
        # Process the documents in parallel
        parallel_results = batch_processor.process_parallel(document_paths)
        
        # Calculate processing time
        parallel_time = time.time() - parallel_start
        
        # Save parallel results
        parallel_path = output_dir / "parallel_results.json"
        # Remove the document objects from results before saving
        serializable_parallel = {
            **parallel_results,
            "results": {k: {"page_count": len(v.pages)} for k, v in parallel_results["results"].items()},
            "processing_time_seconds": parallel_time,
            "avg_time_per_document": parallel_time / len(document_paths) if document_paths else 0
        }
        with open(parallel_path, 'w', encoding='utf-8') as f:
            json.dump(serializable_parallel, f, indent=2)
        
        print(f"\nParallel processing complete! Results saved to {parallel_path}")
        print(f"Parallel stats: {parallel_results['successful_count']} successful, {parallel_results['failed_count']} failed")
        print(f"Total time: {parallel_time:.2f} seconds")
        print(f"Average time per document: {parallel_time / len(document_paths):.2f} seconds")
        
        # Compare performance
        speed_ratio = sequential_time / parallel_time if parallel_time > 0 else 0
        print(f"\nPerformance comparison: Parallel processing was {speed_ratio:.2f}x faster than sequential")
        
        return 0
        
    except DocumentIntelligenceError as e:
        print(f"Document Intelligence Error: {e}")
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main()) 