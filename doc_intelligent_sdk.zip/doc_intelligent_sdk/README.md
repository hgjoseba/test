# Document Intelligence SDK

A Python SDK for analyzing documents using document intelligence services such as Azure Document Intelligence (formerly Form Recognizer), with support for multiple providers.

## Features

- Analyze documents using various document intelligence services
- Initial support for Azure Document Intelligence service
- Extensible architecture to support additional providers in the future
- Extract text, tables, key-value pairs, and more from documents
- Support for various document types (PDF, images, Word documents)
- Simple authentication with cloud services
- Support for base64 encoded document data
- Convert analyzed documents to various formats (JSON, CSV, text)
- SSL certificate verification control for secure environments

## Installation

```bash
# Basic installation
pip install doc-intelligent-sdk

# With document processing extras
pip install doc-intelligent-sdk[document_processing]

# With development tools
pip install doc-intelligent-sdk[dev]
```

## Quick Start

```python
import os
from doc_intelligent_sdk import DocIntelligenceClient

# Set your Azure Document Intelligence endpoint and key
endpoint = "https://your-resource-name.cognitiveservices.azure.com/"
api_key = "your-api-key"

# Or use environment variables
# os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = endpoint
# os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"] = api_key

# Create a client (uses Azure provider by default)
client = DocIntelligenceClient(endpoint=endpoint, api_key=api_key)

# Analyze a document
result = client.analyze_document(
    file_path="path/to/your/document.pdf",
    model_id="prebuilt-document"
)

# Get the analyzed document
document = result.get_analyzed_document()

# Extract text
text = document.get_text()
print(f"Document text: {text[:100]}...")

# Extract tables
tables = document.get_tables()
print(f"Number of tables found: {len(tables)}")

# Extract key-value pairs
key_values = document.get_key_value_pairs()
for kv in key_values:
    print(f"{kv.key}: {kv.value}")
```

## Direct HTTP Requests with requests Library

This SDK now uses the `requests` library for direct HTTP calls to the Azure Document Intelligence API instead of the Azure AI Cognitive Services SDK. This change provides more flexibility and transparency in the API interactions. Here's an example of a simplified direct usage with `requests`:

```python
import os
import sys
import time
import base64
import logging
import requests

# Configure logging
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)

def analyze_document(file_path, api_key=None, upload_mode="multipart", poll_interval=5, timeout=300):
    """
    Analyze a document using the Document Intelligence service with direct API calls.
   
    Parameters:
      - file_path: path to the file to analyze (PDF)
      - api_key: API key for Azure Document Intelligence
      - upload_mode: "multipart" or "base64" for document upload
      - poll_interval: interval (in seconds) between each polling request
      - timeout: maximum time (in seconds) to wait for the result
     
    Returns:
      - result_json: JSON with the analysis result (or None in case of error)
    """
    # Read necessary environment variables
    api_key = api_key or os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_KEY")
    endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    
    if not endpoint or not api_key:
        logger.error("Missing required environment variables for endpoint or API key")
        return None

    # Configure proxy settings if needed
    private_fqdn = endpoint.replace("https://", "")
    os.environ["NO_PROXY"] = private_fqdn
    
    # Prepare API URL and version
    api_version = "2023-07-31"
    analyze_url = f"{endpoint}/documentintelligence/documentModels/prebuilt-document:analyze?api-version={api_version}"
    logger.info(f"Analyze URL: {analyze_url}")

    # Authentication header
    headers = {"Ocp-Apim-Subscription-Key": api_key}
    
    # Upload document
    if upload_mode == "multipart":
        logger.info("Uploading file using multipart/form-data...")
        try:
            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f, "application/pdf")}
                response = requests.post(analyze_url, headers=headers, files=files, timeout=30)
        except Exception as ex:
            logger.error(f"Error during multipart upload: {ex}")
            return None
    elif upload_mode == "base64":
        logger.info("Uploading file using base64...")
        try:
            with open(file_path, "rb") as f:
                file_bytes = f.read()
            encoded_data = base64.b64encode(file_bytes).decode("utf-8")
            payload = {"base64Source": encoded_data}
            headers["Content-Type"] = "application/json"
            response = requests.post(analyze_url, headers=headers, json=payload, timeout=30)
        except Exception as ex:
            logger.error(f"Error during base64 upload: {ex}")
            return None

    logger.info(f"Upload response, status: {response.status_code}")
    if response.status_code not in [200, 202]:
        logger.error(f"Upload failed: {response.status_code} {response.text}")
        return None

    # Get operation location for polling
    op_location = response.headers.get("Operation-Location")
    if not op_location:
        logger.error("Operation-Location header not found in response")
        return None

    logger.info(f"Operation-Location: {op_location}")
    
    # Start polling for results
    start_time = time.time()
    
    while True:
        try:
            poll_response = requests.get(op_location, headers=headers, timeout=30)
        except Exception as ex:
            logger.error(f"Error during polling: {ex}")
            time.sleep(poll_interval)
            continue

        if poll_response.status_code != 200:
            logger.error(f"Polling failed: {poll_response.status_code} {poll_response.text}")
            return None

        try:
            result_json = poll_response.json()
        except Exception as ex:
            logger.error(f"Error parsing JSON response: {ex}")
            time.sleep(poll_interval)
            continue

        status = result_json.get("status")
        logger.info(f"Current job status: {status}")
        
        if status in ["running", "notStarted"]:
            if time.time() - start_time > timeout:
                logger.error("Polling timeout exceeded")
                return None
            time.sleep(poll_interval)
        elif status == "succeeded":
            logger.info("Job completed successfully")
            return result_json
        else:
            logger.error(f"Job completed with unexpected status: {status}")
            return None

## Provider Architecture

The SDK uses a provider-based architecture, allowing for the addition of different document intelligence services. Currently, the SDK supports:

- **Azure Document Intelligence** (default): Microsoft's document analysis service

Future versions may include support for:
- Google Document AI
- Amazon Textract
- Other document intelligence services

You can specify which provider to use when creating the client:

```python
# Default - Azure provider
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    api_key="your-api-key",
    provider="azure"  # This is the default
)

# Future providers would be used like this:
# client = DocIntelligenceClient(
#     provider="google",
#     project_id="your-google-project-id",
#     credentials_path="path/to/google/credentials.json"
# )
```

## Analyzing Documents from Base64 Data

The SDK supports analyzing documents directly from base64 encoded data:

```python
import base64
from doc_intelligent_sdk import DocIntelligenceClient

# Set your Azure Document Intelligence endpoint and key
endpoint = "https://your-resource-name.cognitiveservices.azure.com/"
api_key = "your-api-key"

# Create a client
client = DocIntelligenceClient(endpoint=endpoint, api_key=api_key)

# Read and encode your document to base64
with open("path/to/your/document.pdf", "rb") as f:
    file_content = f.read()
    base64_content = base64.b64encode(file_content).decode('utf-8')

# Specify the content type
content_type = "application/pdf"  # Change based on document type

# Analyze the document from base64 data
result = client.analyze_document_from_base64(
    base64_string=base64_content,
    content_type=content_type,
    model_id="prebuilt-document"
)

# Get the analyzed document
document = result.get_analyzed_document()

# Extract text
text = document.get_text()
print(f"Document text from base64: {text[:100]}...")
```

## Authentication Options

### API Key Authentication

```python
from doc_intelligent_sdk import DocIntelligenceClient

client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    api_key="your-api-key"
)
```

### Azure Identity Authentication

```python
from doc_intelligent_sdk import DocIntelligenceClient
from doc_intelligent_sdk.auth.azure import AzureCredential

# Using default credential chain
credential = AzureCredential.default_credential()
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    credential=credential
)

# Using service principal
credential = AzureCredential.from_service_principal(
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret"
)
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    credential=credential
)
```

## SSL Certificate Verification

The SDK supports controlling SSL certificate verification for connections to Azure services, which is especially useful in environments with custom SSL certificates or proxies:

```python
# Disable SSL verification (not recommended for production)
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    api_key="your-api-key",
    connection_verify=False
)

# Use a custom CA certificate bundle
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    api_key="your-api-key",
    connection_verify="/path/to/your/ca-bundle.pem"
)

# Also available for credentials
credential = AzureCredential.from_service_principal(
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret",
    connection_verify=False  # Or path to custom CA bundle
)
```

## Available Model IDs

The Azure Document Intelligence service provides several pre-built models:

- `prebuilt-document`: General document analysis
- `prebuilt-layout`: Document layout analysis
- `prebuilt-receipt`: Receipt analysis
- `prebuilt-invoice`: Invoice analysis
- `prebuilt-idDocument`: ID document analysis
- `prebuilt-businessCard`: Business card analysis
- `prebuilt-contract`: Contract analysis
- `prebuilt-tax.us.w2`: US W2 tax form analysis

You can also use your own custom models by specifying their model ID.

## Document Conversion

The SDK provides utilities for converting analyzed documents to different formats:

```python
from doc_intelligent_sdk import DocIntelligenceClient
from doc_intelligent_sdk.core import DocumentConverter

# Analyze a document
client = DocIntelligenceClient(endpoint=endpoint, api_key=api_key)
result = client.analyze_document("path/to/document.pdf")
document = result.get_analyzed_document()

# Create a converter
converter = DocumentConverter()

# Convert to JSON
json_str = converter.to_json(document, "output.json")

# Extract text
text = converter.to_text(document, "output.txt")

# Convert tables to CSV
csv_paths = converter.to_csv(document, "output.csv")

# Get key-value pairs as dictionary
kv_dict = converter.to_key_value_dict(document)
```

## Environment Variables

The SDK supports the following environment variables:

- `AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT`: The Azure Document Intelligence endpoint URL
- `AZURE_DOCUMENT_INTELLIGENCE_KEY`: Your API key for Azure Document Intelligence
- `AZURE_TENANT_ID`: Azure tenant ID for service principal authentication
- `AZURE_CLIENT_ID`: Azure client ID for service principal authentication
- `AZURE_CLIENT_SECRET`: Azure client secret for service principal authentication
- `DOC_INTELLIGENCE_LOG_LEVEL`: Logging level (default: INFO)

## Development

```bash
# Clone the repository
git clone https://github.com/yourusername/doc-intelligent-sdk.git
cd doc-intelligent-sdk

# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest
```

## License

This project is licensed under the MIT License - see the LICENSE file for details. 