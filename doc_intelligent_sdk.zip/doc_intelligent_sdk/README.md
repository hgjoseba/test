# Document Intelligence SDK (OCR Version)

Un SDK simplificado para la extracción de texto de documentos utilizando servicios de inteligencia de documentos de Azure.

## Descripción

Este SDK proporciona una interfaz simplificada para extraer texto plano de documentos utilizando el servicio Azure Document Intelligence. Es ideal para aplicaciones que solo necesitan la funcionalidad de OCR (Reconocimiento Óptico de Caracteres) sin el procesamiento adicional de tablas, pares clave-valor u otros elementos estructurados.

## Características

- **Extracción de texto**: Extraer texto plano de documentos PDF, imágenes y otros formatos compatibles
- **Procesamiento por página**: Obtener texto de páginas específicas o de todo el documento
- **Soporte para múltiples fuentes**: Procesar documentos desde archivos locales o datos codificados en base64
- **Interfaz simplificada**: API fácil de usar para la extracción de texto

## Instalación

```bash
pip install doc-intelligent-sdk
```

## Requisitos

- Python 3.7 o superior
- Cuenta de Azure con acceso al servicio Document Intelligence (anteriormente Form Recognizer)

## Uso básico

### Configuración

```python
from doc_intelligent import DocIntelligenceClient

# Usando una clave API
client = DocIntelligenceClient(
    endpoint="https://su-recurso.cognitiveservices.azure.com/",
    api_key="su-clave-api"
)

# O usando credenciales de Azure
from doc_intelligent.auth import AzureCredential
credential = AzureCredential.from_default_credential()
client = DocIntelligenceClient(
    endpoint="https://su-recurso.cognitiveservices.azure.com/",
    credential=credential
)
```

### Extraer texto de un documento

```python
# Método directo para extraer texto
texto = client.extract_text("ruta/al/documento.pdf")
print(texto)

# O para más control sobre el proceso
response = client.analyze_document("ruta/al/documento.pdf")
documento = response.get_analyzed_document()
texto = documento.get_text()
print(texto)

# Extraer texto de una página específica
texto_pagina = documento.get_page_text(2)  # Obtiene el texto de la página 2
print(texto_pagina)
```

### Procesar datos codificados en base64

```python
import base64

# Leer un archivo y codificarlo
with open("ruta/al/documento.pdf", "rb") as f:
    content = f.read()
    base64_string = base64.b64encode(content).decode("utf-8")

# Extraer texto directamente
texto = client.extract_text_from_base64(
    base64_string=base64_string,
    content_type="application/pdf"
)
print(texto)
```

### Guardar el texto extraído a un archivo

```python
from doc_intelligent.core import TextExtractor

extractor = TextExtractor()

# Analizar el documento
response = client.analyze_document("ruta/al/documento.pdf")
documento = response.get_analyzed_document()

# Guardar todo el texto
extractor.to_text(documento, "salida.txt")

# O guardar cada página por separado
extractor.extract_all_pages(documento, "directorio_de_salida")
```

## Variables de entorno

El SDK puede configurarse utilizando variables de entorno:

```
DOC_INTELLIGENCE_ENDPOINT=https://su-recurso.cognitiveservices.azure.com/
DOC_INTELLIGENCE_API_KEY=su-clave-api
DOC_INTELLIGENCE_API_VERSION=2023-07-31  # Opcional, por defecto a la última versión
```

## Contribución

Las contribuciones son bienvenidas. Por favor, siga estos pasos:

1. Haga un fork del repositorio
2. Cree una rama para su característica (`git checkout -b feature/amazing-feature`)
3. Confirme sus cambios (`git commit -m 'Añadir característica asombrosa'`)
4. Empuje a la rama (`git push origin feature/amazing-feature`)
5. Abra una Pull Request

## Licencia

Distribuido bajo la licencia MIT. Vea `LICENSE` para más información. 