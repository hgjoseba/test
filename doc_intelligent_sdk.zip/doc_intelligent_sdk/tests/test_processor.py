#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for the document processor module.
"""

import os
import pytest
from pathlib import Path
from tempfile import NamedTemporaryFile, TemporaryDirectory

from doc_intelligent.core.processor import DocumentProcessor
from doc_intelligent.utils.errors import DocumentTypeError


class TestDocumentProcessor:
    """Tests for the DocumentProcessor class."""
    
    def test_init(self):
        """Test initialization of DocumentProcessor."""
        processor = DocumentProcessor()
        assert processor is not None
        assert processor.SUPPORTED_EXTENSIONS == [
            ".pdf", ".docx"
        ]
    
    def test_validate_document_valid_file(self):
        """Test validating a document with valid file."""
        processor = DocumentProcessor()
        
        # Create a temporary PDF file
        with NamedTemporaryFile(suffix=".pdf", delete=False) as temp_file:
            temp_file.write(b"test PDF content")
            temp_path = temp_file.name
        
        try:
            # Validate the file
            result = processor.validate_document(temp_path)
            
            # Verify the result
            assert isinstance(result, Path)
            assert result.exists()
            assert result.name == Path(temp_path).name
        finally:
            # Clean up
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def test_validate_document_nonexistent_file(self):
        """Test validating a document with a nonexistent file."""
        processor = DocumentProcessor()
        
        # Use a nonexistent file path
        with pytest.raises(FileNotFoundError):
            processor.validate_document("/path/to/nonexistent/document.pdf")
    
    def test_validate_document_unsupported_extension(self):
        """Test validating a document with an unsupported file extension."""
        processor = DocumentProcessor()
        
        # Create a temporary file with an unsupported extension
        with NamedTemporaryFile(suffix=".txt", delete=False) as temp_file:
            temp_file.write(b"test text content")
            temp_path = temp_file.name
        
        try:
            # Validate the file, should raise DocumentTypeError
            with pytest.raises(DocumentTypeError):
                processor.validate_document(temp_path)
        finally:
            # Clean up
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def test_validate_document_unsupported_image_extension(self):
        """Test validating a document with an image extension (now unsupported)."""
        processor = DocumentProcessor()
        
        # Create a temporary file with an image extension (previously supported)
        with NamedTemporaryFile(suffix=".jpg", delete=False) as temp_file:
            temp_file.write(b"test image content")
            temp_path = temp_file.name
        
        try:
            # Validate the file, should raise DocumentTypeError
            with pytest.raises(DocumentTypeError):
                processor.validate_document(temp_path)
        finally:
            # Clean up
            if os.path.exists(temp_path):
                os.unlink(temp_path)
    
    def test_get_content_type(self):
        """Test getting content type for different file extensions."""
        processor = DocumentProcessor()
        
        # Test all supported extensions
        assert processor.get_content_type(Path("test.pdf")) == "application/pdf"
        assert processor.get_content_type(Path("test.docx")) == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        
        # Test unsupported extension
        assert processor.get_content_type(Path("test.txt")) == "application/octet-stream"
        assert processor.get_content_type(Path("test.jpg")) == "application/octet-stream"
        assert processor.get_content_type(Path("test.png")) == "application/octet-stream"
    
    def test_prepare_document(self):
        """Test preparing a document for analysis."""
        processor = DocumentProcessor()
        
        # Create a temporary PDF file
        with NamedTemporaryFile(suffix=".pdf", delete=False) as temp_file:
            temp_file.write(b"test PDF content")
            temp_path = temp_file.name
        
        try:
            # Prepare the document
            result = processor.prepare_document(temp_path)
            
            # Verify the result
            assert isinstance(result, dict)
            assert result["file_name"] == Path(temp_path).name
            assert result["content_type"] == "application/pdf"
            assert result["content"] == b"test PDF content"
            assert result["size_bytes"] == len(b"test PDF content")
        finally:
            # Clean up
            if os.path.exists(temp_path):
                os.unlink(temp_path) 