"""
Tests for the DocumentAnalysisResponse model.
"""

import unittest
from unittest.mock import MagicMock, patch
from datetime import datetime
import json

from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.models.document import AnalyzedDocument
from doc_intelligent.utils.errors import DocumentIntelligenceError


class TestDocumentAnalysisResponse(unittest.TestCase):
    """Test cases for the DocumentAnalysisResponse class."""

    def test_init(self):
        """Test initialization of DocumentAnalysisResponse."""
        response = DocumentAnalysisResponse(status="succeeded")
        self.assertEqual(response.status, "succeeded")
        self.assertIsInstance(response.created_on, datetime)
        self.assertIsNone(response.last_updated_on)
        self.assertIsNone(response.expires_on)
        self.assertIsNone(response.result)
        self.assertEqual(response.errors, [])

    def test_from_azure_result_success(self):
        """Test from_azure_result method with a successful result."""
        # Create a mock Azure result
        mock_result = MagicMock()
        mock_result.status = "succeeded"
        mock_result.created_date_time = datetime(2023, 1, 1, 12, 0, 0)
        mock_result.last_updated_date_time = datetime(2023, 1, 1, 12, 5, 0)
        mock_result.expires_date_time = datetime(2023, 1, 3, 12, 0, 0)
        mock_result.errors = []
        
        # Convert result to dict via to_dict method
        mock_result.to_dict.return_value = {
            "status": "succeeded",
            "analyzeResult": {
                "apiVersion": "2023-07-31",
                "modelId": "prebuilt-document",
                "content": "Sample document content",
                "pages": []
            }
        }

        # Call the method
        response = DocumentAnalysisResponse.from_azure_result(mock_result)

        # Verify response
        self.assertEqual(response.status, "succeeded")
        self.assertEqual(response.created_on, datetime(2023, 1, 1, 12, 0, 0))
        self.assertEqual(response.last_updated_on, datetime(2023, 1, 1, 12, 5, 0))
        self.assertEqual(response.expires_on, datetime(2023, 1, 3, 12, 0, 0))
        self.assertIsNotNone(response.result)
        self.assertEqual(response.errors, [])

    def test_from_azure_result_with_errors(self):
        """Test from_azure_result method with errors."""
        # Create a mock Azure result with errors
        mock_result = MagicMock()
        mock_result.status = "failed"
        mock_result.created_date_time = datetime(2023, 1, 1, 12, 0, 0)
        
        # Create mock errors
        mock_error = MagicMock()
        mock_error.code = "InvalidRequest"
        mock_error.message = "Invalid request parameters"
        mock_result.errors = [mock_error]
        
        # Call the method
        response = DocumentAnalysisResponse.from_azure_result(mock_result)

        # Verify response
        self.assertEqual(response.status, "failed")
        self.assertEqual(response.created_on, datetime(2023, 1, 1, 12, 0, 0))
        self.assertEqual(len(response.errors), 1)
        self.assertEqual(response.errors[0]["code"], "InvalidRequest")
        self.assertEqual(response.errors[0]["message"], "Invalid request parameters")

    @patch('doc_intelligent.models.response.AnalyzedDocument')
    def test_get_analyzed_document_success(self, mock_analyzed_document_class):
        """Test get_analyzed_document method with a successful result."""
        # Crear mock para AnalyzedDocument
        mock_document = MagicMock(spec=AnalyzedDocument)
        mock_analyzed_document_class.from_azure_result.return_value = mock_document
        
        # Create a response with successful status and mock result
        mock_result = {
            "modelId": "prebuilt-document",
            "content": "Sample document content",
            "pages": [
                {
                    "pageNumber": 1,
                    "width": 8.5,
                    "height": 11.0,
                    "unit": "inch",
                    "lines": [
                        {
                            "content": "Line 1",
                            "span": {"offset": 0, "length": 6}
                        }
                    ]
                }
            ]
        }
        
        response = DocumentAnalysisResponse(
            status="succeeded",
            result=mock_result
        )

        # Call the method
        document = response.get_analyzed_document()

        # Verify document
        self.assertEqual(document, mock_document)
        mock_analyzed_document_class.from_azure_result.assert_called_once_with(mock_result)

    @patch('doc_intelligent.models.response.AnalyzedDocument')
    def test_get_analyzed_document_cached(self, mock_analyzed_document_class):
        """Test get_analyzed_document method caches the document."""
        # Crear mock para AnalyzedDocument y su método from_azure_result
        mock_document = MagicMock(spec=AnalyzedDocument)
        mock_analyzed_document_class.from_azure_result.return_value = mock_document
        
        # Create a response with successful status
        response = DocumentAnalysisResponse(
            status="succeeded",
            result={"modelId": "prebuilt-document", "content": "Sample content"}
        )

        # Call the method twice
        document1 = response.get_analyzed_document()
        document2 = response.get_analyzed_document()

        # Verify both calls return the same document and from_azure_result was called only once
        self.assertEqual(document1, document2)
        mock_analyzed_document_class.from_azure_result.assert_called_once()

    def test_get_analyzed_document_failure(self):
        """Test get_analyzed_document method with a failed status."""
        # Create a response with failed status
        response = DocumentAnalysisResponse(
            status="failed",
            errors=[{"code": "ProcessingError", "message": "Document processing failed"}]
        )

        # Call the method, should raise an error
        with self.assertRaises(DocumentIntelligenceError):
            response.get_analyzed_document()

    @patch('doc_intelligent.models.response.DocumentAnalysisResponse.get_analyzed_document')
    def test_get_text(self, mock_get_analyzed_document):
        """Test get_text method."""
        # Create a mock analyzed document
        mock_document = MagicMock(spec=AnalyzedDocument)
        mock_document.get_text.return_value = "Extracted text content"
        mock_get_analyzed_document.return_value = mock_document
        
        # Create a response
        response = DocumentAnalysisResponse(status="succeeded")

        # Call the method
        text = response.get_text()

        # Verify result
        self.assertEqual(text, "Extracted text content")
        mock_document.get_text.assert_called_once()

    def test_get_text_no_document(self):
        """Test get_text method when document is not available."""
        # Create a response with a failed status
        response = DocumentAnalysisResponse(
            status="failed",
            errors=[{"code": "ProcessingError", "message": "Document processing failed"}]
        )

        # Call the method, should raise an error
        with self.assertRaises(DocumentIntelligenceError):
            response.get_text()

    def test_get_errors(self):
        """Test get_errors method."""
        # Create a response with errors
        response = DocumentAnalysisResponse(
            status="failed",
            errors=[
                {"code": "ProcessingError", "message": "Document processing failed"},
                {"code": "InvalidFormat", "message": "Invalid document format"}
            ]
        )

        # Call the method
        errors = response.get_errors()

        # Verify result
        self.assertEqual(len(errors), 2)
        self.assertEqual(errors[0]["code"], "ProcessingError")
        self.assertEqual(errors[0]["message"], "Document processing failed")
        self.assertEqual(errors[1]["code"], "InvalidFormat")
        self.assertEqual(errors[1]["message"], "Invalid document format")


if __name__ == "__main__":
    unittest.main() 