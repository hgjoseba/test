"""
Tests for the Document models.
"""

import unittest
from unittest.mock import MagicMock, patch
from datetime import datetime

from doc_intelligent.models.document import (
    BoundingBox,
    TextLine,
    TextPage,
    DocumentModel,
    AnalyzedDocument,
    DocumentStatus,
    TextParagraph,
    Table,
    TableCell
)


class TestBoundingBox(unittest.TestCase):
    """Test cases for the BoundingBox class."""

    def test_init(self):
        """Test initialization of BoundingBox."""
        bbox = BoundingBox(left=10, top=20, width=100, height=50)
        self.assertEqual(bbox.left, 10)
        self.assertEqual(bbox.top, 20)
        self.assertEqual(bbox.width, 100)
        self.assertEqual(bbox.height, 50)

    def test_from_azure_polygon_with_dicts(self):
        """Test from_azure_polygon method with a list of dicts."""
        points = [
            {"x": 10, "y": 20},
            {"x": 110, "y": 20},
            {"x": 110, "y": 70},
            {"x": 10, "y": 70}
        ]
        bbox = BoundingBox.from_azure_polygon(points)
        self.assertEqual(bbox.left, 10)
        self.assertEqual(bbox.top, 20)
        self.assertEqual(bbox.width, 100)
        self.assertEqual(bbox.height, 50)

    def test_from_azure_polygon_with_flat_list(self):
        """Test from_azure_polygon method with a flat list of coordinates."""
        points = [10, 20, 110, 20, 110, 70, 10, 70]
        bbox = BoundingBox.from_azure_polygon(points)
        self.assertEqual(bbox.left, 10)
        self.assertEqual(bbox.top, 20)
        self.assertEqual(bbox.width, 100)
        self.assertEqual(bbox.height, 50)

    def test_from_azure_polygon_empty(self):
        """Test from_azure_polygon method with an empty list."""
        bbox = BoundingBox.from_azure_polygon([])
        self.assertEqual(bbox.left, 0)
        self.assertEqual(bbox.top, 0)
        self.assertEqual(bbox.width, 0)
        self.assertEqual(bbox.height, 0)


class TestTextLine(unittest.TestCase):
    """Test cases for the TextLine class."""

    def test_init(self):
        """Test initialization of TextLine."""
        line = TextLine(content="Sample text line")
        self.assertEqual(line.content, "Sample text line")
        self.assertIsNone(line.bounding_box)
        self.assertEqual(line.confidence, 1.0)
        self.assertIsNone(line.span)

    def test_from_azure_line(self):
        """Test from_azure_line method."""
        # Create a mock Azure line
        mock_line = MagicMock()
        mock_line.content = "Sample text line"
        mock_line.confidence = 0.95
        mock_line.polygon = [{"x": 10, "y": 20}, {"x": 110, "y": 20}, {"x": 110, "y": 70}, {"x": 10, "y": 70}]
        mock_line.span.offset = 0
        mock_line.span.length = 16

        # Call the method
        text_line = TextLine.from_azure_line(mock_line)

        # Verify result
        self.assertEqual(text_line.content, "Sample text line")
        self.assertIsNotNone(text_line.bounding_box)
        self.assertEqual(text_line.bounding_box.left, 10)
        self.assertEqual(text_line.bounding_box.top, 20)
        self.assertEqual(text_line.bounding_box.width, 100)
        self.assertEqual(text_line.bounding_box.height, 50)
        self.assertEqual(text_line.confidence, 0.95)
        self.assertEqual(text_line.span, {"offset": 0, "length": 16})


class TestTextPage(unittest.TestCase):
    """Test cases for the TextPage class."""

    def test_init(self):
        """Test initialization of TextPage."""
        page = TextPage(page_number=1)
        self.assertEqual(page.page_number, 1)
        self.assertEqual(page.width, 0.0)
        self.assertEqual(page.height, 0.0)
        self.assertEqual(page.unit, "pixel")
        self.assertEqual(page.lines, [])
        self.assertIsNone(page.language)

    def test_from_azure_page(self):
        """Test from_azure_page method."""
        # Create mock Azure page and lines
        mock_line1 = MagicMock()
        mock_line1.content = "Line 1"
        mock_line1.confidence = 0.9
        mock_line1.polygon = []
        mock_line1.span = MagicMock(offset=0, length=6)

        mock_line2 = MagicMock()
        mock_line2.content = "Line 2"
        mock_line2.confidence = 0.95
        mock_line2.polygon = []
        mock_line2.span = MagicMock(offset=7, length=6)

        mock_page = MagicMock()
        mock_page.page_number = 1
        mock_page.width = 8.5
        mock_page.height = 11.0
        mock_page.unit = "inch"
        mock_page.lines = [mock_line1, mock_line2]
        mock_page.language = "en"

        # Call the method
        text_page = TextPage.from_azure_page(mock_page)

        # Verify result
        self.assertEqual(text_page.page_number, 1)
        self.assertEqual(text_page.width, 8.5)
        self.assertEqual(text_page.height, 11.0)
        self.assertEqual(text_page.unit, "inch")
        self.assertEqual(len(text_page.lines), 2)
        self.assertEqual(text_page.lines[0].content, "Line 1")
        self.assertEqual(text_page.lines[1].content, "Line 2")
        self.assertEqual(text_page.language, "en")

    def test_get_text(self):
        """Test get_text method."""
        # Create page with lines
        page = TextPage(
            page_number=1,
            lines=[
                TextLine(content="Line 1"),
                TextLine(content="Line 2"),
                TextLine(content="Line 3")
            ]
        )

        # Call the method
        text = page.get_text()

        # Verify result
        self.assertEqual(text, "Line 1\nLine 2\nLine 3")

    def test_create_text_page(self):
        """Test creation of a TextPage."""
        page = TextPage(
            page_number=1,
            lines=[],
            width=8.5,
            height=11,
            unit="inch",
            angle=0
        )
        self.assertEqual(page.page_number, 1)
        self.assertEqual(page.lines, [])
        self.assertEqual(page.width, 8.5)
        self.assertEqual(page.height, 11)
        self.assertEqual(page.unit, "inch")
        self.assertEqual(page.angle, 0)


class TestDocumentModel(unittest.TestCase):
    """Test cases for the DocumentModel class."""

    def test_init(self):
        """Test initialization of DocumentModel."""
        model = DocumentModel(model_id="test-model", description="Test model")
        self.assertEqual(model.model_id, "test-model")
        self.assertEqual(model.description, "Test model")
        self.assertIsNone(model.created_on)
        self.assertFalse(model.is_prebuilt)
        self.assertEqual(model.capabilities, [])

    def test_from_azure_model(self):
        """Test from_azure_model method."""
        # Create a mock Azure model
        mock_model = MagicMock()
        mock_model.model_id = "prebuilt-document"
        mock_model.description = "Prebuilt document model"
        mock_model.created_on = datetime(2023, 1, 1)
        mock_model.is_prebuilt = True
        mock_model.capabilities = ["Layout", "Languages"]

        # Call the method
        document_model = DocumentModel.from_azure_model(mock_model)

        # Verify result
        self.assertEqual(document_model.model_id, "prebuilt-document")
        self.assertEqual(document_model.description, "Prebuilt document model")
        self.assertEqual(document_model.created_on, datetime(2023, 1, 1))
        self.assertTrue(document_model.is_prebuilt)
        self.assertEqual(document_model.capabilities, ["Layout", "Languages"])


class TestAnalyzedDocument(unittest.TestCase):
    """Test cases for the AnalyzedDocument class."""

    def test_init(self):
        """Test initialization of AnalyzedDocument."""
        document = AnalyzedDocument(model_id="test-model")
        self.assertIsNone(document.document_id)
        self.assertEqual(document.model_id, "test-model")
        self.assertEqual(document.pages, [])
        self.assertEqual(document.content, "")
        self.assertEqual(document.content_type, "")
        self.assertIsNone(document.file_name)
        self.assertIsNone(document.language)
        self.assertIsNone(document.analysis_timestamp)

    def test_create_analyzed_document(self):
        """Test creation of an AnalyzedDocument."""
        doc = AnalyzedDocument(
            model_id="prebuilt-document",
            content="Sample document content",
            status=DocumentStatus.SUCCEEDED,
            pages=[],
            paragraphs=[],
            tables=[]
        )
        self.assertEqual(doc.model_id, "prebuilt-document")
        self.assertEqual(doc.content, "Sample document content")
        self.assertEqual(doc.status, DocumentStatus.SUCCEEDED)
        self.assertEqual(doc.pages, [])
        self.assertEqual(doc.paragraphs, [])
        self.assertEqual(doc.tables, [])

    def test_from_azure_result_with_analyze_result(self):
        """Test from_azure_result method with analyze_result."""
        # Crear un mock del resultado de Azure
        mock_result = MagicMock()
        mock_result.status = "succeeded"
        
        # Configurar el mock para tener un analyze_result anidado
        mock_analyze_result = MagicMock()
        mock_result.analyze_result = mock_analyze_result
        
        # Configurar las propiedades del analyze_result
        mock_analyze_result.model_id = "prebuilt-document"
        mock_analyze_result.content = "Sample document content"
        mock_analyze_result.api_version = "2023-07-31"
        
        # Configurar las páginas
        page1 = MagicMock()
        page1.page_number = 1
        page1.width = 8.5
        page1.height = 11.0
        page1.unit = "inch"
        page1.angle = 0.0
        # Asegurarse de que las líneas tienen la estructura correcta
        line1 = MagicMock()
        line1.content = "Line 1 content"
        line1.bounding_box = [1.0, 1.0, 5.0, 1.0, 5.0, 2.0, 1.0, 2.0]
        line1.spans = []
        
        page1.lines = [line1]
        mock_analyze_result.pages = [page1]
        
        # Párrafos vacíos y tablas vacías
        mock_analyze_result.paragraphs = []
        mock_analyze_result.tables = []
        
        # Llamar al método estático
        doc = AnalyzedDocument.from_azure_result(mock_result)
        
        # Verificaciones
        self.assertEqual(doc.model_id, "prebuilt-document")
        self.assertEqual(doc.content, "Sample document content")
        self.assertEqual(doc.status, DocumentStatus.SUCCEEDED)
        self.assertEqual(len(doc.pages), 1)
        
        # Verificar que la página se creó correctamente
        page = doc.pages[0]
        self.assertEqual(page.page_number, 1)
        self.assertEqual(len(page.lines), 1)
        
        # Verificar que la línea se creó correctamente
        line = page.lines[0]
        self.assertEqual(line.content, "Line 1 content")

    def test_from_azure_result_without_analyze_result(self):
        """Test from_azure_result method without analyze_result."""
        result = {
            "status": "running",
            "createdDateTime": "2023-01-01T00:00:00Z",
            "lastUpdatedDateTime": "2023-01-01T00:01:00Z"
        }
        doc = AnalyzedDocument.from_azure_result(result)
        self.assertIsNone(doc.model_id)
        self.assertEqual(doc.content, "")
        self.assertEqual(doc.status, DocumentStatus.RUNNING)
        self.assertEqual(doc.pages, [])

    def test_get_text(self):
        """Test get_text method."""
        # Create document with pages
        document = AnalyzedDocument(
            model_id="test-model",
            content="Full document content",
            pages=[
                TextPage(
                    page_number=1,
                    lines=[
                        TextLine(content="Page 1 Line 1"),
                        TextLine(content="Page 1 Line 2")
                    ]
                ),
                TextPage(
                    page_number=2,
                    lines=[
                        TextLine(content="Page 2 Line 1"),
                        TextLine(content="Page 2 Line 2")
                    ]
                )
            ]
        )

        # Call the method
        text = document.get_text()

        # Verify result
        self.assertEqual(text, "Full document content")

    def test_get_page_text(self):
        """Test get_page_text method."""
        # Create document with pages
        document = AnalyzedDocument(
            model_id="test-model",
            pages=[
                TextPage(
                    page_number=1,
                    lines=[
                        TextLine(content="Page 1 Line 1"),
                        TextLine(content="Page 1 Line 2")
                    ]
                ),
                TextPage(
                    page_number=2,
                    lines=[
                        TextLine(content="Page 2 Line 1"),
                        TextLine(content="Page 2 Line 2")
                    ]
                )
            ]
        )

        # Call the method for page 2
        text = document.get_page_text(2)

        # Verify result
        self.assertEqual(text, "Page 2 Line 1\nPage 2 Line 2")

    def test_get_page_text_not_found(self):
        """Test get_page_text method with a non-existent page."""
        # Create document with pages
        document = AnalyzedDocument(
            model_id="test-model",
            pages=[
                TextPage(
                    page_number=1,
                    lines=[
                        TextLine(content="Page 1 Line 1")
                    ]
                )
            ]
        )

        # Call the method for a non-existent page
        text = document.get_page_text(2)

        # Verify result
        self.assertEqual(text, "")


class TestTextParagraph(unittest.TestCase):
    """Test cases for the TextParagraph class."""

    def test_create_text_paragraph(self):
        """Test creation of a TextParagraph."""
        paragraph = TextParagraph(
            content="Sample paragraph content",
            bounding_box=[1, 2, 3, 4, 5, 6, 7, 8]
        )
        self.assertEqual(paragraph.content, "Sample paragraph content")
        self.assertEqual(paragraph.bounding_box, [1, 2, 3, 4, 5, 6, 7, 8])


class TestTable(unittest.TestCase):
    """Test cases for the Table class."""

    def test_create_table(self):
        """Test creation of a Table."""
        table = Table(
            row_count=2,
            column_count=3,
            cells=[]
        )
        self.assertEqual(table.row_count, 2)
        self.assertEqual(table.column_count, 3)
        self.assertEqual(table.cells, [])


class TestTableCell(unittest.TestCase):
    """Test cases for the TableCell class."""

    def test_create_table_cell(self):
        """Test creation of a TableCell."""
        cell = TableCell(
            row_index=1,
            column_index=2,
            row_span=1,
            column_span=1,
            content="Cell content",
            bounding_box=[1, 2, 3, 4, 5, 6, 7, 8]
        )
        self.assertEqual(cell.row_index, 1)
        self.assertEqual(cell.column_index, 2)
        self.assertEqual(cell.row_span, 1)
        self.assertEqual(cell.column_span, 1)
        self.assertEqual(cell.content, "Cell content")
        self.assertEqual(cell.bounding_box, [1, 2, 3, 4, 5, 6, 7, 8])


if __name__ == "__main__":
    unittest.main() 