"""
Pytest configuration for Document Intelligence SDK tests.

This file contains fixtures and configuration for pytest.
"""

import pytest
import os
from pathlib import Path
from unittest.mock import MagicMock


@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Set up the test environment for all tests."""
    # Save original environment variables
    original_env = os.environ.copy()
    
    # Set test environment variables
    os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = "https://test-endpoint.cognitiveservices.azure.com/"
    os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"] = "test-api-key"
    
    # Yield control to the tests
    yield
    
    # Restore original environment variables
    os.environ.clear()
    os.environ.update(original_env)


@pytest.fixture
def mock_azure_response():
    """Create a mock Azure response object for testing."""
    mock_response = MagicMock()
    mock_response.status = "succeeded"
    mock_response.to_dict.return_value = {
        "status": "succeeded",
        "modelId": "prebuilt-document",
        "analyzeResult": {
            "apiVersion": "2023-07-31",
            "modelId": "prebuilt-document",
            "content": "Sample document content",
            "pages": [
                {
                    "pageNumber": 1,
                    "width": 8.5,
                    "height": 11.0,
                    "unit": "inch",
                    "lines": [
                        {
                            "content": "Line 1",
                            "polygon": [{"x": 10, "y": 20}, {"x": 110, "y": 20}, {"x": 110, "y": 70}, {"x": 10, "y": 70}],
                            "span": {"offset": 0, "length": 6}
                        }
                    ]
                }
            ]
        }
    }
    return mock_response


@pytest.fixture
def sample_pdf_path():
    """Create a path to a sample PDF file for testing."""
    # This is a mock path for testing, not a real file
    return Path("tests/resources/sample.pdf")


@pytest.fixture
def sample_base64_pdf():
    """Return a sample base64-encoded PDF for testing."""
    # This is a mock base64 string for testing, not a real PDF
    return "JVBERi0xLjMKJeLjz9MKMSAwIG9iago8PC9UeXBlL1BhZ2UvUGFyZW50IDIgMCBSL0NvbnRlbnRzIDMgMCBSPj4KZW5kb2JqCjMgMCBvYmoKPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMD4+CnN0cmVhbQp4nCvk5QIABLQBuAplYmRpcwplbmRzdHJlYW0KZW5kb2JqCjIgMCBvYmoKPDwvVHlwZS9QYWdlcy9LaWRzWzEgMCBSXS9Db3VudCAxPj4KZW5kb2JqCjQgMCBvYmoKPDwvVHlwZS9DYXRhbG9nL1BhZ2VzIDIgMCBSPj4KZW5kb2JqCjUgMCBvYmoKPDwvUHJvZHVjZXIoVGVzdCBQREYpL0NyZWF0aW9uRGF0ZShEOjIwMjMwMTAxMDAwMDAwKT4+CmVuZG9iagp4cmVmCjAgNgowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAwMTAgMDAwMDAgbiAKMDAwMDAwMDEzNSAwMDAwMCBuIAowMDAwMDAwMDYzIDAwMDAwIG4gCjAwMDAwMDAxODYgMDAwMDAgbiAKMDAwMDAwMDIzMSAwMDAwMCBuIAp0cmFpbGVyCjw8L1Jvb3QgNCAwIFIvSW5mbyA1IDAgUi9TaXplIDY+PgpzdGFydHhyZWYKMzA0CiUlRU9G" 