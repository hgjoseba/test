#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Pytest configuration for Document Intelligence SDK tests.
"""

import os
import sys
from pathlib import Path
import pytest
from unittest.mock import MagicMock

# Add the parent directory to sys.path to make modules importable
ROOT_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT_DIR))

# Define fixtures to be used across all tests

@pytest.fixture
def mock_api_response():
    """Fixture to simulate API responses."""
    class MockResponse:
        def __init__(self, json_data, status_code=200):
            self.json_data = json_data
            self.status_code = status_code
            self.headers = {"Content-Type": "application/json"}
            
        def json(self):
            return self.json_data
            
        @property
        def content(self):
            import json
            return json.dumps(self.json_data).encode("utf-8")
    
    return MockResponse

@pytest.fixture
def mock_document_response():
    """Fixture to create a simulated document analysis response."""
    return {
        "modelId": "prebuilt-document",
        "apiVersion": "2023-07-31",
        "analyzeResult": {
            "version": "2023-07-31",
            "pages": [
                {
                    "pageNumber": 1,
                    "angle": 0,
                    "width": 8.5,
                    "height": 11,
                    "unit": "inch",
                    "words": [
                        {
                            "content": "Example",
                            "boundingBox": [1, 1, 2, 1, 2, 2, 1, 2],
                            "confidence": 0.99
                        }
                    ],
                    "lines": [
                        {
                            "content": "Example text",
                            "boundingBox": [1, 1, 4, 1, 4, 2, 1, 2],
                            "spans": [{"offset": 0, "length": 12}]
                        }
                    ]
                }
            ],
            "keyValuePairs": [
                {
                    "key": {
                        "content": "Customer",
                        "boundingBox": [1, 3, 2, 3, 2, 4, 1, 4],
                        "spans": [{"offset": 16, "length": 8}]
                    },
                    "value": {
                        "content": "ABC Company",
                        "boundingBox": [3, 3, 6, 3, 6, 4, 3, 4],
                        "spans": [{"offset": 24, "length": 11}]
                    }
                }
            ],
            "tables": [
                {
                    "rowCount": 2,
                    "columnCount": 2,
                    "cells": [
                        {
                            "rowIndex": 0,
                            "columnIndex": 0,
                            "content": "Product",
                            "boundingBox": [1, 5, 2, 5, 2, 6, 1, 6],
                            "spans": [{"offset": 36, "length": 7}]
                        },
                        {
                            "rowIndex": 0,
                            "columnIndex": 1,
                            "content": "Price",
                            "boundingBox": [3, 5, 4, 5, 4, 6, 3, 6],
                            "spans": [{"offset": 45, "length": 5}]
                        },
                        {
                            "rowIndex": 1,
                            "columnIndex": 0,
                            "content": "Item 1",
                            "boundingBox": [1, 7, 2, 7, 2, 8, 1, 8],
                            "spans": [{"offset": 52, "length": 6}]
                        },
                        {
                            "rowIndex": 1,
                            "columnIndex": 1,
                            "content": "$100",
                            "boundingBox": [3, 7, 4, 7, 4, 8, 3, 8],
                            "spans": [{"offset": 63, "length": 4}]
                        }
                    ]
                }
            ]
        }
    }

@pytest.fixture
def mock_client():
    """Fixture to create a simulated SDK client."""
    from doc_intelligent.client import DocIntelligenceClient
    
    # Create a client with simulated values
    client = MagicMock(spec=DocIntelligenceClient)
    client.endpoint = "https://example.com/document-intelligence"
    client.api_key = "fake-api-key"
    client.api_version = "2023-07-31"
    
    return client

@pytest.fixture
def sample_pdf_path():
    """Fixture that provides a path to a sample PDF."""
    # In real tests, this could point to an actual test file
    return "tests/data/sample.pdf" 