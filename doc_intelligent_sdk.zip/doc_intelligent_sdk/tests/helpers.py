#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Helper functions and utilities for Document Intelligence SDK tests.

This module provides common utility functions that are useful across
multiple test files, making test code more DRY and maintainable.
"""

import os
import json
import base64
from pathlib import Path
from typing import Dict, Any, Optional, Union

# Helper functions for test data
def get_test_dir() -> Path:
    """Return the path to the tests directory."""
    return Path(os.path.dirname(os.path.abspath(__file__)))

def get_project_root() -> Path:
    """Return the path to the project root directory."""
    return get_test_dir().parent

def get_test_data_dir() -> Path:
    """Return the path to the test data directory."""
    data_dir = get_test_dir() / "data"
    if not data_dir.exists():
        data_dir.mkdir()
    return data_dir

def get_test_file_path(filename: str) -> Path:
    """
    Return the full path to a test file.
    
    Args:
        filename: The name of the test file
        
    Returns:
        Path to the specified test file
    """
    return get_test_data_dir() / filename

def load_json_fixture(fixture_name: str) -> Dict[str, Any]:
    """
    Load a JSON fixture file from the test data directory.
    
    Args:
        fixture_name: Name of the JSON fixture file
        
    Returns:
        Dictionary containing the JSON data
    """
    fixture_path = get_test_data_dir() / fixture_name
    with open(fixture_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def file_to_base64(file_path: Union[str, Path]) -> str:
    """
    Convert a file to base64 string.
    
    Args:
        file_path: Path to the file to convert
        
    Returns:
        Base64-encoded string of the file contents
    """
    file_path = Path(file_path)
    with open(file_path, 'rb') as f:
        content = f.read()
    return base64.b64encode(content).decode('utf-8')

def get_content_type(file_path: Union[str, Path]) -> str:
    """
    Determine the content type based on file extension.
    
    Args:
        file_path: Path to the file
        
    Returns:
        Content type string appropriate for the file
    """
    file_path = Path(file_path)
    extension = file_path.suffix.lower()
    
    content_types = {
        ".pdf": "application/pdf",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".bmp": "image/bmp",
        ".tiff": "image/tiff",
        ".tif": "image/tiff",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }
    
    return content_types.get(extension, "application/octet-stream")

# Test validation helpers
def assert_document_structure(document: Any) -> None:
    """
    Validate that a document has the expected structure.
    
    Args:
        document: The document object to validate
    
    Raises:
        AssertionError: If validation fails
    """
    assert hasattr(document, "model_id"), "Document missing model_id"
    assert hasattr(document, "pages"), "Document missing pages"
    assert hasattr(document, "key_value_pairs"), "Document missing key_value_pairs"
    assert hasattr(document, "tables"), "Document missing tables" 