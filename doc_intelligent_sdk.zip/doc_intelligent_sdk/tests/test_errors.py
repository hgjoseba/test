#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for the error handling components.
"""

import pytest
from unittest.mock import MagicMock

from doc_intelligent.utils.errors import (
    DocumentIntelligenceError,
    ApiError,
    ValidationError,
    AuthenticationError,
    RequestError
)


class TestDocumentIntelligenceError:
    """Tests for the base DocumentIntelligenceError class."""
    
    def test_init(self):
        """Test initialization with a message."""
        error = DocumentIntelligenceError("Test error message")
        
        assert str(error) == "Test error message"
        assert error.message == "Test error message"
        assert error.status_code is None
        assert error.error_code is None
        
    def test_init_with_details(self):
        """Test initialization with additional details."""
        error = DocumentIntelligenceError(
            message="Test error message",
            status_code=400,
            error_code="InvalidRequest"
        )
        
        assert str(error) == "Test error message (400 - InvalidRequest)"
        assert error.message == "Test error message"
        assert error.status_code == 400
        assert error.error_code == "InvalidRequest"


class TestApiError:
    """Tests for the ApiError class."""
    
    def test_init(self):
        """Test initialization with a message."""
        error = ApiError("API error message")
        
        assert str(error) == "API error message"
        assert error.message == "API error message"
        assert error.status_code is None
        assert error.error_code is None
        
    def test_init_with_details(self):
        """Test initialization with additional details."""
        error = ApiError(
            message="API error message",
            status_code=500,
            error_code="ServerError"
        )
        
        assert str(error) == "API error message (500 - ServerError)"
        assert error.message == "API error message"
        assert error.status_code == 500
        assert error.error_code == "ServerError"
        
    def test_from_response(self):
        """Test creation from a response object."""
        # Create a mock response
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.json.return_value = {
            "error": {
                "code": "InvalidRequest",
                "message": "The request is invalid."
            }
        }
        
        # Create error from response
        error = ApiError.from_response(mock_response)
        
        assert str(error) == "The request is invalid. (400 - InvalidRequest)"
        assert error.message == "The request is invalid."
        assert error.status_code == 400
        assert error.error_code == "InvalidRequest"
        
    def test_from_response_with_missing_details(self):
        """Test creation from a response with missing details."""
        # Create a mock response with missing error details
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.return_value = {}
        
        # Create error from response
        error = ApiError.from_response(mock_response)
        
        assert "API call failed with status code 500" in str(error)
        assert error.status_code == 500
        
    def test_from_response_with_json_error(self):
        """Test creation from a response that raises error on json parsing."""
        # Create a mock response that raises on json()
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.side_effect = ValueError("Invalid JSON")
        mock_response.text = "Internal Server Error"
        
        # Create error from response
        error = ApiError.from_response(mock_response)
        
        assert "Internal Server Error" in str(error)
        assert "Status code: 500" in str(error)
        assert error.status_code == 500


class TestValidationError:
    """Tests for the ValidationError class."""
    
    def test_init(self):
        """Test initialization with a message."""
        error = ValidationError("Validation error message")
        
        assert str(error) == "Validation error message"
        assert error.message == "Validation error message"


class TestAuthenticationError:
    """Tests for the AuthenticationError class."""
    
    def test_init(self):
        """Test initialization with a message."""
        error = AuthenticationError("Authentication error message")
        
        assert str(error) == "Authentication error message"
        assert error.message == "Authentication error message"
        
    def test_init_with_details(self):
        """Test initialization with additional details."""
        error = AuthenticationError(
            message="Authentication error message",
            status_code=401,
            error_code="Unauthorized"
        )
        
        assert str(error) == "Authentication error message (401 - Unauthorized)"
        assert error.message == "Authentication error message"
        assert error.status_code == 401
        assert error.error_code == "Unauthorized"


class TestRequestError:
    """Tests for the RequestError class."""
    
    def test_init(self):
        """Test initialization with a message."""
        error = RequestError("Request error message")
        
        assert str(error) == "Request error message"
        assert error.message == "Request error message"
        
    def test_init_with_details(self):
        """Test initialization with additional details."""
        error = RequestError(
            message="Request error message",
            status_code=400,
            error_code="BadRequest"
        )
        
        assert str(error) == "Request error message (400 - BadRequest)"
        assert error.message == "Request error message"
        assert error.status_code == 400
        assert error.error_code == "BadRequest" 