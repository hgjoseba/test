#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Test package for Document Intelligence SDK.

This package contains tests for the Document Intelligence SDK.
It exposes useful classes and fixtures to facilitate their reuse.
"""

import os
import sys
from pathlib import Path

# Ensure the project root directory is in sys.path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Test package version
__version__ = "0.1.0"

# Export fixtures from conftest
from tests.conftest import (
    mock_api_response,
    mock_document_response,
    mock_client,
    sample_pdf_path,
)

# Export helper functions
from tests.helpers import (
    get_test_dir,
    get_project_root,
    get_test_data_dir,
    get_test_file_path,
    load_json_fixture,
    file_to_base64,
    get_content_type,
    assert_document_structure,
)

# Export mock and test classes
from tests.test_models import (
    MockAzureResult,
    TestAnalyzedDocument,
    TestPage,
    TestKeyValuePair,
    TestTable,
    TestCell,
)

from tests.test_azure_provider import TestAzureDocumentProvider
from tests.test_client import TestDocIntelligenceClient
from tests.test_auth import TestAzureCredential
from tests.test_converter import TestDocumentConverter
from tests.test_processor import TestDocumentProcessor
from tests.test_batch import TestBatchProcessor
from tests.test_errors import (
    TestDocumentIntelligenceError,
    TestApiError, 
    TestValidationError,
    TestAuthenticationError,
    TestRequestError,
)
from tests.test_response import TestDocumentAnalysisResponse

# Export SDK classes for convenience
from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.models.document import AnalyzedDocument
from doc_intelligent.auth.azure import AzureCredential 