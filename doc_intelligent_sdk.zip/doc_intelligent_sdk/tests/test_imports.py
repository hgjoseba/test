#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Test script to verify imports from the tests package.
"""

import sys
import os
from pathlib import Path

# Add project root to path if needed
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

def test_imports():
    """Test that imports from the tests package work properly."""
    # Import from the tests package
    from tests import (
        # Version
        __version__,
        
        # Fixtures
        mock_api_response,
        mock_document_response,
        mock_client,
        sample_pdf_path,
        
        # Helper functions
        get_test_dir,
        get_project_root,
        get_test_data_dir,
        get_test_file_path,
        load_json_fixture,
        file_to_base64,
        get_content_type,
        assert_document_structure,
        
        # Mock classes
        MockAzureResult,
        
        # Test classes
        TestAzureDocumentProvider,
        TestDocIntelligenceClient,
        TestAzureCredential,
        TestDocumentConverter,
        TestDocumentProcessor,
        TestBatchProcessor,
        TestDocumentAnalysisResponse,
        
        # SDK classes
        DocIntelligenceClient,
        AnalyzedDocument,
        AzureCredential,
    )
    
    # Print success messages for each imported component
    print("✅ Tests package version:", __version__)
    
    print("\n📋 Successfully imported fixtures:")
    print("  ✓ mock_api_response")
    print("  ✓ mock_document_response")
    print("  ✓ mock_client")
    print("  ✓ sample_pdf_path")
    
    print("\n🔧 Successfully imported helper functions:")
    print("  ✓ get_test_dir")
    print("  ✓ get_project_root")
    print("  ✓ get_test_data_dir")
    print("  ✓ get_test_file_path")
    print("  ✓ load_json_fixture")
    print("  ✓ file_to_base64")
    print("  ✓ get_content_type")
    print("  ✓ assert_document_structure")
    
    print("\n🧪 Successfully imported test classes:")
    print("  ✓ MockAzureResult")
    print("  ✓ TestAzureDocumentProvider")
    print("  ✓ TestDocIntelligenceClient")
    print("  ✓ TestAzureCredential")
    print("  ✓ TestDocumentConverter")
    print("  ✓ TestDocumentProcessor")
    print("  ✓ TestBatchProcessor")
    print("  ✓ TestDocumentAnalysisResponse")
    
    print("\n📦 Successfully imported SDK classes:")
    print("  ✓ DocIntelligenceClient")
    print("  ✓ AnalyzedDocument")
    print("  ✓ AzureCredential")
    
    return True

if __name__ == "__main__":
    test_imports()
    print("\n🎉 All imports successfully verified!") 