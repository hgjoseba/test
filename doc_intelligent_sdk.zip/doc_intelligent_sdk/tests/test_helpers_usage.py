#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Example of using test helpers from the tests package.

This file demonstrates how to use the test helpers and classes
exported by the tests package to create new tests more efficiently.
"""

import pytest
from unittest.mock import MagicMock, patch

# Import helpers and classes from the tests package
from tests import (
    # Fixtures
    mock_api_response,
    mock_document_response,
    
    # Helper functions
    get_test_dir,
    get_project_root,
    get_test_data_dir,
    file_to_base64,
    get_content_type,
    assert_document_structure,
    
    # Mock classes
    MockAzureResult,
    
    # SDK classes for convenience
    DocIntelligenceClient,
    AnalyzedDocument,
    AzureCredential,
)


class TestHelperUsageExample:
    """Example class demonstrating the use of test helpers."""
    
    def test_path_helpers(self):
        """Test the path helpers."""
        # These helper functions make it easy to work with test paths
        test_dir = get_test_dir()
        project_root = get_project_root()
        test_data_dir = get_test_data_dir()
        
        # Verify the paths
        assert test_dir.exists()
        assert project_root.exists()
        assert project_root.name == "doc_intelligent_sdk"
        assert test_data_dir.name == "data"
        
        print(f"Test directory: {test_dir}")
        print(f"Project root: {project_root}")
        print(f"Test data directory: {test_data_dir}")
    
    def test_file_helpers(self):
        """Test the file helpers."""
        # Get content type for different file extensions
        pdf_type = get_content_type("example.pdf")
        docx_type = get_content_type("example.docx")
        
        # Formats que ahora deberían devolver "application/octet-stream"
        jpg_type = get_content_type("example.jpg")
        png_type = get_content_type("example.png")
        
        # Verify the content types - solo PDF y DOCX soportados
        assert pdf_type == "application/pdf"
        assert docx_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        
        # Verificar que los otros formatos ahora devuelven el tipo por defecto
        assert jpg_type == "application/octet-stream"
        assert png_type == "application/octet-stream"
    
    def test_with_mock_document(self, mock_document_response):
        """Test using the mock_document_response fixture."""
        # Create a simulated Azure result
        azure_result = MockAzureResult(mock_document_response)
        
        # Convert to our document model
        document = AnalyzedDocument.from_azure_result(azure_result)
        
        # Validate the document structure
        assert_document_structure(document)
        
        # Use the document
        assert document.model_id == "prebuilt-document"
        assert len(document.pages) == 1
        assert len(document.key_value_pairs) == 1
        assert len(document.tables) == 1
        
        # Get the text from the document
        text = document.get_text()
        assert "Example text" in text
    
    @patch("doc_intelligent.client.DocIntelligenceClient")
    def test_with_client(self, mock_analysis_client):
        """Test creating and using a client."""
        # Set up a mock client
        client = DocIntelligenceClient(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        
        # Use the client in your test
        assert client.endpoint == "https://example.com/document-intelligence"
        assert client.api_key == "fake-api-key"
    
    def test_with_credential(self):
        """Test creating and using a credential."""
        # Create a credential
        credential = AzureCredential(api_key="fake-api-key")
        
        # Use the credential in your test
        assert credential.api_key == "fake-api-key"
        assert credential.get_token() == "fake-api-key"


if __name__ == "__main__":
    # You can run this file directly to test the helper functions
    pytest.main(["-v", __file__]) 