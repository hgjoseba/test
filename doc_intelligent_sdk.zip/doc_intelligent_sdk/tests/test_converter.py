#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for the DocumentConverter utility class.
"""

import pytest
import json
import csv
import os
from unittest.mock import patch, mock_open, MagicMock
from pathlib import Path

from doc_intelligent.core.converter import DocumentConverter
from doc_intelligent.models.document import AnalyzedDocument


class TestDocumentConverter:
    """Tests for the DocumentConverter class."""

    @pytest.fixture
    def sample_document(self, mock_document_response):
        """Fixture to create a sample document for testing."""
        return AnalyzedDocument.from_azure_result(mock_document_response)

    def test_init(self):
        """Test initialization of DocumentConverter."""
        converter = DocumentConverter()
        assert converter is not None

    @patch("builtins.open", new_callable=mock_open)
    def test_to_json(self, mock_file, sample_document):
        """Test converting a document to JSON."""
        converter = DocumentConverter()
        
        # Test with Path object
        output_path = MagicMock(spec=Path)
        converter.to_json(sample_document, output_path)
        
        # Check that the file was opened for writing - but let's be flexible about string vs Path
        assert mock_file.call_count == 1
        args, kwargs = mock_file.call_args
        assert args[1] == 'w'  # Second arg should be mode
        assert kwargs.get('encoding') == 'utf-8'
        
        # Check that json.dump was called with the document data
        file_handle = mock_file()
        dumped_data = file_handle.write.call_args[0][0]
        
        # Convert the dumped string back to a dictionary
        loaded_data = json.loads(dumped_data)
        
        # Verify the contents - use the actual field names from the class
        assert loaded_data["model_id"] == "prebuilt-document"
        assert "pages" in loaded_data
        assert "key_value_pairs" in loaded_data
        assert "tables" in loaded_data

    @patch("builtins.open", new_callable=mock_open)
    def test_to_text(self, mock_file, sample_document):
        """Test converting a document to plain text."""
        converter = DocumentConverter()
        
        # Test with string path
        converter.to_text(sample_document, "output.txt")
        
        # Check that the file was opened for writing - but let's be flexible about string vs Path
        assert mock_file.call_count == 1
        args, kwargs = mock_file.call_args
        assert 'output.txt' in str(args[0])  # First arg should be path containing output.txt
        assert args[1] == 'w'  # Second arg should be mode
        assert kwargs.get('encoding') == 'utf-8'
        
        # Check that the text content was written
        file_handle = mock_file()
        written_text = file_handle.write.call_args[0][0]
        
        # Verify the contents
        assert "Example text" in written_text
        
    @patch("builtins.open", new_callable=mock_open)
    @patch("csv.writer")
    def test_to_csv_single_table(self, mock_csv_writer, mock_file, sample_document):
        """Test converting a document with a single table to CSV."""
        mock_writer = MagicMock()
        mock_csv_writer.return_value = mock_writer
        
        converter = DocumentConverter()
        output_path = "output.csv"
        
        result = converter.to_csv(sample_document, output_path)
        
        # Check that the result is a string path
        assert result == output_path or result == str(Path(output_path))
        
        # Check that the file was opened for writing - but let's be flexible about string vs Path
        assert mock_file.call_count == 1
        args, kwargs = mock_file.call_args
        assert 'output.csv' in str(args[0])  # First arg should be path containing output.csv
        assert args[1] == 'w'  # Second arg should be mode
        assert kwargs.get('encoding') == 'utf-8'
        assert kwargs.get('newline') == ''
        
        # Check that the CSV writer was created
        mock_csv_writer.assert_called_once()
        
        # Check that writerow was called for headers and data
        assert mock_writer.writerows.call_count >= 1  # Should call writerows at least once
        
    @patch("os.path.exists")
    @patch("os.makedirs")
    @patch("builtins.open", new_callable=mock_open)
    @patch("csv.writer")
    def test_to_csv_multiple_tables(self, mock_csv_writer, mock_file, mock_makedirs, mock_exists, sample_document):
        """Test converting a document with multiple tables to CSV."""
        # Mock a document with multiple tables
        sample_document.tables.append(sample_document.tables[0])  # Add duplicate table for testing
        
        mock_writer = MagicMock()
        mock_csv_writer.return_value = mock_writer
        mock_exists.return_value = False
        
        converter = DocumentConverter()
        output_path = Path("output.csv")  # Use Path instead of string
        
        result = converter.to_csv(sample_document, output_path)
        
        # Check that the result is a list of file paths
        assert isinstance(result, list)
        assert len(result) == 2  # Two tables
        
        # El código de DocumentConverter usa Path.mkdir() y no os.path.exists o os.makedirs directamente
        # por lo que no se espera que estos mocks sean llamados
        
        # Check that the files were opened for writing
        assert mock_file.call_count == 2
        
        # Check that CSV writers were created
        assert mock_csv_writer.call_count == 2
        
        # Check that writerow was called for each table
        assert mock_writer.writerows.call_count >= 2  # At least call per table
        
    def test_get_table_data(self, sample_document):
        """Test accessing table data from the document."""
        converter = DocumentConverter()
        
        # Verify that our sample document has table data
        assert len(sample_document.tables) > 0
        
        # Check the first table
        table = sample_document.tables[0]
        assert table.row_count == 2
        assert table.column_count == 2
        
        # Verify cell data
        cells = table.cells
        assert len(cells) == 4  # 2x2 table should have 4 cells
        
        # Verify cell content
        header_cells = [cell for cell in cells if cell.row_index == 0]
        assert len(header_cells) == 2
        assert any(cell.text == "Product" for cell in header_cells)
        assert any(cell.text == "Price" for cell in header_cells)
        
        data_cells = [cell for cell in cells if cell.row_index == 1]
        assert len(data_cells) == 2
        assert any(cell.text == "Item 1" for cell in data_cells)
        assert any(cell.text == "$100" for cell in data_cells) 