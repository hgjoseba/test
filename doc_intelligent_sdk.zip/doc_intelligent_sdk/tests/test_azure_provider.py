#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for the Azure Document Intelligence provider.
"""

import os
import pytest
from unittest.mock import patch, MagicMock, mock_open
from pathlib import Path
import base64

from doc_intelligent.providers.azure import AzureDocumentProvider
from doc_intelligent.auth.azure import AzureCredential
from doc_intelligent.models.document import DocumentModel
from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.utils.errors import ModelNotFoundError, ServiceError, DocumentIntelligenceError


class TestAzureDocumentProvider:
    """Tests for the AzureDocumentProvider class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        # Mock environment variables for tests
        self.original_environ = os.environ.copy()
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = "https://example.com/document-intelligence"
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"] = "fake-api-key"
    
    def teardown_method(self):
        """Tear down test fixtures."""
        # Restore original environment
        os.environ.clear()
        os.environ.update(self.original_environ)
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_init_with_api_key(self, mock_admin_client, mock_analysis_client):
        """Test initialization with API key."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Create provider
        provider = AzureDocumentProvider(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        
        # Verify the provider was initialized correctly
        assert provider.endpoint == "https://example.com/document-intelligence"
        assert provider.api_key == "fake-api-key"
        assert provider.api_version == "2023-07-31"
        assert provider._analysis_client is not None
        assert provider._admin_client is not None
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_init_with_credential(self, mock_admin_client, mock_analysis_client):
        """Test initialization with AzureCredential."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Create credential
        credential = AzureCredential(api_key="fake-api-key")
        
        # Create provider with credential but without api_key
        provider = AzureDocumentProvider(
            endpoint="https://example.com/document-intelligence",
            credential=credential,
            api_key=None  # Explícitamente null para evitar que use el api_key de credential
        )
        
        # Verify the provider was initialized correctly
        assert provider.endpoint == "https://example.com/document-intelligence"
        assert provider.credential == credential
        assert provider._analysis_client is not None
        assert provider._admin_client is not None
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_init_from_environment(self, mock_admin_client, mock_analysis_client):
        """Test initialization using environment variables."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Create provider without explicit endpoint/key (should use environment)
        provider = AzureDocumentProvider()
        
        # Verify the provider was initialized correctly
        assert provider.endpoint == "https://example.com/document-intelligence"
        assert provider.api_key == "fake-api-key"
        assert provider._analysis_client is not None
        assert provider._admin_client is not None
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_init_without_auth(self, mock_admin_client, mock_analysis_client):
        """Test initialization without authentication."""
        # Clear environment variables
        os.environ.pop("AZURE_DOCUMENT_INTELLIGENCE_KEY", None)
        
        # Create provider without api_key or credential (should raise error)
        with pytest.raises(ValueError, match="Either API key or credential must be provided"):
            AzureDocumentProvider(endpoint="https://example.com/document-intelligence")
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_init_without_endpoint(self, mock_admin_client, mock_analysis_client):
        """Test initialization without endpoint."""
        # Clear environment variables
        os.environ.pop("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", None)
        
        # Create provider without endpoint (should raise error)
        with pytest.raises(ValueError, match="Endpoint must be provided"):
            AzureDocumentProvider(api_key="fake-api-key")
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_analyze_document(self, mock_admin_client, mock_analysis_client):
        """Test analyze_document method."""
        # Set up mock instances and response
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Mock the begin_analyze_document method and poller
        mock_poller = MagicMock()
        mock_result = MagicMock()
        mock_result.model_id = "prebuilt-document"
        mock_poller.result.return_value = mock_result
        mock_analysis_instance.begin_analyze_document.return_value = mock_poller
        
        # Mock DocumentAnalysisResponse.from_azure_result
        mock_response = MagicMock()
        with patch("doc_intelligent.providers.azure.DocumentAnalysisResponse.from_azure_result", return_value=mock_response):
            # Create provider
            provider = AzureDocumentProvider()
            
            # Create a temporary file path for mocking
            file_path = Path("/tmp/test_document.pdf")
            
            # Mock the file existence check
            with patch("pathlib.Path.exists", return_value=True):
                # Mock the open function
                with patch("builtins.open", mock_open(read_data=b"test document content")):
                    # Call the method
                    result = provider.analyze_document(
                        file_path=file_path,
                        model_id="prebuilt-document",
                        locale="en"
                    )
            
            # Verify the result and method calls
            assert result == mock_response
            mock_analysis_instance.begin_analyze_document.assert_called_once()
            mock_poller.result.assert_called_once()
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_analyze_document_file_not_found(self, mock_admin_client, mock_analysis_client):
        """Test analyze_document with a nonexistent file."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Create a temporary file path for mocking
        file_path = Path("/tmp/nonexistent_document.pdf")
        
        # Mock the file existence check
        with patch("pathlib.Path.exists", return_value=False):
            # Call the method, should raise FileNotFoundError
            with pytest.raises(FileNotFoundError):
                provider.analyze_document(
                    file_path=file_path,
                    model_id="prebuilt-document"
                )
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    @patch("doc_intelligent.providers.azure.HttpResponseError")
    def test_analyze_document_model_not_found(self, mock_http_error, mock_admin_client, mock_analysis_client):
        """Test analyze_document with a nonexistent model."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Mock HttpResponseError with 404 status
        error_instance = MagicMock()
        error_instance.status_code = 404
        mock_http_error.side_effect = [error_instance]
        
        # Mock the begin_analyze_document method to raise HttpResponseError
        mock_analysis_instance.begin_analyze_document.side_effect = error_instance
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Create a temporary file path for mocking
        file_path = Path("/tmp/test_document.pdf")
        
        # Mock the file existence check
        with patch("pathlib.Path.exists", return_value=True):
            # Mock the open function
            with patch("builtins.open", mock_open(read_data=b"test document content")):
                # Call the method, should raise ModelNotFoundError
                with pytest.raises(ModelNotFoundError):
                    provider.analyze_document(
                        file_path=file_path,
                        model_id="nonexistent-model"
                    )
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_analyze_document_from_base64(self, mock_admin_client, mock_analysis_client):
        """Test analyze_document_from_base64 method."""
        # Set up mock instances and response
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Mock the begin_analyze_document method and poller
        mock_poller = MagicMock()
        mock_result = MagicMock()
        mock_result.model_id = "prebuilt-document"
        mock_poller.result.return_value = mock_result
        mock_analysis_instance.begin_analyze_document.return_value = mock_poller
        
        # Mock DocumentAnalysisResponse.from_azure_result
        mock_response = MagicMock()
        with patch("doc_intelligent.providers.azure.DocumentAnalysisResponse.from_azure_result", return_value=mock_response):
            # Create provider
            provider = AzureDocumentProvider()
            
            # Create base64 encoded data
            test_data = b"test document content"
            base64_data = base64.b64encode(test_data).decode("utf-8")
            
            # Call the method
            result = provider.analyze_document_from_base64(
                base64_string=base64_data,
                content_type="application/pdf",
                model_id="prebuilt-document",
                locale="en"
            )
            
            # Verify the result and method calls
            assert result == mock_response
            mock_analysis_instance.begin_analyze_document.assert_called_once()
            mock_poller.result.assert_called_once()
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_list_models(self, mock_admin_client, mock_analysis_client):
        """Test list_models method."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Mock get_models method and model objects
        model1 = MagicMock()
        model1.model_id = "prebuilt-document"
        model1.description = "Document model"
        model1.created_on = None
        model1.model_type = "prebuilt"
        
        model2 = MagicMock()
        model2.model_id = "prebuilt-layout"
        model2.description = "Layout model"
        model2.created_on = None
        model2.model_type = "prebuilt"
        
        mock_admin_instance.list_models.return_value = [model1, model2]
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Call the method
        result = provider.list_models()
        
        # Verify the result
        assert len(result) == 2
        assert result[0].id == "prebuilt-document"
        assert result[1].id == "prebuilt-layout"
        
        # Verify the method calls
        mock_admin_instance.list_models.assert_called_once()
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_get_document_analysis_client(self, mock_admin_client, mock_analysis_client):
        """Test get_document_analysis_client method."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Call the method
        result = provider.get_document_analysis_client()
        
        # Verify the result
        assert result == mock_analysis_instance
    
    @patch("doc_intelligent.providers.azure.DocumentAnalysisClient")
    @patch("doc_intelligent.providers.azure.DocumentModelAdministrationClient")
    def test_get_model_admin_client(self, mock_admin_client, mock_analysis_client):
        """Test get_model_admin_client method."""
        # Set up mock instances
        mock_analysis_instance = MagicMock()
        mock_admin_instance = MagicMock()
        mock_analysis_client.return_value = mock_analysis_instance
        mock_admin_client.return_value = mock_admin_instance
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Call the method
        result = provider.get_model_admin_client()
        
        # Verify the result
        assert result == mock_admin_instance 