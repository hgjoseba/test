#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for the Azure Document Intelligence provider.
"""

import os
import pytest
from unittest.mock import patch, MagicMock, mock_open, call
from pathlib import Path
import base64
import json

from doc_intelligent.providers.azure import AzureDocumentProvider
from doc_intelligent.auth.azure import AzureCredential
from doc_intelligent.models.document import DocumentModel
from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.utils.errors import ModelNotFoundError, ServiceError, DocumentIntelligenceError


class TestAzureDocumentProvider:
    """Tests for the AzureDocumentProvider class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        # Mock environment variables for tests
        self.original_environ = os.environ.copy()
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = "https://example.com/document-intelligence"
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"] = "fake-api-key"
    
    def teardown_method(self):
        """Tear down test fixtures."""
        # Restore original environment
        os.environ.clear()
        os.environ.update(self.original_environ)
    
    def test_init_with_api_key(self):
        """Test initialization with API key."""
        # Create provider
        provider = AzureDocumentProvider(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        
        # Verify the provider was initialized correctly
        assert provider.endpoint == "https://example.com/document-intelligence"
        assert provider.api_key == "fake-api-key"
        assert provider.api_version == "2023-07-31"
    
    def test_init_with_credential(self):
        """Test initialization with AzureCredential."""
        # Create credential
        credential = AzureCredential(api_key="fake-api-key")
        
        # Create provider with credential but without api_key
        provider = AzureDocumentProvider(
            endpoint="https://example.com/document-intelligence",
            credential=credential,
            api_key=None  # Explícitamente null para evitar que use el api_key de credential
        )
        
        # Verify the provider was initialized correctly
        assert provider.endpoint == "https://example.com/document-intelligence"
        assert provider.credential == credential
    
    def test_init_from_environment(self):
        """Test initialization using environment variables."""        
        # Create provider without explicit endpoint/key (should use environment)
        provider = AzureDocumentProvider()
        
        # Verify the provider was initialized correctly
        assert provider.endpoint == "https://example.com/document-intelligence"
        assert provider.api_key == "fake-api-key"
    
    def test_init_without_auth(self):
        """Test initialization without authentication."""
        # Clear environment variables
        os.environ.pop("AZURE_DOCUMENT_INTELLIGENCE_KEY", None)
        
        # Create provider without api_key or credential (should raise error)
        with pytest.raises(ValueError, match="Debe proporcionarse una clave API o credenciales para la autenticación"):
            AzureDocumentProvider(endpoint="https://example.com/document-intelligence")
    
    def test_init_without_endpoint(self):
        """Test initialization without endpoint."""
        # Clear environment variables
        os.environ.pop("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", None)
        
        # Create provider without endpoint (should raise error)
        with pytest.raises(ValueError, match="El endpoint debe proporcionarse directamente o a través de una variable de entorno"):
            AzureDocumentProvider(api_key="fake-api-key")
    
    def test_get_headers_with_api_key(self):
        """Test _get_headers method with API key."""
        # Create provider
        provider = AzureDocumentProvider(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        
        # Get headers
        headers = provider._get_headers()
        
        # Verify headers
        assert headers == {"Ocp-Apim-Subscription-Key": "fake-api-key"}
    
    def test_get_headers_with_credential(self):
        """Test _get_headers method with credential."""
        # Create credential
        credential = MagicMock()
        credential.get_token.return_value = "fake-token"
        
        # Create provider
        provider = AzureDocumentProvider(
            endpoint="https://example.com/document-intelligence",
            credential=credential,
            api_key=None
        )
        
        # Get headers
        headers = provider._get_headers()
        
        # Verify headers
        assert headers == {"Authorization": "Bearer fake-token"}
        credential.get_token.assert_called_once()
    
    @patch("doc_intelligent.providers.azure.requests.post")
    def test_analyze_document(self, mock_post):
        """Test analyze_document method."""
        # Mock the response for post request
        mock_response = MagicMock()
        mock_response.status_code = 202
        mock_response.headers = {"Operation-Location": "https://example.com/operations/123"}
        mock_post.return_value = mock_response
        
        # Mock the response for polling
        mock_poll_response = MagicMock()
        mock_poll_response.status_code = 200
        mock_poll_response.json.return_value = {
            "status": "succeeded",
            "createdDateTime": "2023-01-01T00:00:00Z",
            "lastUpdatedDateTime": "2023-01-01T00:01:00Z",
            "analyzeResult": {
                "content": "Sample content",
                "pages": [{"pageNumber": 1}],
                "tables": [],
                "keyValuePairs": []
            }
        }
        
        # Configure the requests.get mock for polling
        with patch("doc_intelligent.providers.azure.requests.get", return_value=mock_poll_response):
            # Create provider
            provider = AzureDocumentProvider()
            
            # Create a temporary file path for mocking
            file_path = Path("/tmp/test_document.pdf")
            
            # Mock the file existence check
            with patch("pathlib.Path.exists", return_value=True):
                # Mock the open function
                with patch("builtins.open", mock_open(read_data=b"test document content")):
                    # Call the method
                    result = provider.analyze_document(
                        file_path=file_path,
                        model_id="prebuilt-document",
                        locale="en"
                    )
            
            # Verify the result
            assert result is not None
            assert result.status == "succeeded"
            assert result.content == "Sample content"
            
            # Verify method calls
            mock_post.assert_called_once()
            args, kwargs = mock_post.call_args
            assert args[0] == "https://example.com/document-intelligence/documentModels/prebuilt-document:analyze?api-version=2023-07-31"
            assert "headers" in kwargs
            assert "files" in kwargs
            assert "data" in kwargs
            assert kwargs["data"].get("locale") == "en"
    
    @patch("doc_intelligent.providers.azure.requests.post")
    def test_analyze_document_file_not_found(self, mock_post):
        """Test analyze_document with a nonexistent file."""
        # Create provider
        provider = AzureDocumentProvider()
        
        # Create a temporary file path for mocking
        file_path = Path("/tmp/nonexistent_document.pdf")
        
        # Mock the file existence check
        with patch("pathlib.Path.exists", return_value=False):
            # Call the method, should raise FileNotFoundError
            with pytest.raises(FileNotFoundError):
                provider.analyze_document(
                    file_path=file_path,
                    model_id="prebuilt-document"
                )
        
        # Verify post was not called
        mock_post.assert_not_called()
    
    @patch("doc_intelligent.providers.azure.requests.post")
    def test_analyze_document_model_not_found(self, mock_post):
        """Test analyze_document with a nonexistent model."""
        # Mock the response for post request with 404 status
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.text = "Model not found"
        mock_post.return_value = mock_response
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Create a temporary file path for mocking
        file_path = Path("/tmp/test_document.pdf")
        
        # Mock the file existence check
        with patch("pathlib.Path.exists", return_value=True):
            # Mock the open function
            with patch("builtins.open", mock_open(read_data=b"test document content")):
                # Call the method, should raise ModelNotFoundError
                with pytest.raises(ModelNotFoundError):
                    provider.analyze_document(
                        file_path=file_path,
                        model_id="nonexistent-model"
                    )
        
        # Verify post was called
        mock_post.assert_called_once()
    
    @patch("doc_intelligent.providers.azure.requests.post")
    def test_analyze_document_from_base64(self, mock_post):
        """Test analyze_document_from_base64 method."""
        # Mock the response for post request
        mock_response = MagicMock()
        mock_response.status_code = 202
        mock_response.headers = {"Operation-Location": "https://example.com/operations/123"}
        mock_post.return_value = mock_response
        
        # Mock the response for polling
        mock_poll_response = MagicMock()
        mock_poll_response.status_code = 200
        mock_poll_response.json.return_value = {
            "status": "succeeded",
            "createdDateTime": "2023-01-01T00:00:00Z",
            "lastUpdatedDateTime": "2023-01-01T00:01:00Z",
            "analyzeResult": {
                "content": "Sample content from base64",
                "pages": [{"pageNumber": 1}],
                "tables": [],
                "keyValuePairs": []
            }
        }
        
        # Configure the requests.get mock for polling
        with patch("doc_intelligent.providers.azure.requests.get", return_value=mock_poll_response):
            # Create provider
            provider = AzureDocumentProvider()
            
            # Create base64 string
            base64_string = base64.b64encode(b"test document content").decode("utf-8")
            
            # Call the method
            result = provider.analyze_document_from_base64(
                base64_string=base64_string,
                content_type="application/pdf",
                model_id="prebuilt-document",
                locale="en"
            )
            
            # Verify the result
            assert result is not None
            assert result.status == "succeeded"
            assert result.content == "Sample content from base64"
            
            # Verify method calls
            mock_post.assert_called_once()
            args, kwargs = mock_post.call_args
            assert args[0] == "https://example.com/document-intelligence/documentModels/prebuilt-document:analyze?api-version=2023-07-31"
            assert "headers" in kwargs
            assert "json" in kwargs
            assert kwargs["json"].get("base64Source") == base64_string
            assert kwargs["json"].get("locale") == "en"
    
    @patch("doc_intelligent.providers.azure.requests.get")
    def test_list_models(self, mock_get):
        """Test list_models method."""
        # Mock the response for get request
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "value": [
                {
                    "modelId": "prebuilt-document",
                    "description": "General document model",
                    "createdDateTime": "2023-01-01T00:00:00Z",
                    "expirationDateTime": None
                },
                {
                    "modelId": "prebuilt-layout",
                    "description": "Layout model",
                    "createdDateTime": "2023-01-01T00:00:00Z",
                    "expirationDateTime": None
                }
            ]
        }
        mock_get.return_value = mock_response
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Call the method
        models = provider.list_models()
        
        # Verify the result
        assert len(models) == 2
        assert models[0].model_id == "prebuilt-document"
        assert models[1].model_id == "prebuilt-layout"
        
        # Verify method calls
        mock_get.assert_called_once()
        args, kwargs = mock_get.call_args
        assert args[0] == "https://example.com/document-intelligence/models?api-version=2023-07-31"
        assert "headers" in kwargs
    
    @patch("doc_intelligent.providers.azure.AzureDocumentProvider.analyze_document")
    def test_analyze_documents_batch(self, mock_analyze):
        """Test batch document analysis."""
        # Create mock documents
        mock_response1 = MagicMock(spec=DocumentAnalysisResponse)
        mock_response1.status = "succeeded"
        mock_response1.content = "Sample content 1"
        
        mock_response2 = MagicMock(spec=DocumentAnalysisResponse)
        mock_response2.status = "succeeded"
        mock_response2.content = "Sample content 2"
        
        # Configure the mock to return different values for different calls
        mock_analyze.side_effect = [mock_response1, mock_response2]
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Create test file paths - we'll patch Path.exists to always return True
        file_paths = [Path("/tmp/test1.pdf"), Path("/tmp/test2.pdf")]
        
        # Test the batch method
        with patch("pathlib.Path.exists", return_value=True):
            results = provider.analyze_documents_batch(
                file_paths=file_paths,
                model_id="prebuilt-document",
                max_concurrent_requests=2
            )
        
        # Verify results
        assert len(results) == 2
        assert str(file_paths[0]) in results
        assert str(file_paths[1]) in results
        assert results[str(file_paths[0])] == mock_response1
        assert results[str(file_paths[1])] == mock_response2
        
        # Verify analyze_document was called correctly for each file
        assert mock_analyze.call_count == 2
        calls = [
            call(file_path=file_paths[0], model_id="prebuilt-document", locale="en", pages=None, poll_interval=5, timeout=300),
            call(file_path=file_paths[1], model_id="prebuilt-document", locale="en", pages=None, poll_interval=5, timeout=300)
        ]
        mock_analyze.assert_has_calls(calls, any_order=True)
    
    @patch("doc_intelligent.providers.azure.AzureDocumentProvider.analyze_document_from_base64")
    def test_analyze_documents_batch_from_base64(self, mock_analyze_base64):
        """Test batch document analysis from base64 data."""
        # Create mock documents
        mock_response1 = MagicMock(spec=DocumentAnalysisResponse)
        mock_response1.status = "succeeded"
        mock_response1.content = "Sample content 1 from base64"
        
        mock_response2 = MagicMock(spec=DocumentAnalysisResponse)
        mock_response2.status = "succeeded"
        mock_response2.content = "Sample content 2 from base64"
        
        # Configure the mock to return different values for different calls
        mock_analyze_base64.side_effect = [mock_response1, mock_response2]
        
        # Create provider
        provider = AzureDocumentProvider()
        
        # Create test document data
        documents = [
            {
                'id': 'doc1',
                'base64_string': 'base64_data_1',
                'content_type': 'application/pdf'
            },
            {
                'id': 'doc2',
                'base64_string': 'base64_data_2',
                'content_type': 'image/jpeg'
            }
        ]
        
        # Test the batch method
        results = provider.analyze_documents_batch_from_base64(
            documents=documents,
            model_id="prebuilt-document",
            max_concurrent_requests=2
        )
        
        # Verify results
        assert len(results) == 2
        assert 'doc1' in results
        assert 'doc2' in results
        assert results['doc1'] == mock_response1
        assert results['doc2'] == mock_response2
        
        # Verify analyze_document_from_base64 was called correctly for each document
        assert mock_analyze_base64.call_count == 2
        calls = [
            call(
                base64_string='base64_data_1',
                content_type='application/pdf',
                model_id="prebuilt-document",
                locale="en",
                pages=None,
                poll_interval=5,
                timeout=300
            ),
            call(
                base64_string='base64_data_2',
                content_type='image/jpeg',
                model_id="prebuilt-document",
                locale="en",
                pages=None,
                poll_interval=5,
                timeout=300
            )
        ]
        mock_analyze_base64.assert_has_calls(calls, any_order=True)
