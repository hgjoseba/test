"""
Tests for the DocIntelligenceClient class.
"""

import unittest
from unittest.mock import patch, MagicMock
import os
from pathlib import Path

from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.utils.errors import DocumentIntelligenceError


class TestDocIntelligenceClient(unittest.TestCase):
    """Test cases for the DocIntelligenceClient class."""

    @patch('doc_intelligent.client.AzureDocumentProvider', autospec=True)
    def setUp(self, mock_provider_class):
        """Set up test environment before each test."""
        # Configurar el mock para que sea devuelto cuando se instancia AzureDocumentProvider
        self.mock_provider = MagicMock()
        mock_provider_class.return_value = self.mock_provider
        
        self.endpoint = "https://test-endpoint.cognitiveservices.azure.com/"
        self.api_key = "test-api-key"
        self.api_version = "2023-07-31"
        self.client = DocIntelligenceClient(
            endpoint=self.endpoint,
            api_key=self.api_key,
            api_version=self.api_version
        )

    @patch('doc_intelligent.client.AzureDocumentProvider', autospec=True)
    def test_init_with_default_provider(self, mock_provider_class):
        """Test initialization with default provider."""
        # Configurar el mock
        mock_provider = MagicMock()
        mock_provider_class.return_value = mock_provider
        
        client = DocIntelligenceClient(
            endpoint=self.endpoint,
            api_key=self.api_key
        )
        self.assertEqual(client.provider_name, "azure")
        self.assertEqual(client.endpoint, self.endpoint)
        self.assertEqual(client.api_key, self.api_key)
        self.assertEqual(client.api_version, "2023-07-31")  # default value
        # Verificar que se llamó correctamente al constructor del proveedor
        mock_provider_class.assert_called_once_with(
            endpoint=self.endpoint,
            api_key=self.api_key,
            api_version="2023-07-31",
            credential=None,
            connection_verify=True
        )

    @patch('doc_intelligent.client.AzureDocumentProvider', autospec=True)
    def test_init_with_unsupported_provider(self, mock_provider_class):
        """Test initialization with unsupported provider."""
        with self.assertRaises(ValueError):
            DocIntelligenceClient(
                endpoint=self.endpoint,
                api_key=self.api_key,
                provider="unsupported"
            )
        # No debería llamarse al constructor del proveedor
        mock_provider_class.assert_not_called()

    def test_analyze_document(self):
        """Test analyze_document method."""
        # Mock the provider response
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        self.mock_provider.analyze_document.return_value = mock_response

        # Call the method
        file_path = "test_document.pdf"
        response = self.client.analyze_document(
            file_path=file_path,
            model_id="prebuilt-document",
            locale="en"
        )

        # Assert the provider method was called with correct parameters
        self.mock_provider.analyze_document.assert_called_once_with(
            file_path=file_path,
            model_id="prebuilt-document",
            locale="en",
            pages=None
        )
        self.assertEqual(response, mock_response)

    def test_analyze_document_from_base64(self):
        """Test analyze_document_from_base64 method."""
        # Mock the provider response
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        self.mock_provider.analyze_document_from_base64.return_value = mock_response

        # Call the method
        base64_string = "base64_encoded_data"
        content_type = "application/pdf"
        response = self.client.analyze_document_from_base64(
            base64_string=base64_string,
            content_type=content_type,
            model_id="prebuilt-document",
            locale="es"
        )

        # Assert the provider method was called with correct parameters
        self.mock_provider.analyze_document_from_base64.assert_called_once_with(
            base64_string=base64_string,
            content_type=content_type,
            model_id="prebuilt-document",
            locale="es",
            pages=None
        )
        self.assertEqual(response, mock_response)

    def test_extract_text(self):
        """Test extract_text method."""
        # Create a mock response with a mocked document
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_document = MagicMock()
        mock_document.get_text.return_value = "Extracted text content"
        mock_response.get_analyzed_document.return_value = mock_document
        self.mock_provider.analyze_document.return_value = mock_response

        # Call the method
        file_path = "test_document.pdf"
        text = self.client.extract_text(
            file_path=file_path,
            model_id="prebuilt-document",
            locale="en"
        )

        # Assert the provider method was called and correct text was returned
        self.mock_provider.analyze_document.assert_called_once()
        self.assertEqual(text, "Extracted text content")

    def test_extract_text_error(self):
        """Test extract_text method when document extraction fails."""
        # Create a mock response with no document
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_response.get_analyzed_document.return_value = None
        self.mock_provider.analyze_document.return_value = mock_response

        # Call the method and assert it raises an error
        file_path = "test_document.pdf"
        with self.assertRaises(DocumentIntelligenceError):
            self.client.extract_text(
                file_path=file_path,
                model_id="prebuilt-document",
                locale="en"
            )

    def test_extract_text_from_base64(self):
        """Test extract_text_from_base64 method."""
        # Create a mock response with a mocked document
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_document = MagicMock()
        mock_document.get_text.return_value = "Extracted text from base64"
        mock_response.get_analyzed_document.return_value = mock_document
        self.mock_provider.analyze_document_from_base64.return_value = mock_response

        # Call the method
        base64_string = "base64_encoded_data"
        content_type = "application/pdf"
        text = self.client.extract_text_from_base64(
            base64_string=base64_string,
            content_type=content_type
        )

        # Assert the provider method was called and correct text was returned
        self.mock_provider.analyze_document_from_base64.assert_called_once()
        self.assertEqual(text, "Extracted text from base64")


if __name__ == "__main__":
    unittest.main() 