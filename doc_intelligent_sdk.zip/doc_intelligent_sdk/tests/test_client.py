#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Tests for the DocIntelligenceClient class.
"""

import os
import pytest
from unittest.mock import patch, MagicMock
import base64
from pathlib import Path
from unittest.mock import mock_open

from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.utils.errors import DocumentIntelligenceError
from doc_intelligent.models.response import DocumentAnalysisResponse


class TestDocIntelligenceClient:
    """Tests for the DocIntelligenceClient class."""

    def test_init_with_api_key(self):
        """Test client initialization with API key."""
        client = DocIntelligenceClient(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        
        assert client.endpoint == "https://example.com/document-intelligence"
        assert client.api_key == "fake-api-key"
        assert client.credential is None
        assert client.connection_verify is True  # Default

    def test_init_with_credential(self):
        """Test client initialization with Azure credential."""
        # Create a mock credential
        mock_credential = MagicMock()
        
        client = DocIntelligenceClient(
            endpoint="https://example.com/document-intelligence",
            credential=mock_credential,
            connection_verify=False
        )
        
        assert client.endpoint == "https://example.com/document-intelligence"
        assert client.api_key is None
        assert client.credential == mock_credential
        assert client.connection_verify is False

    def test_init_validation_error(self):
        """Test that initialization fails if neither api_key nor credential is provided."""
        with pytest.raises(ValueError):
            DocIntelligenceClient(
                endpoint="https://example.com/document-intelligence"
            )

    @patch('requests.post')
    @patch('builtins.open', new_callable=mock_open, read_data=b'mocked file content')
    def test_analyze_document(self, mock_open_func, mock_post, mock_document_response, mock_api_response, sample_pdf_path):
        """Test analyze_document method."""
        # Create a mock file that doesn't need to exist
        mock_file_path = MagicMock(spec=Path)
        mock_file_path.__str__.return_value = "mock_path.pdf"
        mock_file_path.exists.return_value = True
        mock_file_path.is_file.return_value = True
        
        # Setup the analyze_document method of the provider to return a mock response
        mock_provider = MagicMock()
        mock_provider.analyze_document.return_value = DocumentAnalysisResponse(
            status="succeeded",
            model_id="prebuilt-document"
        )
        
        # Create client with mocked provider
        client = DocIntelligenceClient(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        client.provider = mock_provider
        
        # Call analyze_document
        result = client.analyze_document(
            file_path=mock_file_path,
            model_id="prebuilt-document"
        )
        
        # Verify provider.analyze_document was called with the right parameters
        mock_provider.analyze_document.assert_called_once_with(
            file_path=mock_file_path,
            model_id="prebuilt-document",
            locale="en",
            pages=None
        )
        
        # Verify result
        assert result is not None
        assert result.status == "succeeded"
        assert result.model_id == "prebuilt-document"

    @patch('requests.post')
    def test_analyze_document_from_base64(self, mock_post, mock_document_response, mock_api_response):
        """Test analyze_document_from_base64 method."""
        # Mock base64 data
        base64_content = base64.b64encode(b"test document content").decode('utf-8')
        
        # Setup the analyze_document_from_base64 method of the provider to return a mock response
        mock_provider = MagicMock()
        mock_provider.analyze_document_from_base64.return_value = DocumentAnalysisResponse(
            status="succeeded",
            model_id="prebuilt-document"
        )
        
        # Create client with mocked provider
        client = DocIntelligenceClient(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        client.provider = mock_provider
        
        # Call analyze_document_from_base64
        result = client.analyze_document_from_base64(
            base64_string=base64_content,
            content_type="application/pdf",
            model_id="prebuilt-document"
        )
        
        # Verify provider.analyze_document_from_base64 was called with the right parameters
        mock_provider.analyze_document_from_base64.assert_called_once_with(
            base64_string=base64_content,
            content_type="application/pdf",
            model_id="prebuilt-document",
            locale="en",
            pages=None
        )
        
        # Verify result
        assert result is not None
        assert result.status == "succeeded"
        assert result.model_id == "prebuilt-document"

    @patch('requests.post')
    def test_analyze_document_api_error(self, mock_post, mock_api_response):
        """Test handling of API errors in analyze_document."""
        # Create a mock error response
        error_response = {
            "error": {
                "code": "InvalidRequest",
                "message": "The request is invalid."
            }
        }
        mock_post.return_value = mock_api_response(error_response, status_code=400)
        
        # Create client
        client = DocIntelligenceClient(
            endpoint="https://example.com/document-intelligence",
            api_key="fake-api-key"
        )
        
        # Mock file path
        mock_file_path = MagicMock(spec=Path)
        mock_file_path.exists.return_value = True
        mock_file_path.is_file.return_value = True
        
        # Test that it raises an error
        with pytest.raises(DocumentIntelligenceError):
            client.analyze_document(
                file_path=mock_file_path,
                model_id="prebuilt-document"
            )

    def test_batch_analyze_directory(self, mock_client):
        """Test batch_analyze_directory method."""
        # Create a mock directory
        mock_dir = MagicMock(spec=Path)
        mock_dir.exists.return_value = True
        mock_dir.is_dir.return_value = True
        
        # Create some mock files
        mock_files = [MagicMock(spec=Path) for _ in range(3)]
        for i, f in enumerate(mock_files):
            f.name = f"test{i}.pdf"
            f.stem = f"test{i}"
            f.suffix = ".pdf"
            f.exists.return_value = True
            f.is_file.return_value = True
        
        # Setup the batch_analyze_directory method to return a mock result
        mock_client.batch_analyze_directory.return_value = {
            "total_documents": 3,
            "success_count": 3,
            "error_count": 0,
            "results": {}
        }
        
        # Call batch_analyze_directory
        result = mock_client.batch_analyze_directory(
            directory_path=mock_dir,
            extensions=['.pdf'],
            recursive=True,
            parallel=False,
            model_id="prebuilt-document"
        )
        
        # Verify the function was called with the expected arguments
        mock_client.batch_analyze_directory.assert_called_once()
        args, kwargs = mock_client.batch_analyze_directory.call_args
        assert kwargs["directory_path"] == mock_dir
        assert kwargs["extensions"] == ['.pdf']
        assert kwargs["recursive"] is True
        assert kwargs["parallel"] is False
        assert kwargs["model_id"] == "prebuilt-document"
        
        # Verify result
        assert result["total_documents"] == 3
        assert result["success_count"] == 3 