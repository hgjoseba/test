#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
from setuptools import setup, find_packages

# Read long description from README.md
with open(os.path.join(os.path.dirname(__file__), "README.md"), encoding="utf-8") as f:
    long_description = f.read()

# Define main dependencies
install_requires = [
    "pydantic>=1.8.0,<2.0.0",
    "python-dotenv>=1.0.0",
    "azure-ai-formrecognizer>=3.2.0",
    "azure-core>=1.26.0",
    "azure-identity>=1.12.0",
]

# Define optional dependencies
extras_require = {
    "document_processing": [
        "PyPDF2>=3.0.0",
        "python-docx>=1.0.0",
    ],
    "dev": [
        "pytest>=7.0.0",
        "pytest-cov>=4.1.0",
        "black>=24.0.0",
        "isort>=5.12.0",
        "mypy>=1.0.0",
        "pytest-mock>=3.10.0",
    ],
}

setup(
    name="doc-intelligent-sdk",
    version="0.2.0",
    description="A SDK for document analysis using Azure Document Intelligence",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Document Intelligence SDK Team",
    author_email="contact@example.com",
    url="https://github.com/yourusername/doc-intelligent-sdk",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    include_package_data=True,
    zip_safe=False,
    python_requires=">=3.8",
    install_requires=install_requires,
    extras_require=extras_require,
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Office/Business :: Office Suites",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Typing :: Typed",
    ],
    keywords=[
        "document",
        "intelligence",
        "azure",
        "ocr",
        "pdf",
        "document processing",
        "text extraction",
        "layout analysis",
    ],
    license="MIT",
) 