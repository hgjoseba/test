"""
Utility modules for the Document Intelligence SDK (OCR version).

This package contains various utility modules used throughout the SDK
for authentication, error handling, logging, and other common functions.
"""

import os
import logging
from azure.identity import DefaultAzureCredential
from azure.core.exceptions import ClientAuthenticationError

from .logging import get_logger

__all__ = ["get_logger", "get_token_azurecredential"]

def get_token_azurecredential(scope="https://cognitiveservices.azure.com/.default"):
    """
    Obtiene un token de autenticación utilizando DefaultAzureCredential.
    
    Args:
        scope: El ámbito para el token de autenticación.
        
    Returns:
        str: El token de autenticación.
        
    Raises:
        DocumentIntelligenceError: Si falla la obtención del token.
    """
    logger = get_logger(__name__)
    try:
        # Configuración de proxy para la autenticación si está definida en el entorno
        http_proxy = os.environ.get("HTTP_PROXY")
        https_proxy = os.environ.get("HTTPS_PROXY")
        no_proxy = os.environ.get("NO_PROXY", "")
        
        # Obtener credenciales de DefaultAzureCredential
        credential = DefaultAzureCredential()
        
        # Obtener el token para el ámbito especificado
        token = credential.get_token(scope)
        logger.info("Token adquirido correctamente utilizando DefaultAzureCredential")
        
        return token.token
    except ClientAuthenticationError as auth_error:
        logger.error(f"Error de autenticación: {auth_error}")
        from .errors import DocumentIntelligenceError
        raise DocumentIntelligenceError(f"Error al obtener el token de autenticación: {auth_error}")
    except Exception as e:
        logger.error(f"Error inesperado al obtener token: {e}")
        from .errors import DocumentIntelligenceError
        raise DocumentIntelligenceError(f"Error inesperado al obtener token: {e}") 