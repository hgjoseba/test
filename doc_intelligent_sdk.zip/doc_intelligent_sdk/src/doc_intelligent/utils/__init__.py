"""
Utility modules for the Document Intelligence SDK.

This package contains various utility modules used throughout the SDK
for error handling, logging, and other common functions.
"""

import os
import logging

from .logging import get_logger

__all__ = ["get_logger"] 