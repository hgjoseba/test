"""
Utility functions and classes for Document Intelligence SDK.

This package contains various utility functions and helper classes
used throughout the SDK.
"""

from .logging import get_logger

__all__ = ["get_logger"] 