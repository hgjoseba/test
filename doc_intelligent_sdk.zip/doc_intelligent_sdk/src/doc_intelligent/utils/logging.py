"""
Logging utilities for Document Intelligence SDK.

This module provides logging functionality for the SDK,
allowing for consistent log formatting and management.
"""

import logging
import os
from typing import Optional


def get_logger(name: str, level: Optional[int] = None) -> logging.Logger:
    """
    Get a configured logger instance.
    
    Args:
        name: The name of the logger, typically the module name.
        level: The log level. If None, uses the LOG_LEVEL environment 
            variable or defaults to INFO.
            
    Returns:
        logging.Logger: A configured logger instance.
    """
    # Get log level from environment variable or use default
    if level is None:
        level_name = os.getenv("DOC_INTELLIGENCE_LOG_LEVEL", "INFO").upper()
        level = getattr(logging, level_name, logging.INFO)
        
    # Create logger and set level
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Only add handlers if they don't already exist
    if not logger.handlers:
        # Create console handler
        handler = logging.StreamHandler()
        handler.setLevel(level)
        
        # Create formatter
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        handler.setFormatter(formatter)
        
        # Add handler to logger
        logger.addHandler(handler)
    
    return logger 