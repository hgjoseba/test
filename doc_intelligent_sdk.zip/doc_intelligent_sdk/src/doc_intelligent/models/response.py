"""
Response model classes for Document Intelligence SDK.

This module defines models representing API responses from 
the Azure Document Intelligence service.
"""

from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel, Field

# Use validator instead of root_validator in Pydantic v1
from pydantic import validator

from .document import AnalyzedDocument, BoundingBox, Table, KeyValuePair, TextPage, TextLine, TableCell


class DocumentAnalysisResponse(BaseModel):
    """
    Represents a response from the Document Analysis API.
    
    This is the main model for handling responses from the Document 
    Intelligence service, including status information and the 
    analyzed document data.
    """
    status: str = "succeeded"
    created_on: Optional[datetime] = None
    last_updated_on: Optional[datetime] = None
    expires_on: Optional[datetime] = None
    model_id: Optional[str] = None
    api_version: Optional[str] = None
    content: Optional[str] = None
    content_type: Optional[str] = None
    pages: Optional[List[Dict[str, Any]]] = None
    tables: Optional[List[Dict[str, Any]]] = None
    key_value_pairs: Optional[List[Dict[str, Any]]] = None
    documents: Optional[List[Dict[str, Any]]] = None
    errors: Optional[List[Dict[str, Any]]] = None
    
    # Raw data for access to additional fields
    _analyzed_document: Optional[AnalyzedDocument] = None
    _raw_data: Optional[Dict[str, Any]] = None
    
    class Config:
        """Pydantic model configuration."""
        # Exclude _analyzed_document and _raw_data fields from serialization
        underscore_attrs_are_private = True
    
    @classmethod
    def from_azure_result(cls, result: Any) -> "DocumentAnalysisResponse":
        """
        Create a DocumentAnalysisResponse from an Azure SDK result.
        
        Args:
            result: Azure SDK analyze document result.
            
        Returns:
            DocumentAnalysisResponse: The constructed response.
        """
        # Create the analyzed document from the Azure result
        analyzed_document = AnalyzedDocument.from_azure_result(result)
        
        # Create a response with minimal required info
        response = cls(
            status="succeeded",
            model_id=getattr(result, 'model_id', None),
            content=getattr(result, 'content', None),
            created_on=datetime.now(),
            last_updated_on=datetime.now(),
            _analyzed_document=analyzed_document
        )
        
        return response
    
    def get_analyzed_document(self) -> Optional[AnalyzedDocument]:
        """
        Get the analyzed document from the response.
        
        Returns:
            AnalyzedDocument: The analyzed document, or None if not available.
        """
        if self.status != "succeeded":
            return None
            
        if self._analyzed_document:
            return self._analyzed_document
            
        # If no pre-constructed document is available, try to build one from response data
        return self._build_analyzed_document()
    
    def _build_analyzed_document(self) -> Optional[AnalyzedDocument]:
        """
        Build an analyzed document from response data.
        
        This is a fallback method used when a pre-constructed document
        is not available.
        
        Returns:
            AnalyzedDocument: The constructed document, or None if not possible.
        """
        if not self.pages:
            return None
            
        # Process pages
        processed_pages = []
        for page_data in self.pages:
            page_number = page_data.get("pageNumber", 0)
            width = page_data.get("width", 0.0)
            height = page_data.get("height", 0.0)
            unit = page_data.get("unit", "pixel")
            
            # Process lines
            lines = []
            for line_data in page_data.get("lines", []):
                bounding_box = None
                if "boundingBox" in line_data:
                    bb = line_data["boundingBox"]
                    if len(bb) >= 4:  # Simple validation
                        bounding_box = BoundingBox(
                            left=bb[0], 
                            top=bb[1],
                            width=bb[2] - bb[0],  # Assuming format is [left, top, right, bottom]
                            height=bb[3] - bb[1]
                        )
                
                lines.append(TextLine(
                    content=line_data.get("content", ""),
                    bounding_box=bounding_box,
                    confidence=line_data.get("confidence", 0.0),
                    span=line_data.get("span")
                ))
            
            processed_pages.append(TextPage(
                page_number=page_number,
                width=width,
                height=height,
                unit=unit,
                lines=lines,
                language=page_data.get("language")
            ))
        
        # Process tables
        processed_tables = []
        if self.tables:
            for table_data in self.tables:
                # Process cells
                cells = []
                for cell_data in table_data.get("cells", []):
                    bounding_box = None
                    if "boundingBox" in cell_data:
                        bb = cell_data["boundingBox"]
                        if len(bb) >= 4:
                            bounding_box = BoundingBox(
                                left=bb[0], 
                                top=bb[1],
                                width=bb[2] - bb[0],
                                height=bb[3] - bb[1]
                            )
                    
                    cells.append(TableCell(
                        text=cell_data.get("content", ""),
                        row_index=cell_data.get("rowIndex", 0),
                        column_index=cell_data.get("columnIndex", 0),
                        row_span=cell_data.get("rowSpan", 1),
                        column_span=cell_data.get("columnSpan", 1),
                        bounding_box=bounding_box,
                        confidence=cell_data.get("confidence", 0.0)
                    ))
                
                processed_tables.append(Table(
                    page_number=table_data.get("pageNumber", 1),
                    cells=cells,
                    row_count=table_data.get("rowCount", 0),
                    column_count=table_data.get("columnCount", 0)
                ))
        
        # Process key-value pairs
        processed_kvp = []
        if self.key_value_pairs:
            for kvp_data in self.key_value_pairs:
                key = kvp_data.get("key", {}).get("content", "")
                value = kvp_data.get("value", {}).get("content", "")
                confidence = kvp_data.get("confidence", 0.0)
                page_number = kvp_data.get("pageNumber", 1)
                
                processed_kvp.append(KeyValuePair(
                    key=key,
                    value=value,
                    confidence=confidence,
                    page_number=page_number
                ))
        
        # Create the analyzed document
        return AnalyzedDocument(
            document_id=self._raw_data.get("documentId") if self._raw_data else None,
            model_id=self.model_id or "",
            pages=processed_pages,
            tables=processed_tables,
            key_value_pairs=processed_kvp,
            content=self.content or "",
            content_type=self.content_type or "",
            analysis_timestamp=self.last_updated_on
        )
    
    @validator('*', pre=True)
    def store_raw_data(cls, v, values, **kwargs):
        """Store the raw data for later access."""
        # Make a copy to avoid modifying the input
        # In Pydantic v1, we need to manually update the values dict
        if '_raw_data' not in values:
            values['_raw_data'] = dict(values)
        return v
    
    def get_errors(self) -> List[Dict[str, Any]]:
        """
        Get any errors from the response.
        
        Returns:
            List[Dict[str, Any]]: List of error objects.
        """
        if self.errors:
            return self.errors
        elif self._raw_data and "error" in self._raw_data:
            return [self._raw_data["error"]]
        return [] 