"""
Response models for Document Intelligence SDK (OCR version).

This module defines the response models for document analysis operations,
focused on text extraction.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .document import AnalyzedDocument
from ..utils.errors import DocumentIntelligenceError
from ..utils.logging import get_logger

logger = get_logger(__name__)


class DocumentAnalysisResponse(BaseModel):
    """
    Response model for document analysis operations.
    
    This model represents the response from the document analysis API,
    containing the result status and the analyzed document.
    """
    status: str
    created_on: datetime = Field(default_factory=datetime.now)
    last_updated_on: Optional[datetime] = None
    expires_on: Optional[datetime] = None
    result: Optional[Dict[str, Any]] = None
    errors: List[Dict[str, Any]] = Field(default_factory=list)
    _analyzed_document: Optional[AnalyzedDocument] = None
    
    @classmethod
    def from_azure_result(cls, result: Any) -> "DocumentAnalysisResponse":
        """
        Create a DocumentAnalysisResponse from an Azure API result.
        
        Args:
            result: The Azure API result.
            
        Returns:
            DocumentAnalysisResponse: The constructed response.
        """
        status = getattr(result, "status", "failed")
        created_on = getattr(result, "created_date_time", datetime.now())
        last_updated_on = getattr(result, "last_updated_date_time", None)
        expires_on = getattr(result, "expires_date_time", None)
        
        # Handle errors if present
        errors = []
        if hasattr(result, "errors") and result.errors:
            for error in result.errors:
                errors.append({
                    "code": getattr(error, "code", "unknown"),
                    "message": getattr(error, "message", "Unknown error")
                })
        
        # Convert result to dictionary
        result_dict = None
        if result is not None:
            try:
                if hasattr(result, "to_dict"):
                    result_dict = result.to_dict()
                else:
                    # Try to convert the object to a dictionary
                    result_dict = {
                        key: getattr(result, key) 
                        for key in dir(result) 
                        if not key.startswith('_') and not callable(getattr(result, key))
                    }
            except:
                logger.warning("Could not convert result to dictionary")
                result_dict = None
        
        return cls(
            status=status,
            created_on=created_on,
            last_updated_on=last_updated_on,
            expires_on=expires_on,
            result=result_dict,
            errors=errors
        )
    
    def get_analyzed_document(self) -> Optional[AnalyzedDocument]:
        """
        Get the analyzed document from the response.
        
        Returns:
            AnalyzedDocument: The analyzed document if available.
            
        Raises:
            DocumentIntelligenceError: If the analysis failed.
        """
        if self.status.lower() not in ["succeeded", "success", "completed"]:
            error_message = "Document analysis has not succeeded"
            if self.errors:
                error_details = ", ".join([f"{e.get('code', 'Error')}: {e.get('message', '')}" for e in self.errors])
                error_message = f"{error_message}: {error_details}"
            
            raise DocumentIntelligenceError(error_message)
        
        if self._analyzed_document is not None:
            return self._analyzed_document
        
        if self.result:
            self._analyzed_document = self.build_analyzed_document()
            return self._analyzed_document
        
        return None
    
    def build_analyzed_document(self) -> AnalyzedDocument:
        """
        Build an AnalyzedDocument from the response result.
        
        Returns:
            AnalyzedDocument: The constructed analyzed document.
        """
        # Create analyzed document from the result dict
        return AnalyzedDocument.from_azure_result(self.result)
    
    def get_text(self) -> str:
        """
        Get the extracted text from the analyzed document.
        
        Returns:
            str: The extracted text.
            
        Raises:
            DocumentIntelligenceError: If the analysis failed or text extraction is not possible.
        """
        document = self.get_analyzed_document()
        if document:
            return document.get_text()
        else:
            raise DocumentIntelligenceError("Failed to extract text from document")
    
    def get_errors(self) -> List[Dict[str, str]]:
        """
        Get the errors from the response.
        
        Returns:
            List[Dict[str, str]]: The errors.
        """
        return self.errors 