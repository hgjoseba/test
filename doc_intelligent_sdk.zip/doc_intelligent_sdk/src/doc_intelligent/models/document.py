"""
Document model classes for Document Intelligence SDK.

This module defines data models representing analyzed documents
and their components such as pages, tables, and key-value pairs.
"""

from datetime import datetime
from typing import Dict, List, Optional, Any, Union, ClassVar
from pydantic import BaseModel, Field

# Use validator instead of root_validator in Pydantic v1
from pydantic import validator


class BoundingBox(BaseModel):
    """Represents a bounding box with normalized coordinates."""
    left: float
    top: float
    width: float
    height: float
    
    @classmethod
    def from_azure_polygon(cls, points: List[Dict[str, float]]) -> "BoundingBox":
        """
        Create a BoundingBox from Azure SDK polygon points.
        
        Args:
            points: List of points in the polygon (usually 4 points).
                Can be either list of dicts with 'x' and 'y' keys or
                a flat list of coordinates [x1, y1, x2, y2, ...].
            
        Returns:
            BoundingBox: The constructed bounding box.
        """
        if not points or len(points) < 4:
            return cls(left=0, top=0, width=0, height=0)
        
        # Check if points is a flat list of coordinates [x1, y1, x2, y2, ...]
        if isinstance(points[0], (int, float)):
            # Extract x and y coordinates from the flat list
            xs = [points[i] for i in range(0, len(points), 2)]
            ys = [points[i] for i in range(1, len(points), 2)]
            
            # Calculate bounding box
            min_x = min(xs)
            min_y = min(ys)
            max_x = max(xs)
            max_y = max(ys)
        else:
            # Calculate bounding box from polygon points as dicts
            min_x = min(p.get('x', 0) for p in points)
            min_y = min(p.get('y', 0) for p in points)
            max_x = max(p.get('x', 0) for p in points)
            max_y = max(p.get('y', 0) for p in points)
        
        return cls(
            left=min_x,
            top=min_y,
            width=max_x - min_x,
            height=max_y - min_y
        )


class TextLine(BaseModel):
    """Represents a line of text in a document."""
    content: str
    bounding_box: Optional[BoundingBox] = None
    confidence: float = 1.0
    span: Optional[Dict[str, int]] = None
    
    @classmethod
    def from_azure_line(cls, line: Any) -> "TextLine":
        """
        Create a TextLine from an Azure SDK line object.
        
        Args:
            line: Azure SDK line object.
            
        Returns:
            TextLine: The constructed text line.
        """
        bounding_box = None
        if hasattr(line, 'polygon') and line.polygon:
            bounding_box = BoundingBox.from_azure_polygon(line.polygon)
        
        span = None
        if hasattr(line, 'span') and line.span:
            span = {"offset": line.span.offset, "length": line.span.length}
        
        return cls(
            content=line.content,
            bounding_box=bounding_box,
            confidence=getattr(line, 'confidence', 1.0),
            span=span
        )


class TextPage(BaseModel):
    """Represents a page of text in a document."""
    page_number: int
    width: float = 0.0
    height: float = 0.0
    unit: str = "pixel"
    lines: List[TextLine] = Field(default_factory=list)
    tables: List[Any] = Field(default_factory=list)  # Will be replaced with Table references
    language: Optional[str] = None
    
    @classmethod
    def from_azure_page(cls, page: Any) -> "TextPage":
        """
        Create a TextPage from an Azure SDK page object.
        
        Args:
            page: Azure SDK page object.
            
        Returns:
            TextPage: The constructed text page.
        """
        lines = []
        for line in page.lines:
            lines.append(TextLine.from_azure_line(line))
        
        return cls(
            page_number=page.page_number,
            width=page.width,
            height=page.height,
            unit=page.unit,
            lines=lines,
            language=getattr(page, "language", None)
        )
    
    def get_text(self) -> str:
        """
        Get the text content of the page.
        
        Returns:
            str: The text content of the page.
        """
        return "\n".join([line.content for line in self.lines])


class TableCell(BaseModel):
    """Represents a cell in a table."""
    text: str
    row_index: int
    column_index: int
    row_span: int = 1
    column_span: int = 1
    bounding_box: Optional[BoundingBox] = None
    confidence: float = 1.0
    
    @classmethod
    def from_azure_cell(cls, cell: Any) -> "TableCell":
        """
        Create a TableCell from an Azure SDK cell object.
        
        Args:
            cell: Azure SDK cell object.
            
        Returns:
            TableCell: The constructed table cell.
        """
        bounding_box = None
        if hasattr(cell, 'polygon') and cell.polygon:
            bounding_box = BoundingBox.from_azure_polygon(cell.polygon)
        
        return cls(
            text=cell.content,
            row_index=cell.row_index,
            column_index=cell.column_index,
            row_span=getattr(cell, 'row_span', 1),
            column_span=getattr(cell, 'column_span', 1),
            bounding_box=bounding_box,
            confidence=getattr(cell, 'confidence', 1.0)
        )


class Table(BaseModel):
    """Represents a table in a document."""
    page_number: int
    cells: List[TableCell] = Field(default_factory=list)
    row_count: int
    column_count: int
    bounding_box: Optional[BoundingBox] = None
    
    @classmethod
    def from_azure_table(cls, table: Any) -> "Table":
        """
        Create a Table from an Azure SDK table object.
        
        Args:
            table: Azure SDK table object.
            
        Returns:
            Table: The constructed table.
        """
        bounding_box = None
        if hasattr(table, 'polygon') and table.polygon:
            bounding_box = BoundingBox.from_azure_polygon(table.polygon)
        
        return cls(
            page_number=table.page_number,
            cells=[TableCell.from_azure_cell(cell) for cell in table.cells],
            row_count=table.row_count,
            column_count=table.column_count,
            bounding_box=bounding_box
        )


class KeyValuePair(BaseModel):
    """Represents a key-value pair extracted from a document."""
    key: str
    value: str
    confidence: float = 1.0
    bounding_box: Optional[BoundingBox] = None
    page_number: int = 1
    
    @classmethod
    def from_azure_kvp(cls, kvp: Any) -> "KeyValuePair":
        """
        Create a KeyValuePair from an Azure SDK key-value pair object.
        
        Args:
            kvp: Azure SDK key-value pair object.
            
        Returns:
            KeyValuePair: The constructed key-value pair.
        """
        key_content = kvp.key.content if kvp.key else ""
        value_content = kvp.value.content if kvp.value else ""
        
        page_number = 1
        if hasattr(kvp, 'key') and hasattr(kvp.key, 'polygon') and kvp.key.polygon:
            # Try to extract page number from the key's page reference
            page_number = getattr(kvp.key, 'page_number', 1)
        
        return cls(
            key=key_content,
            value=value_content,
            confidence=getattr(kvp, 'confidence', 1.0),
            page_number=page_number
        )


class DocumentModel(BaseModel):
    """Represents a document model available in the service."""
    model_id: str
    description: str
    created_on: Optional[datetime] = None
    model_type: str = "prebuilt"
    is_prebuilt: bool = False
    capabilities: List[str] = Field(default_factory=list)
    
    @classmethod
    def from_azure_model(cls, model: Any) -> "DocumentModel":
        """
        Create a DocumentModel from an Azure SDK model object.
        
        Args:
            model: Azure SDK model object or dictionary.
            
        Returns:
            DocumentModel: The constructed document model.
        """
        # Verificar si es un diccionario o un objeto
        if isinstance(model, dict):
            return cls(
                model_id=model.get('modelId', ''),
                description=model.get('description', ''),
                created_on=model.get('createdDateTime', None),
                model_type=model.get('modelType', 'prebuilt'),
                is_prebuilt=model.get('isPrebuilt', False),
                capabilities=model.get('capabilities', [])
            )
        else:
            # Es un objeto
            return cls(
                model_id=getattr(model, 'model_id', ''),
                description=getattr(model, 'description', ''),
                created_on=getattr(model, 'created_on', None),
                model_type=getattr(model, 'model_type', 'prebuilt'),
                is_prebuilt=getattr(model, 'is_prebuilt', False),
                capabilities=getattr(model, 'capabilities', [])
            )


class AnalyzedDocument(BaseModel):
    """
    Represents an analyzed document with all extracted information.
    
    This is the main model that contains all the information extracted
    from a document, including text, tables, key-value pairs, etc.
    """
    document_id: Optional[str] = None
    model_id: str
    pages: List[TextPage] = Field(default_factory=list)
    tables: List[Table] = Field(default_factory=list)
    key_value_pairs: List[KeyValuePair] = Field(default_factory=list)
    content: str = ""
    content_type: str = ""
    file_name: Optional[str] = None
    language: Optional[str] = None
    analysis_timestamp: Optional[datetime] = None
    
    @classmethod
    def from_azure_result(cls, result: Any) -> "AnalyzedDocument":
        """
        Create an AnalyzedDocument from an Azure SDK analysis result.
        
        Args:
            result: Azure SDK analysis result or JSON dict response.
        
        Returns:
            AnalyzedDocument: The constructed analyzed document.
        """
        # Si result no es un diccionario, podría ser un objeto de tipo MockAzureResult u otro objeto
        if not isinstance(result, dict):
            # Extraer los atributos directamente del objeto
            model_id = getattr(result, "model_id", "")
            pages = []
            tables = []
            key_value_pairs = []
            
            # Procesar páginas si están disponibles
            if hasattr(result, "pages"):
                for page in result.pages:
                    pages.append(TextPage.from_azure_page(page))
            
            # Procesar tablas si están disponibles
            if hasattr(result, "tables"):
                for table in result.tables:
                    tables.append(Table.from_azure_table(table))
            
            # Procesar key-value pairs si están disponibles
            if hasattr(result, "key_value_pairs"):
                for kvp in result.key_value_pairs:
                    key_value_pairs.append(KeyValuePair.from_azure_kvp(kvp))
            
            # Crear el documento con los datos extraídos
            return cls(
                model_id=model_id,
                pages=pages,
                tables=tables,
                key_value_pairs=key_value_pairs,
                content="\n".join([l.content for p in pages for l in p.lines]) if pages else "",
                language="en"  # Default language
            )
        
        # Handle dict response (from tests or API)
        if "analyzeResult" in result:
            content = result.get("analyzeResult", {})
            model_id = result.get("modelId", "")
        else:
            content = result
            model_id = result.get("modelId", "")
        
        # Extract pages
        pages_data = content.get("pages", [])
        pages = []
        for page_data in pages_data:
            # Create a simple object to mimic the API result
            class PageObject:
                def __init__(self, data):
                    self.page_number = data.get("pageNumber", 0)
                    self.width = data.get("width", 0)
                    self.height = data.get("height", 0)
                    self.unit = data.get("unit", "pixel")
                    self.lines = []
                    for line in data.get("lines", []):
                        self.lines.append(type('LineObject', (), {
                            'content': line.get("content", ""),
                            'polygon': line.get("boundingBox", []),
                            'span': type('SpanObject', (), {
                                'offset': line.get("spans", [{}])[0].get("offset", 0) if line.get("spans") else 0,
                                'length': line.get("spans", [{}])[0].get("length", 0) if line.get("spans") else 0
                            }) if line.get("spans") else None,
                            'confidence': line.get("confidence", 1.0)
                        }))
                    self.language = data.get("language")
            
            page_obj = PageObject(page_data)
            pages.append(TextPage.from_azure_page(page_obj))
        
        # Extract tables
        tables_data = content.get("tables", [])
        tables = []
        for table_data in tables_data:
            # Create a simple object to mimic the API result
            class TableObject:
                def __init__(self, data):
                    self.page_number = data.get("pageNumber", 1)
                    self.row_count = data.get("rowCount", 0)
                    self.column_count = data.get("columnCount", 0)
                    self.polygon = data.get("boundingBox", [])
                    self.cells = []
                    for cell in data.get("cells", []):
                        self.cells.append(type('CellObject', (), {
                            'content': cell.get("content", ""),
                            'row_index': cell.get("rowIndex", 0),
                            'column_index': cell.get("columnIndex", 0),
                            'row_span': cell.get("rowSpan", 1),
                            'column_span': cell.get("columnSpan", 1),
                            'polygon': cell.get("boundingBox", []),
                            'confidence': cell.get("confidence", 1.0)
                        }))
            
            table_obj = TableObject(table_data)
            tables.append(Table.from_azure_table(table_obj))
        
        # Extract key-value pairs
        kvp_data = content.get("keyValuePairs", [])
        key_value_pairs = []
        for kvp in kvp_data:
            # Create a simple object to mimic the API result
            key_content = kvp.get("key", {}).get("content", "")
            value_content = kvp.get("value", {}).get("content", "")
            
            # Find on which page the KVP appears (use first page if not specified)
            page_number = 1
            if "boundingBox" in kvp.get("key", {}):
                # In a real implementation, you might calculate the page based on coordinates
                pass
            
            key_value_pairs.append(KeyValuePair(
                key=key_content,
                value=value_content,
                confidence=kvp.get("confidence", 1.0),
                page_number=page_number
            ))
        
        # Create the document with extracted data
        return cls(
            document_id=result.get("documentId"),
            model_id=model_id,
            pages=pages,
            tables=tables,
            key_value_pairs=key_value_pairs,
            content="\n".join([l.content for p in pages for l in p.lines]),
            content_type=result.get("contentType", ""),
            file_name=result.get("fileName"),
            language="en"  # Default language
        )
    
    def get_text(self) -> str:
        """
        Get the full text content of the document.
        
        Returns:
            str: The concatenated text content.
        """
        return self.content or "\n".join(
            [line.content for page in self.pages for line in page.lines]
        )
    
    def get_page_text(self, page_number: int) -> str:
        """
        Get the text content of a specific page.
        
        Args:
            page_number: The page number (1-based index).
            
        Returns:
            str: The text content of the page.
        """
        for page in self.pages:
            if page.page_number == page_number:
                return "\n".join([line.content for line in page.lines])
        return ""
    
    def get_tables(self, page_number: Optional[int] = None) -> List[Table]:
        """
        Get tables from the document, optionally filtered by page number.
        
        Args:
            page_number: Optional page number to filter tables.
            
        Returns:
            List[Table]: Tables matching the filter.
        """
        if page_number is None:
            return self.tables
        
        return [table for table in self.tables if table.page_number == page_number]
    
    def get_key_value_pairs(self, page_number: Optional[int] = None) -> List[KeyValuePair]:
        """
        Get key-value pairs from the document, optionally filtered by page number.
        
        Args:
            page_number: Optional page number to filter key-value pairs.
            
        Returns:
            List[KeyValuePair]: Key-value pairs matching the filter.
        """
        if page_number is None:
            return self.key_value_pairs
        
        return [kv for kv in self.key_value_pairs if kv.page_number == page_number] 