"""
Document Intelligence SDK

A SDK for processing documents using Azure Document Intelligence service.
"""

from .client import DocIntelligenceClient

__version__ = "0.2.0"
__all__ = ["DocIntelligenceClient"] 