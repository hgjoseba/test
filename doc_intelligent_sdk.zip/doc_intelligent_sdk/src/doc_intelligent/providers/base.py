"""
Base provider module for Document Intelligence SDK.

This module defines the base interface that all document
analysis service providers must implement.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Union, Any
from pathlib import Path

from ..models.document import AnalyzedDocument
from ..models.response import DocumentAnalysisResponse


class DocumentProvider(ABC):
    """
    Abstract base class for document analysis providers.
    
    All specific providers must implement this interface.
    """
    
    @abstractmethod
    def analyze_document(
        self,
        file_path: Union[str, Path],
        model_id: str,
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyzes a document from a file.
        
        Args:
            file_path: Path to the document file.
            model_id: ID of the model to use.
            locale: Document locale configuration.
            pages: Specific page numbers to analyze.
            **kwargs: Additional provider-specific parameters.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
        """
        pass
    
    @abstractmethod
    def analyze_document_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str,
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyzes a document from base64 encoded data.
        
        Args:
            base64_string: Base64 encoded document data.
            content_type: Content type of the document.
            model_id: ID of the model to use.
            locale: Document locale configuration.
            pages: Specific page numbers to analyze.
            **kwargs: Additional provider-specific parameters.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
        """
        pass
    
    @abstractmethod
    def analyze_documents_batch(
        self,
        file_paths: List[Union[str, Path]],
        model_id: str,
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> Dict[str, DocumentAnalysisResponse]:
        """
        Analyzes multiple documents in batch.
        
        Args:
            file_paths: List of paths to document files.
            model_id: ID of the model to use.
            locale: Document locale configuration.
            pages: Specific page numbers to analyze.
            **kwargs: Additional provider-specific parameters.
            
        Returns:
            Dict[str, DocumentAnalysisResponse]: Dictionary with file paths as keys and analysis results as values.
        """
        pass
    
    @abstractmethod
    def analyze_documents_batch_from_base64(
        self,
        documents: List[Dict[str, str]],
        model_id: str,
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> Dict[str, DocumentAnalysisResponse]:
        """
        Analyzes multiple documents in batch from base64 encoded data.
        
        Args:
            documents: List of dictionaries with at least 'base64_string' and 'content_type' keys.
            model_id: ID of the model to use.
            locale: Document locale configuration.
            pages: Specific page numbers to analyze.
            **kwargs: Additional provider-specific parameters.
            
        Returns:
            Dict[str, DocumentAnalysisResponse]: Dictionary with document identifiers as keys and analysis results as values.
        """
        pass
    
    @abstractmethod
    def list_models(self) -> List[Any]:
        """
        Lists available models for this provider.
        
        Returns:
            List of available models.
        """
        pass 