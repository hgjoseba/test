"""
Providers for Document Intelligence SDK.

This module contains the different service providers
for document analysis, such as Azure Document Intelligence,
Google Document AI, Amazon Textract, etc.
"""

from .azure import AzureDocumentProvider

__all__ = ["AzureDocumentProvider"] 