"""
Azure Document Intelligence Provider.

This module defines the Azure-specific document intelligence provider
implementation, using the Azure Document Intelligence service.
"""

import os
import logging
import base64
from pathlib import Path
from io import BytesIO
from typing import Dict, List, Optional, Any, Union, BinaryIO
import importlib.util

# Import Azure dependencies conditionally to allow testing without having the dependencies installed
try:
    from azure.ai.formrecognizer import DocumentAnalysisClient, DocumentModelAdministrationClient
    from azure.core.credentials import AzureKeyCredential
    from azure.core.exceptions import ResourceNotFoundError, ClientAuthenticationError, HttpResponseError
    AZURE_IMPORTS_AVAILABLE = True
except ImportError:
    # Create mocks for Azure classes to allow imports without errors during testing
    class DocumentAnalysisClient:
        pass
    class DocumentModelAdministrationClient:
        pass
    class AzureKeyCredential:
        pass
    class ResourceNotFoundError(Exception):
        pass
    class ClientAuthenticationError(Exception):
        pass
    class HttpResponseError(Exception):
        pass
    AZURE_IMPORTS_AVAILABLE = False

from .base import DocumentProvider
from ..auth.azure import AzureCredential
from ..models.document import AnalyzedDocument, DocumentModel
from ..models.response import DocumentAnalysisResponse
from ..utils.errors import DocumentIntelligenceError, ModelNotFoundError, ServiceError, ApiError, AuthenticationError, RequestError, ValidationError
from ..utils.logging import get_logger

logger = logging.getLogger(__name__)


class AzureDocumentProvider(DocumentProvider):
    """
    Provider for accessing Azure Document Intelligence services.
    
    This class implements the DocumentProvider interface for Azure Document Intelligence.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        api_key: str = None,
        api_version: str = "2023-07-31",
        credential: AzureCredential = None,
        connection_verify: Union[bool, str] = True,
    ):
        """
        Initializes the Azure Document Intelligence provider.
        
        Args:
            endpoint: Azure Document Intelligence endpoint URL.
                Can also be configured via the AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT environment variable.
            api_key: Azure Document Intelligence API key.
                Can also be configured via the AZURE_DOCUMENT_INTELLIGENCE_KEY environment variable.
            api_version: API version to use. Default: "2023-07-31".
            credential: AzureCredential object for authentication.
                If not provided, api_key will be used if available.
            connection_verify: Controls SSL certificate verification. Set to False to disable verification,
                or provide a path to a CA bundle to use. Default: True.
        """
        self.endpoint = endpoint or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        self.api_key = api_key or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
        self.api_version = api_version
        self.credential = credential
        self.connection_verify = connection_verify
        
        if not self.endpoint:
            raise ValueError("Endpoint must be provided directly or via environment variable")
        
        if not self.api_key and not self.credential:
            raise ValueError("Either API key or credential must be provided for authentication")
        
        # Initialize Azure SDK clients
        if self.api_key:
            azure_credential = AzureKeyCredential(self.api_key)
        else:
            # Get token credential from AzureCredential wrapper
            azure_credential = self.credential.get_azure_credential()
            
        # Configure client with connection verification settings
        client_kwargs = {
            "verify": self.connection_verify
        } if isinstance(self.connection_verify, bool) else {
            "verify": True,
            "connection_verify": self.connection_verify  # Path to CA bundle
        }
        
        # Initialize Document Analysis Client for analyzing documents
        self._analysis_client = DocumentAnalysisClient(
            endpoint=self.endpoint,
            credential=azure_credential,
            **client_kwargs
        )
        
        # Initialize Document Model Administration Client for model operations
        self._admin_client = DocumentModelAdministrationClient(
            endpoint=self.endpoint,
            credential=azure_credential,
            **client_kwargs
        )
    
    def analyze_document(
        self,
        file_path: Union[str, Path],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyzes a document using Azure Document Intelligence.
        
        Args:
            file_path: Path to the document file to analyze.
            model_id: ID of the model to use. Default: "prebuilt-document".
                Available options include: "prebuilt-document", "prebuilt-layout",
                "prebuilt-receipt", "prebuilt-invoice", and others.
            locale: Document language locale. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Document file not found: {file_path}")
        
        # Prepare analysis options
        options = {}
        if locale:
            options["locale"] = locale
        if pages:
            options["pages"] = pages
        # Add any additional parameters from kwargs
        options.update(kwargs)
        
        try:
            # Open file for reading and analyze with the Azure SDK client
            with open(file_path, "rb") as f:
                poller = self._analysis_client.begin_analyze_document(
                    model_id=model_id,
                    document=f,
                    **options
                )
                
                # Wait for the operation to complete
                result = poller.result()
                
                # Convert the Azure SDK result to our model
                return DocumentAnalysisResponse.from_azure_result(result)
                
        except HttpResponseError as e:
            if e.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                logger.error(f"Error analyzing document: {str(e)}")
                raise ServiceError(str(e), e.status_code)
        except Exception as e:
            logger.error(f"Error analyzing document: {str(e)}")
            raise DocumentIntelligenceError(f"Error analyzing document: {str(e)}")
    
    def analyze_document_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyzes a document from base64 encoded data.
        
        Args:
            base64_string: Base64 encoded document data.
            content_type: Content type of the document (e.g., "application/pdf", "image/jpeg").
            model_id: ID of the model to use. Default: "prebuilt-document".
                Available options include: "prebuilt-document", "prebuilt-layout",
                "prebuilt-receipt", "prebuilt-invoice", and others.
            locale: Document language locale. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        try:
            # Decode the base64 string to binary data
            binary_data = base64.b64decode(base64_string)
            
            # Prepare analysis options
            options = {}
            if locale:
                options["locale"] = locale
            if pages:
                options["pages"] = pages
            # We don't pass content_type to options, as Azure SDK sets it internally
            # Add any additional parameters from kwargs
            for key, value in kwargs.items():
                if key != "content_type":  # Skip content_type to avoid collision
                    options[key] = value
            
            # Create a BytesIO object from the binary data and analyze with the Azure SDK client
            with BytesIO(binary_data) as document_stream:
                # Pass the mime_content_type as a separate parameter
                poller = self._analysis_client.begin_analyze_document(
                    model_id=model_id,
                    document=document_stream,
                    **options
                )
                
                # Wait for the operation to complete
                result = poller.result()
                
                # Convert the Azure SDK result to our model
                return DocumentAnalysisResponse.from_azure_result(result)
                
        except ValueError as e:
            logger.error(f"Error decoding base64 data: {str(e)}")
            raise DocumentIntelligenceError(f"Error decoding base64 data: {str(e)}")
        except HttpResponseError as e:
            if e.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                logger.error(f"Error analyzing document: {str(e)}")
                raise ServiceError(str(e), e.status_code)
        except Exception as e:
            logger.error(f"Error analyzing document: {str(e)}")
            raise DocumentIntelligenceError(f"Error analyzing document: {str(e)}")
    
    def list_models(self) -> List[DocumentModel]:
        """
        Lists available document models.
        
        Returns:
            List of available DocumentModel objects.
        """
        try:
            # Use the Azure SDK to list models
            models = self._admin_client.list_models()
            
            # Convert to our model format
            return [DocumentModel.from_azure_model(model) for model in models]
            
        except Exception as e:
            logger.error(f"Error retrieving models: {str(e)}")
            raise DocumentIntelligenceError(f"Error retrieving models: {str(e)}")
    
    def get_document_analysis_client(self):
        """
        Gets the underlying Azure SDK DocumentAnalysisClient.
        
        Returns:
            The underlying DocumentAnalysisClient.
        """
        return self._analysis_client
    
    def get_model_admin_client(self):
        """
        Gets the underlying Azure SDK DocumentModelAdministrationClient.
        
        Returns:
            The underlying DocumentModelAdministrationClient.
        """
        return self._admin_client 