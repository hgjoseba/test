"""
Azure Document Intelligence Provider.

Este módulo define el proveedor específico de Azure para servicios de inteligencia documental
utilizando peticiones HTTP directas al servicio Azure Document Intelligence.
"""

import os
import sys
import time
import logging
import base64
import requests
from pathlib import Path
from typing import Dict, List, Optional, Any, Union

from .base import DocumentProvider
from ..auth.azure import AzureCredential
from ..models.document import AnalyzedDocument, DocumentModel
from ..models.response import DocumentAnalysisResponse
from ..utils.errors import DocumentIntelligenceError, ModelNotFoundError, ServiceError

# Configuración del logger
logger = logging.getLogger(__name__)

class AzureDocumentProvider(DocumentProvider):
    """
    Proveedor para acceder a los servicios de Azure Document Intelligence usando peticiones HTTP directas.
    
    Esta clase implementa la interfaz DocumentProvider para Azure Document Intelligence.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        api_key: str = None,
        api_version: str = "2023-07-31",
        credential: AzureCredential = None,
        connection_verify: Union[bool, str] = True,
        public_endpoint: str = None,  # Añadir parámetro para el endpoint público
    ):
        """
        Inicializa el proveedor Azure Document Intelligence.
        
        Args:
            endpoint: URL del endpoint de Azure Document Intelligence.
                También puede configurarse mediante la variable de entorno AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT.
            api_key: Clave API de Azure Document Intelligence.
                También puede configurarse mediante la variable de entorno AZURE_DOCUMENT_INTELLIGENCE_KEY.
            api_version: Versión de la API a utilizar. Por defecto: "2023-07-31".
            credential: Objeto AzureCredential para autenticación.
                Si no se proporciona, se utilizará api_key si está disponible.
            connection_verify: Controla la verificación de certificados SSL. False para desactivar la verificación,
                o proporcionar una ruta a un bundle CA para usar. Por defecto: True.
            public_endpoint: URL del endpoint público de Azure Document Intelligence, utilizado en las URLs de respuesta.
                Si se proporciona, se reemplazará automáticamente por el endpoint privado para operaciones de polling.
                También puede configurarse mediante la variable de entorno AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT.
        """
        # Configuración de endpoints
        self.endpoint = endpoint or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
        self.api_key = api_key or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
        self.api_version = api_version
        self.credential = credential
        self.connection_verify = connection_verify
        # Usar el endpoint público proporcionado o la variable de entorno, con fallback al endpoint privado
        self.public_endpoint = public_endpoint or os.getenv("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT", self.endpoint)
        
        # Configuración de proxy
        if self.endpoint:
            private_fqdn = self.endpoint.replace("https://", "")
            os.environ["NO_PROXY"] = private_fqdn
        
        # Validación
        if not self.endpoint:
            raise ValueError("El endpoint debe proporcionarse directamente o a través de una variable de entorno")
        
        if not self.api_key and not self.credential:
            raise ValueError("Debe proporcionarse una clave API o credenciales para la autenticación")
    
    def _get_headers(self) -> Dict[str, str]:
        """
        Obtiene los encabezados de autenticación para las peticiones a la API.
        
        Returns:
            Dict[str, str]: Encabezados de autenticación.
        
        Raises:
            DocumentIntelligenceError: Si falla la autenticación.
        """
        try:
            if self.api_key:
                return {"Ocp-Apim-Subscription-Key": self.api_key}
            elif self.credential:
                # Usar directamente el método get_token de AzureCredential
                token = self.credential.get_token()
                return {"Authorization": f"Bearer {token}"}
            else:
                raise DocumentIntelligenceError("No hay método de autenticación disponible")
        except Exception as e:
            logger.error(f"Error al obtener cabeceras de autenticación: {str(e)}")
            raise DocumentIntelligenceError(f"Error de autenticación: {str(e)}")
    
    def _get_content_type(self, file_path: Path) -> str:
        """
        Determina el tipo de contenido basado en la extensión del archivo.
        Solo soporta PDF y DOCX.
        
        Args:
            file_path: Ruta al archivo.
            
        Returns:
            str: El tipo de contenido del archivo.
        """
        extension = file_path.suffix.lower()
        content_types = {
            ".pdf": "application/pdf",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }
        
        return content_types.get(extension, "application/octet-stream")
    
    def analyze_document(
        self,
        file_path: Union[str, Path],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analiza un documento usando Azure Document Intelligence con llamadas directas a la API.
        
        Si se proporcionó un endpoint público diferente al endpoint privado, el sistema
        reemplazará automáticamente el endpoint público por el privado en la URL de 
        Operation-Location para el polling, permitiendo el acceso a endpoints privados
        con firewalls restrictivos o en redes virtuales.
        
        Args:
            file_path: Ruta al archivo de documento a analizar.
            model_id: ID del modelo a utilizar. Por defecto: "prebuilt-document".
            locale: Localización del idioma del documento. Por defecto: "en".
            pages: Números de página específicos para analizar. Si es None, analiza todas las páginas.
            poll_interval: Intervalo (en segundos) entre cada petición de polling. Por defecto: 5.
            timeout: Tiempo máximo (en segundos) para esperar el resultado. Por defecto: 300.
            **kwargs: Parámetros adicionales para pasar a la API.
            
        Returns:
            DocumentAnalysisResponse: Los resultados del análisis.
            
        Raises:
            DocumentIntelligenceError: Si falla el análisis.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Archivo no encontrado: {file_path}")
        
        # Preparar la URL para el análisis
        analyze_url = f"{self.endpoint}/documentModels/{model_id}:analyze?api-version={self.api_version}"
        logger.info(f"URL de análisis: {analyze_url}")
        
        # Obtener cabeceras de autenticación
        headers = self._get_headers()
        
        # Determinar el tipo de contenido basado en la extensión del archivo
        content_type = self._get_content_type(file_path)
        logger.info(f"Tipo de contenido determinado: {content_type}")
        
        # FASE 1: Enviar solicitud de análisis
        try:
            with open(file_path, "rb") as f:
                files = {"file": (file_path.name, f, content_type)}
                
                # Preparar datos del formulario con opciones
                form_data = {}
                if locale:
                    form_data["locale"] = locale
                if pages:
                    form_data["pages"] = ','.join(map(str, pages))
                # Añadir parámetros adicionales
                form_data.update(kwargs)
                
                response = requests.post(
                    analyze_url,
                    headers=headers,
                    files=files,
                    data=form_data, 
                    timeout=30,
                    verify=self.connection_verify
                )
        except Exception as e:
            logger.error(f"Error al enviar solicitud de análisis: {str(e)}")
            raise DocumentIntelligenceError(f"Error en solicitud: {str(e)}")
        
        # Verificar respuesta
        logger.info(f"Estado de la respuesta: {response.status_code}")
        if response.status_code not in [200, 202]:
            logger.error(f"La solicitud falló: {response.status_code} {response.text}")
            if response.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                raise ServiceError(f"Error del servicio: {response.text}", response.status_code)
        
        # Obtener ubicación de la operación para polling
        op_location = response.headers.get("Operation-Location")
        if not op_location:
            logger.error("No se encontró el encabezado Operation-Location en la respuesta")
            raise DocumentIntelligenceError("Falta el encabezado Operation-Location en la respuesta")
        
        logger.info(f"Operation-Location: {op_location}")
        
        # FASE 2: Realizar polling para obtener resultados
        start_time = time.time()
        
        # Reemplazar endpoint público por privado si es necesario
        if self.public_endpoint and op_location.startswith(self.public_endpoint):
            poll_url = op_location.replace(self.public_endpoint, self.endpoint)
        else:
            poll_url = op_location
            
        logger.info(f"URL de polling: {poll_url}")
        
        # Bucle de polling
        while True:
            try:
                poll_response = requests.get(
                    poll_url,
                    headers=headers,
                    timeout=30,
                    verify=self.connection_verify
                )
            except Exception as e:
                logger.error(f"Error durante el polling: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            if poll_response.status_code != 200:
                logger.error(f"Polling fallido: {poll_response.status_code} {poll_response.text}")
                raise ServiceError(f"Error en polling: {poll_response.text}", poll_response.status_code)
            
            try:
                result_json = poll_response.json()
            except Exception as e:
                logger.error(f"Error al analizar JSON: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            status = result_json.get("status")
            logger.info(f"Estado actual: {status}")
            
            if status in ["running", "notStarted"]:
                if time.time() - start_time > timeout:
                    logger.error("Se superó el tiempo de espera del polling")
                    raise DocumentIntelligenceError("Tiempo de operación agotado")
                time.sleep(poll_interval)
            elif status == "succeeded":
                logger.info("Trabajo de análisis completado con éxito")
                break
            else:
                logger.error(f"Trabajo completado con estado inesperado: {status}")
                raise DocumentIntelligenceError(f"Operación fallida con estado: {status}")
        
        # Convertir el resultado a nuestro modelo de respuesta
        try:
            # Crear una respuesta básica con la información que tenemos
            response = DocumentAnalysisResponse(
                status="succeeded",
                model_id=model_id,
                content=result_json.get("analyzeResult", {}).get("content", ""),
                created_on=result_json.get("createdDateTime"),
                last_updated_on=result_json.get("lastUpdatedDateTime"),
                _raw_data=result_json
            )
            
            # Extraer el resultado del análisis
            analyze_result = result_json.get("analyzeResult", {})
            
            # Establecer páginas, tablas y pares clave-valor si están disponibles
            if "pages" in analyze_result:
                response.pages = analyze_result["pages"]
            if "tables" in analyze_result:
                response.tables = analyze_result["tables"]
            if "keyValuePairs" in analyze_result:
                response.key_value_pairs = analyze_result["keyValuePairs"]
            if "documents" in analyze_result:
                response.documents = analyze_result["documents"]
            
            return response
        except Exception as e:
            logger.error(f"Error al construir respuesta: {str(e)}")
            raise DocumentIntelligenceError(f"Error al procesar resultado: {str(e)}")
    
    def analyze_document_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analiza un documento a partir de datos codificados en base64.
        
        Si se proporcionó un endpoint público diferente al endpoint privado, el sistema
        reemplazará automáticamente el endpoint público por el privado en la URL de 
        Operation-Location para el polling, permitiendo el acceso a endpoints privados
        con firewalls restrictivos o en redes virtuales.
        
        Args:
            base64_string: Datos del documento codificados en base64.
            content_type: Tipo de contenido del documento (p.ej., "application/pdf", "image/jpeg").
            model_id: ID del modelo a utilizar. Por defecto: "prebuilt-document".
            locale: Localización del idioma del documento. Por defecto: "en".
            pages: Números de página específicos para analizar. Si es None, analiza todas las páginas.
            poll_interval: Intervalo (en segundos) entre cada petición de polling. Por defecto: 5.
            timeout: Tiempo máximo (en segundos) para esperar el resultado. Por defecto: 300.
            **kwargs: Parámetros adicionales para pasar a la API.
            
        Returns:
            DocumentAnalysisResponse: Los resultados del análisis.
            
        Raises:
            DocumentIntelligenceError: Si falla el análisis.
        """
        # Preparar la URL para el análisis
        analyze_url = f"{self.endpoint}/documentModels/{model_id}:analyze?api-version={self.api_version}"
        logger.info(f"URL de análisis (base64): {analyze_url}")
        
        # Obtener cabeceras de autenticación
        headers = self._get_headers()
        headers["Content-Type"] = "application/json"
        
        # Preparar el payload
        payload = {
            "base64Source": base64_string,
            "contentType": content_type  # Ensures the content_type is properly included in the API request
        }
        
        # Añadir opciones al payload
        if locale:
            payload["locale"] = locale
        if pages:
            payload["pages"] = pages
        
        # Añadir parámetros adicionales
        for key, value in kwargs.items():
            if key != "content_type":  # Avoid collisions with content_type
                payload[key] = value
        
        # FASE 1: Enviar solicitud de análisis
        try:
            response = requests.post(
                analyze_url,
                headers=headers,
                json=payload,
                timeout=30,
                verify=self.connection_verify
            )
        except Exception as e:
            logger.error(f"Error al enviar solicitud base64: {str(e)}")
            raise DocumentIntelligenceError(f"Error en solicitud base64: {str(e)}")
        
        # Verificar respuesta
        logger.info(f"Estado de la respuesta base64: {response.status_code}")
        if response.status_code not in [200, 202]:
            logger.error(f"La solicitud base64 falló: {response.status_code} {response.text}")
            if response.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                raise ServiceError(f"Error del servicio: {response.text}", response.status_code)
        
        # Obtener ubicación de la operación para polling
        op_location = response.headers.get("Operation-Location")
        if not op_location:
            logger.error("No se encontró el encabezado Operation-Location en la respuesta base64")
            raise DocumentIntelligenceError("Falta el encabezado Operation-Location en la respuesta")
        
        logger.info(f"Operation-Location (base64): {op_location}")
        
        # FASE 2: Realizar polling para obtener resultados (idéntico al método anterior)
        start_time = time.time()
        
        # Reemplazar endpoint público por privado si es necesario
        if self.public_endpoint and op_location.startswith(self.public_endpoint):
            poll_url = op_location.replace(self.public_endpoint, self.endpoint)
        else:
            poll_url = op_location
            
        logger.info(f"URL de polling (base64): {poll_url}")
        
        # Bucle de polling
        while True:
            try:
                poll_response = requests.get(
                    poll_url,
                    headers=headers,
                    timeout=30,
                    verify=self.connection_verify
                )
            except Exception as e:
                logger.error(f"Error durante el polling base64: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            if poll_response.status_code != 200:
                logger.error(f"Polling base64 fallido: {poll_response.status_code} {poll_response.text}")
                raise ServiceError(f"Error en polling base64: {poll_response.text}", poll_response.status_code)
            
            try:
                result_json = poll_response.json()
            except Exception as e:
                logger.error(f"Error al analizar JSON base64: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            status = result_json.get("status")
            logger.info(f"Estado actual base64: {status}")
            
            if status in ["running", "notStarted"]:
                if time.time() - start_time > timeout:
                    logger.error("Se superó el tiempo de espera del polling base64")
                    raise DocumentIntelligenceError("Tiempo de operación agotado")
                time.sleep(poll_interval)
            elif status == "succeeded":
                logger.info("Trabajo de análisis base64 completado con éxito")
                break
            else:
                logger.error(f"Trabajo base64 completado con estado inesperado: {status}")
                raise DocumentIntelligenceError(f"Operación fallida con estado: {status}")
        
        # Convertir el resultado a nuestro modelo de respuesta (igual que en analyze_document)
        try:
            # Crear una respuesta básica con la información que tenemos
            response = DocumentAnalysisResponse(
                status="succeeded",
                model_id=model_id,
                content=result_json.get("analyzeResult", {}).get("content", ""),
                created_on=result_json.get("createdDateTime"),
                last_updated_on=result_json.get("lastUpdatedDateTime"),
                _raw_data=result_json
            )
            
            # Extraer el resultado del análisis
            analyze_result = result_json.get("analyzeResult", {})
            
            # Establecer páginas, tablas y pares clave-valor si están disponibles
            if "pages" in analyze_result:
                response.pages = analyze_result["pages"]
            if "tables" in analyze_result:
                response.tables = analyze_result["tables"]
            if "keyValuePairs" in analyze_result:
                response.key_value_pairs = analyze_result["keyValuePairs"]
            if "documents" in analyze_result:
                response.documents = analyze_result["documents"]
            
            return response
        except Exception as e:
            logger.error(f"Error al construir respuesta base64: {str(e)}")
            raise DocumentIntelligenceError(f"Error al procesar resultado base64: {str(e)}")
    
    def list_models(self) -> List[DocumentModel]:
        """
        Lista los modelos disponibles en Azure Document Intelligence.
        
        Si se proporcionó un endpoint público diferente al endpoint privado, el sistema
        reemplazará automáticamente el endpoint público por el privado en cualquier URL de 
        respuesta para operaciones subsiguientes.
        
        Returns:
            List[DocumentModel]: Lista de modelos disponibles.
            
        Raises:
            DocumentIntelligenceError: Si falla la obtención de la lista.
        """
        # Preparar la URL para listar modelos
        list_url = f"{self.endpoint}/models?api-version={self.api_version}"
        logger.info(f"URL para listar modelos: {list_url}")
        
        # Obtener cabeceras de autenticación
        headers = self._get_headers()
        
        # Enviar solicitud
        try:
            response = requests.get(
                list_url,
                headers=headers,
                timeout=30,
                verify=self.connection_verify
            )
        except Exception as e:
            logger.error(f"Error al listar modelos: {str(e)}")
            raise DocumentIntelligenceError(f"Error en solicitud: {str(e)}")
        
        # Verificar respuesta
        if response.status_code != 200:
            logger.error(f"La solicitud falló: {response.status_code} {response.text}")
            raise ServiceError(f"Error del servicio: {response.text}", response.status_code)
        
        try:
            data = response.json()
            models = []
            for model_data in data.get("value", []):
                model = DocumentModel.from_azure_model(model_data)
                models.append(model)
            return models
        except Exception as e:
            logger.error(f"Error al procesar la respuesta: {str(e)}")
            raise DocumentIntelligenceError(f"Error al procesar la respuesta: {str(e)}")

    def analyze_documents_batch(
        self,
        file_paths: List[Union[str, Path]],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        max_concurrent_requests: int = 5,
        **kwargs,
    ) -> Dict[str, DocumentAnalysisResponse]:
        """
        Analyzes multiple documents in batch using Azure Document Intelligence.
        
        Si se proporcionó un endpoint público diferente al endpoint privado, el sistema
        reemplazará automáticamente el endpoint público por el privado en la URL de 
        Operation-Location para el polling, permitiendo el acceso a endpoints privados
        con firewalls restrictivos o en redes virtuales.
        
        Args:
            file_paths: List of paths to document files to analyze.
            model_id: ID of the model to use. Default: "prebuilt-document".
            locale: Language locale of the documents. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Default: 5.
            timeout: Maximum time (in seconds) to wait for each document result. Default: 300.
            max_concurrent_requests: Maximum number of concurrent requests. Default: 5.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            Dict[str, DocumentAnalysisResponse]: Dictionary with file paths as keys and analysis results as values.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        import concurrent.futures
        
        # Verify that there are files to process
        if not file_paths:
            logger.warning("No files provided for batch analysis")
            return {}
        
        # Convert all paths to Path objects and verify existence
        paths = []
        for path in file_paths:
            p = Path(path)
            if not p.exists():
                logger.warning(f"File not found, will be skipped: {p}")
            else:
                paths.append(p)
        
        if not paths:
            logger.warning("None of the provided files exist")
            return {}
        
        logger.info(f"Starting batch analysis of {len(paths)} documents")
        
        # Function to process a single document
        def process_document(file_path):
            try:
                result = self.analyze_document(
                    file_path=file_path,
                    model_id=model_id,
                    locale=locale,
                    pages=pages,
                    poll_interval=poll_interval,
                    timeout=timeout,
                    **kwargs
                )
                return str(file_path), result
            except Exception as e:
                logger.error(f"Error processing {file_path}: {str(e)}")
                return str(file_path), None
        
        # Process documents with ThreadPoolExecutor for parallelism
        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_concurrent_requests) as executor:
            # Start tasks and get results as they complete
            future_to_path = {executor.submit(process_document, path): path for path in paths}
            
            for future in concurrent.futures.as_completed(future_to_path):
                path = future_to_path[future]
                try:
                    file_path, result = future.result()
                    if result:
                        results[file_path] = result
                        logger.info(f"Document successfully processed: {path}")
                    else:
                        logger.warning(f"Could not process document: {path}")
                except Exception as e:
                    logger.error(f"Error getting result for {path}: {str(e)}")
        
        logger.info(f"Batch analysis completed. Processed: {len(results)}/{len(paths)} documents")
        return results
        
    def analyze_documents_batch_from_base64(
        self,
        documents: List[Dict[str, str]],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        max_concurrent_requests: int = 5,
        **kwargs,
    ) -> Dict[str, DocumentAnalysisResponse]:
        """
        Analyzes multiple documents in batch from base64 encoded data.
        
        Si se proporcionó un endpoint público diferente al endpoint privado, el sistema
        reemplazará automáticamente el endpoint público por el privado en la URL de 
        Operation-Location para el polling, permitiendo el acceso a endpoints privados
        con firewalls restrictivos o en redes virtuales.
        
        Args:
            documents: List of dictionaries with at least 'base64_string' and 'content_type' keys.
            model_id: ID of the model to use. Default: "prebuilt-document".
            locale: Language locale of the documents. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Default: 5.
            timeout: Maximum time (in seconds) to wait for each document result. Default: 300.
            max_concurrent_requests: Maximum number of concurrent requests. Default: 5.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            Dict[str, DocumentAnalysisResponse]: Dictionary with document identifiers as keys and analysis results as values.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        import concurrent.futures
        
        # Verify that there are documents to process
        if not documents:
            logger.warning("No documents provided for batch analysis")
            return {}
        
        # Validate document dictionaries
        valid_documents = []
        for idx, doc in enumerate(documents):
            doc_id = doc.get('id', f"document_{idx}")
            if 'base64_string' not in doc:
                logger.warning(f"Document {doc_id} is missing 'base64_string' field, it will be skipped")
                continue
            if 'content_type' not in doc:
                logger.warning(f"Document {doc_id} is missing 'content_type' field, it will be skipped")
                continue
            
            # Add document ID if not provided
            if 'id' not in doc:
                doc['id'] = doc_id
                
            valid_documents.append(doc)
        
        if not valid_documents:
            logger.warning("No valid documents provided for batch analysis")
            return {}
        
        logger.info(f"Starting batch analysis of {len(valid_documents)} base64 documents")
        
        # Function to process a single document
        def process_document(doc):
            doc_id = doc['id']
            try:
                result = self.analyze_document_from_base64(
                    base64_string=doc['base64_string'],
                    content_type=doc['content_type'],
                    model_id=model_id,
                    locale=locale,
                    pages=pages,
                    poll_interval=poll_interval,
                    timeout=timeout,
                    **kwargs
                )
                return doc_id, result
            except Exception as e:
                logger.error(f"Error processing document {doc_id}: {str(e)}")
                return doc_id, None
        
        # Process documents with ThreadPoolExecutor for parallelism
        results = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_concurrent_requests) as executor:
            # Start tasks and get results as they complete
            future_to_doc = {executor.submit(process_document, doc): doc for doc in valid_documents}
            
            for future in concurrent.futures.as_completed(future_to_doc):
                doc = future_to_doc[future]
                doc_id = doc['id']
                try:
                    doc_key, result = future.result()
                    if result:
                        results[doc_key] = result
                        logger.info(f"Document successfully processed: {doc_id}")
                    else:
                        logger.warning(f"Could not process document: {doc_id}")
                except Exception as e:
                    logger.error(f"Error getting result for document {doc_id}: {str(e)}")
        
        logger.info(f"Batch analysis completed. Processed: {len(results)}/{len(valid_documents)} documents")
        return results 