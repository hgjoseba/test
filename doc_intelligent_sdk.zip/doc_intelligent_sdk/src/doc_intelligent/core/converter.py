"""
Document converter module for document format conversions.

This module provides the DocumentConverter class for converting
between different document formats and extracting structured data.
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Union, Any

from ..models.document import AnalyzedDocument
from ..utils.errors import DocumentIntelligenceError
from ..utils.logging import get_logger

logger = get_logger(__name__)


class DocumentConverter:
    """
    Document converter for handling document format conversions.
    
    This class provides methods for converting document analysis results
    to various formats like JSON, CSV, and structured data.
    """
    
    def __init__(self):
        """Initialize the document converter."""
        pass
    
    def to_json(self, document: AnalyzedDocument, output_path: Optional[Union[str, Path]] = None) -> str:
        """
        Convert an analyzed document to JSON format.
        
        Args:
            document: The analyzed document to convert.
            output_path: Optional path to save the JSON output.
            
        Returns:
            str: The JSON string representation of the document.
        """
        # Convert document to dictionary and then to JSON
        doc_dict = document.dict(exclude_none=True)
        json_str = json.dumps(doc_dict, indent=2, default=str)
        
        # Save to file if output path is provided
        if output_path:
            output_path = Path(output_path)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(json_str)
                
        return json_str
    
    def to_text(self, document: AnalyzedDocument, output_path: Optional[Union[str, Path]] = None) -> str:
        """
        Extract plain text from an analyzed document.
        
        Args:
            document: The analyzed document to convert.
            output_path: Optional path to save the text output.
            
        Returns:
            str: The extracted text content.
        """
        text_content = document.get_text()
        
        # Save to file if output path is provided
        if output_path:
            output_path = Path(output_path)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(text_content)
                
        return text_content
    
    def to_key_value_dict(self, document: AnalyzedDocument) -> Dict[str, str]:
        """
        Convert key-value pairs to a dictionary.
        
        Args:
            document: The analyzed document containing key-value pairs.
            
        Returns:
            Dict[str, str]: Dictionary of key-value pairs.
        """
        kv_dict = {}
        for kv in document.key_value_pairs:
            kv_dict[kv.key] = kv.value
            
        return kv_dict
    
    def to_csv(self, document: AnalyzedDocument, output_path: Union[str, Path]) -> str:
        """
        Convert tables in a document to CSV format.
        
        Args:
            document: The analyzed document containing tables.
            output_path: Path to save the CSV output.
            
        Returns:
            str: Path to the saved CSV file(s).
        """
        import csv
        
        output_path = Path(output_path)
        output_dir = output_path.parent
        base_name = output_path.stem
        
        # Create directory if it doesn't exist
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Process each table
        file_paths = []
        for i, table in enumerate(document.tables):
            # Create a matrix representing the table
            rows = table.row_count
            cols = table.column_count
            matrix = [['' for _ in range(cols)] for _ in range(rows)]
            
            # Fill the matrix with cell values
            for cell in table.cells:
                row_idx = cell.row_index
                col_idx = cell.column_index
                matrix[row_idx][col_idx] = cell.text
            
            # Write to CSV
            if len(document.tables) > 1:
                # If multiple tables, use numbered filenames
                csv_path = output_dir / f"{base_name}_table_{i+1}.csv"
            else:
                csv_path = output_path
                
            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerows(matrix)
                
            file_paths.append(str(csv_path))
        
        return file_paths[0] if len(file_paths) == 1 else file_paths 