"""
Document processor module for handling document analysis.

This module contains the DocumentProcessor class which handles
the processing and analysis of documents using Azure's Document Intelligence.
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Union, Any

from ..models.document import AnalyzedDocument
from ..utils.errors import DocumentIntelligenceError, DocumentTypeError
from ..utils.logging import get_logger

logger = get_logger(__name__)


class DocumentProcessor:
    """
    Document processor for handling document analysis.
    
    This class provides methods for processing different types of documents
    and preparing them for analysis by the Document Intelligence service.
    """
    
    # Supported file extensions
    SUPPORTED_EXTENSIONS = [
        ".pdf", ".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".tif", ".docx"
    ]
    
    def __init__(self):
        """Initialize the document processor."""
        pass
        
    def validate_document(self, file_path: Union[str, Path]) -> Path:
        """
        Validate a document file.
        
        Args:
            file_path: Path to the document file.
            
        Returns:
            Path: The validated file path.
            
        Raises:
            FileNotFoundError: If the file does not exist.
            DocumentTypeError: If the file type is not supported.
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"Document file not found: {file_path}")
        
        if file_path.suffix.lower() not in self.SUPPORTED_EXTENSIONS:
            raise DocumentTypeError(file_path.suffix)
        
        return file_path
    
    def get_content_type(self, file_path: Path) -> str:
        """
        Get the content type for a document file.
        
        Args:
            file_path: Path to the document file.
            
        Returns:
            str: The content type string.
        """
        extension = file_path.suffix.lower()
        content_types = {
            ".pdf": "application/pdf",
            ".jpeg": "image/jpeg",
            ".jpg": "image/jpeg",
            ".png": "image/png",
            ".bmp": "image/bmp",
            ".tiff": "image/tiff",
            ".tif": "image/tiff",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }
        
        return content_types.get(extension, "application/octet-stream")
    
    def prepare_document(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """
        Prepare a document for analysis.
        
        This method validates the document and prepares it for submission
        to the Document Intelligence service.
        
        Args:
            file_path: Path to the document file.
            
        Returns:
            Dict[str, Any]: A dictionary with the prepared document data.
        """
        file_path = self.validate_document(file_path)
        
        # Get file content
        with open(file_path, "rb") as f:
            content = f.read()
            
        # Prepare document data
        document_data = {
            "file_name": file_path.name,
            "content_type": self.get_content_type(file_path),
            "content": content,
            "size_bytes": len(content),
        }
        
        return document_data 