"""
Batch processing module for Document Intelligence SDK.

This module provides functionality for processing multiple documents
in batch mode, either sequentially or in parallel.
"""

import time
import os
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Any, Callable, Optional, Union, Tuple
from pathlib import Path

from ..models.document import AnalyzedDocument
from ..models.response import DocumentAnalysisResponse
from ..utils.errors import DocumentIntelligenceError

logger = logging.getLogger(__name__)


class BatchProcessor:
    """
    Batch processor for analyzing multiple documents efficiently.
    
    This class provides functionality to process multiple documents
    either sequentially or in parallel, with detailed results tracking.
    """
    
    def __init__(
        self,
        client: Any,
        max_workers: int = 5,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        on_success_callback: Optional[Callable] = None,
        on_error_callback: Optional[Callable] = None
    ):
        """
        Initialize the batch processor.
        
        Args:
            client: The DocIntelligenceClient instance to use for document analysis
            max_workers: Maximum number of parallel workers when using parallel processing
            model_id: ID of the model to use for document analysis
            locale: Language locale for document analysis
            on_success_callback: Optional callback function called when a document is successfully processed
                The callback receives (file_path, document_result) as parameters
            on_error_callback: Optional callback function called when a document processing fails
                The callback receives (file_path, error_message) as parameters
        """
        self.client = client
        self.max_workers = max_workers
        self.model_id = model_id
        self.locale = locale
        self.on_success_callback = on_success_callback
        self.on_error_callback = on_error_callback
    
    def _process_single_document(
        self, 
        file_path: Union[str, Path], 
        **kwargs
    ) -> Tuple[str, Optional[AnalyzedDocument], Optional[str]]:
        """
        Process a single document and return its result.
        
        Args:
            file_path: Path to the document file
            **kwargs: Additional parameters to pass to analyze_document
            
        Returns:
            Tuple of (file_path, document, error_message)
            If successful, error_message will be None
            If failed, document will be None
        """
        file_path_str = str(file_path)
        try:
            # Call the client's analyze_document method
            result = self.client.analyze_document(
                file_path=file_path,
                model_id=kwargs.get('model_id', self.model_id),
                locale=kwargs.get('locale', self.locale),
                **{k: v for k, v in kwargs.items() if k not in ['model_id', 'locale']}
            )
            
            # Get the analyzed document
            document = result.get_analyzed_document()
            if not document:
                error_message = "Analysis completed but no document was returned"
                if self.on_error_callback:
                    self.on_error_callback(file_path_str, error_message)
                return file_path_str, None, error_message
            
            # Call success callback if provided
            if self.on_success_callback:
                self.on_success_callback(file_path_str, document)
                
            return file_path_str, document, None
            
        except Exception as e:
            error_message = str(e)
            logger.error(f"Error processing document {file_path_str}: {error_message}")
            
            # Call error callback if provided
            if self.on_error_callback:
                self.on_error_callback(file_path_str, error_message)
                
            return file_path_str, None, error_message
    
    def process_sequential(
        self, 
        document_paths: List[Union[str, Path]], 
        **kwargs
    ) -> Dict[str, Any]:
        """
        Process multiple documents sequentially.
        
        Args:
            document_paths: List of paths to documents to process
            **kwargs: Additional parameters to pass to analyze_document
            
        Returns:
            Dictionary with detailed results and statistics
        """
        start_time = time.time()
        results = {}
        successful_count = 0
        failed_count = 0
        errors = {}
        
        for path in document_paths:
            path_str = str(path)
            file_path, document, error_message = self._process_single_document(path, **kwargs)
            
            if error_message:
                failed_count += 1
                errors[path_str] = error_message
            else:
                successful_count += 1
                results[path_str] = document
        
        processing_time = time.time() - start_time
        
        return {
            "mode": "sequential",
            "total_documents": len(document_paths),
            "successful_count": successful_count,
            "failed_count": failed_count,
            "processing_time_seconds": processing_time,
            "avg_time_per_document": processing_time / len(document_paths) if document_paths else 0,
            "results": results,
            "errors": errors
        }
    
    def process_parallel(
        self, 
        document_paths: List[Union[str, Path]], 
        **kwargs
    ) -> Dict[str, Any]:
        """
        Process multiple documents in parallel.
        
        Args:
            document_paths: List of paths to documents to process
            **kwargs: Additional parameters to pass to analyze_document
            
        Returns:
            Dictionary with detailed results and statistics
        """
        start_time = time.time()
        results = {}
        successful_count = 0
        failed_count = 0
        errors = {}
        
        # Adjust max_workers to not exceed document count
        actual_workers = min(self.max_workers, len(document_paths))
        
        with ThreadPoolExecutor(max_workers=actual_workers) as executor:
            # Create a future for each document
            future_to_path = {
                executor.submit(self._process_single_document, path, **kwargs): path
                for path in document_paths
            }
            
            # Process results as they complete
            for future in as_completed(future_to_path):
                path = future_to_path[future]
                path_str = str(path)
                
                try:
                    _, document, error_message = future.result()
                    
                    if error_message:
                        failed_count += 1
                        errors[path_str] = error_message
                    else:
                        successful_count += 1
                        results[path_str] = document
                        
                except Exception as e:
                    failed_count += 1
                    errors[path_str] = str(e)
        
        processing_time = time.time() - start_time
        
        return {
            "mode": "parallel",
            "max_workers": actual_workers,
            "total_documents": len(document_paths),
            "successful_count": successful_count,
            "failed_count": failed_count,
            "processing_time_seconds": processing_time,
            "avg_time_per_document": processing_time / len(document_paths) if document_paths else 0,
            "results": results,
            "errors": errors
        }
        
    def process_directory(
        self,
        directory_path: Union[str, Path],
        extensions: List[str] = None,
        recursive: bool = False,
        parallel: bool = True,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Process all documents in a directory.
        
        Args:
            directory_path: Path to directory containing documents
            extensions: List of file extensions to include (e.g., ['.pdf', '.jpg'])
                If None, includes common document formats
            recursive: Whether to search subdirectories
            parallel: Whether to use parallel processing
            **kwargs: Additional parameters to pass to analyze_document
            
        Returns:
            Dictionary with detailed results and statistics
        """
        directory = Path(directory_path)
        if not directory.exists() or not directory.is_dir():
            raise ValueError(f"Directory not found: {directory}")
        
        # Default extensions if none provided
        if extensions is None:
            extensions = ['.pdf', '.jpg', '.jpeg', '.png', '.tiff', '.tif', '.bmp', '.docx']
            
        # Find all matching files
        document_paths = []
        
        if recursive:
            for ext in extensions:
                document_paths.extend(directory.glob(f'**/*{ext}'))
        else:
            for ext in extensions:
                document_paths.extend(directory.glob(f'*{ext}'))
        
        if not document_paths:
            logger.warning(f"No documents with extensions {extensions} found in {directory}")
            return {
                "mode": "parallel" if parallel else "sequential",
                "directory": str(directory),
                "extensions": extensions,
                "total_documents": 0,
                "successful_count": 0,
                "failed_count": 0,
                "results": {},
                "errors": {}
            }
        
        # Process the documents
        if parallel:
            return self.process_parallel(document_paths, **kwargs)
        else:
            return self.process_sequential(document_paths, **kwargs)


# Convenience functions for batch processing

def batch_process_documents(
    client: Any,
    document_paths: List[Union[str, Path]],
    parallel: bool = True,
    max_workers: int = 5,
    model_id: str = "prebuilt-document",
    **kwargs
) -> Dict[str, Any]:
    """
    Process multiple documents in batch mode.
    
    Args:
        client: DocIntelligenceClient instance
        document_paths: List of paths to documents to process
        parallel: Whether to use parallel processing
        max_workers: Maximum number of parallel workers (if parallel=True)
        model_id: ID of the model to use
        **kwargs: Additional parameters to pass to analyze_document
        
    Returns:
        Dictionary with detailed results and statistics
    """
    processor = BatchProcessor(
        client=client,
        max_workers=max_workers,
        model_id=model_id
    )
    
    if parallel:
        return processor.process_parallel(document_paths, **kwargs)
    else:
        return processor.process_sequential(document_paths, **kwargs)


def batch_process_directory(
    client: Any,
    directory_path: Union[str, Path],
    extensions: List[str] = None,
    recursive: bool = False,
    parallel: bool = True,
    max_workers: int = 5,
    model_id: str = "prebuilt-document",
    **kwargs
) -> Dict[str, Any]:
    """
    Process all documents in a directory in batch mode.
    
    Args:
        client: DocIntelligenceClient instance
        directory_path: Path to directory containing documents
        extensions: List of file extensions to include (e.g., ['.pdf', '.jpg'])
        recursive: Whether to search subdirectories
        parallel: Whether to use parallel processing
        max_workers: Maximum number of parallel workers (if parallel=True)
        model_id: ID of the model to use
        **kwargs: Additional parameters to pass to analyze_document
        
    Returns:
        Dictionary with detailed results and statistics
    """
    processor = BatchProcessor(
        client=client,
        max_workers=max_workers,
        model_id=model_id
    )
    
    return processor.process_directory(
        directory_path=directory_path,
        extensions=extensions,
        recursive=recursive,
        parallel=parallel,
        **kwargs
    ) 