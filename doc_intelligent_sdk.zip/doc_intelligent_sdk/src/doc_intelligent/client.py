"""
Client module for the Document Intelligence SDK.

This module provides the main client class for interacting with
Azure Document Intelligence services.
"""

from typing import Dict, List, Optional, Union, Any, Callable
from pathlib import Path

from .providers.azure import AzureDocumentProvider
from .auth.azure import AzureCredential
from .models.document import DocumentModel
from .models.response import DocumentAnalysisResponse
from .core.batch import BatchProcessor
from .utils.errors import DocumentIntelligenceError
from .utils.logging import get_logger

logger = get_logger(__name__)

class DocIntelligenceClient:
    """
    Client for accessing Document Intelligence services.
    
    This client provides methods for analyzing documents, extracting text,
    tables, key-value pairs, and other information from various document types.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        api_key: str = None,
        api_version: str = "2023-07-31",
        credential: AzureCredential = None,
        connection_verify: Union[bool, str] = True,
        provider: str = "azure",
    ):
        """
        Initialize the Document Intelligence client.
        
        Args:
            endpoint: Document Intelligence endpoint URL.
                Can also be set via environment variable.
            api_key: Document Intelligence API key.
                Can also be set via environment variable.
            api_version: API version to use. Defaults to "2023-07-31".
            credential: Credential object for authentication.
                If not provided, will use api_key if available.
            connection_verify: Controls SSL certificate verification. Set to False to disable verification,
                or provide a path to a CA bundle to use. Defaults to True.
            provider: Provider to use. Currently supports "azure" only.
        """
        self.provider_name = provider.lower()
        self.endpoint = endpoint
        self.api_key = api_key
        self.api_version = api_version
        self.credential = credential
        self.connection_verify = connection_verify
        
        # Initialize the appropriate provider
        if self.provider_name == "azure":
            self.provider = AzureDocumentProvider(
                endpoint=endpoint,
                api_key=api_key,
                api_version=api_version,
                credential=credential,
                connection_verify=connection_verify
            )
        else:
            raise ValueError(f"Unsupported provider: {provider}. Currently only 'azure' is supported.")
    
    def analyze_document(
        self,
        file_path: Union[str, Path],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document.
        
        Args:
            file_path: Path to the document file to analyze.
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the document. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the provider.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        return self.provider.analyze_document(
            file_path=file_path,
            model_id=model_id,
            locale=locale,
            pages=pages,
            **kwargs
        )
    
    def analyze_document_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document from base64 encoded data.
        
        Args:
            base64_string: Base64 encoded document data.
            content_type: Content type of the document (e.g., "application/pdf", "image/jpeg").
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the document. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the provider.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        return self.provider.analyze_document_from_base64(
            base64_string=base64_string,
            content_type=content_type,
            model_id=model_id,
            locale=locale,
            pages=pages,
            **kwargs
        )
    
    def list_models(self) -> List[DocumentModel]:
        """
        List available document models.
        
        Returns:
            List of available DocumentModel objects.
        """
        return self.provider.list_models()
    
    def get_provider(self):
        """
        Get the underlying provider.
        
        Returns:
            The provider instance being used by this client.
        """
        return self.provider
        
    def create_batch_processor(
        self,
        max_workers: int = 5,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        on_success_callback: Optional[Callable] = None,
        on_error_callback: Optional[Callable] = None
    ) -> BatchProcessor:
        """
        Create a batch processor for analyzing multiple documents.
        
        Args:
            max_workers: Maximum number of parallel workers when using parallel processing.
            model_id: ID of the model to use for document analysis.
            locale: Language locale for document analysis.
            on_success_callback: Optional callback function called when a document is successfully processed.
                The callback receives (file_path, document_result) as parameters.
            on_error_callback: Optional callback function called when a document processing fails.
                The callback receives (file_path, error_message) as parameters.
                
        Returns:
            BatchProcessor: A batch processor instance configured with this client.
        """
        return BatchProcessor(
            client=self,
            max_workers=max_workers,
            model_id=model_id,
            locale=locale,
            on_success_callback=on_success_callback,
            on_error_callback=on_error_callback
        )
    
    def batch_analyze_documents(
        self,
        document_paths: List[Union[str, Path]],
        parallel: bool = True,
        max_workers: int = 5,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Analyze multiple documents in batch mode.
        
        Args:
            document_paths: List of paths to documents to process.
            parallel: Whether to use parallel processing. Defaults to True.
            max_workers: Maximum number of parallel workers if using parallel processing.
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the documents. Defaults to "en".
            **kwargs: Additional parameters to pass to analyze_document.
            
        Returns:
            Dictionary with detailed results and statistics.
        """
        processor = self.create_batch_processor(
            max_workers=max_workers,
            model_id=model_id,
            locale=locale
        )
        
        if parallel:
            return processor.process_parallel(document_paths, **kwargs)
        else:
            return processor.process_sequential(document_paths, **kwargs)
    
    def batch_analyze_directory(
        self,
        directory_path: Union[str, Path],
        extensions: List[str] = None,
        recursive: bool = False,
        parallel: bool = True,
        max_workers: int = 5,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Analyze all documents in a directory in batch mode.
        
        Args:
            directory_path: Path to directory containing documents.
            extensions: List of file extensions to include (e.g., ['.pdf', '.jpg']).
                If None, includes common document formats.
            recursive: Whether to search subdirectories. Defaults to False.
            parallel: Whether to use parallel processing. Defaults to True.
            max_workers: Maximum number of parallel workers if using parallel processing.
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the documents. Defaults to "en".
            **kwargs: Additional parameters to pass to analyze_document.
            
        Returns:
            Dictionary with detailed results and statistics.
        """
        processor = self.create_batch_processor(
            max_workers=max_workers,
            model_id=model_id,
            locale=locale
        )
        
        return processor.process_directory(
            directory_path=directory_path,
            extensions=extensions,
            recursive=recursive,
            parallel=parallel,
            **kwargs
        )
        
    def analyze_documents_batch(
        self,
        file_paths: List[Union[str, Path]],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        max_concurrent_requests: int = 5,
        **kwargs,
    ) -> Dict[str, DocumentAnalysisResponse]:
        """
        Analyze multiple documents in batch using the provider's optimized batch implementation.
        
        This method uses the provider's native batch processing capability, which may be more 
        efficient than the BatchProcessor for certain providers.
        
        Args:
            file_paths: List of paths to document files to analyze.
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the documents. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Defaults to 5.
            timeout: Maximum time (in seconds) to wait for each document result. Defaults to 300.
            max_concurrent_requests: Maximum number of concurrent requests. Defaults to 5.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            Dict[str, DocumentAnalysisResponse]: Dictionary with file paths as keys and analysis results as values.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        return self.provider.analyze_documents_batch(
            file_paths=file_paths,
            model_id=model_id,
            locale=locale,
            pages=pages,
            poll_interval=poll_interval,
            timeout=timeout,
            max_concurrent_requests=max_concurrent_requests,
            **kwargs
        )
        
    def analyze_documents_batch_from_base64(
        self,
        documents: List[Dict[str, str]],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[List[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        max_concurrent_requests: int = 5,
        **kwargs,
    ) -> Dict[str, DocumentAnalysisResponse]:
        """
        Analyze multiple documents in batch using base64 encoded data.
        
        This method allows processing multiple documents provided as base64 encoded strings,
        which is useful when documents are not available as local files but as data in memory.
        
        Args:
            documents: List of dictionaries with at least 'base64_string' and 'content_type' keys.
                Each dictionary may also contain an 'id' key to identify the document in results.
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the documents. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Defaults to 5.
            timeout: Maximum time (in seconds) to wait for each document result. Defaults to 300.
            max_concurrent_requests: Maximum number of concurrent requests. Defaults to 5.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            Dict[str, DocumentAnalysisResponse]: Dictionary with document identifiers as keys and analysis results as values.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        return self.provider.analyze_documents_batch_from_base64(
            documents=documents,
            model_id=model_id,
            locale=locale,
            pages=pages,
            poll_interval=poll_interval,
            timeout=timeout,
            max_concurrent_requests=max_concurrent_requests,
            **kwargs
        ) 