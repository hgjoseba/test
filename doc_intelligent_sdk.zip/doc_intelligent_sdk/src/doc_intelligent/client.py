"""
Client module for the Document Intelligence SDK (OCR version).

This module provides a simplified client class for extracting text from documents
using Azure Document Intelligence services.
"""

from typing import Optional, Union
from pathlib import Path

from .providers.azure import AzureDocumentProvider
from .auth.azure import AzureCredential
from .models.response import DocumentAnalysisResponse
from .utils.errors import DocumentIntelligenceError
from .utils.logging import get_logger

logger = get_logger(__name__)

class DocIntelligenceClient:
    """
    Simplified OCR client for extracting text from documents.
    
    This client provides methods for analyzing documents and extracting plain text
    from various document types.
    """
    
    def __init__(
        self,
        endpoint: str = None,
        api_key: str = None,
        api_version: str = "2023-07-31",
        credential: AzureCredential = None,
        connection_verify: Union[bool, str] = True,
        provider: str = "azure",
    ):
        """
        Initialize the Document Intelligence OCR client.
        
        Args:
            endpoint: Document Intelligence endpoint URL.
                Can also be set via environment variable.
            api_key: Document Intelligence API key.
                Can also be set via environment variable.
            api_version: API version to use. Defaults to "2023-07-31".
            credential: Credential object for authentication.
                If not provided, will use api_key if available.
            connection_verify: Controls SSL certificate verification. Set to False to disable verification,
                or provide a path to a CA bundle to use. Defaults to True.
            provider: Provider to use. Currently supports "azure" only.
        """
        self.provider_name = provider.lower()
        self.endpoint = endpoint
        self.api_key = api_key
        self.api_version = api_version
        self.credential = credential
        self.connection_verify = connection_verify
        
        # Initialize the appropriate provider
        if self.provider_name == "azure":
            self.provider = AzureDocumentProvider(
                endpoint=endpoint,
                api_key=api_key,
                api_version=api_version,
                credential=credential,
                connection_verify=connection_verify
            )
        else:
            raise ValueError(f"Unsupported provider: {provider}. Currently only 'azure' is supported.")
    
    def analyze_document(
        self,
        file_path: Union[str, Path],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document and extract text.
        
        Args:
            file_path: Path to the document file to analyze.
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the document. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the provider.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        return self.provider.analyze_document(
            file_path=file_path,
            model_id=model_id,
            locale=locale,
            pages=pages,
            **kwargs
        )
    
    def analyze_document_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document from base64 encoded data and extract text.
        
        Args:
            base64_string: Base64 encoded document data.
            content_type: Content type of the document (e.g., "application/pdf", "image/jpeg").
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the document. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the provider.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        return self.provider.analyze_document_from_base64(
            base64_string=base64_string,
            content_type=content_type,
            model_id=model_id,
            locale=locale,
            pages=pages,
            **kwargs
        )
    
    def extract_text(
        self,
        file_path: Union[str, Path],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        **kwargs,
    ) -> str:
        """
        Extract plain text from a document.
        
        This is a convenience method that analyzes a document and returns only the extracted text.
        
        Args:
            file_path: Path to the document file to analyze.
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the document. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the provider.
            
        Returns:
            str: The extracted text content.
            
        Raises:
            DocumentIntelligenceError: If the text extraction fails.
        """
        response = self.analyze_document(
            file_path=file_path,
            model_id=model_id,
            locale=locale,
            pages=pages,
            **kwargs
        )
        
        document = response.get_analyzed_document()
        if document:
            return document.get_text()
        else:
            raise DocumentIntelligenceError("Failed to extract text from document")
    
    def extract_text_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        **kwargs,
    ) -> str:
        """
        Extract plain text from a base64 encoded document.
        
        This is a convenience method that analyzes a document and returns only the extracted text.
        
        Args:
            base64_string: Base64 encoded document data.
            content_type: Content type of the document (e.g., "application/pdf", "image/jpeg").
            model_id: ID of the model to use. Defaults to "prebuilt-document".
            locale: Language locale of the document. Defaults to "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            **kwargs: Additional parameters to pass to the provider.
            
        Returns:
            str: The extracted text content.
            
        Raises:
            DocumentIntelligenceError: If the text extraction fails.
        """
        response = self.analyze_document_from_base64(
            base64_string=base64_string,
            content_type=content_type,
            model_id=model_id,
            locale=locale,
            pages=pages,
            **kwargs
        )
        
        document = response.get_analyzed_document()
        if document:
            return document.get_text()
        else:
            raise DocumentIntelligenceError("Failed to extract text from document") 