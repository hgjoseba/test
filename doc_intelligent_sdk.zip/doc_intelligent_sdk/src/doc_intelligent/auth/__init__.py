"""
Authentication module for the Document Intelligence SDK.

This module provides classes for authenticating with Azure services.
"""

from .azure import AzureCredential

__all__ = ["AzureCredential"] 