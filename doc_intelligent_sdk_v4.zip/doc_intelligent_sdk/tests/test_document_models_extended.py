"""
Extended tests for the Document models, focusing on uncovered areas.
"""

import unittest
from unittest.mock import MagicMock, patch
from datetime import datetime

from doc_intelligent.models.document import (
    BoundingBox,
    TextLine,
    TextPage,
    DocumentModel,
    AnalyzedDocument,
    DocumentStatus
)


class MockResult:
    """Clase helper para crear resultados simulados para tests."""
    def __init__(self, status="succeeded"):
        self.status = status
        self.document_id = "test-doc"
        self.model_id = "test-model"
        self.content = "Test content"
        self.content_type = "application/pdf"
        self.file_name = "test.pdf"
        self.language = "en-US"
        self.pages = []
        self.analyze_result = None
        self.documents = []


class TestAnalyzedDocumentExtended(unittest.TestCase):
    """Extended test cases for the AnalyzedDocument class."""
    
    def test_from_azure_result_with_documents(self):
        """Test from_azure_result method with documents field."""
        # Crear un resultado simulado con valores string
        result = MockResult()
        result.documents = ["invoice"]  # Simplificado para el test
        
        # Ahora crear un documento
        doc = AnalyzedDocument.from_azure_result(result)
        
        self.assertEqual(doc.model_id, "test-model")
        self.assertEqual(doc.content, "Test content")
        self.assertEqual(doc.content_type, "application/pdf")
        self.assertEqual(doc.file_name, "test.pdf")
        self.assertEqual(doc.status, DocumentStatus.SUCCEEDED)
    
    def test_from_azure_result_running_status(self):
        """Test from_azure_result method with running status."""
        result = MockResult(status="running")
        
        # Ahora crear un documento
        doc = AnalyzedDocument.from_azure_result(result)
        
        self.assertEqual(doc.model_id, "test-model")
        self.assertEqual(doc.status, DocumentStatus.RUNNING)
    
    def test_from_azure_result_failed_status(self):
        """Test from_azure_result method with failed status."""
        result = MockResult(status="failed")
        
        # Ahora crear un documento
        doc = AnalyzedDocument.from_azure_result(result)
        
        self.assertEqual(doc.model_id, "test-model")
        self.assertEqual(doc.status, DocumentStatus.FAILED)
    
    def test_from_azure_result_legacy_format(self):
        """Test from_azure_result method with legacy format (analyzeResult)."""
        # Crear un resultado simulado con valores string
        result = MockResult()
        # Añadir analyze_result
        result.analyze_result = MockResult()
        result.analyze_result.pages = [{"page_number": 1, "lines": [{"content": "Test line"}]}]
        result.analyze_result.read_results = [{"page_number": 1, "lines": [{"content": "Test line"}]}]
        
        # Ahora crear un documento
        doc = AnalyzedDocument.from_azure_result(result)
        
        self.assertEqual(doc.model_id, "test-model")
        self.assertEqual(doc.content, "Test content")
        self.assertEqual(doc.status, DocumentStatus.SUCCEEDED)
    
    def test_get_page_text_with_invalid_page(self):
        """Test get_page_text method with invalid page number."""
        document = AnalyzedDocument(
            document_id="test-doc",
            model_id="prebuilt-document",
            pages=[
                TextPage(
                    page_number=1,
                    lines=[TextLine(content="Page 1 content")]
                )
            ]
        )

        # Con la implementación actual, no se lanza excepción para páginas no existentes
        text = document.get_page_text(100)
        self.assertEqual(text, "")
    
    def test_validator_default_content(self):
        """Test validator that sets default content from pages."""
        # Create a document with pages but no content
        document = AnalyzedDocument(
            document_id="test-doc",
            model_id="prebuilt-document",
            pages=[
                TextPage(
                    page_number=1,
                    lines=[TextLine(content="Page 1 Line 1"), TextLine(content="Page 1 Line 2")]
                ),
                TextPage(
                    page_number=2,
                    lines=[TextLine(content="Page 2 Line 1")]
                )
            ],
            content=""  # Empty content should be populated from pages
        )
        
        # Content should be populated from pages
        expected_content = "Page 1 Line 1\nPage 1 Line 2\n\nPage 2 Line 1"
        self.assertEqual(document.content, expected_content)


class TestDocumentStatusEnum(unittest.TestCase):
    """Test cases for the DocumentStatus enum."""
    
    def test_enum_values(self):
        """Test enum values."""
        self.assertEqual(DocumentStatus.SUCCEEDED.value, "succeeded")
        self.assertEqual(DocumentStatus.RUNNING.value, "running")
        self.assertEqual(DocumentStatus.FAILED.value, "failed")


class TestBoundingBoxExtended(unittest.TestCase):
    """Extended test cases for the BoundingBox class."""
    
    def test_from_azure_polygon_with_three_points(self):
        """Test from_azure_polygon method with three points (less than expected)."""
        points = [
            {"x": 10, "y": 20},
            {"x": 110, "y": 20},
            {"x": 110, "y": 70}
        ]
        bbox = BoundingBox.from_azure_polygon(points)
        
        # Asegurar que las coordenadas se normalicen correctamente para los tests
        self.assertLessEqual(bbox.left, 1.0)
        self.assertLessEqual(bbox.top, 1.0)
        self.assertLessEqual(bbox.width, 1.0)
        self.assertLessEqual(bbox.height, 1.0)
        
        # Verificando proporciones
        self.assertEqual(bbox.width / bbox.left, 10.0)
        self.assertEqual(bbox.height / bbox.top, 2.5)
    
    def test_from_azure_polygon_with_none(self):
        """Test from_azure_polygon method with None."""
        bbox = BoundingBox.from_azure_polygon(None)
        
        # Should return a default bounding box with zeros
        self.assertEqual(bbox.left, 0)
        self.assertEqual(bbox.top, 0)
        self.assertEqual(bbox.width, 0)
        self.assertEqual(bbox.height, 0)


class TestTextLineExtended(unittest.TestCase):
    """Extended test cases for the TextLine class."""
    
    def test_from_azure_line_without_polygon(self):
        """Test from_azure_line method without polygon."""
        mock_line = MagicMock()
        mock_line.content = "Test line"
        mock_line.confidence = 0.9
        # No polygon attribute
        
        text_line = TextLine.from_azure_line(mock_line)
        
        self.assertEqual(text_line.content, "Test line")
        self.assertIsNone(text_line.bounding_box)
        self.assertEqual(text_line.confidence, 0.9)
    
    def test_from_azure_line_without_span(self):
        """Test from_azure_line method without span."""
        mock_line = MagicMock()
        mock_line.content = "Test line"
        mock_line.confidence = 0.9
        mock_line.polygon = [{"x": 10, "y": 20}, {"x": 110, "y": 20}, {"x": 110, "y": 70}, {"x": 10, "y": 70}]
        # Eliminar explícitamente el atributo span para el test
        del mock_line.span
        
        text_line = TextLine.from_azure_line(mock_line)
        
        self.assertEqual(text_line.content, "Test line")
        self.assertIsNotNone(text_line.bounding_box)
        self.assertEqual(text_line.confidence, 0.9)
        self.assertIsNone(text_line.span)
    
    def test_from_azure_line_without_confidence(self):
        """Test from_azure_line method without confidence."""
        mock_line = MagicMock()
        mock_line.content = "Test line"
        # No confidence attribute
        mock_line.polygon = [{"x": 10, "y": 20}, {"x": 110, "y": 20}, {"x": 110, "y": 70}, {"x": 10, "y": 70}]
        # Eliminar explícitamente el atributo span para el test
        del mock_line.span
        
        text_line = TextLine.from_azure_line(mock_line)
        
        self.assertEqual(text_line.content, "Test line")
        self.assertIsNotNone(text_line.bounding_box)
        self.assertEqual(text_line.confidence, 1.0)
        self.assertIsNone(text_line.span)


if __name__ == "__main__":
    unittest.main() 