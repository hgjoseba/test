"""
Tests for the Document Intelligence SDK.
""" 