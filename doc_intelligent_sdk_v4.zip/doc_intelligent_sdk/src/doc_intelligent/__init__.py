"""
Document Intelligence SDK (OCR version).

SDK simplificado para la extracción de texto de documentos,
utilizando servicios como Azure Document Intelligence.
"""

from .client import DocIntelligenceClient
from .utils import get_token_azurecredential

__version__ = "0.2.0"
__all__ = ["DocIntelligenceClient", "get_token_azurecredential"] 