"""
Error classes for Document Intelligence SDK.

This module defines custom exceptions used throughout the SDK.
"""

class DocumentIntelligenceError(Exception):
    """Base exception for all Document Intelligence errors."""
    
    def __init__(self, message: str = "An error occurred in the Document Intelligence SDK", status_code=None, error_code=None):
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        
        display_msg = message
        if status_code and error_code and "(Status code:" not in message and "error_code" not in message:
            display_msg = f"{message} ({status_code} - {error_code})"
        elif status_code and "(Status code:" not in message:
            display_msg = f"{message} (Status code: {status_code})"
            
        super().__init__(display_msg)
        
        
class AuthenticationError(DocumentIntelligenceError):
    """Exception raised for authentication errors."""
    
    def __init__(self, message: str = "Authentication failed", status_code=None, error_code=None):
        super().__init__(message, status_code, error_code)
        
        
class ServiceError(DocumentIntelligenceError):
    """Exception raised for Azure service errors."""
    
    def __init__(self, message: str = "Service error", status_code: int = None):
        self.status_code = status_code
        status_msg = f" (Status code: {status_code})" if status_code else ""
        super().__init__(f"Service error{status_msg}: {message}", status_code=status_code)
        
        
class ModelNotFoundError(DocumentIntelligenceError):
    """Exception raised when a requested model is not found."""
    
    def __init__(self, model_id: str):
        super().__init__(f"Model not found: {model_id}")


class DocumentTypeError(DocumentIntelligenceError):
    """Exception raised for unsupported document types."""
    
    def __init__(self, file_type: str = None):
        if file_type:
            message = f"Unsupported document type: {file_type}"
        else:
            message = "Unsupported document type"
        super().__init__(message)
        
        
class ApiError(DocumentIntelligenceError):
    """Exception raised for API errors."""
    
    def __init__(self, message: str = "API call failed", status_code=None, error_code=None):
        super().__init__(message, status_code, error_code)
        
    @classmethod
    def from_response(cls, response):
        """Create an ApiError from a response object."""
        status_code = getattr(response, 'status_code', None)
        error_info = {}
        
        try:
            error_info = response.json().get('error', {})
        except (ValueError, AttributeError):
            # If response.json() fails or there's no error key
            error_message = getattr(response, 'text', None)
            if error_message is None:
                error_message = f"API call failed with status code {status_code}"
            return cls(error_message, status_code)
            
        error_code = error_info.get('code')
        error_message = error_info.get('message', f"API call failed with status code {status_code}")
        
        return cls(error_message, status_code, error_code)


class ValidationError(DocumentIntelligenceError):
    """Exception raised for validation errors."""
    
    def __init__(self, message: str = "Validation error"):
        super().__init__(message)


class RequestError(DocumentIntelligenceError):
    """Exception raised for request errors."""
    
    def __init__(self, message: str = "Request error", status_code=None, error_code=None):
        super().__init__(message, status_code, error_code) 