"""
Text extractor module for Document Intelligence SDK (OCR version).

This module provides the TextExtractor class for extracting text
from analyzed documents.
"""

import os
from pathlib import Path
from typing import Optional, Union, Dict, List

from ..models.document import AnalyzedDocument, DocumentStatus
from ..utils.logging import get_logger

logger = get_logger(__name__)


class TextExtractor:
    """
    Text extractor for extracting plain text from analyzed documents.
    
    This class provides methods for extracting and saving text content
    from document analysis results.
    """
    
    def __init__(
        self, 
        confidence_threshold: float = 0.0, 
        output_format: str = None,
        include_metadata: bool = False
    ):
        """
        Initialize the text extractor.
        
        Args:
            confidence_threshold: Minimum confidence threshold for including text (0.0-1.0).
            output_format: Custom output file format for pages. Example: "page_{page_number:03d}.txt"
            include_metadata: Whether to include document metadata in the output text.
        """
        self.confidence_threshold = confidence_threshold
        self.output_format = output_format
        self.include_metadata = include_metadata
    
    def to_text(self, document: AnalyzedDocument, output_path: Optional[Union[str, Path]] = None) -> str:
        """
        Extract plain text from an analyzed document.
        
        Args:
            document: The analyzed document to extract text from.
            output_path: Optional path to save the text output.
            
        Returns:
            str: The extracted text content.
        """
        # Check if document is in a failed state
        if document.status == DocumentStatus.FAILED:
            raise ValueError("Cannot extract text from failed document")
        
        # Extract text with confidence threshold
        if self.confidence_threshold > 0:
            text_content = self._extract_with_confidence(document)
        else:
            text_content = document.get_text()
        
        # Add metadata if requested
        if self.include_metadata:
            metadata = self._format_metadata(document)
            text_content = f"{metadata}\n\n{text_content}"
        
        # Save to file if output path is provided
        if output_path:
            output_path = Path(output_path)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(text_content)
                
        return text_content
    
    def _extract_with_confidence(self, document: AnalyzedDocument) -> str:
        """
        Extract text considering confidence threshold.
        
        Args:
            document: The analyzed document to extract text from.
            
        Returns:
            str: The filtered text content.
        """
        lines_by_page = []
        
        for page in document.pages:
            page_lines = []
            for line in page.lines:
                if line.confidence is None or line.confidence >= self.confidence_threshold:
                    page_lines.append(line.content)
            
            if page_lines:
                lines_by_page.append("\n".join(page_lines))
        
        return "\n\n".join(lines_by_page)
    
    def _format_metadata(self, document: AnalyzedDocument) -> str:
        """
        Format document metadata as text.
        
        Args:
            document: The document to extract metadata from.
            
        Returns:
            str: Formatted metadata text.
        """
        metadata_lines = []
        
        if document.document_id:
            metadata_lines.append(f"Document ID: {document.document_id}")
        if document.model_id:
            metadata_lines.append(f"Model ID: {document.model_id}")
        if document.file_name:
            metadata_lines.append(f"File Name: {document.file_name}")
        if document.content_type:
            metadata_lines.append(f"Content Type: {document.content_type}")
        if document.language:
            metadata_lines.append(f"Language: {document.language}")
        if document.analysis_timestamp:
            metadata_lines.append(f"Analyzed: {document.analysis_timestamp}")
        
        return "\n".join(metadata_lines)
    
    def extract_by_page(self, document: AnalyzedDocument, page_number: int) -> str:
        """
        Extract text from a specific page of an analyzed document.
        
        Args:
            document: The analyzed document to extract text from.
            page_number: The page number to extract (1-based index).
            
        Returns:
            str: The extracted text content for the specified page.
                Returns empty string if the page does not exist.
        """
        try:
            return document.get_page_text(page_number)
        except ValueError:
            # Return empty string for non-existent pages
            return ""
    
    def extract_all_pages(self, document: AnalyzedDocument, output_dir: Union[str, Path] = None) -> Dict[int, str]:
        """
        Extract text from each page of an analyzed document separately.
        
        Args:
            document: The analyzed document to extract text from.
            output_dir: Optional directory to save individual page text files.
            
        Returns:
            dict: Dictionary mapping page numbers to their text content.
        """
        page_texts = {}
        
        for page in document.pages:
            page_num = page.page_number
            
            # Apply confidence threshold if needed
            if self.confidence_threshold > 0:
                filtered_lines = []
                for line in page.lines:
                    if line.confidence is None or line.confidence >= self.confidence_threshold:
                        filtered_lines.append(line.content)
                text = "\n".join(filtered_lines)
            else:
                text = page.get_text()
                
            page_texts[page_num] = text
            
            # Save to files if output directory is provided
            if output_dir:
                output_dir_path = Path(output_dir)
                output_dir_path.mkdir(parents=True, exist_ok=True)
                
                # Use custom output format if provided
                if self.output_format:
                    file_name = self.output_format.format(page_number=page_num)
                else:
                    file_name = f"{os.path.splitext(document.file_name)[0] if document.file_name else 'document'}_page_{page_num}.txt"
                
                file_path = output_dir_path / file_name
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(text)
        
        return page_texts 