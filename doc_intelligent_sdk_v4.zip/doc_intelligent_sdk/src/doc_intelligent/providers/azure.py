"""
Azure Document Intelligence Provider (OCR version).

This module defines the specific provider for Azure's document intelligence services
focused on text extraction using direct HTTP requests to the Azure Document Intelligence service.
"""

import os
import time
import logging
import requests
from pathlib import Path
from typing import Dict, Optional, Any, Union, List

from .base import DocumentProvider
from ..auth.azure import AzureCredential
from ..models.response import DocumentAnalysisResponse
from ..models.document import DocumentModel
from ..utils.errors import DocumentIntelligenceError, ModelNotFoundError, ServiceError, AuthenticationError
from azure.core.credentials import TokenCredential
from azure.identity import DefaultAzureCredential

# Logger configuration
logger = logging.getLogger(__name__)

class AzureDocumentProvider(DocumentProvider):
    """
    Provider for accessing Azure Document Intelligence services for text extraction.
    
    This class implements the DocumentProvider interface for Azure Document Intelligence.
    """
    
    def __init__(
        self,
        endpoint: Optional[str] = None,
        credential: Optional[Union[str, TokenCredential]] = None,
        api_key: Optional[str] = None,
        api_version: str = "2023-10-31-preview",
        connection_verify: Union[bool, str] = True
    ):
        """
        Initialize the Azure Document Intelligence provider.
        
        Args:
            endpoint: The endpoint URL for the service. If not provided, tries to use AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT environment variable.
            credential: TokenCredential for authentication.
            api_key: API key for authentication (alternative to credential).
            api_version: API version to use.
            connection_verify: Controls SSL certificate verification. Set to False to disable verification,
                or provide a path to a CA bundle to use. Defaults to True.
        """
        super().__init__()
        
        # Check for endpoint in env vars if not provided
        if endpoint is None:
            endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
            if not endpoint:
                raise ValueError("Endpoint not provided. Please provide an endpoint or set AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT environment variable.")
        
        # Ensure endpoint ends with a trailing slash
        self.endpoint = endpoint.rstrip('/') + '/'
        self.api_version = api_version
        self.connection_verify = connection_verify
        self.public_endpoint = None  # Inicializar atributo usado en analyze_document
        
        # Set up authentication
        if api_key:
            self.api_key = api_key
            self.credential = None
        elif isinstance(credential, str):
            self.api_key = credential
            self.credential = None
        elif credential:
            self.api_key = None
            self.credential = credential
        else:
            # Si no se proporciona ni api_key ni credential, verificar variables de entorno
            if os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_KEY"):
                self.api_key = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_KEY")
                self.credential = None
            else:
                self.api_key = None
                # Intentar usar DefaultAzureCredential
                self.credential = DefaultAzureCredential()
    
    def _get_headers(self) -> Dict[str, str]:
        """
        Get authentication headers for API requests.
        
        Returns:
            Dict[str, str]: Authentication headers.
        
        Raises:
            DocumentIntelligenceError: If authentication fails.
        """
        try:
            if self.api_key:
                return {"Ocp-Apim-Subscription-Key": self.api_key}
            elif self.credential:
                # Directly use the get_token method from AzureCredential
                token = self.credential.get_token()
                return {"Authorization": f"Bearer {token}"}
            else:
                raise DocumentIntelligenceError("No authentication method available")
        except Exception as e:
            logger.error(f"Error getting authentication headers: {str(e)}")
            raise DocumentIntelligenceError(f"Authentication error: {str(e)}")
    
    def _get_content_type(self, file_path: Path) -> str:
        """
        Determine content type based on file extension.
        Only supports PDF and DOCX.
        
        Args:
            file_path: Path to the file.
            
        Returns:
            str: The content type of the file.
        """
        extension = file_path.suffix.lower()
        content_types = {
            ".pdf": "application/pdf",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }
        
        return content_types.get(extension, "application/octet-stream")
    
    def analyze_document(
        self,
        file_path: Union[str, Path],
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document for text extraction using Azure Document Intelligence.
        
        If a public endpoint different from the private endpoint was provided, the system
        will automatically replace the public endpoint with the private one in the
        Operation-Location URL for polling, allowing access to private endpoints
        with restrictive firewalls or in virtual networks.
        
        Args:
            file_path: Path to the document file to analyze.
            model_id: ID of the model to use. Default: "prebuilt-document".
            locale: Language locale of the document. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Default: 5.
            timeout: Maximum time (in seconds) to wait for the result. Default: 300.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Prepare the URL for analysis
        analyze_url = f"{self.endpoint}documentModels/{model_id}:analyze?api-version={self.api_version}"
        logger.info(f"Analysis URL: {analyze_url}")
        
        # Get authentication headers
        headers = self._get_headers()
        
        # Determine content type based on file extension
        content_type = self._get_content_type(file_path)
        logger.info(f"Determined content type: {content_type}")
        
        # PHASE 1: Send analysis request
        try:
            with open(file_path, "rb") as f:
                files = {"file": (file_path.name, f, content_type)}
                
                # Prepare form data with options
                form_data = {}
                if locale:
                    form_data["locale"] = locale
                if pages:
                    form_data["pages"] = ','.join(map(str, pages))
                # Add additional parameters
                form_data.update(kwargs)
                
                response = requests.post(
                    analyze_url,
                    headers=headers,
                    files=files,
                    data=form_data, 
                    timeout=30,
                    verify=self.connection_verify
                )
        except Exception as e:
            logger.error(f"Error sending analysis request: {str(e)}")
            raise DocumentIntelligenceError(f"Request error: {str(e)}")
        
        # Verify response
        logger.info(f"Response status: {response.status_code}")
        if response.status_code not in [200, 202]:
            logger.error(f"Request failed: {response.status_code} {response.text}")
            if response.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                raise ServiceError(f"Service error: {response.text}", response.status_code)
        
        # Get operation location for polling
        op_location = response.headers.get("Operation-Location")
        if not op_location:
            logger.error("Operation-Location header not found in response")
            raise DocumentIntelligenceError("Missing Operation-Location header in response")
        
        logger.info(f"Operation-Location: {op_location}")
        
        # PHASE 2: Poll for results
        start_time = time.time()
        
        # Replace public endpoint with private if necessary
        if self.public_endpoint and op_location.startswith(self.public_endpoint):
            poll_url = op_location.replace(self.public_endpoint, self.endpoint)
        else:
            poll_url = op_location
            
        logger.info(f"Polling URL: {poll_url}")
        
        # Polling loop
        while True:
            try:
                poll_response = requests.get(
                    poll_url,
                    headers=headers,
                    timeout=30,
                    verify=self.connection_verify
                )
            except Exception as e:
                logger.error(f"Error during polling: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            if poll_response.status_code != 200:
                logger.error(f"Polling failed: {poll_response.status_code} {poll_response.text}")
                raise ServiceError(f"Polling error: {poll_response.text}", poll_response.status_code)
            
            try:
                result = poll_response.json()
            except Exception as e:
                logger.error(f"Error parsing JSON response: {str(e)}")
                time.sleep(poll_interval)
                continue
            
            status = result.get("status")
            logger.info(f"Current status: {status}")
            
            if status in ["running", "notStarted"]:
                if time.time() - start_time > timeout:
                    logger.error("Polling timeout exceeded")
                    raise DocumentIntelligenceError(f"Analysis timeout after {timeout} seconds")
                time.sleep(poll_interval)
            elif status == "succeeded":
                logger.info("Analysis job completed successfully")
                # Create a DocumentAnalysisResponse from the result
                return DocumentAnalysisResponse.from_azure_result(result)
            else:
                logger.error(f"Analysis failed with status: {status}")
                error_details = result.get("errors", [])
                if error_details:
                    error_message = "; ".join([f"{e.get('code')}: {e.get('message')}" for e in error_details])
                    raise DocumentIntelligenceError(f"Analysis failed: {error_message}")
                else:
                    raise DocumentIntelligenceError(f"Analysis failed with status: {status}")
    
    def analyze_document_from_base64(
        self,
        base64_string: str,
        content_type: str,
        model_id: str = "prebuilt-document",
        locale: str = "en",
        pages: Optional[list[int]] = None,
        poll_interval: int = 5,
        timeout: int = 300,
        **kwargs,
    ) -> DocumentAnalysisResponse:
        """
        Analyze a document from base64 encoded data for text extraction.
        
        Args:
            base64_string: Base64 encoded document data.
            content_type: Content type of the document (e.g., "application/pdf").
            model_id: ID of the model to use. Default: "prebuilt-document".
            locale: Language locale of the document. Default: "en".
            pages: Specific page numbers to analyze. If None, analyzes all pages.
            poll_interval: Interval (in seconds) between polling requests. Default: 5.
            timeout: Maximum time (in seconds) to wait for the result. Default: 300.
            **kwargs: Additional parameters to pass to the API.
            
        Returns:
            DocumentAnalysisResponse: The analysis results.
            
        Raises:
            DocumentIntelligenceError: If the analysis fails.
        """
        # Prepare the URL for analysis
        analyze_url = f"{self.endpoint}documentModels/{model_id}:analyze?api-version={self.api_version}"
        logger.info(f"Analysis URL (base64): {analyze_url}")
        
        # Get authentication headers
        headers = self._get_headers()
        
        # Add content type and other headers
        headers["Content-Type"] = "application/json"
        
        # Prepare the request body
        body = {"base64Source": base64_string}
        
        # Add options
        options = {}
        if locale:
            options["locale"] = locale
        if pages:
            options["pages"] = pages
        
        # Add additional parameters
        options.update(kwargs)
        
        if options:
            body["analyzeRequest"] = {"modelId": model_id, "options": options}
        
        # PHASE 1: Send analysis request
        try:
            response = requests.post(
                analyze_url,
                headers=headers,
                json=body,
                timeout=30,
                verify=self.connection_verify
            )
        except Exception as e:
            logger.error(f"Error sending base64 analysis request: {str(e)}")
            raise DocumentIntelligenceError(f"Request error: {str(e)}")
        
        # Verify response
        logger.info(f"Base64 response status: {response.status_code}")
        if response.status_code not in [200, 202]:
            logger.error(f"Base64 request failed: {response.status_code} {response.text}")
            if response.status_code == 404:
                raise ModelNotFoundError(model_id)
            else:
                raise ServiceError(f"Service error: {response.text}", response.status_code)
        
        # Get operation location for polling
        op_location = response.headers.get("Operation-Location")
        if not op_location:
            logger.error("Operation-Location header not found in response")
            raise DocumentIntelligenceError("Missing Operation-Location header in response")
        
        logger.info(f"Operation-Location (base64): {op_location}")
        
        # PHASE 2: Poll for results
        start_time = time.time()
        
        # Replace public endpoint with private if necessary
        if self.public_endpoint and op_location.startswith(self.public_endpoint):
            poll_url = op_location.replace(self.public_endpoint, self.endpoint)
        else:
            poll_url = op_location
            
        logger.info(f"Polling URL (base64): {poll_url}")
        
        # Polling loop
        while True:
            try:
                poll_response = requests.get(
                    poll_url,
                    headers=self._get_headers(),
                    timeout=30,
                    verify=self.connection_verify
                )
            except Exception as e:
                logger.error(f"Error during polling (base64): {str(e)}")
                time.sleep(poll_interval)
                continue
            
            if poll_response.status_code != 200:
                logger.error(f"Polling failed (base64): {poll_response.status_code} {poll_response.text}")
                raise ServiceError(f"Polling error: {poll_response.text}", poll_response.status_code)
            
            try:
                result = poll_response.json()
            except Exception as e:
                logger.error(f"Error parsing JSON response (base64): {str(e)}")
                time.sleep(poll_interval)
                continue
            
            status = result.get("status")
            logger.info(f"Current status (base64): {status}")
            
            if status in ["running", "notStarted"]:
                if time.time() - start_time > timeout:
                    logger.error("Polling timeout exceeded (base64)")
                    raise DocumentIntelligenceError(f"Analysis timeout after {timeout} seconds")
                time.sleep(poll_interval)
            elif status == "succeeded":
                logger.info("Analysis job completed successfully (base64)")
                # Create a DocumentAnalysisResponse from the result
                return DocumentAnalysisResponse.from_azure_result(result)
            else:
                logger.error(f"Analysis failed with status (base64): {status}")
                error_details = result.get("errors", [])
                if error_details:
                    error_message = "; ".join([f"{e.get('code')}: {e.get('message')}" for e in error_details])
                    raise DocumentIntelligenceError(f"Analysis failed: {error_message}")
                else:
                    raise DocumentIntelligenceError(f"Analysis failed with status: {status}")
    
    def analyze_documents_batch(
        self,
        files: List[str],
        model_id: str,
        **kwargs
    ) -> List[DocumentAnalysisResponse]:
        """
        Analyze multiple documents using the specified model.
        
        Args:
            files: List of file paths to analyze.
            model_id: ID of the model to use.
            **kwargs: Additional arguments to pass to the service.
            
        Returns:
            List[DocumentAnalysisResponse]: List of analysis responses.
            
        Raises:
            DocumentIntelligenceError: If any document analysis fails.
        """
        responses = []
        for file_path in files:
            try:
                response = self.analyze_document(file_path, model_id, **kwargs)
                responses.append(response)
            except Exception as e:
                # Log error but continue with other documents
                logging.error(f"Failed to analyze {file_path}: {str(e)}")
                responses.append(DocumentAnalysisResponse(
                    status="failed",
                    errors=[{"code": "AnalysisFailed", "message": str(e)}]
                ))
        return responses
    
    def analyze_documents_batch_from_base64(
        self,
        documents: List[Dict[str, str]],
        model_id: str,
        **kwargs
    ) -> List[DocumentAnalysisResponse]:
        """
        Analyze multiple base64-encoded documents using the specified model.
        
        Args:
            documents: List of dictionaries containing base64 content and metadata.
            model_id: ID of the model to use.
            **kwargs: Additional arguments to pass to the service.
            
        Returns:
            List[DocumentAnalysisResponse]: List of analysis responses.
            
        Raises:
            DocumentIntelligenceError: If any document analysis fails.
        """
        responses = []
        for doc in documents:
            try:
                response = self.analyze_document_from_base64(
                    doc.get('content'),
                    model_id,
                    content_type=doc.get('contentType'),
                    file_name=doc.get('fileName'),
                    **kwargs
                )
                responses.append(response)
            except Exception as e:
                # Log error but continue with other documents
                logging.error(f"Failed to analyze document: {str(e)}")
                responses.append(DocumentAnalysisResponse(
                    status="failed",
                    errors=[{"code": "AnalysisFailed", "message": str(e)}]
                ))
        return responses
    
    def list_models(self) -> List[DocumentModel]:
        """
        List available document analysis models.
        
        Returns:
            List[DocumentModel]: List of available models.
            
        Raises:
            ServiceError: If the service request fails.
            AuthenticationError: If authentication fails.
        """
        url = f"{self.endpoint}documentModels?api-version={self.api_version}"
        
        try:
            response = requests.get(url, headers=self._get_headers())
            response.raise_for_status()
            
            models_data = response.json().get('models', [])
            return [DocumentModel.from_azure_model(model) for model in models_data]
            
        except requests.exceptions.RequestException as e:
            if response.status_code == 401:
                raise AuthenticationError("Failed to authenticate with Azure service")
            raise ServiceError(f"Failed to list models: {str(e)}", response.status_code) 