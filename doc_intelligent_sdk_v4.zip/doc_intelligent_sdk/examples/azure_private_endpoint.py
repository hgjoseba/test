#!/usr/bin/env python
"""
Ejemplo de uso de endpoints privados con Azure Document Intelligence.

Este ejemplo demuestra cómo el SDK maneja automáticamente:
1. La configuración de NO_PROXY para el dominio del endpoint privado
2. El reemplazo de URLs de operación públicas por URLs de endpoint privado durante polling
"""

import os
import time
from doc_intelligent import DocumentIntelligence
from doc_intelligent.providers import AzureDocumentProvider

# Configuración para el manejo de endpoints
CONFIG = {
    # Endpoint privado (usando Azure Private Link o ExpressRoute)
    "private_endpoint": "https://your-private-endpoint.cognitiveservices.azure.com/",
    
    # Endpoint público que Azure podría devolver en las URLs de respuesta
    "public_endpoint": "https://eastus.api.cognitive.microsoft.com/",
    
    # API key
    "api_key": os.environ.get("AZURE_DOC_API_KEY", "your_api_key"),
    
    # Documento para analizar (debe ser un documento grande que requiera polling)
    "document_path": "samples/large_document.pdf"
}

def log_environment_variables():
    """Muestra las variables de entorno relevantes para el manejo de proxies."""
    no_proxy = os.environ.get("NO_PROXY", "")
    http_proxy = os.environ.get("HTTP_PROXY", "")
    https_proxy = os.environ.get("HTTPS_PROXY", "")
    
    print("\n=== Variables de entorno de proxy ===")
    print(f"NO_PROXY: {no_proxy}")
    print(f"HTTP_PROXY: {http_proxy}")
    print(f"HTTPS_PROXY: {https_proxy}")

def main():
    print("=== Ejemplo de manejo de endpoints privados con Azure Document Intelligence ===")
    print("Este ejemplo demuestra cómo el SDK maneja automáticamente:")
    print("1. La configuración de NO_PROXY para el dominio del endpoint privado")
    print("2. El reemplazo de URLs de operación públicas por URLs privadas durante polling")
    
    print("\nConfiguración:")
    print(f"  Endpoint privado: {CONFIG['private_endpoint']}")
    print(f"  Endpoint público (a reemplazar): {CONFIG['public_endpoint']}")
    
    # Mostrar estado inicial de la variable NO_PROXY
    print("\n=== Estado inicial de NO_PROXY ===")
    initial_no_proxy = os.environ.get("NO_PROXY", "")
    if initial_no_proxy:
        print(f"NO_PROXY ya contiene: {initial_no_proxy}")
    else:
        print("NO_PROXY no está definido inicialmente")
    
    # Inicializar el proveedor de Azure con los endpoints
    # El SDK agregará automáticamente el dominio del endpoint privado a NO_PROXY
    provider = AzureDocumentProvider(
        endpoint=CONFIG["private_endpoint"],
        api_key=CONFIG["api_key"],
        public_endpoint=CONFIG["public_endpoint"]  # Crucial para el reemplazo de URLs
    )
    
    # Inicializar el SDK con el proveedor
    doc_intelligence = DocumentIntelligence(provider=provider)
    
    # Mostrar NO_PROXY después de la inicialización para ver lo que el SDK añadió
    print("\n=== NO_PROXY después de inicializar el SDK ===")
    updated_no_proxy = os.environ.get("NO_PROXY", "")
    print(f"NO_PROXY actualizado: {updated_no_proxy}")
    
    # Verificar si el dominio privado fue añadido correctamente
    private_domain = CONFIG["private_endpoint"].replace("https://", "").split("/")[0]
    if private_domain in updated_no_proxy:
        print(f"✓ El dominio privado '{private_domain}' fue añadido correctamente a NO_PROXY")
    else:
        print(f"✗ El dominio privado '{private_domain}' no fue añadido a NO_PROXY")
    
    print("\n=== Simulación de análisis con reemplazo de endpoint ===")
    print("Nota: Esta es una simulación para mostrar el proceso")
    
    # Simular un proceso de polling para mostrar el reemplazo de URL
    # (sin hacer realmente el análisis para evitar errores de credenciales)
    
    # Simular la URL de Operation-Location que vendría en la respuesta de Azure
    simulated_op_location = f"{CONFIG['public_endpoint']}/operations/documentModels/abc123"
    print(f"1. URL de operación original de Azure: {simulated_op_location}")
    
    # Simular cómo el SDK reemplazaría esta URL
    if CONFIG["public_endpoint"] and simulated_op_location.startswith(CONFIG["public_endpoint"]):
        simulated_poll_url = simulated_op_location.replace(
            CONFIG["public_endpoint"], 
            CONFIG["private_endpoint"]
        )
        print(f"2. URL reemplazada para polling: {simulated_poll_url}")
        print("✓ El SDK reemplazó correctamente el endpoint público con el privado")
    else:
        print("✗ No se pudo reemplazar el endpoint (la URL no comienza con el endpoint público)")
    
    print("\n=== Explicación del funcionamiento real del SDK ===")
    print("1. Al inicializar AzureDocumentProvider, el SDK:")
    print(f"   - Extrae el FQDN del endpoint privado: {private_domain}")
    print("   - Añade este dominio a la variable de entorno NO_PROXY del sistema")
    print("   - Esto hace que las solicitudes HTTP a este dominio eviten cualquier proxy configurado")
    
    print("\n2. Cuando se envía una solicitud de análisis:")
    print("   - El SDK envía la solicitud inicial al endpoint privado")
    print("   - Azure responde con un encabezado 'Operation-Location' que contiene una URL con el endpoint público")
    
    print("\n3. Durante el polling de resultados:")
    print("   - El SDK compara la URL de operación con el endpoint público configurado")
    print("   - Si coincide, reemplaza esa parte de la URL con el endpoint privado")
    print("   - Todas las solicitudes de polling usan la URL modificada")
    print("   - Al estar ya configurado NO_PROXY, estas solicitudes evitan cualquier proxy")
    
    print("\n=== Casos de uso ===")
    print("Esta funcionalidad es esencial para:")
    print("- Entornos con Azure Private Link donde los endpoints están disponibles a través de una red privada")
    print("- Configuraciones con ExpressRoute para conexiones privadas a Azure")
    print("- Escenarios donde los firewalls bloquean el acceso a endpoints públicos de Azure")
    print("- Entornos corporativos con proxies que requieren acceso directo a recursos privados")

if __name__ == "__main__":
    # Guardar el valor original de NO_PROXY para restaurarlo después
    original_no_proxy = os.environ.get("NO_PROXY", "")
    
    try:
        main()
    finally:
        # Restaurar el valor original de NO_PROXY
        if original_no_proxy:
            os.environ["NO_PROXY"] = original_no_proxy
        else:
            if "NO_PROXY" in os.environ:
                del os.environ["NO_PROXY"]
        print("\n=== NO_PROXY restaurado a su valor original ===")
        log_environment_variables() 