#!/usr/bin/env python
"""
Ejemplo de análisis de documentos a partir de datos codificados en base64.
Útil para aplicaciones web o APIs donde los documentos se transmiten como strings base64.
"""

import base64
import os
from doc_intelligent import DocumentIntelligence
from doc_intelligent.providers import AWSDocumentProvider

def main():
    # Inicializar el SDK con AWS como proveedor
    provider = AWSDocumentProvider(
        region="us-east-1",
        aws_access_key_id="your_aws_access_key",
        aws_secret_access_key="your_aws_secret_key"
    )
    
    doc_intelligence = DocumentIntelligence(provider=provider)
    
    # Ruta al archivo para convertir a base64
    file_path = "samples/contract.pdf"
    
    # Leer el archivo y convertir a base64
    with open(file_path, "rb") as file:
        file_bytes = file.read()
        base64_data = base64.b64encode(file_bytes).decode("utf-8")
    
    # Determinar el tipo de contenido
    content_type = "application/pdf"  # Para documentos PDF
    # Otros tipos comunes:
    # - "image/jpeg" para JPG
    # - "image/png" para PNG
    # - "image/tiff" para TIFF
    
    print(f"Analizando documento desde datos base64...")
    
    # Realizar el análisis usando datos base64
    response = doc_intelligence.analyze_document_from_base64(
        base64_string=base64_data,
        content_type=content_type,
        model_id="Lending.Contract",
        locale="es"
    )
    
    # Trabajar con los resultados
    print(f"Análisis completado. Estado: {response.status}")
    
    # Ver el número de páginas detectadas
    print(f"Páginas totales: {len(response.pages)}")
    
    # Ver campos específicos de contratos
    print("\nInformación del contrato detectada:")
    contract_fields = [
        "EffectiveDate", "ExpirationDate", "ContractType", 
        "ContractParties", "ContractAmount"
    ]
    
    for field in contract_fields:
        if field in response.fields:
            print(f"{field}: {response.fields[field].value}")
    
    # Ejemplo de procesamiento batch con múltiples documentos base64
    print("\n--- Ejemplo de procesamiento por lotes con base64 ---")
    
    # Crear una lista de documentos para procesar en lote
    documents = [
        {
            "base64_string": base64_data,
            "content_type": content_type,
            "document_id": "contract_sample_1"  # ID opcional para identificar documentos
        },
        # Aquí puedes agregar más documentos
    ]
    
    # Procesar todos los documentos en un solo lote
    batch_results = doc_intelligence.analyze_documents_batch_from_base64(
        documents=documents,
        model_id="Lending.Contract",
        locale="es"
    )
    
    # Verificar los resultados
    for doc_id, response in batch_results.items():
        print(f"Documento {doc_id}: {len(response.fields)} campos detectados")

if __name__ == "__main__":
    main() 