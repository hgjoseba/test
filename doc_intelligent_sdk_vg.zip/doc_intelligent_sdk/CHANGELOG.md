# Changelog

Todos los cambios notables en este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/),
y este proyecto se adhiere a [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.4.0] - Por publicar

### Añadido
- Nuevo parámetro `verify_ssl` en todas las funciones de análisis de documentos para controlar la verificación SSL
- Verificación SSL activada por defecto para mayor seguridad

### Cambiado
- Estandarización de la gestión de verificación SSL en todo el código
- Uso consistente de la verificación SSL entre los proveedores y las funciones de utilidad

### Eliminado
- Eliminado completamente el módulo `utils/auth.py` y la función `get_token_azurecredential`
- Todo el código ha sido migrado para usar `AzureCredential` de forma exclusiva

## [0.3.0] - Por publicar

### Cambiado
- Migración del mecanismo de autenticación desde `get_token_azurecredential` a la clase `AzureCredential`
- Funciones de análisis de documentos ahora aceptan un parámetro `credential` opcional

### Obsoleto
- Función `get_token_azurecredential` marcada como obsoleta y será eliminada en versiones futuras
- Se recomienda usar la clase `AzureCredential` para toda la autenticación

### Arreglado
- Mejora en la reutilización de credenciales para evitar múltiples autenticaciones

## [0.2.0] - 2024-05-15

### Añadido
- Soporte para el análisis por lotes de documentos
- Nueva función para procesar documentos directamente desde strings base64

### Cambiado
- Actualizada la API a la versión 2024-11-30
- Mejorado el manejo de errores en procesamiento de documentos

## [0.1.0] - 2024-03-01

### Añadido
- Primera versión del SDK
- Soporte para extraer texto de documentos PDF y DOCX
- Autenticación mediante API key y Service Principal
- Soporte para endpoints privados 