"""
Unit tests for the Document Converter.

This module contains comprehensive test cases for the TextExtractor class,
which handles the conversion of analyzed documents into text formats.
"""

import os
import pytest
from pathlib import Path
from doc_intelligent.core.converter import TextExtractor
from doc_intelligent.models.document import (
    AnalyzedDocument,
    TextPage,
    TextLine,
    UnitType,
    DocumentStatus
)


@pytest.fixture
def sample_document():
    """Create a sample analyzed document for testing."""
    return AnalyzedDocument(
        document_id="test-doc-001",
        model_id="test-model",
        file_name="test.pdf",
        content_type="application/pdf",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                width=8.5,
                height=11.0,
                unit=UnitType.INCH,
                lines=[
                    TextLine(content="Line 1 Page 1", confidence=0.95),
                    TextLine(content="Line 2 Page 1", confidence=0.98)
                ]
            ),
            TextPage(
                page_number=2,
                width=8.5,
                height=11.0,
                unit=UnitType.INCH,
                lines=[
                    TextLine(content="Line 1 Page 2", confidence=0.97),
                    TextLine(content="Line 2 Page 2", confidence=0.96)
                ]
            )
        ]
    )


@pytest.fixture
def temp_dir(tmp_path):
    """Create a temporary directory for test outputs."""
    return tmp_path


def test_text_extractor_initialization():
    """Test TextExtractor initialization."""
    extractor = TextExtractor()
    assert isinstance(extractor, TextExtractor)


def test_to_text_without_output(sample_document):
    """Test extracting text without saving to file."""
    extractor = TextExtractor()
    text = extractor.to_text(sample_document)
    
    # Verify all lines are present
    assert "Line 1 Page 1" in text
    assert "Line 2 Page 1" in text
    assert "Line 1 Page 2" in text
    assert "Line 2 Page 2" in text
    
    # Verify correct line breaks between pages
    lines = text.split("\n")
    assert len(lines) >= 4  # At least 4 lines (2 per page)
    assert lines[0] == "Line 1 Page 1"
    assert lines[1] == "Line 2 Page 1"


def test_to_text_with_output(sample_document, temp_dir):
    """Test extracting text and saving to file."""
    extractor = TextExtractor()
    output_path = temp_dir / "output.txt"
    text = extractor.to_text(sample_document, output_path)
    
    # Verify file was created
    assert output_path.exists()
    assert output_path.is_file()
    
    # Verify file content
    with open(output_path, 'r', encoding='utf-8') as f:
        file_content = f.read()
    
    assert file_content == text
    assert "Line 1 Page 1" in file_content
    assert "Line 2 Page 2" in file_content


def test_extract_by_page_valid(sample_document):
    """Test extracting text from a specific valid page."""
    extractor = TextExtractor()
    
    # Test first page
    page1_text = extractor.extract_by_page(sample_document, 1)
    assert "Line 1 Page 1" in page1_text
    assert "Line 2 Page 1" in page1_text
    assert "Page 2" not in page1_text
    
    # Test second page
    page2_text = extractor.extract_by_page(sample_document, 2)
    assert "Line 1 Page 2" in page2_text
    assert "Line 2 Page 2" in page2_text
    assert "Page 1" not in page2_text


def test_extract_by_page_invalid(sample_document):
    """Test extracting text from an invalid page number."""
    extractor = TextExtractor()
    
    # Test non-existent page
    assert extractor.extract_by_page(sample_document, 3) == ""
    assert extractor.extract_by_page(sample_document, 0) == ""
    assert extractor.extract_by_page(sample_document, -1) == ""


def test_extract_all_pages_without_output(sample_document):
    """Test extracting text from all pages without saving."""
    extractor = TextExtractor()
    page_texts = extractor.extract_all_pages(sample_document)
    
    # Verify correct number of pages
    assert len(page_texts) == 2
    
    # Verify page contents
    assert "Line 1 Page 1" in page_texts[1]
    assert "Line 2 Page 1" in page_texts[1]
    assert "Line 1 Page 2" in page_texts[2]
    assert "Line 2 Page 2" in page_texts[2]


def test_extract_all_pages_with_output(sample_document, temp_dir):
    """Test extracting text from all pages and saving to files."""
    extractor = TextExtractor()
    page_texts = extractor.extract_all_pages(sample_document, temp_dir)
    
    # Verify correct number of pages
    assert len(page_texts) == 2
    
    # Verify files were created
    page1_file = temp_dir / "test_page_1.txt"
    page2_file = temp_dir / "test_page_2.txt"
    assert page1_file.exists()
    assert page2_file.exists()
    
    # Verify file contents
    with open(page1_file, 'r', encoding='utf-8') as f:
        content = f.read()
        assert "Line 1 Page 1" in content
        assert "Line 2 Page 1" in content
        assert "Page 2" not in content
    
    with open(page2_file, 'r', encoding='utf-8') as f:
        content = f.read()
        assert "Line 1 Page 2" in content
        assert "Line 2 Page 2" in content
        assert "Page 1" not in content


def test_extract_all_pages_no_filename(sample_document, temp_dir):
    """Test extracting all pages when document has no filename."""
    # Remove filename from document
    sample_document.file_name = None
    
    extractor = TextExtractor()
    page_texts = extractor.extract_all_pages(sample_document, temp_dir)
    
    # Verify correct number of pages
    assert len(page_texts) == 2
    
    # Verify files were created with default naming
    assert (temp_dir / "document_page_1.txt").exists()
    assert (temp_dir / "document_page_2.txt").exists()


def test_extract_all_pages_empty_document():
    """Test extracting all pages from an empty document."""
    empty_doc = AnalyzedDocument(
        model_id="test-model",
        status=DocumentStatus.SUCCEEDED
    )
    
    extractor = TextExtractor()
    page_texts = extractor.extract_all_pages(empty_doc)
    
    assert len(page_texts) == 0


def test_extract_all_pages_single_page(temp_dir):
    """Test extracting all pages from a single-page document."""
    single_page_doc = AnalyzedDocument(
        model_id="test-model",
        file_name="test.pdf",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                lines=[TextLine(content="Single page content")]
            )
        ]
    )
    
    extractor = TextExtractor()
    page_texts = extractor.extract_all_pages(single_page_doc, temp_dir)
    
    assert len(page_texts) == 1
    assert "Single page content" in page_texts[1]
    assert (temp_dir / "test_page_1.txt").exists()


def test_to_text_with_failed_document():
    """Test extracting text from a document with failed status."""
    failed_doc = AnalyzedDocument(
        model_id="test-model",
        status=DocumentStatus.FAILED,
        error_message="Processing failed"
    )
    
    extractor = TextExtractor()
    with pytest.raises(ValueError, match="Cannot extract text from failed document"):
        extractor.to_text(failed_doc)


def test_to_text_with_special_characters(temp_dir):
    """Test extracting text with special characters and Unicode content."""
    doc = AnalyzedDocument(
        model_id="test-model",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                lines=[
                    TextLine(content="Special chars: áéíóú ñ"),
                    TextLine(content="Symbols: @#$%& ¡¿"),
                    TextLine(content="Emojis: 😀 🌟 📚")
                ]
            )
        ]
    )
    
    extractor = TextExtractor()
    output_path = temp_dir / "special_chars.txt"
    text = extractor.to_text(doc, output_path)
    
    assert "áéíóú" in text
    assert "Symbols: @#$%&" in text
    assert "😀 🌟 📚" in text
    
    # Verify file encoding
    with open(output_path, 'r', encoding='utf-8') as f:
        content = f.read()
        assert content == text


def test_extract_by_page_with_empty_page():
    """Test extracting text from a page without lines."""
    doc = AnalyzedDocument(
        model_id="test-model",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                lines=[]
            )
        ]
    )
    
    extractor = TextExtractor()
    text = extractor.extract_by_page(doc, 1)
    assert text == ""


def test_extract_all_pages_with_missing_numbers():
    """Test extracting all pages when page numbers are not sequential."""
    doc = AnalyzedDocument(
        model_id="test-model",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                lines=[TextLine(content="Page 1")]
            ),
            TextPage(
                page_number=3,  # Skip page 2
                lines=[TextLine(content="Page 3")]
            ),
            TextPage(
                page_number=5,  # Skip page 4
                lines=[TextLine(content="Page 5")]
            )
        ]
    )
    
    extractor = TextExtractor()
    page_texts = extractor.extract_all_pages(doc)
    
    assert len(page_texts) == 3
    assert page_texts[1] == "Page 1"
    assert page_texts[3] == "Page 3"
    assert page_texts[5] == "Page 5"
    assert 2 not in page_texts
    assert 4 not in page_texts


def test_to_text_with_low_confidence():
    """Test extracting text with low confidence threshold filtering."""
    doc = AnalyzedDocument(
        model_id="test-model",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                lines=[
                    TextLine(content="High confidence", confidence=0.95),
                    TextLine(content="Medium confidence", confidence=0.75),
                    TextLine(content="Low confidence", confidence=0.30)
                ]
            )
        ]
    )
    
    extractor = TextExtractor(confidence_threshold=0.80)
    text = extractor.to_text(doc)
    
    assert "High confidence" in text
    assert "Medium confidence" not in text
    assert "Low confidence" not in text


def test_extract_all_pages_with_custom_output_format(temp_dir):
    """Test extracting all pages with custom output file format."""
    doc = AnalyzedDocument(
        model_id="test-model",
        file_name="test.pdf",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                lines=[TextLine(content="Page 1 content")]
            )
        ]
    )
    
    extractor = TextExtractor(output_format="page_{page_number:03d}.txt")
    page_texts = extractor.extract_all_pages(doc, temp_dir)
    
    assert (temp_dir / "page_001.txt").exists()
    
    with open(temp_dir / "page_001.txt", 'r', encoding='utf-8') as f:
        assert f.read() == "Page 1 content"


def test_to_text_with_metadata():
    """Test extracting text with document metadata included."""
    doc = AnalyzedDocument(
        model_id="test-model",
        document_id="doc-123",
        file_name="test.pdf",
        content_type="application/pdf",
        status=DocumentStatus.SUCCEEDED,
        pages=[
            TextPage(
                page_number=1,
                lines=[TextLine(content="Document content")]
            )
        ]
    )
    
    extractor = TextExtractor(include_metadata=True)
    text = extractor.to_text(doc)
    
    assert "Document ID: doc-123" in text
    assert "File Name: test.pdf" in text
    assert "Content Type: application/pdf" in text
    assert "Document content" in text


if __name__ == "__main__":
    pytest.main() 