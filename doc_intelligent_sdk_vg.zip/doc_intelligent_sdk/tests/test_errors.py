"""
Tests for error classes in the doc_intelligent.utils.errors module.
"""

import unittest
from unittest.mock import MagicMock

from doc_intelligent.utils.errors import (
    DocumentIntelligenceError,
    AuthenticationError,
    ServiceError,
    ModelNotFoundError, 
    DocumentTypeError,
    ApiError,
    ValidationError,
    RequestError
)


class TestDocumentIntelligenceError(unittest.TestCase):
    """Test cases for DocumentIntelligenceError class."""
    
    def test_init_with_default_message(self):
        """Test initialization with default message."""
        error = DocumentIntelligenceError()
        self.assertEqual(error.message, "An error occurred in the Document Intelligence SDK")
        self.assertIsNone(error.status_code)
        self.assertIsNone(error.error_code)
        
    def test_init_with_custom_message(self):
        """Test initialization with custom message."""
        error = DocumentIntelligenceError("Custom error message")
        self.assertEqual(error.message, "Custom error message")
        self.assertIsNone(error.status_code)
        self.assertIsNone(error.error_code)
        
    def test_init_with_status_code(self):
        """Test initialization with status code."""
        error = DocumentIntelligenceError("Error with status", 404)
        self.assertEqual(error.message, "Error with status")
        self.assertEqual(error.status_code, 404)
        self.assertIsNone(error.error_code)
        self.assertEqual(str(error), "Error with status (Status code: 404)")
        
    def test_init_with_status_and_error_code(self):
        """Test initialization with status and error code."""
        error = DocumentIntelligenceError("Complete error", 500, "INTERNAL_ERROR")
        self.assertEqual(error.message, "Complete error")
        self.assertEqual(error.status_code, 500)
        self.assertEqual(error.error_code, "INTERNAL_ERROR")
        self.assertEqual(str(error), "Complete error (500 - INTERNAL_ERROR)")


class TestAuthenticationError(unittest.TestCase):
    """Test cases for AuthenticationError class."""
    
    def test_init_with_default_message(self):
        """Test initialization with default message."""
        error = AuthenticationError()
        self.assertEqual(error.message, "Authentication failed")
        self.assertIsNone(error.status_code)
        self.assertIsNone(error.error_code)
        
    def test_init_with_custom_message(self):
        """Test initialization with custom message."""
        error = AuthenticationError("Invalid API key")
        self.assertEqual(error.message, "Invalid API key")
        self.assertIsNone(error.status_code)
        self.assertIsNone(error.error_code)
        
    def test_init_with_status_code(self):
        """Test initialization with status code."""
        error = AuthenticationError("Auth failed", 401)
        self.assertEqual(error.message, "Auth failed")
        self.assertEqual(error.status_code, 401)
        self.assertIsNone(error.error_code)
        self.assertEqual(str(error), "Auth failed (Status code: 401)")


class TestServiceError(unittest.TestCase):
    """Test cases for ServiceError class."""
    
    def test_init_with_default_message(self):
        """Test initialization with default message."""
        error = ServiceError()
        self.assertEqual(str(error), "Service error: Service error")
        
    def test_init_with_custom_message(self):
        """Test initialization with custom message."""
        error = ServiceError("API is unavailable")
        self.assertEqual(str(error), "Service error: API is unavailable")
        
    def test_init_with_status_code(self):
        """Test initialization with status code."""
        error = ServiceError("Service unavailable", 503)
        self.assertEqual(error.status_code, 503)
        self.assertEqual(str(error), "Service error (Status code: 503): Service unavailable")


class TestModelNotFoundError(unittest.TestCase):
    """Test cases for ModelNotFoundError class."""
    
    def test_init_with_model_id(self):
        """Test initialization with model ID."""
        error = ModelNotFoundError("test-model")
        self.assertEqual(str(error), "Model not found: test-model")


class TestDocumentTypeError(unittest.TestCase):
    """Test cases for DocumentTypeError class."""
    
    def test_init_with_default_message(self):
        """Test initialization with default message."""
        error = DocumentTypeError()
        self.assertEqual(str(error), "Unsupported document type")
        
    def test_init_with_file_type(self):
        """Test initialization with file type."""
        error = DocumentTypeError("text/csv")
        self.assertEqual(str(error), "Unsupported document type: text/csv")


class TestApiError(unittest.TestCase):
    """Test cases for ApiError class."""
    
    def test_init_with_default_message(self):
        """Test initialization with default message."""
        error = ApiError()
        self.assertEqual(error.message, "API call failed")
        self.assertIsNone(error.status_code)
        self.assertIsNone(error.error_code)
        
    def test_init_with_custom_message(self):
        """Test initialization with custom message."""
        error = ApiError("Request timed out")
        self.assertEqual(error.message, "Request timed out")
        
    def test_from_response_with_json_error(self):
        """Test from_response method with JSON error response."""
        mock_response = MagicMock()
        mock_response.status_code = 400
        mock_response.json.return_value = {
            "error": {
                "code": "InvalidRequest",
                "message": "The request is invalid"
            }
        }
        
        error = ApiError.from_response(mock_response)
        self.assertEqual(error.message, "The request is invalid")
        self.assertEqual(error.status_code, 400)
        self.assertEqual(error.error_code, "InvalidRequest")
        
    def test_from_response_without_json(self):
        """Test from_response method with non-JSON response."""
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.json.side_effect = ValueError("Invalid JSON")
        mock_response.text = "Internal Server Error"
        
        error = ApiError.from_response(mock_response)
        self.assertEqual(error.message, "Internal Server Error")
        self.assertEqual(error.status_code, 500)
        self.assertIsNone(error.error_code)
        
    def test_from_response_without_error_key(self):
        """Test from_response method with JSON response missing error key."""
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.json.return_value = {"message": "Too many requests"}
        
        error = ApiError.from_response(mock_response)
        self.assertEqual(error.message, "API call failed with status code 429")
        self.assertEqual(error.status_code, 429)
        self.assertIsNone(error.error_code)


class TestValidationError(unittest.TestCase):
    """Test cases for ValidationError class."""
    
    def test_init_with_default_message(self):
        """Test initialization with default message."""
        error = ValidationError()
        self.assertEqual(str(error), "Validation error")
        
    def test_init_with_custom_message(self):
        """Test initialization with custom message."""
        error = ValidationError("Invalid parameter value")
        self.assertEqual(str(error), "Invalid parameter value")


class TestRequestError(unittest.TestCase):
    """Test cases for RequestError class."""
    
    def test_init_with_default_message(self):
        """Test initialization with default message."""
        error = RequestError()
        self.assertEqual(error.message, "Request error")
        self.assertIsNone(error.status_code)
        self.assertIsNone(error.error_code)
        
    def test_init_with_custom_message(self):
        """Test initialization with custom message."""
        error = RequestError("Failed to connect")
        self.assertEqual(error.message, "Failed to connect")
        
    def test_init_with_status_and_error_code(self):
        """Test initialization with status and error code."""
        error = RequestError("Connection timeout", 408, "TIMEOUT")
        self.assertEqual(error.message, "Connection timeout")
        self.assertEqual(error.status_code, 408)
        self.assertEqual(error.error_code, "TIMEOUT")
        self.assertEqual(str(error), "Connection timeout (408 - TIMEOUT)")


if __name__ == "__main__":
    unittest.main() 