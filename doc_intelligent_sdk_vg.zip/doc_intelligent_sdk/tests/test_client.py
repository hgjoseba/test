"""
Tests for the DocIntelligenceClient class.
"""

import os
import pytest
import base64
from pathlib import Path
from unittest.mock import Mock, patch
from doc_intelligent.client import DocIntelligenceClient
from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.models.document import AnalyzedDocument, TextPage, TextLine, DocumentStatus
from doc_intelligent.utils.errors import DocumentIntelligenceError

@pytest.fixture
def mock_provider():
    """Create a mock document provider."""
    provider = Mock()
    provider.analyze_document.return_value = DocumentAnalysisResponse(
        status="succeeded",
        result={
            "modelId": "test-model",
            "content": "Test content",
            "contentType": "application/pdf",
            "pages": [
                {
                    "pageNumber": 1,
                    "width": 8.5,
                    "height": 11.0,
                    "unit": "inch",
                    "lines": [
                        {
                            "content": "Test content",
                            "confidence": 0.99,
                            "span": {"offset": 0, "length": 11}
                        }
                    ]
                }
            ]
        }
    )
    provider.analyze_document_from_base64.return_value = provider.analyze_document.return_value
    return provider

@pytest.fixture
def client(mock_provider):
    """Create a DocIntelligenceClient instance with a mock provider."""
    with patch('doc_intelligent.client.AzureDocumentProvider', return_value=mock_provider):
        client_instance = DocIntelligenceClient(
            endpoint="https://test.cognitiveservices.azure.com/",
            api_key="test_key"
        )
        assert client_instance.provider is mock_provider
        return client_instance

@pytest.fixture
def sample_pdf(tmp_path):
    """Create a sample PDF file."""
    file_path = tmp_path / "test.pdf"
    with open(file_path, "wb") as f:
        f.write(b"%PDF-1.4\n%Test PDF content")
    return file_path

def test_client_initialization():
    """Test client initialization with default parameters."""
    with patch('doc_intelligent.providers.azure.AzureDocumentProvider') as mock_provider_class:
        mock_provider = Mock()
        mock_provider_class.return_value = mock_provider
        
        client = DocIntelligenceClient(
            endpoint="https://test.cognitiveservices.azure.com/",
            api_key="test_key"
        )
        
        assert client.endpoint == "https://test.cognitiveservices.azure.com/"
        assert client.api_key == "test_key"
        assert client.api_version == "2024-11-30"
        assert client.provider_name == "azure"

def test_client_initialization_invalid_provider():
    """Test client initialization with invalid provider."""
    with pytest.raises(ValueError, match="Unsupported provider"):
        DocIntelligenceClient(
            endpoint="https://test.cognitiveservices.azure.com/",
            api_key="test_key",
            provider="invalid"
        )

def test_analyze_document(client, sample_pdf):
    """Test analyzing a document."""
    response = client.analyze_document(sample_pdf)
    assert isinstance(response, DocumentAnalysisResponse)
    assert response.status == "succeeded"
    
    # Test with optional parameters
    response = client.analyze_document(
        sample_pdf,
        model_id="custom-model",
        locale="es",
        pages=[1, 2]
    )
    client.provider.analyze_document.assert_called_with(
        file_path=sample_pdf,
        model_id="custom-model",
        locale="es",
        pages=[1, 2]
    )

def test_analyze_document_from_base64(client):
    """Test analyzing a document from base64 string."""
    base64_string = base64.b64encode(b"%PDF-1.4\n%Test PDF content").decode()
    response = client.analyze_document_from_base64(
        base64_string=base64_string,
        content_type="application/pdf"
    )
    
    assert isinstance(response, DocumentAnalysisResponse)
    assert response.status == "succeeded"
    
    # Test with optional parameters
    response = client.analyze_document_from_base64(
        base64_string=base64_string,
        content_type="application/pdf",
        model_id="custom-model",
        locale="es",
        pages=[1, 2]
    )
    client.provider.analyze_document_from_base64.assert_called_with(
        base64_string=base64_string,
        content_type="application/pdf",
        model_id="custom-model",
        locale="es",
        pages=[1, 2],
        verify_ssl=False
    )

def test_extract_text(client, sample_pdf):
    """Test extracting text from a document."""
    text = client.extract_text(sample_pdf)
    assert text == "Test content"
    
    # Test with optional parameters
    text = client.extract_text(
        sample_pdf,
        model_id="custom-model",
        locale="es",
        pages=[1]
    )
    client.provider.analyze_document.assert_called_with(
        file_path=sample_pdf,
        model_id="custom-model",
        locale="es",
        pages=[1]
    )

def test_extract_text_from_base64(client):
    """Test extracting text from a base64 encoded document."""
    base64_string = base64.b64encode(b"%PDF-1.4\n%Test PDF content").decode()
    text = client.extract_text_from_base64(
        base64_string=base64_string,
        content_type="application/pdf"
    )
    assert text == "Test content"
    
    # Test with optional parameters
    text = client.extract_text_from_base64(
        base64_string=base64_string,
        content_type="application/pdf",
        model_id="custom-model",
        locale="es",
        pages=[1]
    )
    client.provider.analyze_document_from_base64.assert_called_with(
        base64_string=base64_string,
        content_type="application/pdf",
        model_id="custom-model",
        locale="es",
        pages=[1],
        verify_ssl=None
    )

def test_extract_text_failure(client, sample_pdf):
    """Test extracting text when document analysis fails."""
    with patch.object(client.provider, 'analyze_document', 
                     return_value=DocumentAnalysisResponse(status="failed", result=None)):
        with pytest.raises(DocumentIntelligenceError, match="Failed to extract text"):
            client.extract_text(sample_pdf)

def test_extract_text_from_base64_failure(client):
    """Test extracting text from base64 when document analysis fails."""
    with patch.object(client.provider, 'analyze_document_from_base64', 
                     return_value=DocumentAnalysisResponse(status="failed", result=None)):
        with pytest.raises(DocumentIntelligenceError, match="Failed to extract text"):
            client.extract_text_from_base64(
                base64_string="dGVzdA==",  # "test" in base64
                content_type="application/pdf"
            )

if __name__ == "__main__":
    pytest.main() 