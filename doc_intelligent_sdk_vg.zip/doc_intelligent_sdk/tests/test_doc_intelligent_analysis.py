"""
Tests for the doc_intelligent_analysis.py module

This file contains unit tests for the doc_intelligent_analysis.py utility module,
which provides document analysis functions based on AzureDocumentProvider.
"""

import unittest
from unittest.mock import patch, MagicMock, mock_open
import os
import base64
from pathlib import Path

from doc_intelligent.utils.doc_intelligent_analysis import (
    analyze_document,
    analyze_document_from_base64,
    analyze_multiple_base64_documents
)
from doc_intelligent.utils.document_analysis import (
    analyze_document as analyze_document_original,
    analyze_document_from_base64 as analyze_document_from_base64_original
)
from doc_intelligent.providers.azure import AzureDocumentProvider
from doc_intelligent.models.response import DocumentAnalysisResponse
from doc_intelligent.auth import AzureCredential


class TestDocIntelligentAnalysis(unittest.TestCase):
    """Tests for the document analysis functions."""

    def setUp(self):
        """Set up the test environment."""
        # Save original environment variables
        self.original_env = os.environ.copy()
        
        # Configure environment variables for testing
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = "https://test-endpoint.cognitiveservices.azure.com/"
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"] = "https://test-pub-endpoint.cognitiveservices.azure.com/"
        
        # Define test path for documents
        self.test_pdf_path = Path("test_document.pdf")
        
        # Create a test base64 string
        self.test_base64 = "JVBERi0xLjMKJeLjz9MKMSAwIG9iago8PC9UeXBlL1BhZ2UvUGFyZW50IDIgMCBSL0NvbnRlbnRzIDMgMCBSPj4KZW5kb2JqCjMgMCBvYmoKPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMD4+CnN0cmVhbQp4nCvk5QIABLQBuAplYmRpcwplbmRzdHJlYW0KZW5kb2JqCjIgMCBvYmoKPDwvVHlwZS9QYWdlcy9LaWRzWzEgMCBSXS9Db3VudCAxPj4KZW5kb2JqCjQgMCBvYmoKPDwvVHlwZS9DYXRhbG9nL1BhZ2VzIDIgMCBSPj4KZW5kb2JqCjUgMCBvYmoKPDwvUHJvZHVjZXIoVGVzdCBQREYpL0NyZWF0aW9uRGF0ZShEOjIwMjMwMTAxMDAwMDAwKT4+CmVuZG9iagp4cmVmCjAgNgowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAwMTAgMDAwMDAgbiAKMDAwMDAwMDEzNSAwMDAwMCBuIAowMDAwMDAwMDYzIDAwMDAwIG4gCjAwMDAwMDAxODYgMDAwMDAgbiAKMDAwMDAwMDIzMSAwMDAwMCBuIAp0cmFpbGVyCjw8L1Jvb3QgNCAwIFIvSW5mbyA1IDAgUi9TaXplIDY+PgpzdGFydHhyZWYKMzA0CiUlRU9G"
    
    def tearDown(self):
        """Restore the environment after each test."""
        # Restore original environment variables
        os.environ.clear()
        os.environ.update(self.original_env)

    @patch.object(AzureDocumentProvider, 'analyze_document')
    @patch.object(AzureDocumentProvider, '_get_content_type')
    @patch('pathlib.Path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data=b'test pdf content')
    @patch.object(AzureCredential, 'default_credential')
    def test_analyze_document_multipart(self, mock_credential, mock_file, mock_exists, 
                                         mock_get_content_type, mock_analyze):
        """Test the analyze_document function with upload_mode='multipart'."""
        # Configure mocks
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_response.status = "succeeded"
        mock_response.document_id = "test-job-id"
        mock_response.get_text.return_value = "Test document content"
        mock_analyze.return_value = mock_response
        
        # Call the function
        content, job_id = analyze_document(
            file_path=self.test_pdf_path, 
            upload_mode="multipart",
            model_id="prebuilt-read"
        )
        
        # Verify that AzureDocumentProvider.analyze_document was called
        mock_analyze.assert_called_once()
        args, kwargs = mock_analyze.call_args
        self.assertEqual(kwargs['file_path'], self.test_pdf_path)
        self.assertEqual(kwargs['model_id'], "prebuilt-read")
        
        # Verify the result
        self.assertEqual(content, "Test document content")
        self.assertEqual(job_id, "test-job-id")

    @patch.object(AzureDocumentProvider, 'analyze_document_from_base64')
    @patch.object(AzureDocumentProvider, '_get_content_type')
    @patch('pathlib.Path.exists', return_value=True)
    @patch('builtins.open', new_callable=mock_open, read_data=b'test pdf content')
    @patch.object(AzureCredential, 'default_credential')
    def test_analyze_document_base64(self, mock_credential, mock_file, mock_exists, 
                                      mock_get_content_type, mock_analyze_base64):
        """Test the analyze_document function with upload_mode='base64'."""
        # Configure mocks
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_response.status = "succeeded"
        mock_response.document_id = "test-job-id"
        mock_response.get_text.return_value = "Test document content"
        mock_analyze_base64.return_value = mock_response
        mock_get_content_type.return_value = "application/pdf"
        
        # Call the function
        content, job_id = analyze_document(
            file_path=self.test_pdf_path, 
            upload_mode="base64",
            model_id="prebuilt-read"
        )
        
        # Verify that AzureDocumentProvider.analyze_document_from_base64 was called
        mock_analyze_base64.assert_called_once()
        args, kwargs = mock_analyze_base64.call_args
        self.assertEqual(kwargs['model_id'], "prebuilt-read")
        self.assertEqual(kwargs['content_type'], "application/pdf")
        
        # Verify that the file content was encoded correctly
        mock_file.assert_called_once_with(self.test_pdf_path, "rb")
        
        # Verify the result
        self.assertEqual(content, "Test document content")
        self.assertEqual(job_id, "test-job-id")

    @patch.object(AzureDocumentProvider, 'analyze_document_from_base64')
    @patch.object(AzureCredential, 'default_credential')
    def test_analyze_document_from_base64(self, mock_credential, mock_analyze_base64):
        """Test the analyze_document_from_base64 function."""
        # Configure mocks
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_response.status = "succeeded"
        mock_response.document_id = "test-job-id"
        mock_response.result = {"content": "Test document content"}
        mock_response.get_text.return_value = None  # Simulate that get_text is not available
        mock_analyze_base64.return_value = mock_response
        
        # Call the function
        content, job_id = analyze_document_from_base64(
            base64_string=self.test_base64,
            content_type="application/pdf",
            model_id="prebuilt-read"
        )
        
        # Verify that AzureDocumentProvider.analyze_document_from_base64 was called
        mock_analyze_base64.assert_called_once()
        args, kwargs = mock_analyze_base64.call_args
        self.assertEqual(kwargs['base64_string'], self.test_base64)
        self.assertEqual(kwargs['content_type'], "application/pdf")
        self.assertEqual(kwargs['model_id'], "prebuilt-read")
        
        # Verify the result using the content from result
        self.assertEqual(content, "Test document content")
        self.assertEqual(job_id, "test-job-id")

    @patch.object(AzureDocumentProvider, 'analyze_documents_batch_from_base64')
    @patch.object(AzureCredential, 'default_credential')
    def test_analyze_multiple_base64_documents(self, mock_credential, mock_analyze_batch):
        """Test the analyze_multiple_base64_documents function."""
        # Configure test documents
        documents = [
            {"base64_string": self.test_base64, "content_type": "application/pdf"},
            {"base64_string": self.test_base64, "content_type": "application/pdf"}
        ]
        
        # Configure mocks for the responses
        mock_response1 = MagicMock(spec=DocumentAnalysisResponse)
        mock_response1.status = "succeeded"
        mock_response1.get_text.return_value = "Document 1 content"
        
        mock_response2 = MagicMock(spec=DocumentAnalysisResponse)
        mock_response2.status = "succeeded"
        mock_response2.get_text.return_value = "Document 2 content"
        
        mock_analyze_batch.return_value = [mock_response1, mock_response2]
        
        # Call the function
        results = analyze_multiple_base64_documents(
            documents=documents,
            model_id="prebuilt-read"
        )
        
        # Verify that AzureDocumentProvider.analyze_documents_batch_from_base64 was called
        mock_analyze_batch.assert_called_once()
        args, kwargs = mock_analyze_batch.call_args
        
        # Verify arguments sent to the method
        self.assertEqual(kwargs['model_id'], "prebuilt-read")
        self.assertEqual(len(kwargs['documents']), 2)
        self.assertEqual(kwargs['documents'][0]['content'], self.test_base64)
        self.assertEqual(kwargs['documents'][0]['contentType'], "application/pdf")
        
        # Verify results
        self.assertEqual(len(results), 2)
        self.assertEqual(results["doc_0"], "Document 1 content")
        self.assertEqual(results["doc_1"], "Document 2 content")

    @patch.object(AzureDocumentProvider, 'analyze_document')
    @patch.object(AzureCredential, 'default_credential')
    def test_analyze_document_failed_status(self, mock_credential, mock_analyze):
        """Test the analyze_document function when the status is failed."""
        # Configure mock with failed status
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_response.status = "failed"
        mock_response.document_id = "test-job-id"
        mock_analyze.return_value = mock_response
        
        # Call the function
        content, job_id = analyze_document(
            file_path=self.test_pdf_path, 
            upload_mode="multipart"
        )
        
        # Verify that None is returned for content and the job ID is preserved
        self.assertIsNone(content)
        self.assertEqual(job_id, "test-job-id")

    def test_missing_environment_variables(self):
        """Test the behavior when environment variables are missing."""
        # Delete the required environment variables
        del os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"]
        del os.environ["AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"]
        
        # Test analyze_document
        content, job_id = analyze_document(
            file_path=self.test_pdf_path, 
            upload_mode="multipart"
        )
        self.assertIsNone(content)
        self.assertIsNone(job_id)
        
        # Test analyze_document_from_base64
        content, job_id = analyze_document_from_base64(
            base64_string=self.test_base64,
            content_type="application/pdf"
        )
        self.assertIsNone(content)
        self.assertIsNone(job_id)
        
        # Test analyze_multiple_base64_documents
        documents = [
            {"base64_string": self.test_base64, "content_type": "application/pdf"},
            {"base64_string": self.test_base64, "content_type": "application/pdf"}
        ]
        results = analyze_multiple_base64_documents(documents=documents)
        self.assertEqual(len(results), 2)
        self.assertIsNone(results["doc_0"])
        self.assertIsNone(results["doc_1"])

    @patch.object(AzureDocumentProvider, 'analyze_document')
    @patch.object(AzureCredential, 'default_credential')
    def test_analyze_document_exception(self, mock_credential, mock_analyze):
        """Test the analyze_document function when an exception occurs."""
        # Configure the mock to raise an exception
        mock_analyze.side_effect = Exception("Test error")
        
        # Call the function
        content, job_id = analyze_document(
            file_path=self.test_pdf_path, 
            upload_mode="multipart"
        )
        
        # Verify that exceptions are handled correctly
        self.assertIsNone(content)
        self.assertIsNone(job_id)


class TestComparisonBetweenModules(unittest.TestCase):
    """Tests to compare document_analysis.py and doc_intelligent_analysis.py modules."""

    def setUp(self):
        """Set up the test environment."""
        # Save original environment variables
        self.original_env = os.environ.copy()
        
        # Configure environment variables for testing
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"] = "https://test-endpoint.cognitiveservices.azure.com/"
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT"] = "https://test-pub-endpoint.cognitiveservices.azure.com/"
        
        # Define test path for documents
        self.test_pdf_path = Path("test_document.pdf")
        
        # Create a test base64 string
        self.test_base64 = "JVBERi0xLjMKJeLjz9MKMSAwIG9iago8PC9UeXBlL1BhZ2UvUGFyZW50IDIgMCBSL0NvbnRlbnRzIDMgMCBSPj4KZW5kb2JqCjMgMCBvYmoKPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxMD4+CnN0cmVhbQp4nCvk5QIABLQBuAplYmRpcwplbmRzdHJlYW0KZW5kb2JqCjIgMCBvYmoKPDwvVHlwZS9QYWdlcy9LaWRzWzEgMCBSXS9Db3VudCAxPj4KZW5kb2JqCjQgMCBvYmoKPDwvVHlwZS9DYXRhbG9nL1BhZ2VzIDIgMCBSPj4KZW5kb2JqCjUgMCBvYmoKPDwvUHJvZHVjZXIoVGVzdCBQREYpL0NyZWF0aW9uRGF0ZShEOjIwMjMwMTAxMDAwMDAwKT4+CmVuZG9iagp4cmVmCjAgNgowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAwMTAgMDAwMDAgbiAKMDAwMDAwMDEzNSAwMDAwMCBuIAowMDAwMDAwMDYzIDAwMDAwIG4gCjAwMDAwMDAxODYgMDAwMDAgbiAKMDAwMDAwMDIzMSAwMDAwMCBuIAp0cmFpbGVyCjw8L1Jvb3QgNCAwIFIvSW5mbyA1IDAgUi9TaXplIDY+PgpzdGFydHhyZWYKMzA0CiUlRU9G"
    
    def tearDown(self):
        """Restore the environment after each test."""
        # Restore original environment variables
        os.environ.clear()
        os.environ.update(self.original_env)

    @patch('requests.post')
    @patch('requests.get')
    @patch('builtins.open', new_callable=mock_open, read_data=b'test pdf content')
    @patch('pathlib.Path.exists', return_value=True)
    def test_api_compatibility(self, mock_exists, mock_file, mock_get, mock_post):
        """Test that both modules have the same interface and return compatible results."""
        # Configure mocks for HTTP requests
        mock_post_response = MagicMock()
        mock_post_response.status_code = 202
        mock_post_response.headers = {"Operation-Location": "https://test-endpoint.cognitiveservices.azure.com/operations/123"}
        mock_post.return_value = mock_post_response
        
        mock_get_response = MagicMock()
        mock_get_response.status_code = 200
        mock_get_response.json.return_value = {
            "status": "succeeded",
            "analyzeResult": {
                "content": "Test document content",
                "pages": []
            }
        }
        mock_get.return_value = mock_get_response
        
        # Call the functions from both modules with the same parameters
        with patch.object(AzureDocumentProvider, 'analyze_document') as mock_provider_analyze:
            # Configure the mock for AzureDocumentProvider
            mock_response = MagicMock(spec=DocumentAnalysisResponse)
            mock_response.status = "succeeded"
            mock_response.document_id = "test-job-id"
            mock_response.get_text.return_value = "Test document content"
            mock_provider_analyze.return_value = mock_response
            
            # Call the function from the new module
            new_content, new_job_id = analyze_document(
                file_path=self.test_pdf_path,
                upload_mode="multipart",
                model_id="prebuilt-read"
            )
        
        # Call the function from the original module
        old_content, old_job_id = analyze_document_original(
            file_path=self.test_pdf_path,
            upload_mode="multipart"
        )
        
        # Verify that they return similar results (although the implementation is different)
        self.assertIsNotNone(new_content)
        self.assertIsNotNone(old_content)
        
        # In a real case, we would verify that the contents are equal,
        # but since we're using different mocks, we only verify that they're not None

    @patch('requests.post')
    @patch('requests.get')
    @patch.object(AzureDocumentProvider, 'analyze_document_from_base64')
    def test_base64_api_compatibility(self, mock_provider_analyze, mock_get, mock_post):
        """Test that both modules have the same interface for base64 analysis."""
        # Configure mocks for the provider
        mock_response = MagicMock(spec=DocumentAnalysisResponse)
        mock_response.status = "succeeded"
        mock_response.document_id = "test-job-id"
        mock_response.get_text.return_value = "Test document content"
        mock_provider_analyze.return_value = mock_response
        
        # Configure mocks for direct HTTP requests
        mock_post_response = MagicMock()
        mock_post_response.status_code = 202
        mock_post_response.headers = {"Operation-Location": "https://test-endpoint.cognitiveservices.azure.com/operations/123"}
        mock_post.return_value = mock_post_response
        
        mock_get_response = MagicMock()
        mock_get_response.status_code = 200
        mock_get_response.json.return_value = {
            "status": "succeeded",
            "analyzeResult": {
                "content": "Test document content",
                "pages": []
            }
        }
        mock_get.return_value = mock_get_response
        
        # Call the functions from both modules with the same parameters
        new_content, new_job_id = analyze_document_from_base64(
            base64_string=self.test_base64,
            content_type="application/pdf",
            model_id="prebuilt-read"
        )
        
        old_content, old_job_id = analyze_document_from_base64_original(
            base64_string=self.test_base64,
            content_type="application/pdf"
        )
        
        # Verify that they return similar results
        self.assertIsNotNone(new_content)
        self.assertIsNotNone(old_content)
        
        # Verify that the provider was called with the correct parameters
        mock_provider_analyze.assert_called_once()
        args, kwargs = mock_provider_analyze.call_args
        self.assertEqual(kwargs['base64_string'], self.test_base64)
        self.assertEqual(kwargs['content_type'], "application/pdf")


if __name__ == "__main__":
    unittest.main() 