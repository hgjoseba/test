"""
Document analysis utility functions for Azure Document Intelligence.

This module provides direct utility functions for analyzing documents
using Azure Document Intelligence, including:
- analyze_document: Analyze a document from a file path
- analyze_document_from_base64: Analyze a document directly from a base64 string
- analyze_multiple_base64_documents: Analyze multiple base64 documents at once
"""

import os
import time
import base64
import requests
import warnings
from typing import Optional, Tuple, Dict, List, Any, Union

from .logging import get_logger
from ..auth import AzureCredential

logger = get_logger(__name__)

def analyze_base64_document(
    base64_string: str, 
    content_type: str = "application/pdf",
    model_id: str = "prebuilt-read",
    poll_interval: int = 5, 
    timeout: int = 300,
    api_version: str = "2024-11-30",
    credential = None,
    verify_ssl: Optional[bool] = True
) -> Optional[str]:
    """
    Analyzes a document in base64 format using Azure Document Intelligence (prebuilt-read).
    
    This function implements the complete workflow for analyzing base64 documents:
    1. Configures NO_PROXY for the private endpoint domain
    2. Gets authentication token using AzureCredential
    3. Sends the base64 data to the service
    4. Polls for results, replacing the public endpoint with the private one
    5. Returns the extracted text content
    
    Args:
        base64_string: String with base64 encoded document data
        content_type: Content type of the document (default: "application/pdf")
        model_id: ID of the model to use (default: "prebuilt-read")
        poll_interval: Interval (in seconds) between polling requests
        timeout: Maximum time (in seconds) to wait for the result
        api_version: Document Intelligence API version
        credential: Optional AzureCredential instance. If None, a default one will be created.
        verify_ssl: Whether to verify SSL certificates. Default: True.
    
    Returns:
        str: Extracted text content from the document, or None if an error occurs
    """
    # Read required environment variables
    private_fqdn = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", "").replace("https://", "")
    os.environ["NO_PROXY"] = private_fqdn
    PRIVATE_ENDPOINT = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    PUBLIC_ENDPOINT = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
    
    if not all([PRIVATE_ENDPOINT, PUBLIC_ENDPOINT]):
        logger.error("Missing required environment variables.")
        return None
        
    analyze_url = f"{PRIVATE_ENDPOINT}/documentintelligence/documentModels/{model_id}:analyze?api-version={api_version}"
    logger.info(f"Analyze URL: {analyze_url}")
    
    # Authentication using AzureCredential
    try:
        # Usar la credencial proporcionada o crear una nueva
        azure_credential = credential or AzureCredential.default_credential()
        token = azure_credential.get_token()
        logger.info("Token acquired successfully using AzureCredential.")
    except Exception as ex:
        logger.error(f"Error obtaining token: {ex}")
        return None
        
    headers = {"Authorization": f"Bearer {token}"}
    headers["Content-Type"] = "application/json"
    
    # Prepare payload for the request
    payload = {"base64Source": base64_string}
    
    # Send request
    try:
        response = requests.post(
            analyze_url, 
            headers=headers, 
            json=payload, 
            timeout=30, 
            verify=verify_ssl
        )
    except Exception as ex:
        logger.error(f"Error during base64 upload: {ex}")
        return None
        
    if response is None:
        logger.error("No response received during upload.")
        return None
        
    logger.info(f"Upload response, status: {response.status_code}")
    if response.status_code not in [200, 202]:
        logger.error(f"Upload failed: {response.status_code} {response.text}")
        return None
        
    op_location = response.headers.get("Operation-Location")
    if not op_location:
        logger.error("Operation-Location header not found in response.")
        return None
        
    logger.info(f"Operation-Location: {op_location}")
    # Extract job_id: we assume it's the last segment of the URL before the query string
    job_id = op_location.rstrip("/").split("/")[-1].split("?")[0]
    logger.info(f"Extracted Job ID: {job_id}")
    
    # Replace public endpoint with private endpoint in Operation-Location URL
    private_op_loc = op_location.replace(PUBLIC_ENDPOINT, PRIVATE_ENDPOINT)
    logger.info(f"Polling URL (private): {private_op_loc}")
    
    # Phase 2: Polling
    start_time = time.time()
    final_result = None
    while True:
        try:
            poll_response = requests.get(private_op_loc, headers=headers, timeout=30, verify=verify_ssl)
        except Exception as ex:
            logger.error(f"Error during GET polling: {ex}")
            time.sleep(poll_interval)
            continue
            
        logger.debug(f"Polling status: {poll_response}")
        if poll_response.status_code != 200:
            logger.error(f"Polling failed: {poll_response.status_code} {poll_response.text}")
            break
            
        try:
            result_json = poll_response.json()
        except Exception as ex:
            logger.error(f"Error decoding JSON in polling: {ex}")
            time.sleep(poll_interval)
            continue
            
        status = result_json.get("status")
        logger.info(f"Current job status: {status}")
        if status in ["running", "notStarted"]:
            if time.time() - start_time > timeout:
                logger.error("Polling timeout exceeded.")
                return None
            time.sleep(poll_interval)
        elif status == "succeeded":
            final_result = result_json
            logger.info("Job completed successfully.")
            break
        else:
            logger.error(f"Job completed with unexpected status: {status}")
            final_result = result_json
            break
            
    if final_result and "analyzeResult" in final_result and "content" in final_result["analyzeResult"]:
        return final_result["analyzeResult"]["content"]
    return None

def analyze_multiple_base64_documents(documents: List[Dict[str, str]], credential=None, verify_ssl: Optional[bool] = True, **kwargs) -> Dict[str, Optional[str]]:
    """
    Analyzes multiple base64-encoded documents and returns a dictionary with the results.
    
    Args:
        documents: List of dictionaries with 'base64_string' and optionally 'content_type'
        credential: Optional AzureCredential instance. If None, a default one will be created.
        verify_ssl: Whether to verify SSL certificates. Default: True.
        **kwargs: Additional arguments to pass to analyze_base64_document
        
    Returns:
        Dict[str, Optional[str]]: Dictionary with indices and extracted content
    """
    results = {}
    
    # Usar la credencial proporcionada o crear una nueva
    azure_credential = credential or AzureCredential.default_credential()
    
    for i, doc in enumerate(documents):
        base64_string = doc.get('base64_string')
        content_type = doc.get('content_type', 'application/pdf')
        
        if not base64_string:
            results[f"doc_{i}"] = None
            continue
            
        # Analyze individual document
        content = analyze_base64_document(
            base64_string=base64_string,
            content_type=content_type,
            credential=azure_credential,
            verify_ssl=verify_ssl,
            **kwargs
        )
        
        results[f"doc_{i}"] = content
        
    return results 

def analyze_document(file_path, upload_mode="multipart", poll_interval=5, timeout=300, credential=None, verify_ssl: Optional[bool] = True) -> Tuple[Optional[str], Optional[str]]:
    """
    Analyzes a document using the Document Intelligence service in two phases.
   
    Direct implementation of the original example, which uses:
    - NO_PROXY configuration for the private endpoint domain
    - Authentication with AzureCredential
    - Replacement of public endpoint with private one during polling
    - Support for uploading via multipart/form-data or base64
   
    Args:
      - file_path: path to the document file to analyze (PDF)
      - upload_mode: "multipart" or "base64" for document upload.
      - poll_interval: interval (in seconds) between polling requests.
      - timeout: maximum time (in seconds) to wait for results.
      - credential: Optional AzureCredential instance. If None, a default one will be created.
      - verify_ssl: Whether to verify SSL certificates. Default: True.
     
    Returns:
      - final_result: JSON with analysis result (or None in case of error).
      - job_id: task identifier extracted from Operation-Location.
    """
    # Read required environment variables
    # Set NO_PROXY so the private endpoint FQDN bypasses the proxy
    private_fqdn = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", "").replace("https://", "")
    os.environ["NO_PROXY"] = private_fqdn
    PRIVATE_ENDPOINT = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    PUBLIC_ENDPOINT = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
   
    if not all([PRIVATE_ENDPOINT, PUBLIC_ENDPOINT]):
        logger.error("Missing required environment variables.")
        return None, None

    api_version = "2024-11-30"
    analyze_url = f"{PRIVATE_ENDPOINT}/documentintelligence/documentModels/prebuilt-read:analyze?api-version={api_version}"
    logger.info(f"Analyze URL: {analyze_url}")

    # Authentication using AzureCredential
    try:
        # Usar la credencial proporcionada o crear una nueva
        azure_credential = credential or AzureCredential.default_credential()
        token = azure_credential.get_token()
        logger.info("Token acquired successfully using AzureCredential.")
    except Exception as ex:
        logger.error(f"Error obtaining token: {ex}")
        return None, None

    headers = {"Authorization": f"Bearer {token}"}
    response = None
    if upload_mode == "multipart":
        logger.info("Uploading file using multipart/form-data...")
        try:
            with open(file_path, "rb") as f:
                files = {"file": (os.path.basename(file_path), f, "application/pdf")}
                response = requests.post(analyze_url, headers=headers, files=files, timeout=30, verify=verify_ssl)
        except Exception as ex:
            logger.error(f"Error during multipart upload: {ex}")
            return None, None
    elif upload_mode == "base64":
        logger.info("Uploading file using base64...")
        try:
            with open(file_path, "rb") as f:
                file_bytes = f.read()
            encoded_data = base64.b64encode(file_bytes).decode("utf-8")
            payload = {"base64Source": encoded_data}
            headers["Content-Type"] = "application/json"
            response = requests.post(analyze_url, headers=headers, json=payload, timeout=30, verify=verify_ssl)
        except Exception as ex:
            logger.error(f"Error during base64 upload: {ex}")
            return None, None

    if response is None:
        logger.error("No response received during upload.")
        return None, None

    logger.info(f"Upload response, status: {response.status_code}")
    if response.status_code not in [200, 202]:
        logger.error(f"Upload failed: {response.status_code} {response.text}")
        return None, None

    op_location = response.headers.get("Operation-Location")
    if not op_location:
        logger.error("Operation-Location header not found in response.")
        return None, None

    logger.info(f"Operation-Location: {op_location}")
    # Extract job_id: we assume it's the last segment of the URL before the query string
    job_id = op_location.rstrip("/").split("/")[-1].split("?")[0]
    logger.info(f"Extracted Job ID: {job_id}")

    # Replace public endpoint with private endpoint in Operation-Location URL
    private_op_loc = op_location.replace(PUBLIC_ENDPOINT, PRIVATE_ENDPOINT)
    logger.info(f"Polling URL (private): {private_op_loc}")

    # Phase 2: Polling
    start_time = time.time()
    final_result = None
    while True:
        try:
            poll_response = requests.get(private_op_loc, headers=headers, timeout=30, verify=verify_ssl)
        except Exception as ex:
            logger.error(f"Error during GET polling: {ex}")
            time.sleep(poll_interval)
            continue

        logger.debug(f"Polling status: {poll_response}")
        if poll_response.status_code != 200:
            logger.error(f"Polling failed: {poll_response.status_code} {poll_response.text}")
            break

        try:
            result_json = poll_response.json()
        except Exception as ex:
            logger.error(f"Error decoding JSON in polling: {ex}")
            time.sleep(poll_interval)
            continue

        status = result_json.get("status")
        logger.info(f"Current job status: {status}")
        if status in ["running", "notStarted"]:
            if time.time() - start_time > timeout:
                logger.error("Polling timeout exceeded.")
                return None, job_id
            time.sleep(poll_interval)
        elif status == "succeeded":
            final_result = result_json
            logger.info("Job completed successfully.")
            break
        else:
            logger.error(f"Job completed with unexpected status: {status}")
            final_result = result_json
            break

    if final_result and "analyzeResult" in final_result and "content" in final_result["analyzeResult"]:
        return final_result["analyzeResult"]["content"], job_id
    return None, job_id

def analyze_document_from_base64(
    base64_string: str,
    content_type: str = "application/pdf",
    model_id: str = "prebuilt-read",
    poll_interval: int = 5,
    timeout: int = 300,
    credential = None,
    verify_ssl: Optional[bool] = True
) -> Tuple[Optional[str], Optional[str]]:
    """
    Analyzes a document directly from a base64 string.
    
    Unlike analyze_document with upload_mode="base64", this function
    accepts the base64 string directly instead of a file path. Useful when
    the content is already encoded in base64 in memory.
    
    Implements the same workflow as analyze_document:
    - NO_PROXY configuration for private endpoints
    - Authentication with AzureCredential
    - Two-phase analysis handling (upload and polling)
    - Replacement of public endpoints with private ones during polling
    
    Args:
        base64_string: Base64 encoded string containing the document
        content_type: Content type of the document. Default: "application/pdf"
        model_id: ID of the model to use. Default: "prebuilt-read"
        poll_interval: Interval (in seconds) between polling requests. Default: 5
        timeout: Maximum time (in seconds) to wait for the result. Default: 300
        credential: Optional AzureCredential instance. If None, a default one will be created.
        verify_ssl: Whether to verify SSL certificates. Default: True.
        
    Returns:
        Tuple[Optional[str], Optional[str]]: Extracted text content and job_id
    """
    # Read required environment variables
    # Set NO_PROXY so the private endpoint FQDN bypasses the proxy
    private_fqdn = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", "").replace("https://", "")
    os.environ["NO_PROXY"] = private_fqdn
    PRIVATE_ENDPOINT = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    PUBLIC_ENDPOINT = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
   
    if not all([PRIVATE_ENDPOINT, PUBLIC_ENDPOINT]):
        logger.error("Missing required environment variables.")
        return None, None

    api_version = "2024-11-30"
    analyze_url = f"{PRIVATE_ENDPOINT}/documentintelligence/documentModels/{model_id}:analyze?api-version={api_version}"
    logger.info(f"Analyze URL (direct base64): {analyze_url}")

    # Authentication using AzureCredential
    try:
        # Usar la credencial proporcionada o crear una nueva
        azure_credential = credential or AzureCredential.default_credential()
        token = azure_credential.get_token()
        logger.info("Token acquired successfully using AzureCredential.")
    except Exception as ex:
        logger.error(f"Error obtaining token: {ex}")
        return None, None

    # Prepare headers and payload
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    # Use the provided base64 string directly
    payload = {"base64Source": base64_string}
    
    # Send the request
    try:
        logger.info("Sending base64 string for analysis...")
        response = requests.post(analyze_url, headers=headers, json=payload, timeout=30, verify=verify_ssl)
    except Exception as ex:
        logger.error(f"Error during base64 upload: {ex}")
        return None, None

    if response is None:
        logger.error("No response received during upload.")
        return None, None

    logger.info(f"Upload response, status: {response.status_code}")
    if response.status_code not in [200, 202]:
        logger.error(f"Upload failed: {response.status_code} {response.text}")
        return None, None

    op_location = response.headers.get("Operation-Location")
    if not op_location:
        logger.error("Operation-Location header not found in response.")
        return None, None

    logger.info(f"Operation-Location: {op_location}")
    # Extract job_id: we assume it's the last segment of the URL before the query string
    job_id = op_location.rstrip("/").split("/")[-1].split("?")[0]
    logger.info(f"Extracted Job ID: {job_id}")

    # Replace public endpoint with private endpoint in Operation-Location URL
    private_op_loc = op_location.replace(PUBLIC_ENDPOINT, PRIVATE_ENDPOINT)
    logger.info(f"Polling URL (private): {private_op_loc}")

    # Phase 2: Polling
    start_time = time.time()
    final_result = None
    while True:
        try:
            poll_response = requests.get(private_op_loc, headers=headers, timeout=30, verify=verify_ssl)
        except Exception as ex:
            logger.error(f"Error during GET polling: {ex}")
            time.sleep(poll_interval)
            continue

        logger.debug(f"Polling status: {poll_response}")
        if poll_response.status_code != 200:
            logger.error(f"Polling failed: {poll_response.status_code} {poll_response.text}")
            break

        try:
            result_json = poll_response.json()
        except Exception as ex:
            logger.error(f"Error decoding JSON in polling: {ex}")
            time.sleep(poll_interval)
            continue

        status = result_json.get("status")
        logger.info(f"Current job status: {status}")
        if status in ["running", "notStarted"]:
            if time.time() - start_time > timeout:
                logger.error("Polling timeout exceeded.")
                return None, job_id
            time.sleep(poll_interval)
        elif status == "succeeded":
            final_result = result_json
            logger.info("Job completed successfully.")
            break
        else:
            logger.error(f"Job completed with unexpected status: {status}")
            final_result = result_json
            break

    if final_result and "analyzeResult" in final_result and "content" in final_result["analyzeResult"]:
        return final_result["analyzeResult"]["content"], job_id
    return None, job_id 