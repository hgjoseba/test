"""
Response models for Document Intelligence SDK (OCR version).

This module defines the response models for document analysis operations,
focused on text extraction.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, validator

from .document import AnalyzedDocument, DocumentStatus
from ..utils.errors import DocumentIntelligenceError
from ..utils.logging import get_logger

logger = get_logger(__name__)


class DocumentAnalysisResponse(BaseModel):
    """
    Represents a response from the document analysis service.
    
    This model wraps the raw response and provides methods to access the
    analyzed document and error information.
    """
    status: str = Field(...)
    created_on: datetime = Field(default_factory=lambda: datetime.now())
    last_updated_on: Optional[datetime] = None
    expires_on: Optional[datetime] = None
    result: Optional[Union[Dict[str, Any], Any]] = None
    errors: List[Dict[str, str]] = Field(default_factory=list)
    model_id: str = Field(default="unknown")
    _analyzed_document: Optional[AnalyzedDocument] = None
    
    class Config:
        """Configuration for the DocumentAnalysisResponse model."""
        underscore_attrs_are_private = True
        arbitrary_types_allowed = True
        validate_assignment = True
    
    @validator("status")
    def validate_status(cls, value: str) -> str:
        """Validate the status value."""
        if value is None:
            raise ValueError("Status cannot be None")
            
        if not isinstance(value, str):
            raise ValueError("Status must be a string")
        
        valid_statuses = ["succeeded", "failed", "running", "not_started"]
        if value not in valid_statuses:
            raise ValueError(f"Invalid status value: {value}")
        
        return value
    
    def get_errors(self) -> List[Dict[str, str]]:
        """Get the list of errors from the response."""
        if self.status == 'failed':
            if isinstance(self.result, dict) and "errors" in self.result:
                return self.result["errors"]
            return self.errors
        return []
    
    def get_analyzed_document(self) -> Optional[AnalyzedDocument]:
        """
        Get the analyzed document from the response.
        
        Returns:
            Optional[AnalyzedDocument]: The analyzed document if available, None otherwise.
            
        Raises:
            DocumentIntelligenceError: If the document analysis is in an invalid state.
        """
        if self.status == "not_started":
            return AnalyzedDocument(
                model_id="unknown",
                status=DocumentStatus.RUNNING
            )
            
        if self.status == "running":
            return AnalyzedDocument(
                model_id="unknown",
                status=DocumentStatus.RUNNING
            )
        
        if self.status == "failed":
            return AnalyzedDocument(
                model_id="unknown",
                status=DocumentStatus.FAILED
            )

        if self.status != "succeeded":
            raise DocumentIntelligenceError(f"Invalid document status: {self.status}")

        if self._analyzed_document is not None:
            return self._analyzed_document

        if not self.result:
            return AnalyzedDocument(
                model_id="unknown",
                status=DocumentStatus.SUCCEEDED
            )

        self._analyzed_document = self.build_analyzed_document()
        return self._analyzed_document
    
    def build_analyzed_document(self) -> Optional[AnalyzedDocument]:
        """
        Build an AnalyzedDocument from the response result.
        
        Returns:
            AnalyzedDocument: The constructed document.
        """
        if not self.result:
            return None
        
        # If the result is a dictionary, convert it to an object
        if isinstance(self.result, dict):
            model_id = self.result.get("modelId", "unknown")
            content = self.result.get("content", "")
            content_type = self.result.get("contentType", "application/octet-stream")
            file_name = self.result.get("fileName")
            language = self.result.get("language")
            pages = self.result.get("pages", [])
            
            # Convert pages to proper format
            formatted_pages = []
            for page in pages:
                formatted_page = {
                    "page_number": page.get("pageNumber", 1),
                    "width": page.get("width", 8.5),
                    "height": page.get("height", 11.0),
                    "unit": page.get("unit", "inch"),
                    "lines": []
                }
                
                for line in page.get("lines", []):
                    formatted_line = {
                        "content": line.get("content", ""),
                        "confidence": line.get("confidence", 1.0),
                        "span": line.get("span", {"offset": 0, "length": len(line.get("content", ""))})
                    }
                    formatted_page["lines"].append(formatted_line)
                
                formatted_pages.append(formatted_page)
            
            return AnalyzedDocument(
                model_id=model_id,
                content=content,
                content_type=content_type,
                file_name=file_name,
                language=language,
                pages=formatted_pages,
                status=DocumentStatus.SUCCEEDED
            )
        
        return AnalyzedDocument.from_azure_result(self.result)
    
    def get_text(self) -> str:
        """
        Get the text content from the analyzed document.
        
        Returns:
            str: The extracted text content.
        """
        try:
            document = self.get_analyzed_document()
            if document:
                return document.get_text()
        except DocumentIntelligenceError:
            pass
        return ""
    
    @classmethod
    def from_azure_result(cls, result: Any) -> "DocumentAnalysisResponse":
        """
        Create a DocumentAnalysisResponse from an Azure API result.
        
        Args:
            result: The Azure API result.
            
        Returns:
            DocumentAnalysisResponse: The constructed response.
        """
        # Determinar el estado de la respuesta
        if isinstance(result, dict):
            # Si es un diccionario (JSON), obtiene el status directamente
            status = result.get("status", "failed")
        else:
            # Si es un objeto, intenta obtener el atributo status
            status = getattr(result, "status", "failed")
        
        # Procesar el resto de los campos
        if isinstance(result, dict):
            created_on = result.get("createdDateTime", datetime.now())
            last_updated_on = result.get("lastUpdatedDateTime")
            expires_on = result.get("expiresDateTime")
        else:
            created_on = getattr(result, "created_date_time", datetime.now())
            last_updated_on = getattr(result, "last_updated_date_time", None)
            expires_on = getattr(result, "expires_date_time", None)
        
        # Handle errors if present
        errors = []
        if isinstance(result, dict) and "errors" in result:
            errors = result["errors"]
        elif hasattr(result, "errors") and result.errors:
            for error in result.errors:
                if isinstance(error, dict):
                    errors.append(error)
                else:
                    errors.append({
                        "code": getattr(error, "code", "unknown"),
                        "message": getattr(error, "message", "Unknown error")
                    })
        
        # Extract model_id
        model_id = "unknown"
        if isinstance(result, dict) and "analyzeResult" in result:
            model_id = result["analyzeResult"].get("modelId", "unknown")
        elif hasattr(result, "analyze_result") and hasattr(result.analyze_result, "model_id"):
            model_id = result.analyze_result.model_id
        elif hasattr(result, "model_id"):
            model_id = result.model_id
        
        # Convert result to dictionary if not None
        result_dict = None
        if result is not None and status != "running":
            try:
                if isinstance(result, dict) and "analyzeResult" in result:
                    # Handle direct dictionary from JSON
                    analyze_result = result["analyzeResult"]
                    result_dict = {
                        "modelId": analyze_result.get("modelId", "unknown"),
                        "content": analyze_result.get("content", ""),
                        "contentType": result.get("contentType", ""),
                        "fileName": result.get("fileName", None),
                        "language": analyze_result.get("language", None),
                        "pages": analyze_result.get("pages", [])
                    }
                elif hasattr(result, "analyze_result"):
                    # Handle newer API format
                    analyze_result = result.analyze_result
                    result_dict = {
                        "modelId": getattr(analyze_result, "model_id", "unknown"),
                        "content": getattr(analyze_result, "content", ""),
                        "contentType": getattr(result, "content_type", ""),
                        "fileName": getattr(result, "file_name", None),
                        "language": getattr(analyze_result, "language", None),
                        "pages": []
                    }
                    if hasattr(analyze_result, "pages"):
                        result_dict["pages"] = [
                            {
                                "pageNumber": page.page_number,
                                "width": getattr(page, "width", 8.5),
                                "height": getattr(page, "height", 11.0),
                                "unit": getattr(page, "unit", "inch"),
                                "lines": [
                                    {
                                        "content": line.content,
                                        "confidence": getattr(line, "confidence", 1.0),
                                        "span": {"offset": 0, "length": len(line.content)}
                                    } for line in page.lines
                                ]
                            } for page in analyze_result.pages
                        ]
                elif hasattr(result, "to_dict"):
                    result_dict = result.to_dict()
                else:
                    # Try to convert the object to a dictionary
                    result_dict = {
                        key: getattr(result, key) 
                        for key in dir(result) 
                        if not key.startswith('_') and not callable(getattr(result, key))
                    }
            except Exception as e:
                logger.warning(f"Could not convert result to dictionary: {str(e)}")
                result_dict = None
        
        # Add errors to result if present
        if errors:
            result_dict = result_dict or {}
            result_dict["errors"] = errors
        
        return cls(
            status=status,
            model_id=model_id,
            created_on=created_on,
            last_updated_on=last_updated_on,
            expires_on=expires_on,
            result=result_dict,
            errors=errors
        ) 