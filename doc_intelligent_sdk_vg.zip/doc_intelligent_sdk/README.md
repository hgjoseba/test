# Document Intelligence SDK

SDK para extracción de texto y análisis de documentos utilizando servicios de inteligencia artificial.

## Descripción

Este SDK proporciona una interfaz simplificada para extraer texto plano de documentos utilizando el servicio Azure Document Intelligence. Es ideal para aplicaciones que solo necesitan la funcionalidad de OCR (Reconocimiento Óptico de Caracteres) sin el procesamiento adicional de tablas, pares clave-valor u otros elementos estructurados.

## Características

- **Extracción de texto simplificada**: Extraiga texto de documentos (PDF, DOCX, imágenes) con una API sencilla
- **Análisis de documentos**: Utilice modelos pre-entrenados para reconocer y extraer campos específicos
- **Soporte para múltiples proveedores**: Actualmente compatible con Azure Document Intelligence
- **Soporte para múltiples fuentes**: Procesar documentos desde archivos locales o datos codificados en base64
- **Autenticación flexible**: Soporte para autenticación con API Key, Service Principal y Managed Identity
- **Manejo de endpoints privados**: Compatibilidad con Azure Private Link y configuración automática de NO_PROXY
- **API Versión 2024-11-30**: Implementa la versión más reciente de la API de Document Intelligence
- **Módulos flexibles**: Elija entre el módulo de utilidades directo o el basado en el SDK estructurado

## Instalación

```bash
pip install doc-intelligent-sdk
```

## Requisitos

- Python 3.7 o superior
- Cuenta de Azure con acceso al servicio Document Intelligence (anteriormente Form Recognizer)

## Uso básico

### Configuración

```python
from doc_intelligent import DocIntelligenceClient

# Inicializar cliente
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    api_key="your_api_key",
    api_version="2024-11-30"  # Versión más reciente de la API
)

# Extraer texto de un documento
texto = client.extract_text("documento.pdf")
print(texto)
```

### Métodos de transferencia: Multipart vs Base64

El SDK ofrece dos métodos principales para transferir documentos al servicio:

#### 1. Multipart/form-data (analyze_document)

```python
# Recomendado para archivos locales (más eficiente)
response = client.analyze_document(
    file_path="documento.pdf",
    model_id="prebuilt-document"
)
```

**Ventajas:**
- Mayor eficiencia en archivos grandes (menor overhead)
- Menor consumo de memoria
- Mejor compatibilidad con proxies corporativos

**Uso recomendado:** Para archivos que existen en el sistema de archivos local.

#### 2. Base64 (analyze_document_from_base64)

```python
import base64

# Útil para documentos en memoria o generados dinámicamente
with open("documento.pdf", "rb") as f:
    content = f.read()
base64_string = base64.b64encode(content).decode("utf-8")

# Analizar usando datos base64
texto = client.extract_text_from_base64(
    base64_string=base64_string,
    content_type="application/pdf"
)
```

**Ventajas:**
- Ideal para documentos ya en memoria
- Compatible con APIs JSON
- Funciona en entornos sin acceso al sistema de archivos

**Uso recomendado:** Para documentos que provienen de APIs, bases de datos o son generados dinámicamente.

### Módulos de utilidades

El SDK ofrece dos enfoques para el análisis de documentos a nivel de utilidades:

#### 1. Enfoque directo (document_analysis.py)

```python
from doc_intelligent.utils.document_analysis import analyze_document

# Analizar documento directamente
texto, job_id = analyze_document(
    file_path="documento.pdf",
    upload_mode="multipart"
)
```

**Características:**
- Implementación directa con la API de Azure Document Intelligence
- Acceso de bajo nivel a la API
- Devolución de resultados como JSON o string

#### 2. Enfoque estructurado (doc_intelligent_analysis.py)

```python
from doc_intelligent.utils.doc_intelligent_analysis import analyze_document

# Utiliza internamente AzureDocumentProvider
texto, job_id = analyze_document(
    file_path="documento.pdf",
    upload_mode="multipart"
)
```

**Características:**
- Utiliza la clase `AzureDocumentProvider` internamente
- Misma interfaz que el enfoque directo
- Mejor manejo de errores con excepciones tipadas
- Mayor robustez y flexibilidad

Puede comparar ambos enfoques ejecutando el ejemplo proporcionado:

```bash
python examples/doc_intelligent_analysis_example.py
```

### Autenticación avanzada

#### Con Service Principal

```python
from azure.identity import ClientSecretCredential
from doc_intelligent import DocIntelligenceClient

# Crear credencial de Service Principal
credential = ClientSecretCredential(
    tenant_id="your_tenant_id",
    client_id="your_client_id",
    client_secret="your_client_secret"
)

# Inicializar cliente con credencial
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    credential=credential
)

# El resto del código es igual
```

### Configuración mediante variables de entorno

```bash
# Azure Document Intelligence
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
export AZURE_DOCUMENT_INTELLIGENCE_KEY=your_api_key
export AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT=https://your-region.api.cognitive.microsoft.com/

# Service Principal (opcional)
export AZURE_TENANT_ID=your_tenant_id
export AZURE_CLIENT_ID=your_client_id
export AZURE_CLIENT_SECRET=your_client_secret

# Versión de API (opcional)
export DOC_INTELLIGENCE_API_VERSION=2024-11-30  # Opcional, por defecto a la última versión
```

### Ejemplos

Consulte la carpeta [examples](./examples) para ver ejemplos completos de:

- Uso básico con diferentes tipos de documentos
- Autenticación con Service Principal
- Uso con Azure Private Link
- Procesamiento de documentos base64
- Análisis por lotes de múltiples documentos
- Comparación entre módulos de utilidades

## Variables de entorno

El SDK puede configurarse utilizando variables de entorno:

```
DOC_INTELLIGENCE_ENDPOINT=https://su-recurso.cognitiveservices.azure.com/
DOC_INTELLIGENCE_API_KEY=su-clave-api
DOC_INTELLIGENCE_API_VERSION=2023-07-31  # Opcional, por defecto a la última versión
```

## Migración entre enfoques de utilidades

Si está utilizando actualmente las funciones de `document_analysis.py` y desea migrar al enfoque estructurado con `doc_intelligent_analysis.py`, puede hacerlo fácilmente cambiando los imports:

```python
# Antes
from doc_intelligent.utils.document_analysis import analyze_document

# Después
from doc_intelligent.utils.doc_intelligent_analysis import analyze_document

# La interfaz y parámetros se mantienen iguales
texto, job_id = analyze_document(file_path="documento.pdf", upload_mode="multipart")
```

## Contribución

Las contribuciones son bienvenidas. Por favor, siga estos pasos:

1. Haga un fork del repositorio
2. Cree una rama para su característica (`git checkout -b feature/amazing-feature`)
3. Confirme sus cambios (`git commit -m 'Añadir característica asombrosa'`)
4. Empuje a la rama (`git push origin feature/amazing-feature`)
5. Abra una Pull Request

## Licencia

Distribuido bajo la licencia MIT. Vea `LICENSE` para más información. 