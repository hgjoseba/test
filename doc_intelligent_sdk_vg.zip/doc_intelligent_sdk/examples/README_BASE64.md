# Ejemplos de Análisis de Documentos con Base64

Este directorio contiene ejemplos que muestran cómo analizar documentos utilizando strings base64 con Azure Document Intelligence.

## Ventajas del enfoque base64

El uso de base64 tiene varias ventajas en ciertos escenarios:

- **Datos ya en memoria**: Ideal cuando el documento ya está cargado en memoria y no como archivo físico
- **APIs JSON**: Permite enviar documentos a través de APIs JSON sin multipart/form-data
- **Entornos serverless**: Funciona bien en entornos donde no hay acceso directo al sistema de archivos
- **Facilidad de almacenamiento**: Los strings base64 se pueden almacenar en bases de datos o transmitir fácilmente
- **Integración con otras fuentes**: Útil cuando los datos provienen de sistemas que ya usan base64 (como algunas APIs)

## Archivos de ejemplo

- **base64_analysis_example.py**: Ejemplo principal que muestra cómo utilizar los dos métodos base64:
  - Método 2: Convertir un archivo a base64 y analizarlo con `analyze_document`
  - Método 3: Analizar directamente un string base64 con `analyze_document_from_base64`

- **base64_utils.py**: Utilidades complementarias para trabajar con strings base64:
  - Convertir archivos a strings base64
  - Guardar/cargar strings base64 en/desde archivos
  - Ver información sobre strings base64
  - Verificar el contenido decodificado

## Cómo usar los ejemplos

### 1. Preparar las variables de entorno

```bash
export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT="https://tu-endpoint-privado.cognitiveservices.azure.com/"
export AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT="https://eastus.api.cognitive.microsoft.com/"
```

### 2. Crear un string base64 desde un archivo

```bash
python base64_utils.py -c ruta/al/documento.pdf -o documento.b64 --info --sample
```

### 3. Analizar un documento usando base64 desde archivo

```bash
python base64_analysis_example.py -f ruta/al/documento.pdf -m 2 -o resultado.txt
```

### 4. Analizar un documento desde un string base64 preexistente

```bash
python base64_analysis_example.py -b documento.b64 -m 3 -o resultado.txt
```

### 5. Comparar ambos métodos base64

```bash
python base64_analysis_example.py -f ruta/al/documento.pdf -m 1 -o resultado.txt
```

## Opciones de línea de comandos

### base64_analysis_example.py

```
  -h, --help            Mostrar este mensaje de ayuda
  --file FILE, -f FILE  Ruta al archivo a analizar
  --b64file B64FILE, -b B64FILE
                        Ruta al archivo .b64 que contiene el string base64
  --content-type CONTENT_TYPE, -c CONTENT_TYPE
                        Tipo de contenido del documento (default: application/pdf)
  --output OUTPUT, -o OUTPUT
                        Archivo de salida para guardar el texto extraído
  --mode {1,2,3}, -m {1,2,3}
                        Modo de ejecución: 1=ambos métodos, 2=base64 desde archivo, 3=base64 directo
```

### base64_utils.py

```
  -h, --help            Mostrar este mensaje de ayuda
  --convert CONVERT, -c CONVERT
                        Convertir archivo a base64
  --save SAVE, -s SAVE  Guardar string base64 en archivo
  --load LOAD, -l LOAD  Cargar string base64 desde archivo
  --output OUTPUT, -o OUTPUT
                        Archivo de salida
  --info, -i            Mostrar información del string base64
  --sample              Mostrar muestra del contenido decodificado
```

## Flujo de trabajo típico

1. Convertir un documento a base64 y guardarlo:
   ```bash
   python base64_utils.py -c documento.pdf -o documento.b64 --info
   ```

2. Verificar el string base64:
   ```bash
   python base64_utils.py -l documento.b64 --info --sample
   ```

3. Analizar el documento base64:
   ```bash
   python base64_analysis_example.py -b documento.b64 -o resultado.txt
   ```

## Notas importantes

- Los strings base64 son aproximadamente un 33% más grandes que los datos originales
- Para archivos grandes, el enfoque multipart/form-data (no base64) es más eficiente en términos de memoria y ancho de banda
- Asegúrate de utilizar el content-type correcto (ej. "application/pdf" para PDFs)
- Los archivos .b64 son archivos de texto plano que contienen el string base64, sin formatear 