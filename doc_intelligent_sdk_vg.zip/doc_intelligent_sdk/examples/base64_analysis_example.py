#!/usr/bin/env python
"""
Ejemplo de análisis de documentos utilizando exclusivamente métodos base64.

Este ejemplo muestra cómo analizar documentos utilizando los dos enfoques base64:
1. Método 2: Convertir un archivo a base64 y analizarlo (analyze_document con upload_mode="base64")
2. Método 3: Analizar directamente un string base64 preexistente (analyze_document_from_base64)

Ideal para escenarios donde:
- Se necesita trabajar con datos ya en memoria
- Se requiere enviar documentos a través de APIs JSON
- Se está en entornos serverless sin acceso al sistema de archivos
"""

import os
import sys
import time
import base64
import argparse
from doc_intelligent.utils import analyze_document, analyze_document_from_base64

# Verificar variables de entorno necesarias
REQUIRED_ENV = [
    "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT",     # Endpoint privado 
    "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT", # Endpoint público
]

def check_env_vars():
    """Verifica que las variables de entorno necesarias estén configuradas."""
    missing = [var for var in REQUIRED_ENV if not os.environ.get(var)]
    if missing:
        print(f"❌ Error: Faltan variables de entorno requeridas: {', '.join(missing)}")
        print("\nConfigura estas variables antes de ejecutar el ejemplo:")
        print("export AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://tu-endpoint-privado.cognitiveservices.azure.com/")
        print("export AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT=https://eastus.api.cognitive.microsoft.com/")
        return False
    return True

def base64_file_analysis(file_path):
    """
    Analiza un documento convirtiéndolo a base64.
    
    Args:
        file_path: Ruta al archivo a analizar
        
    Returns:
        Tuple: (texto_extraído, tiempo_ejecución)
    """
    print(f"\n=== Análisis de archivo mediante conversión a base64 ===")
    print(f"Archivo: {file_path}")
    
    start_time = time.time()
    content, job_id = analyze_document(
        file_path=file_path,
        upload_mode="base64",
        poll_interval=5,
        timeout=300
    )
    execution_time = time.time() - start_time
    
    if content:
        print(f"✅ Análisis completado en {execution_time:.2f} segundos")
        print(f"Job ID: {job_id}")
        print(f"Texto extraído ({len(content)} caracteres)")
        print(f"\nPrimeros 200 caracteres:")
        print("-" * 50)
        print(content[:200] + "...")
        print("-" * 50)
    else:
        print(f"❌ Error en el análisis. Job ID: {job_id}")
    
    return content, execution_time

def direct_base64_analysis(base64_string, content_type="application/pdf"):
    """
    Analiza un documento directamente desde un string base64.
    
    Args:
        base64_string: String base64 que contiene el documento
        content_type: Tipo de contenido del documento
        
    Returns:
        Tuple: (texto_extraído, tiempo_ejecución)
    """
    print(f"\n=== Análisis directo de string base64 ===")
    print(f"Longitud del string base64: {len(base64_string)} caracteres")
    print(f"Tipo de contenido: {content_type}")
    
    start_time = time.time()
    content, job_id = analyze_document_from_base64(
        base64_string=base64_string,
        content_type=content_type,
        poll_interval=5,
        timeout=300
    )
    execution_time = time.time() - start_time
    
    if content:
        print(f"✅ Análisis completado en {execution_time:.2f} segundos")
        print(f"Job ID: {job_id}")
        print(f"Texto extraído ({len(content)} caracteres)")
        print(f"\nPrimeros 200 caracteres:")
        print("-" * 50)
        print(content[:200] + "...")
        print("-" * 50)
    else:
        print(f"❌ Error en el análisis. Job ID: {job_id}")
    
    return content, execution_time

def save_text_to_file(content, output_file=None):
    """
    Guarda el texto extraído en un archivo.
    
    Args:
        content: Texto a guardar
        output_file: Ruta del archivo de salida (opcional)
        
    Returns:
        bool: True si se guardó correctamente, False en caso contrario
    """
    if not content:
        return False
        
    if not output_file:
        output_file = input("\nIngresa el nombre del archivo de salida: ")
        
    try:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"✅ Texto guardado en: {output_file}")
        return True
    except Exception as e:
        print(f"❌ Error al guardar el archivo: {e}")
        return False

def main():
    # Configurar argumentos de línea de comandos
    parser = argparse.ArgumentParser(description="Ejemplo de análisis de documentos usando métodos base64")
    parser.add_argument("--file", "-f", help="Ruta al archivo a analizar (requerido para modo 1 y 2)")
    parser.add_argument("--b64file", "-b", help="Ruta al archivo .b64 que contiene el string base64 (para modo 2)")
    parser.add_argument("--content-type", "-c", default="application/pdf", 
                      help="Tipo de contenido del documento (default: application/pdf)")
    parser.add_argument("--output", "-o", help="Archivo de salida para guardar el texto extraído")
    parser.add_argument("--mode", "-m", type=int, choices=[1, 2, 3], default=3,
                      help="Modo de ejecución: 1=ambos métodos, 2=base64 desde archivo, 3=base64 directo")
    
    args = parser.parse_args()
    
    print("\n=== Ejemplo de análisis de documentos con métodos base64 ===")
    
    # Verificar variables de entorno
    if not check_env_vars():
        return 1
    
    # Mostrar configuración actual
    private_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
    public_endpoint = os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT")
    print(f"\nEndpoint privado: {private_endpoint}")
    print(f"Endpoint público: {public_endpoint}")
    
    # Variables para almacenar resultados
    file_content = None
    direct_content = None
    file_time = 0
    direct_time = 0
    
    # === Método 2: Archivo a base64 ===
    if args.mode in [1, 2]:
        if not args.file:
            print("❌ Error: Se requiere un archivo para el modo 1 o 2 (--file)")
            return 1
            
        if not os.path.exists(args.file):
            print(f"❌ Error: El archivo {args.file} no existe")
            return 1
            
        file_content, file_time = base64_file_analysis(args.file)
    
    # === Método 3: String base64 directo ===
    if args.mode in [1, 3]:
        base64_string = None
        
        # Obtener el string base64
        if args.b64file:
            # Cargar desde archivo .b64
            if not os.path.exists(args.b64file):
                print(f"❌ Error: El archivo {args.b64file} no existe")
                return 1
                
            try:
                with open(args.b64file, "r") as f:
                    base64_string = f.read().strip()
                print(f"✅ String base64 cargado desde archivo ({len(base64_string)} caracteres)")
            except Exception as e:
                print(f"❌ Error al leer el archivo base64: {e}")
                return 1
        elif args.file:
            # Convertir archivo a base64
            try:
                with open(args.file, "rb") as f:
                    file_bytes = f.read()
                base64_string = base64.b64encode(file_bytes).decode("utf-8")
                print(f"✅ Archivo convertido a base64 ({len(base64_string)} caracteres)")
            except Exception as e:
                print(f"❌ Error al convertir el archivo a base64: {e}")
                return 1
        else:
            print("❌ Error: Se requiere un archivo (--file) o un archivo base64 (--b64file)")
            return 1
            
        direct_content, direct_time = direct_base64_analysis(base64_string, args.content_type)
    
    # Comparar resultados si se ejecutaron ambos métodos
    if args.mode == 1 and file_content and direct_content:
        print("\n=== Comparación de métodos base64 ===")
        print(f"Tiempo archivo→base64: {file_time:.2f} segundos")
        print(f"Tiempo base64 directo: {direct_time:.2f} segundos")
        print(f"Diferencia:            {direct_time - file_time:.2f} segundos")
        
        same_content = file_content == direct_content
        print(f"¿Contenido idéntico? {'✅ Sí' if same_content else '❌ No'}")
        
        if not same_content:
            print("Hay diferencias entre los contenidos extraídos.")
    
    # Guardar resultado en archivo si se especificó
    if args.output:
        content_to_save = direct_content if args.mode in [1, 3] and direct_content else file_content
        if content_to_save:
            save_text_to_file(content_to_save, args.output)
    else:
        # Preguntar si se desea guardar
        content_to_save = direct_content if args.mode in [1, 3] and direct_content else file_content
        if content_to_save:
            save = input("\n¿Guardar el texto extraído en un archivo? (s/n): ")
            if save.lower() == "s":
                output_file = None
                if 'args.file' in locals() and args.file:
                    output_file = os.path.splitext(args.file)[0] + "_extracted.txt"
                save_text_to_file(content_to_save, output_file)
    
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nOperación cancelada por el usuario.")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        sys.exit(1) 