# Ejemplos de Uso del SDK Document Intelligence

Esta carpeta contiene ejemplos prácticos de cómo utilizar el SDK Document Intelligence para diferentes casos de uso.

## Ejemplos disponibles

### Ejemplos básicos

- [**basic_usage.py**](./basic_usage.py) - Ejemplo simple de cómo usar el SDK para extraer texto de documentos
- [**azurecredential_example.py**](./azurecredential_example.py) - Ejemplos de cómo usar la clase AzureCredential para autenticación (Nuevo)

### Ejemplos con el proveedor de Azure

- [**azure_provider_example.py**](./azure_provider_example.py) - Uso del proveedor de Azure para analizar documentos
- [**azure_service_principal.py**](./azure_service_principal.py) - Autenticación con Service Principal en Azure
- [**azure_private_endpoint.py**](./azure_private_endpoint.py) - Conexión a través de Private Link y endpoints privados

### Ejemplos con base64

- [**base64_analysis_example.py**](./base64_analysis_example.py) - Análisis de documentos codificados en base64
- [**base64_document.py**](./base64_document.py) - Trabajar con documentos en formato base64
- [**azure_base64_with_private_endpoint.py**](./azure_base64_with_private_endpoint.py) - Documentos base64 con endpoints privados
- [**service_principal_base64.py**](./service_principal_base64.py) - Autenticación con Service Principal para documentos base64

### Utilidades y ejemplos avanzados

- [**direct_document_analysis.py**](./direct_document_analysis.py) - Uso directo de las funciones de análisis de documentos
- [**base64_utils.py**](./base64_utils.py) - Utilidades para trabajar con documentos en formato base64

## Requisitos previos

Para ejecutar estos ejemplos, necesitarás:

1. Una suscripción de Azure con acceso al servicio Azure Document Intelligence
2. Un recurso de Azure Document Intelligence creado
3. Las credenciales de acceso al recurso (clave API o credenciales de Service Principal)
4. Python 3.7 o superior
5. El SDK Document Intelligence instalado (`pip install -e ..` desde este directorio)

## Configuración del entorno

La mayoría de los ejemplos usan variables de entorno para configuración. Puedes configurarlas en tu sistema o crear un archivo `.env` con las siguientes variables:

```bash
# Endpoint y clave para Azure Document Intelligence
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
AZURE_DOCUMENT_INTELLIGENCE_KEY=your-api-key

# Para endpoints privados
AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT=https://your-region.api.cognitive.microsoft.com/

# Para Service Principal
AZURE_TENANT_ID=your-tenant-id
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret
```

## Ejemplo de cómo usar la autenticación con AzureCredential (Nuevo)

```python
from doc_intelligent import DocIntelligenceClient
from doc_intelligent.auth import AzureCredential

# Crear una instancia de AzureCredential con API Key
credential = AzureCredential(api_key="your-api-key")

# O usar Service Principal
credential = AzureCredential.from_service_principal(
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret"
)

# O usar DefaultAzureCredential (identidad administrada, CLI, etc.)
credential = AzureCredential.default_credential()

# Luego usar la credencial con el cliente
client = DocIntelligenceClient(
    endpoint="https://your-resource.cognitiveservices.azure.com/",
    credential=credential
)

# Extraer texto de un documento PDF
text = client.extract_text("documento.pdf")
print(text)
```

Para más detalles, consulta el ejemplo completo en [azurecredential_example.py](./azurecredential_example.py).

## Ejecución de los ejemplos

Para ejecutar cualquiera de los ejemplos, simplemente ejecuta el script de Python:

```bash
python basic_usage.py
python azurecredential_example.py
# etc.
```

Asegúrate de revisar y modificar las variables de configuración en cada script según sea necesario.

## Recursos adicionales

- [Documentación oficial del SDK](../README.md)
- [Documentación de Azure Document Intelligence](https://learn.microsoft.com/es-es/azure/ai-services/document-intelligence/)

## Estructura de directorios

Para que los ejemplos funcionen correctamente, debes crear una carpeta `samples` con algunos documentos de ejemplo:

```
examples/
├── samples/
│   ├── invoice.pdf
│   ├── receipt.pdf
│   ├── contract.pdf
│   ├── document.pdf
│   ├── id_document.jpg
│   ├── large_document.pdf
│   └── invoices/
│       ├── invoice1.pdf
│       ├── invoice2.pdf
│       └── invoice3.pdf
├── basic_usage.py
├── batch_processing.py
├── multiple_providers.py
├── base64_document.py
├── azure_service_principal.py
├── custom_endpoints.py
├── azure_provider_example.py
├── azure_private_endpoint.py
├── service_principal_base64.py
└── README.md
```

## Uso

Para ejecutar cualquiera de los ejemplos, simplemente utiliza:

```bash
python examples/basic_usage.py
```

> **Nota**: Asegúrate de reemplazar las credenciales de ejemplo con tus propias claves de API y configuración para cada proveedor.

## Adaptando los ejemplos

Puedes adaptar estos ejemplos para tus propias necesidades:

1. Cambia los tipos de documentos (facturas, recibos, contratos, etc.)
2. Modifica los modelos utilizados según el tipo de documento
3. Ajusta los parámetros de configuración como el idioma (`locale`)
4. Implementa tu propio procesamiento para los resultados obtenidos

## Proveedores soportados

El SDK actualmente soporta los siguientes proveedores:

- Azure Document Intelligence (anteriormente Form Recognizer)
- Google Cloud Document AI
- Amazon Textract y Amazon Comprehend

## Métodos de autenticación

El SDK admite varios métodos de autenticación:

- Claves de API directas (ejemplos básicos)
- Service Principal para Azure (entornos de producción)
- Roles de IAM para AWS
- Cuentas de servicio para Google Cloud

## Configuración regional y endpoints

El SDK permite configurar endpoints específicos para cada proveedor:

- **Azure**: Endpoints regionales o privados mediante el parámetro `endpoint`
  - Soporte para reemplazo automático de URLs públicas con privadas durante polling
  - Configuración automática de la variable de entorno NO_PROXY para evitar proxies
- **AWS**: La región determina automáticamente el endpoint mediante el parámetro `region`  
- **Google**: La ubicación del servicio se configura con el parámetro `location` 