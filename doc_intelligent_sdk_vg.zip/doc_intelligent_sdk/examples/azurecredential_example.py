#!/usr/bin/env python
"""
Ejemplo de uso de AzureCredential para autenticación
====================================================

Este ejemplo muestra cómo utilizar la clase AzureCredential para autenticar con
el servicio Azure Document Intelligence, demostrando las diferentes opciones de
autenticación y cómo se puede reutilizar la misma credencial en múltiples llamadas.

Características clave:
- Uso de AzureCredential para autenticación
- Configuración de diferentes tipos de autenticación
- Creación y reutilización de credenciales
"""

import os
import base64
from pathlib import Path

# Importar las clases y utilidades necesarias
from doc_intelligent import DocIntelligenceClient
from doc_intelligent.auth import AzureCredential
from doc_intelligent.utils.logging import get_logger

# Configurar logging
logger = get_logger(__name__)

def example_api_key():
    """Ejemplo usando API Key."""
    print("\n=== Ejemplo con API Key ===")
    
    # Configurar las credenciales con API Key
    credential = AzureCredential(
        api_key="YOUR_API_KEY"  # También puedes usar la variable de entorno AZURE_DOCUMENT_INTELLIGENCE_KEY
    )
    
    # Crear cliente usando la credencial
    client = DocIntelligenceClient(
        endpoint="https://your-resource.cognitiveservices.azure.com/",
        credential=credential
    )
    
    # Analizar documento
    try:
        # Buscar un documento de ejemplo en el directorio actual
        example_pdf = next(Path(".").glob("*.pdf"), None)
        if example_pdf:
            print(f"Analizando documento: {example_pdf}")
            result = client.extract_text(str(example_pdf))
            print(f"Resultado: {len(result)} caracteres extraídos")
        else:
            print("No se encontró ningún documento PDF para analizar")
    except Exception as e:
        print(f"Error al analizar documento: {e}")

def example_service_principal():
    """Ejemplo usando Service Principal."""
    print("\n=== Ejemplo con Service Principal ===")
    
    # Configurar las credenciales con Service Principal
    credential = AzureCredential.from_service_principal(
        tenant_id="YOUR_TENANT_ID",  # O usar AZURE_TENANT_ID
        client_id="YOUR_CLIENT_ID",  # O usar AZURE_CLIENT_ID
        client_secret="YOUR_CLIENT_SECRET"  # O usar AZURE_CLIENT_SECRET
    )
    
    # Crear cliente usando la credencial
    client = DocIntelligenceClient(
        endpoint="https://your-resource.cognitiveservices.azure.com/",
        credential=credential
    )
    
    # El resto del código es el mismo que en el ejemplo anterior

def example_default_credential():
    """Ejemplo usando DefaultAzureCredential."""
    print("\n=== Ejemplo con DefaultAzureCredential ===")
    
    # Crear credencial usando la cadena DefaultAzureCredential
    # Esto intentará usar:
    # 1. Variables de entorno (AZURE_CLIENT_ID, AZURE_TENANT_ID, AZURE_CLIENT_SECRET)
    # 2. Identidad administrada
    # 3. Credenciales del CLI de Azure
    credential = AzureCredential.default_credential()
    
    # Crear cliente usando la credencial
    client = DocIntelligenceClient(
        endpoint="https://your-resource.cognitiveservices.azure.com/",
        credential=credential
    )
    
    # El resto del código es el mismo que en los ejemplos anteriores

def example_reuse_credential():
    """Ejemplo reutilizando la misma credencial."""
    print("\n=== Ejemplo reutilizando la misma credencial ===")
    
    # Crear una única instancia de AzureCredential
    credential = AzureCredential.default_credential()
    
    # Crear el cliente usando la credencial
    client = DocIntelligenceClient(
        endpoint="https://your-resource.cognitiveservices.azure.com/",
        credential=credential
    )
    
    # Realizar múltiples análisis con la misma credencial
    # AzureCredential manejará automáticamente la caché de tokens
    try:
        pdf_files = list(Path(".").glob("*.pdf"))
        for i, pdf_file in enumerate(pdf_files[:3]):  # Procesar hasta 3 PDFs
            print(f"Analizando documento {i+1}: {pdf_file}")
            result = client.extract_text(str(pdf_file))
            print(f"  Resultado: {len(result)} caracteres extraídos")
    except Exception as e:
        print(f"Error al analizar documentos: {e}")

def example_direct_utils():
    """Ejemplo usando directamente las utilidades de análisis con AzureCredential."""
    print("\n=== Ejemplo usando utilidades directamente ===")
    
    from doc_intelligent.utils.document_analysis import analyze_document
    
    # Crear una credencial para pasar a las funciones de utilidad
    credential = AzureCredential.default_credential()
    
    try:
        # Buscar un documento de ejemplo
        example_pdf = next(Path(".").glob("*.pdf"), None)
        if example_pdf:
            print(f"Analizando documento: {example_pdf}")
            
            # Pasar la credencial como parámetro
            content, _ = analyze_document(
                file_path=str(example_pdf),
                credential=credential  # Pasar la credencial directamente
            )
            
            if content:
                print(f"Resultado: {len(content)} caracteres extraídos")
            else:
                print("No se pudo extraer contenido del documento")
        else:
            print("No se encontró ningún documento PDF para analizar")
    except Exception as e:
        print(f"Error al analizar documento: {e}")

if __name__ == "__main__":
    # Para ejecutar los ejemplos, descomenta la función que quieras probar
    # y configura las credenciales correspondientes
    
    print("Ejemplos de uso de AzureCredential")
    print("==================================")
    print("NOTA: Para ejecutar estos ejemplos, debes modificar el código con tus credenciales")
    
    # Ejecutar ejemplos
    # Descomenta para ejecutar
    
    # example_api_key()
    # example_service_principal()
    # example_default_credential()
    # example_reuse_credential()
    # example_direct_utils()
    
    print("\nEjemplo completado.") 