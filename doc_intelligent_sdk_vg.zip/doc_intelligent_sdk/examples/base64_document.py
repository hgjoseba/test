#!/usr/bin/env python
"""
Ejemplo de análisis de documentos a partir de datos codificados en base64.
Útil para aplicaciones web o APIs donde los documentos se transmiten como strings base64.

Este ejemplo demuestra el uso de la API versión "2024-11-30" (la más reciente).
"""

import base64
import os
import sys
from doc_intelligent import DocIntelligenceClient

# Configuración para el ejemplo
CONFIG = {
    # El endpoint del servicio de Document Intelligence
    "endpoint": os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", "your_endpoint"),
    
    # La clave API del servicio (opcional si se usa autenticación con credenciales)
    "api_key": os.environ.get("AZURE_DOCUMENT_INTELLIGENCE_KEY", "your_api_key"),
    
    # La versión más reciente de la API
    "api_version": "2024-11-30"
}

def main():
    print("=== Ejemplo de análisis de documentos con datos base64 ===")
    print("\nEste ejemplo demuestra:")
    print("1. Cuándo es apropiado usar el enfoque base64 vs multipart")
    print("2. Cómo procesar documentos que ya están en memoria")
    print("3. La versión más reciente de la API (2024-11-30)")
    
    # Ruta al archivo para convertir a base64
    file_path = "samples/invoice.pdf"
    
    # Leer el archivo y convertir a base64
    with open(file_path, "rb") as file:
        file_bytes = file.read()
    base64_data = base64.b64encode(file_bytes).decode("utf-8")
    
    print(f"\nArchivo convertido a base64: {file_path}")
    print(f"Tamaño original: {len(file_bytes)/1024:.2f} KB")
    print(f"Tamaño como base64: {len(base64_data)/1024:.2f} KB")
    print(f"Overhead: {(len(base64_data) - len(file_bytes))/len(file_bytes)*100:.1f}%")
    
    # Inicializar el cliente de Document Intelligence
    print("\n=== Inicializando cliente con API versión 2024-11-30 ===")
    doc_intelligence = DocIntelligenceClient(
        endpoint=CONFIG["endpoint"],
        api_key=CONFIG["api_key"],
        api_version=CONFIG["api_version"]
    )
    
    print(f"\nAnalizando documento desde datos base64...")
    print("\nEscenarios donde base64 es preferible a multipart:")
    print("- Documentos ya en memoria (ej. generados dinámicamente)")
    print("- Integración con APIs JSON donde no se puede usar multipart")
    print("- Entornos serverless sin acceso al sistema de archivos")
    print("- Documentos que provienen de bases de datos o almacenamiento en la nube")
    
    # Realizar el análisis usando datos base64
    response = doc_intelligence.analyze_document_from_base64(
        base64_string=base64_data,
        content_type="application/pdf",
        model_id="prebuilt-document"
    )
    
    if response.status.lower() == "succeeded":
        print("\n✅ Análisis completado con éxito")
        print(f"- Páginas procesadas: {len(response.get_analyzed_document().pages)}")
        print(f"- Contenido extraído (primeros 100 caracteres):")
        print(f"  {response.get_text()[:100]}...")
    else:
        print(f"\n❌ Error en el análisis: {response.status}")
        if response.errors:
            for error in response.get_errors():
                print(f"  - {error.get('code', 'Error')}: {error.get('message', 'Mensaje no disponible')}")
    
    # Ejemplo de procesamiento batch con múltiples documentos base64
    print("\n--- Ejemplo de procesamiento por lotes con base64 ---")
    print("Útil para procesamiento de múltiples documentos en una sola llamada")
    
    # Definir los documentos a procesar
    documents = [
        {
            "base64_string": base64_data,
            "content_type": "application/pdf",
            "model_id": "prebuilt-document"
        }
        # Se podrían añadir más documentos aquí
    ]
    
    # Procesar lote de documentos
    batch_results = doc_intelligence.analyze_documents_batch_from_base64(
        documents=documents
    )
    
    print(f"\nProcesados {len(batch_results)} documentos en lote")
    
    print("\n=== Comparación de enfoques de transferencia ===")
    print("\nMultipart (doc_intelligence.analyze_document):")
    print("✅ Mayor eficiencia en archivos grandes")
    print("✅ Menor consumo de memoria")
    print("✅ Simplifica el procesamiento de archivos locales")
    print("❌ No es adecuado para documentos ya en memoria")
    
    print("\nBase64 (doc_intelligence.analyze_document_from_base64):")
    print("✅ Perfecto para documentos en memoria o generados dinámicamente")
    print("✅ Compatible con APIs JSON y comunicación serializada")
    print("✅ Funciona en entornos sin acceso al sistema de archivos")
    print("❌ Mayor overhead (~33%) debido a la codificación")
    print("❌ Mayor consumo de memoria")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1) 