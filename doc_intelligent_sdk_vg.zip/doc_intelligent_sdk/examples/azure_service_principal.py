#!/usr/bin/env python
"""
Ejemplo de autenticación con Azure Document Intelligence usando un Service Principal.
Este método es recomendado para aplicaciones empresariales y entornos productivos
donde no se recomienda usar claves de API directas.

También muestra cómo el SDK maneja automáticamente endpoints privados en entornos
empresariales con restricciones de red y proxies.
"""

import os
from azure.identity import ClientSecretCredential
from doc_intelligent import DocumentIntelligence
from doc_intelligent.providers import AzureDocumentProvider

def mostrar_configuracion_proxy():
    """Muestra la configuración actual de proxy del sistema."""
    print("\n=== Configuración de proxy del sistema ===")
    print(f"NO_PROXY: {os.environ.get('NO_PROXY', 'No definido')}")
    print(f"HTTP_PROXY: {os.environ.get('HTTP_PROXY', 'No definido')}")
    print(f"HTTPS_PROXY: {os.environ.get('HTTPS_PROXY', 'No definido')}")

def main():
    print("=== Ejemplo de Azure Document Intelligence con Service Principal y endpoint privado ===")
    print("Este ejemplo demuestra cómo:")
    print("1. Autenticarse con Azure Document Intelligence usando un Service Principal")
    print("2. Configurar automáticamente NO_PROXY para endpoints privados")
    print("3. Manejar endpoints públicos y privados en entornos empresariales")
    
    # Información del Service Principal
    # En producción, estas credenciales deberían obtenerse de 
    # variables de entorno o servicios seguros de gestión de secretos
    tenant_id = os.environ.get("AZURE_TENANT_ID", "your_tenant_id")
    client_id = os.environ.get("AZURE_CLIENT_ID", "your_client_id")
    client_secret = os.environ.get("AZURE_CLIENT_SECRET", "your_client_secret")
    
    # Endpoints para escenarios empresariales
    private_endpoint = os.environ.get(
        "AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT", 
        "https://your-private-endpoint.cognitiveservices.azure.com/"
    )
    public_endpoint = os.environ.get(
        "AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT",
        "https://eastus.api.cognitive.microsoft.com/"
    )
    
    # Mostrar configuración de proxy antes de inicializar el SDK
    print("\n=== Estado inicial ===")
    private_domain = private_endpoint.replace("https://", "").split("/")[0]
    print(f"Endpoint privado: {private_endpoint} (dominio: {private_domain})")
    print(f"Endpoint público: {public_endpoint}")
    mostrar_configuracion_proxy()
    
    # Crear credencial usando Service Principal
    print("\n=== Creando credencial con Service Principal ===")
    credential = ClientSecretCredential(
        tenant_id=tenant_id,
        client_id=client_id,
        client_secret=client_secret
    )
    print("✓ Credencial Service Principal creada")
    
    # Inicializar el proveedor de Azure con la autenticación del Service Principal
    # en lugar de usar una clave de API directa
    print("\n=== Inicializando AzureDocumentProvider ===")
    print("El SDK configurará automáticamente lo siguiente:")
    print(f"- Añadirá '{private_domain}' a la variable de entorno NO_PROXY")
    print("- Configurará el reemplazo de endpoint público con privado para polling")
    
    provider = AzureDocumentProvider(
        endpoint=private_endpoint,       # Endpoint privado para acceso directo
        credential=credential,           # Usar Service Principal en vez de API key
        public_endpoint=public_endpoint  # Endpoint público para reemplazo en URLs de respuesta
    )
    print("✓ Proveedor inicializado")
    
    # Mostrar configuración de proxy después de inicializar el proveedor
    # para ver cómo el SDK modificó NO_PROXY
    print("\n=== Configuración después de inicializar el SDK ===")
    mostrar_configuracion_proxy()
    
    # Inicializar el SDK con el proveedor autenticado
    doc_intelligence = DocumentIntelligence(provider=provider)
    
    # Simulación de análisis (comentado para evitar errores con credenciales de ejemplo)
    print("\n=== Simulación de flujo de análisis en entorno empresarial ===")
    print("1. La solicitud inicial se envía al endpoint privado usando el Service Principal")
    print("2. Azure devuelve una URL de operación usando el endpoint público")
    print("3. El SDK reemplaza automáticamente el endpoint público con el privado")
    print("4. Las solicitudes al endpoint privado omiten el proxy corporativo (gracias a NO_PROXY)")
    print("5. Los resultados se obtienen a través del endpoint privado")
    
    # Ejemplo de un escenario real (comentado para evitar errores)
    """
    # A partir de aquí, el uso es idéntico a los otros ejemplos
    file_path = "samples/invoice.pdf"
    model_id = "prebuilt-document"
    
    print("\nAnalizando documento usando Service Principal y endpoint privado...")
    
    # Realizar el análisis
    response = doc_intelligence.analyze_document(
        file_path=file_path,
        model_id=model_id,
        locale="es",
        poll_interval=5  # Intervalo de polling en segundos
    )
    
    # Verificar el estado de la respuesta
    print(f"Análisis completado. Estado: {response.status}")
    print(f"Páginas procesadas: {len(response.pages)}")
    print(f"Campos detectados: {len(response.fields)}")
    """
    
    print("\n=== Ventajas de esta configuración para entornos empresariales ===")
    print("1. Seguridad mejorada:")
    print("   - Sin claves API de larga duración")
    print("   - Autenticación centralizada con Azure AD")
    print("   - Acceso a recursos a través de redes privadas")
    
    print("\n2. Cumplimiento y Gobernanza:")
    print("   - Control de acceso granular (RBAC)")
    print("   - Capacidad de auditoría a nivel de identidad")
    print("   - Rotación automática de secretos")
    
    print("\n3. Mejor integración en infraestructuras empresariales:")
    print("   - Compatibilidad con proxies corporativos")
    print("   - Soporte para Azure Private Link")
    print("   - Trabajo con restricciones de firewall")
    
    print("\n=== Instrucciones para entornos de producción ===")
    print("1. Crear y configurar Service Principal:")
    print("   az ad sp create-for-rbac --name 'doc-intelligence-app' --role 'Cognitive Services User'")
    
    print("\n2. Configurar Azure Private Link para Document Intelligence:")
    print("   - Crear un endpoint privado en Azure Portal")
    print("   - Conectarlo a su recurso de Document Intelligence")
    print("   - Configurar DNS para resolver el endpoint a la IP privada")
    
    print("\n3. Configurar las variables de entorno en el sistema o en Azure App Service:")
    print("   - AZURE_TENANT_ID: ID del tenant de Azure AD")
    print("   - AZURE_CLIENT_ID: ID de la aplicación (Service Principal)")
    print("   - AZURE_CLIENT_SECRET: Secreto del Service Principal")
    print("   - AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT: URL del endpoint privado")
    print("   - AZURE_DOCUMENT_INTELLIGENCE_PUB_ENDPOINT: URL del endpoint público")

if __name__ == "__main__":
    # Guardar configuración original de NO_PROXY
    original_no_proxy = os.environ.get("NO_PROXY", "")
    
    try:
        main()
    finally:
        # Restaurar la configuración original
        if original_no_proxy:
            os.environ["NO_PROXY"] = original_no_proxy
        elif "NO_PROXY" in os.environ:
            del os.environ["NO_PROXY"]
        
        print("\n=== Configuración de proxy restaurada a valores originales ===")
        print(f"NO_PROXY: {os.environ.get('NO_PROXY', 'No definido')}") 