"""Version information for CV Screening SDK."""

__version__ = "0.1.0"
