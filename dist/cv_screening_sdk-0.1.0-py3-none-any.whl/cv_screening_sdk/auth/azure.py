"""
Azure authentication provider.

This module provides authentication capabilities for Azure services
using service principals or other authentication methods.
"""

import logging
from dataclasses import dataclass, field
from typing import Any, Optional, cast

from azure.core.credentials import TokenCredential
from azure.core.exceptions import ClientAuthenticationError
from azure.identity import ClientSecretCredential, DefaultAzureCredential

from ..core.exceptions import AuthenticationError
from ..core.interfaces import AuthProviderInterface
from ..core.config import AzureConfig


@dataclass
class AzureCredentials:
    """
    Azure credentials configuration for service principal authentication.
    """

    tenant_id: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    connection_verify: bool = True
    _credential: Optional[TokenCredential] = field(default=None, repr=False)

    def get_credential(self) -> TokenCredential:
        """
        Gets or creates the Azure credential object.

        Returns:
            TokenCredential: The Azure credential object

        Raises:
            AuthenticationError: If credential creation fails
        """
        try:
            if all([self.tenant_id, self.client_id, self.client_secret]):
                return ClientSecretCredential(
                    tenant_id=cast(str, self.tenant_id),
                    client_id=cast(str, self.client_id),
                    client_secret=cast(str, self.client_secret),
                    connection_verify=self.connection_verify
                )
            return DefaultAzureCredential()
        except Exception as e:
            raise AuthenticationError(f"Failed to create Azure credentials: {str(e)}")


class AzureAuthProvider(AuthProviderInterface):
    """Azure authentication provider."""

    def __init__(
        self,
        tenant_id: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        connection_verify: bool = True,
        logger: Optional[logging.Logger] = None,
    ) -> None:
        """
        Initialize Azure authentication provider.

        Args:
            tenant_id: Azure tenant ID
            client_id: Azure client ID
            client_secret: Azure client secret
            connection_verify: Whether to verify SSL connections
            logger: Optional logger instance

        Raises:
            AuthenticationError: If initialization fails
        """
        try:
            self._credentials = AzureCredentials(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret,
                connection_verify=connection_verify
            )
            self.logger = logger or logging.getLogger(__name__)
            self._scopes = ["https://cognitiveservices.azure.com/.default"]
        except Exception as e:
            logger = logger or logging.getLogger(__name__)
            logger.error(
                f"Failed to initialize Azure auth provider: {str(e)}",
                exc_info=True,
            )
            raise AuthenticationError(f"Failed to initialize Azure auth provider: {str(e)}") from e

    def get_credentials(self) -> TokenCredential:
        """Get Azure credentials.

        Returns:
            Azure credentials

        Raises:
            AuthenticationError: If authentication fails
        """
        try:
            return self._credentials.get_credential()
        except Exception as e:
            raise AuthenticationError(f"Failed to get Azure credentials: {str(e)}")

    async def get_credentials_async(self) -> TokenCredential:
        """Get Azure credentials asynchronously.

        Returns:
            Azure credentials

        Raises:
            AuthenticationError: If authentication fails
        """
        try:
            return self._credentials.get_credential()
        except Exception as e:
            raise AuthenticationError(f"Failed to get Azure credentials: {str(e)}")

    def validate_credentials(self) -> bool:
        """Validate Azure credentials.

        Returns:
            True if credentials are valid, False otherwise

        Raises:
            AuthenticationError: If validation fails
        """
        try:
            credentials = self.get_credentials()
            # Try to get a token to validate credentials
            token = credentials.get_token("https://cognitiveservices.azure.com/.default")
            return bool(token.token)
        except ClientAuthenticationError as e:
            raise AuthenticationError(f"Failed to validate credentials: {str(e)}")
        except Exception as e:
            raise AuthenticationError(f"Unexpected error validating credentials: {str(e)}")

    def refresh_credentials(self) -> None:
        """Refresh Azure credentials."""
        self._credentials = AzureCredentials(
            tenant_id=self._credentials.tenant_id,
            client_id=self._credentials.client_id,
            client_secret=self._credentials.client_secret,
            connection_verify=self._credentials.connection_verify
        )

    def get_token(self) -> Any:
        """Get authentication token.

        Returns:
            str: The Azure authentication token

        Raises:
            AuthenticationError: If token retrieval fails
        """
        try:
            credential = self.get_credentials()
            token = credential.get_token(*self._scopes)
            return token.token
        except ClientAuthenticationError as e:
            self.logger.error(f"Failed to get token: {str(e)}", exc_info=True)
            raise AuthenticationError(
                f"Failed to get authentication token: {str(e)}"
            ) from e

    async def get_token_async(self) -> Any:
        """
        Get Azure AD token asynchronously.
        
        Esta versión sin aiohttp simplemente usa la versión síncrona.

        Returns:
            Azure AD token

        Raises:
            AuthenticationError: If token retrieval fails
        """
        try:
            # Simplemente usamos la versión síncrona
            return self.get_token()
        except Exception as e:
            self.logger.error(
                f"Failed to get token asynchronously: {str(e)}",
                exc_info=True,
            )
            raise AuthenticationError(f"Failed to get token asynchronously: {str(e)}") from e

    def get_credential(self) -> TokenCredential:
        """
        Get the Azure credential object.

        This function is used by the Azure OpenAI provider to directly obtain
        the TokenCredential object instead of the token as a string.

        Returns:
            TokenCredential: Credential object for Azure authentication

        Raises:
            AuthenticationError: If credential retrieval fails
        """
        try:
            return self.get_credentials()
        except Exception as e:
            self.logger.error(f"Error getting Azure credential: {str(e)}", exc_info=True)
            raise AuthenticationError(f"Error getting Azure credential: {str(e)}") from e

    async def get_credential_async(self) -> TokenCredential:
        """
        Get Azure AD credential asynchronously.
        
        Esta versión sin aiohttp simplemente usa la versión síncrona.

        Returns:
            Azure AD credential

        Raises:
            AuthenticationError: If credential retrieval fails
        """
        try:
            # Simplemente usamos la versión síncrona
            return self.get_credential()
        except Exception as e:
            self.logger.error(
                f"Failed to get credential asynchronously: {str(e)}",
                exc_info=True,
            )
            raise AuthenticationError(f"Failed to get credential asynchronously: {str(e)}") from e
