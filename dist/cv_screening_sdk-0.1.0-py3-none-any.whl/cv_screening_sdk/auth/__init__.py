"""
Authentication module for CV Screening SDK.

This module provides authentication providers for Azure services.
"""

from .azure import AzureAuthProvider
from .base import AuthProvider

__all__ = [
    "AuthProvider",
    "AzureAuthProvider",
] 