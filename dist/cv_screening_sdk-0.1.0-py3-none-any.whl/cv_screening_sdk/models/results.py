"""
Result models for CV screening operations.

This module defines the data structures used to represent CV screening results,
providing validation and serialization functionality.
"""

from dataclasses import dataclass, field
from datetime import datetime, UTC
from typing import Any, Dict, List, Optional, Union
import time
import os

from ..core.exceptions import ValidationError


@dataclass
class SkillMatch:
    """
    Represents skills matching results.

    Attributes:
        required_skills: Dictionary of required skills found with confidence
            scores (0-1)
        preferred_skills: Dictionary of preferred skills found with confidence
            scores (0-1)
        overall_score: Overall skills match score (0-100)
        missing_required: List of required skills not found in the CV
        missing_preferred: List of preferred skills not found in the CV
    """

    required_skills: Dict[str, float]
    preferred_skills: Dict[str, float]
    overall_score: float
    missing_required: List[str] = field(default_factory=list)
    missing_preferred: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Validate the model after initialization."""
        try:
            if not 0 <= self.overall_score <= 100:
                raise ValueError("overall_score must be between 0 and 100")
            if any(not 0 <= score <= 1 for score in self.required_skills.values()):
                raise ValueError("Required skill scores must be between 0 and 1")
            if any(not 0 <= score <= 1 for score in self.preferred_skills.values()):
                raise ValueError("Preferred skill scores must be between 0 and 1")
        except ValueError as e:
            raise ValidationError(str(e)) from e


@dataclass
class ExperienceMatch:
    """
    Represents experience matching results.

    Attributes:
        years_of_experience: Total years of relevant experience
        relevance_score: How relevant the experience is to the job (0-1)
        role_matches: List of matching roles with details
        meets_minimum: Whether the candidate meets minimum experience requirements
        overall_score: Overall experience match score (0-100)
    """

    years_of_experience: float
    relevance_score: float
    role_matches: List[Dict[str, Any]]
    meets_minimum: bool
    overall_score: float

    def __post_init__(self) -> None:
        """Validate the model after initialization."""
        try:
            if self.years_of_experience < 0:
                raise ValueError("years_of_experience cannot be negative")
            if not 0 <= self.relevance_score <= 1:
                raise ValueError("relevance_score must be between 0 and 1")
            if not 0 <= self.overall_score <= 100:
                raise ValueError("overall_score must be between 0 and 100")
        except ValueError as e:
            raise ValidationError(str(e)) from e


@dataclass
class EducationMatch:
    """
    Represents education matching results.

    Attributes:
        level_match: Whether the education level matches requirements
        field_relevance: How relevant the field of study is to the job (0-1)
        overall_score: Overall education match score (0-100)
        education_details: Detailed education information
    """

    level_match: bool
    field_relevance: float
    overall_score: float
    education_details: Dict[str, Any]

    def __post_init__(self) -> None:
        """Validate the model after initialization."""
        try:
            if not 0 <= self.field_relevance <= 1:
                raise ValueError("field_relevance must be between 0 and 1")
            if not 0 <= self.overall_score <= 100:
                raise ValueError("overall_score must be between 0 and 100")
        except ValueError as e:
            raise ValidationError(str(e)) from e


@dataclass
class CVContent:
    """
    Class for handling CV content.
    
    This class represents the content of a CV with optional metadata.
    """
    
    content: str
    """Content of the CV as text."""
    
    filepath: Optional[str] = None
    """Optional filepath for reference."""
    
    metadata: Dict[str, Any] = field(default_factory=dict)
    """Optional metadata associated with the CV."""
    
    @classmethod
    def from_file(cls, filepath: str) -> "CVContent":
        """
        Create a CVContent instance from a file.
        
        Args:
            filepath: Path to the CV file
            
        Returns:
            CVContent instance with the file content
            
        Raises:
            FileNotFoundError: If the file does not exist
            ValueError: If the file format is not supported
        """
        from ..client import CVScreeningClient
        
        # Use the client's static method to load the content
        content = CVScreeningClient.load_cv_content(filepath)
        
        # Extract basic metadata
        file_stat = os.stat(filepath)
        metadata = {
            "filename": os.path.basename(filepath),
            "size_bytes": file_stat.st_size,
            "modified_time": file_stat.st_mtime,
            "file_extension": os.path.splitext(filepath)[1].lower()
        }
        
        return cls(content=content, filepath=filepath, metadata=metadata)


@dataclass
class ProcessingFailure:
    """
    Class for representing a CV processing failure.
    """

    cv_path: str
    """Path to the CV file that failed processing."""

    error: str
    """Error message."""

    error_type: Optional[str] = None
    """Type of error."""

    timestamp: float = field(default_factory=time.time)
    """Timestamp of the failure."""

    details: Optional[Dict[str, Any]] = None
    """Additional error details."""


@dataclass
class CVScreeningResult:
    """
    Complete CV screening result.

    Attributes:
        cv_id: Unique identifier for the CV (often a file path)
        overall_score: Overall match score (0-100)
        skill_matches: Skills matching results
        experience_match: Experience matching results
        education_match: Education matching results
        processed_at: When the CV was processed
        summary: Optional summary of the screening results
        raw_text: Optional raw extracted text from the CV
        metadata: Additional metadata about the screening
    """

    cv_id: str
    overall_score: float
    skill_matches: SkillMatch
    experience_match: ExperienceMatch
    education_match: EducationMatch
    processed_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    summary: Optional[str] = None
    raw_text: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate the model after initialization."""
        try:
            if not 0 <= self.overall_score <= 100:
                raise ValueError("overall_score must be between 0 and 100")
            if not self.cv_id:
                raise ValueError("cv_id must not be empty")
        except ValueError as e:
            raise ValidationError(str(e)) from e

    @classmethod
    def from_llm_response(
        cls, response: Dict[str, Any], cv_id: Optional[str] = None
    ) -> "CVScreeningResult":
        """
        Create from LLM response dictionary.

        Args:
            response: Dictionary containing LLM response
            cv_id: Optional CV identifier

        Returns:
            Instantiated CVScreeningResult

        Raises:
            ValidationError: If response is invalid
        """
        try:
            # Use match_score as overall_score if overall_score is not present
            overall_score = float(response.get("overall_score", response.get("match_score", 0.0)))
            
            return cls(
                cv_id=cv_id or str(hash(str(response))),
                overall_score=overall_score,
                skill_matches=SkillMatch(**response["skill_matches"]),
                experience_match=ExperienceMatch(**response["experience_match"]),
                education_match=EducationMatch(**response["education_match"]),
                summary=response.get("summary"),
                raw_text=response.get("analysis"),
                metadata=response.get("metadata", {}),
            )
        except (KeyError, TypeError, ValueError) as e:
            raise ValidationError(f"Invalid LLM response: {str(e)}") from e

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary representation.

        Returns:
            Dictionary representation of the CV screening result
        """
        return {
            "cv_id": self.cv_id,
            "overall_score": self.overall_score,
            "skill_matches": {
                "required_skills": self.skill_matches.required_skills,
                "preferred_skills": self.skill_matches.preferred_skills,
                "overall_score": self.skill_matches.overall_score,
                "missing_required": self.skill_matches.missing_required,
                "missing_preferred": self.skill_matches.missing_preferred,
            },
            "experience_match": {
                "years_of_experience": self.experience_match.years_of_experience,
                "relevance_score": self.experience_match.relevance_score,
                "overall_score": self.experience_match.overall_score,
                "meets_minimum": self.experience_match.meets_minimum,
                "role_matches": self.experience_match.role_matches,
            },
            "education_match": {
                "level_match": self.education_match.level_match,
                "field_relevance": self.education_match.field_relevance,
                "overall_score": self.education_match.overall_score,
                "education_details": self.education_match.education_details,
            },
            "processed_at": self.processed_at.isoformat(),
            "summary": self.summary,
            "raw_text": self.raw_text,
            "metadata": self.metadata,
        }

    @property
    def skills_found(self) -> List[str]:
        """
        Get list of all skills found in the CV.

        Returns:
            List of skill names
        """
        return list(self.skill_matches.required_skills.keys()) + list(
            self.skill_matches.preferred_skills.keys()
        )

    @property
    def missing_skills(self) -> List[str]:
        """
        Get list of all missing required skills.

        Returns:
            List of skill names
        """
        return self.skill_matches.missing_required

    @property
    def experience_years(self) -> float:
        """
        Get total years of experience.

        Returns:
            Years of experience as float
        """
        return self.experience_match.years_of_experience

    @property
    def education_level(self) -> Optional[str]:
        """
        Get highest education level.

        Returns:
            Education level as string, or None if not available
        """
        return self.education_match.education_details.get("highest_level")


@dataclass
class BatchProcessingResult:
    """
    Results from batch CV processing.

    Attributes:
        successful_results: List of successfully processed CV results
        failed_results: List of processing failures
        processing_time: Total processing time in seconds
        total_items: Total number of items processed
        success_count: Number of successful items
        failure_count: Number of failed items
    """

    successful_results: List[CVScreeningResult] = field(default_factory=list)
    failed_results: List[ProcessingFailure] = field(default_factory=list)
    processing_time: float = 0.0
    total_items: int = field(init=False)
    success_count: int = field(init=False)
    failure_count: int = field(init=False)

    def __post_init__(self) -> None:
        """Calculate additional metrics."""
        self.total_items = len(self.successful_results) + len(self.failed_results)
        self.success_count = len(self.successful_results)
        self.failure_count = len(self.failed_results)

    def success_rate(self) -> float:
        """
        Calculate success rate.

        Returns:
            Percentage of successfully processed items (0-1)
        """
        return self.success_count / self.total_items if self.total_items > 0 else 0.0

    def average_score(self) -> float:
        """
        Calculate average score of successful results.

        Returns:
            Average overall score (0-100) or 0 if no successful results
        """
        if not self.successful_results:
            return 0.0
        return sum(result.overall_score for result in self.successful_results) / len(
            self.successful_results
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to dictionary representation.

        Returns:
            Dictionary representation of batch processing results
        """
        return {
            "successful_results": [r.to_dict() for r in self.successful_results],
            "failed_results": [f.to_dict() for f in self.failed_results],
            "processing_time": self.processing_time,
            "total_items": self.total_items,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "success_rate": self.success_rate(),
            "average_score": self.average_score(),
        }
