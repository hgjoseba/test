"""
Validation utilities for the CV Screening SDK.

This module provides functions for validating inputs to the CV Screening SDK.
"""

import os
from typing import Any, Dict, Union
import warnings

from ..core.exceptions import ValidationError
from ..models.criteria import JobCriteria
from ..core.config import SDKConfig


def validate_file_path(file_path: str) -> None:
    """
    Validate that a file path exists and is a file.
    
    Note: For direct CV content processing, use client.screen_cv(cv_content) instead
    of calling this function.

    Args:
        file_path: Path to validate

    Raises:
        ValidationError: If the path is invalid
    """
    warnings.warn(
        "Direct file path validation is deprecated. Consider using "
        "CVScreeningClient.load_cv_content() or CVContent.from_file() instead.",
        DeprecationWarning,
        stacklevel=2
    )
    
    if not file_path:
        raise ValidationError("File path cannot be empty")

    if not os.path.exists(file_path):
        raise ValidationError(f"File does not exist: {file_path}")

    if not os.path.isfile(file_path):
        raise ValidationError(f"Not a file: {file_path}")


def validate_criteria(criteria: Union[Dict[str, Any], JobCriteria]) -> None:
    """
    Validate job criteria for CV screening.

    Args:
        criteria: Job criteria to validate

    Raises:
        ValidationError: If criteria are invalid
    """
    if isinstance(criteria, JobCriteria):
        # JobCriteria performs validation in __post_init__
        return

    if not isinstance(criteria, dict):
        raise ValidationError(
            f"Criteria must be a dictionary or JobCriteria object, got {
                type(criteria)}"
        )

    # Validate required_skills if present
    if "required_skills" in criteria:
        if not isinstance(criteria["required_skills"], list):
            raise ValidationError("required_skills must be a list")

        for skill in criteria["required_skills"]:
            if not isinstance(skill, str):
                raise ValidationError(f"Skill must be a string: {skill}")

    # Validate preferred_skills if present
    if "preferred_skills" in criteria:
        if not isinstance(criteria["preferred_skills"], list):
            raise ValidationError("preferred_skills must be a list")

        for skill in criteria["preferred_skills"]:
            if not isinstance(skill, str):
                raise ValidationError(f"Skill must be a string: {skill}")

    # Validate min_years_experience if present
    if "min_years_experience" in criteria:
        if not isinstance(criteria["min_years_experience"], (int, float)):
            raise ValidationError("min_years_experience must be a number")

        if criteria["min_years_experience"] < 0:
            raise ValidationError("min_years_experience cannot be negative")

    # Validate preferred_years_experience if present
    if "preferred_years_experience" in criteria:
        if criteria["preferred_years_experience"] is not None:
            if not isinstance(criteria["preferred_years_experience"], (int, float)):
                raise ValidationError(
                    "preferred_years_experience must be a number or None"
                )

            if criteria["preferred_years_experience"] < 0:
                raise ValidationError("preferred_years_experience cannot be negative")

            if (
                "min_years_experience" in criteria
                and criteria["preferred_years_experience"]
                < criteria["min_years_experience"]
            ):
                raise ValidationError(
                    "preferred_years_experience must be >= min_years_experience"
                )

    # Validate education_level if present
    if "education_level" in criteria:
        if not isinstance(criteria["education_level"], str):
            raise ValidationError("education_level must be a string")

        valid_levels = {
            "any",
            "high school",
            "associate",
            "bachelors",
            "masters",
            "phd",
            "doctorate",
        }
        if criteria["education_level"].lower() not in valid_levels:
            raise ValidationError(
                f"education_level must be one of: {', '.join(valid_levels)}"
            )


def validate_config(config: Union[Dict[str, Any], SDKConfig]) -> None:
    """
    Validate configuration for the CV Screening SDK.

    Args:
        config: Configuration to validate, either as a dictionary or SDKConfig object

    Raises:
        ValidationError: If configuration is invalid
    """
    if isinstance(config, SDKConfig):
        # SDKConfig performs validation in __post_init__
        return

    if not isinstance(config, dict):
        raise ValidationError(
            f"Configuration must be a dictionary or SDKConfig object, got {type(config)}"
        )

    # Validate Azure configuration if present
    if "azure" in config:
        azure_config = config["azure"]
        if not isinstance(azure_config, dict):
            raise ValidationError("azure config must be a dictionary")

        # Validate required fields
        required_fields = ["endpoint"]
        api_version = config.get("api_version", "2023-05-15")
        if api_version < "2024-07-01-preview":
            required_fields.append("deployment_name")
        for field in required_fields:
            if field not in azure_config:
                raise ValidationError(f"Missing required Azure config field: {field}")
            if not azure_config[field]:
                raise ValidationError(f"Azure config field {field} cannot be empty")

        # Validate URL format for endpoint
        if "endpoint" in azure_config and azure_config["endpoint"]:
            if not isinstance(azure_config["endpoint"], str):
                raise ValidationError("endpoint must be a string")
            if not azure_config["endpoint"].startswith(("http://", "https://")):
                raise ValidationError(
                    "endpoint must be a valid URL starting with http:// or https://"
                )

        # Validate numeric fields if present
        numeric_fields = {
            "max_tokens": (int, lambda x: x > 0),
            "temperature": (float, lambda x: 0 <= x <= 2),
            "top_p": (float, lambda x: 0 <= x <= 1),
            "frequency_penalty": (float, lambda x: -2 <= x <= 2),
            "presence_penalty": (float, lambda x: -2 <= x <= 2),
        }

        for field, (type_func, validator) in numeric_fields.items():
            if field in azure_config and azure_config[field] is not None:
                if not isinstance(azure_config[field], (int, float)):
                    raise ValidationError(f"{field} must be a number")
                if not validator(azure_config[field]):
                    raise ValidationError(f"{field} value is out of valid range")

        # Validate Service Principal credentials if provided
        cred_fields = ["tenant_id", "client_id", "client_secret"]
        if any(field in azure_config and azure_config[field] for field in cred_fields):
            missing = [
                field
                for field in cred_fields
                if field not in azure_config or not azure_config[field]
            ]
            if missing:
                raise ValidationError(
                    f"Missing required credentials: {', '.join(missing)}"
                )

    # Validate client configuration if present
    if "client" in config:
        client_config = config["client"]
        if not isinstance(client_config, dict):
            raise ValidationError("client config must be a dictionary")

        # Validate numeric fields
        client_numeric_fields = {
            "timeout": (int, lambda x: x > 0),
            "max_retries": (int, lambda x: x >= 0),
            "batch_size": (int, lambda x: x > 0),
        }

        for field, (type_func, validator) in client_numeric_fields.items():
            if field in client_config and client_config[field] is not None:
                if not isinstance(client_config[field], (int, float)):
                    raise ValidationError(f"{field} must be a number")
                if not validator(client_config[field]):
                    raise ValidationError(f"{field} value is out of valid range")

    # Validate logging configuration if present
    if "log" in config:
        log_config = config["log"]
        if not isinstance(log_config, dict):
            raise ValidationError("log config must be a dictionary")

        # Validate log level
        if "level" in log_config and log_config["level"]:
            if not isinstance(log_config["level"], str):
                raise ValidationError("level must be a string")
            valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
            if log_config["level"] not in valid_levels:
                raise ValidationError(
                    f"level must be one of: {', '.join(valid_levels)}"
                )


def validate_azure_config(config: Dict[str, Any]) -> None:
    """
    Validate Azure configuration.

    Args:
        config: Azure configuration dictionary

    Raises:
        ValidationError: If configuration is invalid
    """
    required_fields = ["endpoint", "deployment_name"]
    
    # Verificar campos obligatorios
    for field in required_fields:
        if field not in config or not config[field]:
            raise ValidationError(f"Azure configuration missing required field: {field}")

    # Validate Azure OpenAI endpoint
    endpoint = config.get("endpoint", "")
    if not endpoint.startswith(("http://", "https://")):
        raise ValidationError("Azure OpenAI endpoint must be a valid URL starting with http:// or https://")

    # Validate Service Principal credentials if provided
    tenant_id = config.get("tenant_id")
    client_id = config.get("client_id")
    client_secret = config.get("client_secret")

    if any([tenant_id, client_id, client_secret]):
        if not all([tenant_id, client_id, client_secret]):
            raise ValidationError("If using Service Principal authentication, all credentials (tenant_id, client_id, client_secret) must be provided")
