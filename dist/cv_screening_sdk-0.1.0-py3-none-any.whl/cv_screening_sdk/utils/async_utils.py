"""
Async utilities for the CV Screening SDK.

This module provides utilities for working with async code in the SDK.
"""

import asyncio
import functools
import time
from typing import Any, Callable, Coroutine, Optional, Type, TypeVar, Union

T = TypeVar("T")
R = TypeVar("R")


def to_sync(async_func: Callable[..., Coroutine[Any, Any, R]]) -> Callable[..., R]:
    """
    Convert an async function to a sync function.

    Args:
        async_func: Async function to convert

    Returns:
        Synchronous version of the function
    """

    @functools.wraps(async_func)
    def wrapper(*args: Any, **kwargs: Any) -> R:
        """Run the async function synchronously."""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            # Create a new loop for this call
            new_loop = asyncio.new_event_loop()
            try:
                return new_loop.run_until_complete(async_func(*args, **kwargs))
            finally:
                new_loop.close()
        else:
            return loop.run_until_complete(async_func(*args, **kwargs))

    return wrapper


def run_async(coroutine: Coroutine[Any, Any, T]) -> T:
    """
    Run an async coroutine synchronously.

    Args:
        coroutine: Coroutine to run

    Returns:
        Result of the coroutine
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    if loop.is_running():
        # Create a new loop for this call
        new_loop = asyncio.new_event_loop()
        try:
            return new_loop.run_until_complete(coroutine)
        finally:
            new_loop.close()
    else:
        return loop.run_until_complete(coroutine)


async def async_retry(
    coro: Callable[..., Coroutine[Any, Any, T]],
    *args: Any,
    retries: int = 3,
    delay: float = 1.0,
    backoff_factor: float = 2.0,
    exceptions: Union[Type[Exception], tuple[Type[Exception], ...]] = Exception,
    **kwargs: Any,
) -> T:
    """
    Retry an async coroutine with exponential backoff.

    Args:
        coro: Async coroutine function to retry
        *args: Arguments to pass to the coroutine
        retries: Maximum number of retries
        delay: Initial delay between retries in seconds
        backoff_factor: Factor to increase delay between retries
        exceptions: Exception types to catch and retry
        **kwargs: Keyword arguments to pass to the coroutine

    Returns:
        Result of the coroutine

    Raises:
        The last exception raised by the coroutine if all retries fail
    """
    last_exception = None
    current_delay = delay

    for attempt in range(retries + 1):
        try:
            return await coro(*args, **kwargs)
        except exceptions as e:
            last_exception = e
            if attempt == retries:  # Last attempt failed
                break
            
            # Wait with exponential backoff
            await asyncio.sleep(current_delay)
            current_delay *= backoff_factor

    # If we get here, all retries failed
    if last_exception:
        raise last_exception
    
    # This should never happen, but keeps type checkers happy
    raise RuntimeError("async_retry: unknown error occurred")


async def async_timeout(
    coro: Coroutine[Any, Any, T],
    timeout: float,
    timeout_message: Optional[str] = None,
) -> T:
    """
    Run a coroutine with a timeout.

    Args:
        coro: Coroutine to run
        timeout: Timeout in seconds
        timeout_message: Optional message to include in the timeout error

    Returns:
        Result of the coroutine

    Raises:
        asyncio.TimeoutError: If the coroutine times out
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout)
    except asyncio.TimeoutError:
        if timeout_message:
            raise asyncio.TimeoutError(timeout_message)
        raise
