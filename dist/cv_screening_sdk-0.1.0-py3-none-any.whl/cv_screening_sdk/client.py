"""
Main client for CV screening operations.

This module provides the main entry point for the CV Screening SDK, handling
CV analysis and result processing.
"""

import asyncio
import logging
import os
import time
from typing import Any, Dict, List, Optional, Tuple, Union

from .auth.azure import AzureAuthProvider
from .core.config import SDKConfig
from .core.exceptions import ValidationError, ProcessingError, LLMError, DocumentParsingError
from .core.interfaces import ProviderInterface
from .models.criteria import JobCriteria
from .models.results import BatchProcessingResult, CVScreeningResult, ProcessingFailure
from .providers.azure import AzureProvider
from .utils.logging import setup_logging
from .utils.validation import validate_criteria

logger = logging.getLogger(__name__)


class CVScreeningClient:
    """
    Client for CV screening using Azure OpenAI.
    """

    def __init__(
        self,
        config: Optional[SDKConfig] = None,
    ):
        """
        Initialize the client.

        Args:
            config: Optional client configuration

        Raises:
            ConfigurationError: If the configuration is invalid
        """
        self.config = config or SDKConfig()
        self.provider = AzureProvider(
            api_version=self.config.azure.api_version,
            endpoint=self.config.azure.endpoint,
            deployment=self.config.azure.deployment_name,
            tenant_id=self.config.azure.tenant_id,
            client_id=self.config.azure.client_id,
            client_secret=self.config.azure.client_secret,
            ssl_verify=self.config.azure.ssl_verify,
            ssl_cert_path=self.config.azure.ssl_cert_path,
            connection_verify=self.config.azure.connection_verify,
            connection_timeout=self.config.azure.connection_timeout,
            max_keepalive_connections=self.config.azure.max_keepalive_connections,
            max_connections=self.config.azure.max_connections
        )
        self.logger = logging.getLogger(__name__)
        self.criteria = None
        self._initialized = False

    def _initialize(self) -> None:
        """
        Initialize the client if not already initialized.
        
        This method initializes the provider if it hasn't been initialized yet.
        """
        if not self._initialized:
            self.provider.initialize()
            self._initialized = True
            
    def set_criteria(self, criteria: Union[Dict[str, Any], JobCriteria, str]) -> None:
        """
        Set default criteria for CV analysis.
        
        Args:
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string
            
        Raises:
            ValidationError: If the criteria are invalid
        """
        self.criteria = self._process_criteria(criteria)
        
    def get_criteria(self) -> Optional[Dict[str, Any]]:
        """
        Get the current criteria.
        
        Returns:
            The current criteria or None if not set
        """
        return self.criteria

    @staticmethod
    def load_cv_content(file_path: str) -> str:
        """
        Load CV content from a file.
        
        This is a helper method to load CV content from common file formats.
        For more advanced parsing needs, consider using a dedicated document parsing library.
        
        Args:
            file_path: Path to the CV file
            
        Returns:
            String content of the CV
            
        Raises:
            DocumentParsingError: If the file cannot be parsed
            FileNotFoundError: If the file does not exist
        """
        logger.info(f"Loading CV content from: {file_path}")
        
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
            
        file_ext = os.path.splitext(file_path)[1].lower()
        
        # Simple text files
        if file_ext in ['.txt']:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return f.read()
            except Exception as e:
                raise DocumentParsingError(f"Failed to read text file: {str(e)}")
                
        # PDF files require PyPDF2
        elif file_ext in ['.pdf']:
            try:
                # Import here to avoid dependency if not used
                import PyPDF2
                
                content = []
                with open(file_path, 'rb') as f:
                    pdf_reader = PyPDF2.PdfReader(f)
                    for page_num in range(len(pdf_reader.pages)):
                        page = pdf_reader.pages[page_num]
                        content.append(page.extract_text())
                        
                return '\n'.join(content)
            except ImportError:
                raise DocumentParsingError(
                    "PDF parsing requires PyPDF2. Install with: pip install PyPDF2"
                )
            except Exception as e:
                raise DocumentParsingError(f"Failed to parse PDF: {str(e)}")
                
        # DOCX files require python-docx
        elif file_ext in ['.docx']:
            try:
                # Import here to avoid dependency if not used
                import docx
                
                doc = docx.Document(file_path)
                content = [paragraph.text for paragraph in doc.paragraphs]
                return '\n'.join(content)
            except ImportError:
                raise DocumentParsingError(
                    "DOCX parsing requires python-docx. Install with: pip install python-docx"
                )
            except Exception as e:
                raise DocumentParsingError(f"Failed to parse DOCX: {str(e)}")
        
        else:
            raise DocumentParsingError(f"Unsupported file format: {file_ext}")

    def analyze_cv(
        self,
        content: str,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> CVScreeningResult:
        """
        Analyze a CV against given criteria.

        This is one of the main methods for CV screening. It analyzes a single CV
        against the provided criteria and returns a structured result.

        Args:
            content: CV content as text
            criteria: Optional job criteria as dictionary, JobCriteria object,
                or prompt string. If None, a general analysis will be performed.

        Returns:
            CVScreeningResult object containing the analysis with match scores,
            candidate profile, and recommendations.

        Raises:
            ValidationError: If the criteria are invalid
            LLMError: If the analysis fails during LLM processing

        Example:
            ```python
            # Using JobCriteria
            criteria = JobCriteria(
                required_skills=["python", "aws"],
                preferred_skills=["docker", "kubernetes"],
                min_years_experience=3,
                education_level="bachelors"
            )
            result = client.analyze_cv("CV content", criteria)

            # Using dictionary
            criteria = {
                "required_skills": ["python", "aws"],
                "preferred_skills": ["docker", "kubernetes"],
                "min_years_experience": 3,
                "education_level": "bachelors"
            }
            result = client.analyze_cv("CV content", criteria)
            
            # Check the match score
            print(f"Overall match: {result.overall_match}%")
            print(f"Skills match: {result.skills_match.score}%")
            ```
        """
        self.logger.info("Starting CV analysis")

        # Process and validate criteria
        criteria_dict = self._process_criteria(criteria)

        try:
            # Analyze with LLM
            result = self.provider.analyze_cv(content, criteria_dict)

            # Create result object
            screening_result = CVScreeningResult.from_llm_response(result)

            self.logger.info("CV analysis completed")
            return screening_result

        except Exception as e:
            self.logger.error(f"Failed to analyze CV: {str(e)}")
            raise

    async def analyze_cv_async(
        self,
        content: str,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
    ) -> CVScreeningResult:
        """
        Analyze a CV asynchronously against given criteria.

        Asynchronous version of analyze_cv for uso con async/await programming.
        Esta implementación ahora simplemente llama a la versión síncrona,
        ya que eliminamos aiohttp.

        Args:
            content: CV content as text
            criteria: Optional job criteria as dictionary, JobCriteria object,
                or prompt string. If None, a general analysis will be performed.

        Returns:
            CVScreeningResult containing the analysis with match scores,
            candidate profile, and recommendations.

        Raises:
            ValidationError: If the criteria are invalid
            LLMError: If the analysis fails during LLM processing

        Example:
            ```python
            import asyncio
            
            async def process_cv():
                criteria = {
                    "required_skills": ["python", "aws"],
                    "min_years_experience": 3
                }
                
                # Read CV content
                with open("resume.txt", "r") as f:
                    cv_content = f.read()
                    
                # Analyze asynchronously
                result = await client.analyze_cv_async(cv_content, criteria)
                print(f"Overall match: {result.overall_match}%")
                
            # Run the async function
            asyncio.run(process_cv())
            ```
        """
        self.logger.info("Starting async CV analysis")

        # Process and validate criteria
        criteria_dict = self._process_criteria(criteria)

        try:
            # Analyze with LLM asynchronously
            result = await self.provider.analyze_cv_async(content, criteria_dict)

            # Create result object
            screening_result = CVScreeningResult.from_llm_response(result)

            self.logger.info("Async CV analysis completed")
            return screening_result

        except Exception as e:
            self.logger.error(f"Failed to analyze CV asynchronously: {str(e)}")
            raise

    def _process_criteria(
        self, criteria: Optional[Union[Dict[str, Any], JobCriteria, str]]
    ) -> Dict[str, Any]:
        """
        Process and validate job criteria.

        Args:
            criteria: Job criteria as dictionary, JobCriteria object, or prompt string

        Returns:
            Dictionary containing validated criteria

        Raises:
            ValidationError: If criteria are invalid
        """
        if criteria is None:
            return {}

        if isinstance(criteria, JobCriteria):
            criteria_dict = criteria.to_dict()
            # Normalize education level format
            if "education_level" in criteria_dict:
                level = criteria_dict["education_level"].lower()
                if level == "bachelors":
                    criteria_dict["education_level"] = "Bachelor's"
                elif level == "masters":
                    criteria_dict["education_level"] = "Master's"
                elif level == "doctorate" or level == "phd":
                    criteria_dict["education_level"] = "Ph.D."
            return criteria_dict

        if isinstance(criteria, str):
            return {"prompt": criteria}

        if isinstance(criteria, dict):
            # Normalize education level format for dict input
            if "education_level" in criteria:
                level = criteria["education_level"].lower()
                if level == "bachelors":
                    criteria["education_level"] = "Bachelor's"
                elif level == "masters":
                    criteria["education_level"] = "Master's"
                elif level == "doctorate" or level == "phd":
                    criteria["education_level"] = "Ph.D."
            return criteria

        raise ValidationError("Invalid criteria format")

    def screen_cv(
        self,
        cv_content: str,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        cv_path: Optional[str] = None,
    ) -> CVScreeningResult:
        """
        Screen a single CV against given criteria.

        Args:
            cv_content: Text content of the CV to analyze
            criteria: Optional job criteria as dictionary, JobCriteria object,
                or prompt string
            cv_path: Optional path to the CV file (for reference only)

        Returns:
            CVScreeningResult object containing the analysis

        Raises:
            ValidationError: If the criteria are invalid
            LLMError: If the analysis fails

        Example:
            ```python
            # Using JobCriteria with CV content directly
            criteria = JobCriteria(
                required_skills=["python", "aws"],
                preferred_skills=["docker", "kubernetes"],
                min_years_experience=3,
                education_level="bachelors"
            )
            
            # Read CV content from file
            with open("path/to/cv.pdf", "rb") as f:
                # Use appropriate library to parse PDF
                import PyPDF2
                pdf_reader = PyPDF2.PdfReader(f)
                cv_content = ""
                for page in pdf_reader.pages:
                    cv_content += page.extract_text()
                
            result = client.screen_cv(cv_content, criteria)

            # Or with dictionary criteria
            criteria = {
                "required_skills": ["python", "aws"],
                "preferred_skills": ["docker", "kubernetes"],
                "min_years_experience": 3,
                "education_level": "bachelors"
            }
            result = client.screen_cv(cv_content, criteria)
            ```
        """
        if cv_path:
            self.logger.info(f"Starting CV screening for: {cv_path}")
        else:
            self.logger.info("Starting CV screening")

        # Process and validate criteria
        criteria_dict = self._process_criteria(criteria)

        try:
            # Analyze with LLM
            result = self.provider.analyze_cv(cv_content, criteria_dict)

            # Create result object
            screening_result = CVScreeningResult.from_llm_response(result, cv_path)

            if cv_path:
                self.logger.info(f"CV screening completed for: {cv_path}")
            else:
                self.logger.info("CV screening completed")
                
            return screening_result

        except Exception as e:
            error_msg = f"Failed to screen CV"
            if cv_path:
                error_msg += f" {cv_path}"
            error_msg += f": {str(e)}"
            self.logger.error(error_msg)
            raise

    async def screen_cv_async(
        self,
        cv_content: str,
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        cv_path: Optional[str] = None,
    ) -> CVScreeningResult:
        """
        Screen a single CV asynchronously.

        Args:
            cv_content: Text content of the CV to analyze
            criteria: Optional job criteria
            cv_path: Optional path to the CV file (for reference only)

        Returns:
            CVScreeningResult containing the analysis

        Raises:
            ValidationError: If the criteria are invalid
            LLMError: If the analysis fails
        """
        if cv_path:
            self.logger.info(f"Starting async CV screening for: {cv_path}")
        else:
            self.logger.info("Starting async CV screening")

        # Process and validate criteria
        criteria_dict = self._process_criteria(criteria)

        try:
            # Analyze with LLM asynchronously
            result = await self.provider.analyze_cv_async(cv_content, criteria_dict)

            # Create result object
            screening_result = CVScreeningResult.from_llm_response(result, cv_path)

            if cv_path:
                self.logger.info(f"Async CV screening completed for: {cv_path}")
            else:
                self.logger.info("Async CV screening completed")
                
            return screening_result

        except Exception as e:
            error_msg = f"Failed to screen CV asynchronously"
            if cv_path:
                error_msg += f" {cv_path}"
            error_msg += f": {str(e)}"
            self.logger.error(error_msg)
            raise

    def batch_screen_cvs(
        self,
        cv_contents: List[str],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        cv_paths: Optional[List[str]] = None,
    ) -> BatchProcessingResult:
        """
        Screen multiple CVs in batch mode with parallel processing.

        This method provides efficient large-scale CV screening by running 
        multiple analyses concurrently. It automatically handles load balancing
        and concurrent requests according to the batch size configured in
        client settings.

        Args:
            cv_contents: List of CV contents as text
            criteria: Optional screening criteria as dictionary, JobCriteria object,
                or prompt string
            cv_paths: Optional list of CV file paths (for reference only)

        Returns:
            BatchProcessingResult containing all screening results, with separate
            lists for successful and failed results

        Raises:
            ValidationError: If criteria are invalid

        Example:
            ```python
            # Prepare CVs and criteria
            cv_paths = ["cv1.pdf", "cv2.pdf", "cv3.pdf"]
            cv_contents = []
            
            # Load CV content
            for path in cv_paths:
                cv_contents.append(client.load_cv_content(path))
            
            # Define criteria
            criteria = JobCriteria(
                required_skills=["python", "javascript"],
                preferred_skills=["react", "node.js"],
                min_years_experience=2
            )
            
            # Process in batch
            result = client.batch_screen_cvs(cv_contents, criteria, cv_paths)
            
            # Process results
            print(f"Processed {len(result.successful_results)} CVs successfully")
            print(f"Failed to process {len(result.failed_results)} CVs")
            print(f"Success rate: {result.success_rate():.1%}")
            print(f"Processing time: {result.processing_time:.2f} seconds")
            
            # Get the top candidates
            top_candidates = sorted(
                result.successful_results,
                key=lambda x: x.overall_match,
                reverse=True
            )[:3]
            
            for i, candidate in enumerate(top_candidates):
                print(f"Top candidate #{i+1}: Match score {candidate.overall_match}%")
            ```
        """
        self.logger.info(f"Starting batch screening of {len(cv_contents)} CVs")

        # Process criteria only once for the entire batch
        criteria_dict = self._process_criteria(criteria)

        # Use asyncio to run the async implementation
        start_time = time.time()
        result = asyncio.run(self._batch_screen_cvs_async(cv_contents, criteria_dict, cv_paths))
        processing_time = time.time() - start_time

        # Add processing time to result
        result.processing_time = processing_time

        self.logger.info(
            f"Batch screening completed in {processing_time:.2f}s. "
            f"Success rate: {result.success_rate():.1%}"
        )
        return result

    async def _batch_screen_cvs_async(
        self, 
        cv_contents: List[str], 
        criteria: Optional[Dict[str, Any]] = None,
        cv_paths: Optional[List[str]] = None,
    ) -> BatchProcessingResult:
        """
        Internal async implementation of batch CV screening.

        Args:
            cv_contents: List of CV contents as text
            criteria: Optional screening criteria dictionary
            cv_paths: Optional list of CV file paths (for reference only)

        Returns:
            BatchProcessingResult with successful and failed results
        """
        # Prepare paths for reference if provided
        paths = cv_paths if cv_paths else [f"cv_{i}" for i in range(len(cv_contents))]
        
        # Ensure paths list has the same length as contents list
        if len(paths) != len(cv_contents):
            paths = [f"cv_{i}" for i in range(len(cv_contents))]
        
        # Create tasks for each batch of CVs
        tasks = []
        for i in range(0, len(cv_contents), self.config.client.batch_size):
            batch_contents = cv_contents[i : i + self.config.client.batch_size]
            batch_paths = paths[i : i + self.config.client.batch_size]
            batch_tasks = [
                self._process_cv_safe(content, criteria, path) 
                for content, path in zip(batch_contents, batch_paths)
            ]
            tasks.extend(batch_tasks)

        # Execute all tasks concurrently
        results = await asyncio.gather(*tasks)

        # Separate successful and failed results
        successful_results = []
        failed_results = []

        for result, cv_path in results:
            if isinstance(result, Exception):
                failed_results.append(
                    ProcessingFailure(cv_path=cv_path, error=str(result))
                )
            else:
                successful_results.append(result)

        return BatchProcessingResult(
            successful_results=successful_results, failed_results=failed_results
        )

    async def _process_cv_safe(
        self, 
        cv_content: str, 
        criteria: Optional[Dict[str, Any]],
        cv_path: Optional[str] = None
    ) -> Tuple[Union[CVScreeningResult, Exception], str]:
        """
        Process a single CV with error handling.

        Args:
            cv_content: Content of the CV as text
            criteria: Optional screening criteria
            cv_path: Optional path to the CV file (for reference only)

        Returns:
            Tuple of (result or exception, cv_path)
        """
        try:
            result = await self.screen_cv_async(cv_content, criteria, cv_path)
            return result, cv_path if cv_path else "unknown"
        except Exception as e:
            error_msg = f"Error processing CV"
            if cv_path:
                error_msg += f" {cv_path}"
            error_msg += f": {str(e)}"
            self.logger.error(error_msg)
            return e, cv_path if cv_path else "unknown"

    async def _analyze_cv_internal_async(
        self,
        content: str,
        criteria: Dict[str, Any],
        prompt_system: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Internal method to analyze a CV against job criteria asynchronously.
        This method is used internally by analyze_cvs_batch.

        Args:
            content: CV content as text
            criteria: Job criteria as dictionary
            prompt_system: Optional custom system prompt to override default

        Returns:
            Analysis results as dictionary

        Raises:
            ValidationError: If criteria is invalid
            ProcessingError: If analysis fails
        """
        try:
            # Validate criteria
            if not isinstance(criteria, (dict, JobCriteria)):
                raise ValidationError("Criteria must be a dictionary or JobCriteria object")

            return await self.provider.analyze_cv_async(content, criteria, prompt_system)
        except Exception as e:
            self.logger.error(
                f"Error analyzing CV: {str(e)}",
                exc_info=True,
            )
            raise ProcessingError(f"Failed to analyze CV: {str(e)}") from e

    async def analyze_cvs_batch(
        self,
        contents: List[str],
        criteria: Dict[str, Any],
        prompt_system: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Analyze multiple CVs against job criteria asynchronously.

        This method processes each CV in sequence but using asynchronous 
        processing. For large-scale parallel processing, consider using
        batch_screen_cvs instead.

        Args:
            contents: List of CV contents as text
            criteria: Job criteria as dictionary
            prompt_system: Optional custom system prompt to override default

        Returns:
            List of analysis results as dictionaries

        Raises:
            ProcessingError: If analysis fails

        Example:
            ```python
            # Process multiple CVs
            cv_contents = [cv1_text, cv2_text, cv3_text]
            criteria = {
                "required_skills": ["python", "aws"],
                "min_years_experience": 3
            }
            
            # Use asyncio to run the async method
            import asyncio
            results = asyncio.run(client.analyze_cvs_batch(cv_contents, criteria))
            
            # Process results
            for i, result in enumerate(results):
                print(f"CV {i+1} match score: {result['overall_match']}%")
            ```
        """
        try:
            results = []
            for content in contents:
                result = await self._analyze_cv_internal_async(content, criteria, prompt_system)
                results.append(result)
            return results
        except Exception as e:
            self.logger.error(
                f"Error analyzing CVs batch: {str(e)}",
                exc_info=True,
            )
            raise ProcessingError(f"Failed to analyze CVs batch: {str(e)}") from e

    def batch_analyze(
        self,
        cv_contents: List[str],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        batch_size: Optional[int] = None,
    ) -> BatchProcessingResult:
        """
        Analyze multiple CVs synchronously.

        Args:
            cv_contents: List of CV content strings
            criteria: Optional job criteria
            batch_size: Optional batch size for processing

        Returns:
            BatchProcessingResult containing successful and failed results

        Raises:
            ValidationError: If criteria are invalid
        """
        self.logger.info(f"Starting batch analysis of {len(cv_contents)} CVs")
        
        # Initialize client if not already initialized
        self._initialize()
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        # Prepare batch size
        batch_size = batch_size or self.config.client.batch_size
        
        start_time = time.time()
        successful_results = []
        failed_results = []
        
        # Process CVs in batches
        for i in range(0, len(cv_contents), batch_size):
            batch = cv_contents[i:i+batch_size]
            self.logger.info(f"Processing batch {i//batch_size + 1} of {len(cv_contents)//batch_size + 1}")
            
            for cv_content in batch:
                try:
                    result = self.analyze_cv(cv_content, criteria_dict)
                    successful_results.append(result)
                except Exception as e:
                    self.logger.error(f"Failed to process CV: {str(e)}")
                    failed_result = ProcessingFailure(
                        cv_path=f"cv_{len(successful_results) + len(failed_results)}",
                        error=str(e),
                        error_type=type(e).__name__
                    )
                    failed_results.append(failed_result)
        
        processing_time = time.time() - start_time
        
        # Create batch result
        batch_result = BatchProcessingResult(
            successful_results=successful_results,
            failed_results=failed_results,
            processing_time=processing_time
        )
        
        self.logger.info(
            f"Batch analysis completed. Success: {batch_result.success_count}, "
            f"Failed: {batch_result.failure_count}, "
            f"Time: {processing_time:.2f}s"
        )
        
        return batch_result
        
    async def batch_analyze_async(
        self,
        cv_contents: List[str],
        criteria: Optional[Union[Dict[str, Any], JobCriteria, str]] = None,
        batch_size: Optional[int] = None,
    ) -> BatchProcessingResult:
        """
        Analyze multiple CVs asynchronously.

        Args:
            cv_contents: List of CV content strings
            criteria: Optional job criteria
            batch_size: Optional batch size for processing

        Returns:
            BatchProcessingResult containing successful and failed results

        Raises:
            ValidationError: If criteria are invalid
        """
        self.logger.info(f"Starting async batch analysis of {len(cv_contents)} CVs")
        
        # Initialize client if not already initialized
        self._initialize()
        
        # Process criteria
        criteria_dict = self._process_criteria(criteria)
        
        # Prepare batch size
        batch_size = batch_size or self.config.client.batch_size
        
        start_time = time.time()
        tasks = []
        
        # Create tasks for all CVs
        for cv_content in cv_contents:
            tasks.append(self.analyze_cv_async(cv_content, criteria_dict))
        
        # Process results
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        successful_results = []
        failed_results = []
        
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                self.logger.error(f"Failed to process CV asynchronously: {str(result)}")
                failed_result = ProcessingFailure(
                    cv_path=f"cv_{i}",
                    error=str(result),
                    error_type=type(result).__name__
                )
                failed_results.append(failed_result)
            else:
                successful_results.append(result)
        
        processing_time = time.time() - start_time
        
        # Create batch result
        batch_result = BatchProcessingResult(
            successful_results=successful_results,
            failed_results=failed_results,
            processing_time=processing_time
        )
        
        self.logger.info(
            f"Async batch analysis completed. Success: {batch_result.success_count}, "
            f"Failed: {batch_result.failure_count}, "
            f"Time: {processing_time:.2f}s"
        )
        
        return batch_result
