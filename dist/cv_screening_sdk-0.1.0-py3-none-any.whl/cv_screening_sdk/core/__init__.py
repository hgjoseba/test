"""
Core functionality for CV Screening SDK.

This module provides core components like configuration, exceptions, and interfaces.
"""

from .config import AzureConfig, ClientConfig, SDKConfig, LogConfig
from .exceptions import (
    AuthenticationError,
    ConfigurationError,
    SDKError,
    ValidationError,
    ProcessingError,
    ProviderError,
    LLMError,
)
from .interfaces import ProviderInterface, AuthProviderInterface

__all__ = [
    "AzureConfig",
    "ClientConfig",
    "SDKConfig",
    "LogConfig",
    "SDKError",
    "AuthenticationError",
    "ConfigurationError",
    "ValidationError",
    "ProcessingError",
    "ProviderError",
    "LLMError",
    "ProviderInterface",
    "AuthProviderInterface",
] 