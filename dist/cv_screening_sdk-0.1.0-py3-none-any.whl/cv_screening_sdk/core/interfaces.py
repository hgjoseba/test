"""
Core interfaces for the CV Screening SDK.

This module defines abstract base classes that different implementations
must adhere to, enabling modularity and extensibility.
"""

from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Dict, List, Optional


class LLMAdapterInterface(ABC):
    """Interface for LLM adapters."""

    @abstractmethod
    def analyze_cv(
        self,
        content: str,
        criteria: Optional[Dict[str, Any]] = None,
        prompt_system: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Analyze CV content synchronously.

        Args:
            content: CV content as text
            criteria: Optional job criteria for matching
            prompt_system: Optional custom system prompt

        Returns:
            Analysis results as a dictionary

        Raises:
            LLMError: If analysis fails
        """

    @abstractmethod
    async def analyze_cv_async(
        self,
        content: str,
        criteria: Optional[Dict[str, Any]] = None,
        prompt_system: Optional[str] = None,
        return_raw_response: bool = False,
    ) -> Dict[str, Any]:
        """
        Analyze a CV against job criteria asynchronously.
        
        Nota: Esta versión simplemente llama a la versión síncrona
        ya que eliminamos aiohttp.

        Args:
            content: CV content
            criteria: Job criteria
            prompt_system: Optional custom system prompt
            return_raw_response: Whether to return the raw response

        Returns:
            Analysis results

        Raises:
            ProcessingError: If analysis fails
        """
        # Implementación por defecto que usa la versión síncrona
        return self.analyze_cv(content, criteria, prompt_system, return_raw_response)


class AuthProviderInterface(ABC):
    """Interface for authentication providers."""

    @abstractmethod
    def get_credentials(self) -> Any:
        """
        Get credentials for authentication.

        Returns:
            Credentials object

        Raises:
            AuthenticationError: If authentication fails
        """

    @abstractmethod
    async def get_credentials_async(self) -> Any:
        """
        Get authentication credentials asynchronously.
        
        Nota: Esta versión simplemente llama a la versión síncrona
        ya que eliminamos aiohttp.

        Returns:
            Authentication credentials

        Raises:
            AuthenticationError: If authentication fails
        """
        # Implementación por defecto que usa la versión síncrona
        return self.get_credentials()


class ProviderInterface(ABC):
    """Interface for service providers."""

    @abstractmethod
    def initialize(self) -> None:
        """
        Initialize the provider.

        Raises:
            ProviderError: If initialization fails
        """

    @abstractmethod
    async def initialize_async(self) -> None:
        """
        Initialize the provider asynchronously.
        
        Nota: Esta versión simplemente llama a la versión síncrona
        ya que eliminamos aiohttp.

        Raises:
            ProviderError: If initialization fails
        """
        # Implementación por defecto que usa la versión síncrona
        self.initialize()

    @abstractmethod
    def get_chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
    ) -> Dict[str, Any]:
        """
        Get a chat completion synchronously.

        Args:
            messages: List of message dictionaries
            temperature: Controls randomness (0 to 1)
            max_tokens: Maximum tokens to generate
            stream: Whether to stream the results

        Returns:
            Chat completion results

        Raises:
            ProviderError: If chat completion fails
        """

    @abstractmethod
    async def get_chat_completion_async(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        return_raw_response: bool = False,
    ) -> Dict[str, Any]:
        """
        Get chat completion asynchronously.
        
        Nota: Esta versión simplemente llama a la versión síncrona
        ya que eliminamos aiohttp.

        Args:
            messages: List of messages
            temperature: Temperature for sampling
            max_tokens: Maximum number of tokens to generate
            stream: Whether to stream the response
            return_raw_response: Whether to return the raw response

        Returns:
            Chat completion response

        Raises:
            LLMError: If chat completion fails
        """
        # Implementación por defecto que usa la versión síncrona
        return self.get_chat_completion(
            messages, temperature, max_tokens, stream, return_raw_response
        )

    @abstractmethod
    def get_chat_completion_stream(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Get a streaming chat completion.

        Args:
            messages: List of message dictionaries
            temperature: Controls randomness (0 to 1)
            max_tokens: Maximum tokens to generate

        Returns:
            Asynchronous iterator of chat completion chunks

        Raises:
            ProviderError: If streaming completion fails
        """
