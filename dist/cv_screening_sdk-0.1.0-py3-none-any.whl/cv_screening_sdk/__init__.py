"""
CV Screening SDK

A powerful and flexible SDK for automated CV/resume screening and analysis using Azure
OpenAI with Service Principal authentication. This SDK helps streamline the recruitment
process by automatically evaluating candidates' resumes against job criteria.
"""

from .__version__ import __version__

# Import public API
from .client import CVScreeningClient
from .core.config import AzureConfig, ClientConfig, SDKConfig
from .models.criteria import JobCriteria
from .models.results import BatchProcessingResult, CVScreeningResult, ProcessingFailure, CVContent
from .core.exceptions import (
    SDKError,
    ValidationError,
    DocumentParsingError,
    LLMError,
    AuthenticationError,
    ConfigurationError,
    ProcessingError,
    RateLimitError,
    TimeoutError,
    InputError,
    APIError,
)

__all__ = [
    # Main client
    "CVScreeningClient",
    
    # Models
    "JobCriteria",
    "CVScreeningResult",
    "BatchProcessingResult",
    "ProcessingFailure",
    "CVContent",
    
    # Configuration
    "ClientConfig",
    "AzureConfig",
    "SDKConfig",
    
    # Exceptions
    "SDKError",
    "ValidationError",
    "DocumentParsingError",
    "LLMError",
    "AuthenticationError",
    "ConfigurationError",
    "ProcessingError",
    "RateLimitError",
    "TimeoutError",
    "InputError",
    "APIError",
    
    # Version
    "__version__",
]
