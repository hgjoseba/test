#!/usr/bin/env python3
"""
Ejemplo avanzado de uso de CV Screening SDK con esquemas JSON personalizados.

Este ejemplo muestra casos más avanzados de personalización de esquemas JSON
para análisis de CVs, incluyendo análisis de competencias específicas por industria.
"""

import os
import json
from typing import Dict, Any, List
import argparse

# Importar el cliente principal de CV Screening
from src.cv_screening import CVScreeningClient
from src.core.types import ContentType
from src.models.criteria import JobCriteria

# Esquema JSON avanzado para análisis detallado por industria
ESQUEMA_INDUSTRIA_TECH = {
    "type": "object",
    "properties": {
        "informacion_candidato": {
            "type": "object",
            "properties": {
                "nombre": {"type": "string"},
                "contacto": {"type": "string", "description": "Email o teléfono del candidato"},
                "ubicacion": {"type": "string"},
                "nivel_profesional": {"type": "string", "enum": ["junior", "mid-level", "senior", "lead"]}
            }
        },
        "evaluacion_tecnica": {
            "type": "object",
            "properties": {
                "lenguajes_programacion": {
                    "type": "object",
                    "description": "Evaluación de lenguajes de programación (0-10)",
                    "patternProperties": {
                        "^.*$": {"type": "number", "minimum": 0, "maximum": 10}
                    }
                },
                "frameworks": {
                    "type": "object",
                    "description": "Evaluación de frameworks (0-10)",
                    "patternProperties": {
                        "^.*$": {"type": "number", "minimum": 0, "maximum": 10}
                    }
                },
                "bases_datos": {
                    "type": "object",
                    "description": "Evaluación de bases de datos (0-10)",
                    "patternProperties": {
                        "^.*$": {"type": "number", "minimum": 0, "maximum": 10}
                    }
                },
                "devops": {
                    "type": "object",
                    "description": "Evaluación de herramientas DevOps (0-10)",
                    "patternProperties": {
                        "^.*$": {"type": "number", "minimum": 0, "maximum": 10}
                    }
                }
            }
        },
        "experiencia": {
            "type": "object",
            "properties": {
                "anos_total": {"type": "number"},
                "ultimo_puesto": {"type": "string"},
                "proyectos_destacados": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "nombre": {"type": "string"},
                            "tecnologias": {"type": "array", "items": {"type": "string"}},
                            "rol": {"type": "string"},
                            "logros": {"type": "array", "items": {"type": "string"}}
                        }
                    }
                }
            }
        },
        "competencias_blandas": {
            "type": "object",
            "properties": {
                "comunicacion": {"type": "number", "minimum": 0, "maximum": 10},
                "trabajo_equipo": {"type": "number", "minimum": 0, "maximum": 10},
                "liderazgo": {"type": "number", "minimum": 0, "maximum": 10},
                "resolucion_problemas": {"type": "number", "minimum": 0, "maximum": 10},
                "adaptabilidad": {"type": "number", "minimum": 0, "maximum": 10}
            }
        },
        "formacion": {
            "type": "object",
            "properties": {
                "nivel_educativo": {"type": "string"},
                "titulaciones": {"type": "array", "items": {"type": "string"}},
                "certificaciones": {"type": "array", "items": {"type": "string"}}
            }
        },
        "adecuacion_puesto": {
            "type": "object",
            "properties": {
                "puntuacion_global": {"type": "number", "minimum": 0, "maximum": 100},
                "fortalezas": {"type": "array", "items": {"type": "string"}},
                "areas_mejora": {"type": "array", "items": {"type": "string"}},
                "recomendacion": {"type": "string", "enum": ["contratar", "segunda_entrevista", "rechazar"]}
            }
        },
        "comentarios_adicionales": {"type": "string"}
    },
    "required": ["informacion_candidato", "evaluacion_tecnica", "experiencia", "adecuacion_puesto"]
}

def leer_cv_de_archivo(ruta_archivo: str) -> str:
    """Lee el contenido de un archivo de CV."""
    with open(ruta_archivo, 'r', encoding='utf-8') as f:
        return f.read()

def crear_criterios_trabajo_avanzados(puesto: str) -> JobCriteria:
    """
    Define criterios avanzados del trabajo según el puesto.
    
    Args:
        puesto: Nombre del puesto (fullstack, backend, data, devops)
        
    Returns:
        Un objeto JobCriteria con los criterios del trabajo.
    """
    # Mapear tipos de puesto a criterios
    criterios_por_puesto = {
        "fullstack": JobCriteria(
            job_title="Desarrollador Full Stack Senior",
            required_skills=[
                "JavaScript", "React", "Node.js", "Python", "SQL", "Git"
            ],
            preferred_skills=[
                "TypeScript", "AWS", "Docker", "MongoDB", "GraphQL"
            ],
            min_years_experience=5,
            education_level="Ingeniería o similar",
            job_description="Desarrollo full stack de aplicaciones web, diseño de arquitectura de software, implementación de APIs RESTful."
        ),
        "backend": JobCriteria(
            job_title="Ingeniero Backend Senior",
            required_skills=[
                "Python", "Django/Flask", "SQL", "Docker", "Git"
            ],
            preferred_skills=[
                "Go", "Kubernetes", "AWS", "Microservicios", "RabbitMQ/Kafka"
            ],
            min_years_experience=5,
            education_level="Ingeniería o similar",
            job_description="Desarrollo de servicios backend escalables, diseño e implementación de APIs, optimización de bases de datos."
        ),
        "data": JobCriteria(
            job_title="Data Scientist Senior",
            required_skills=[
                "Python", "SQL", "Pandas", "Scikit-learn", "TensorFlow/PyTorch"
            ],
            preferred_skills=[
                "Spark", "AWS", "Docker", "NLP", "Computer Vision"
            ],
            min_years_experience=4,
            education_level="Ingeniería, Matemáticas, Estadística o similar",
            job_description="Desarrollo de modelos de machine learning, análisis y visualización de datos, implementación de pipelines de datos."
        ),
        "devops": JobCriteria(
            job_title="DevOps Engineer Senior",
            required_skills=[
                "Linux", "Docker", "Kubernetes", "AWS/Azure", "CI/CD"
            ],
            preferred_skills=[
                "Terraform", "Ansible", "Python", "Prometheus", "ELK Stack"
            ],
            min_years_experience=5,
            education_level="Ingeniería o similar",
            job_description="Implementación y gestión de infraestructura como código, configuración de pipelines CI/CD, gestión de clusters Kubernetes."
        )
    }
    
    return criterios_por_puesto.get(puesto, criterios_por_puesto["fullstack"])

def main():
    """Función principal del ejemplo avanzado."""
    # Configurar argumentos de línea de comandos
    parser = argparse.ArgumentParser(description='Análisis avanzado de CVs con esquemas JSON personalizados')
    parser.add_argument('--puesto', choices=['fullstack', 'backend', 'data', 'devops'], default='fullstack',
                        help='Puesto para el que se analizará el CV')
    args = parser.parse_args()
    
    # Configuración del cliente CV Screening
    azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    azure_api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not azure_endpoint or not azure_api_key:
        print("Error: Se requieren las variables de entorno AZURE_OPENAI_ENDPOINT y AZURE_OPENAI_API_KEY.")
        return
    
    # Crear instancia del cliente
    client = CVScreeningClient(
        endpoint=azure_endpoint,
        api_key=azure_api_key,
        model_name="gpt-4",
        temperature=0.1
    )
    
    # CV de ejemplo para desarrollador full stack
    cv_desarrollador = """
    CARLOS MARTÍNEZ
    Desarrollador Full Stack
    carlos.martinez@email.com | +34 612 345 678 | Madrid, España
    
    EXPERIENCIA PROFESIONAL
    
    TechSolutions Inc. (2018-Presente)
    Senior Full Stack Developer
    - Lideré el desarrollo de una plataforma SaaS utilizando React, Node.js y MongoDB
    - Implementé CI/CD con GitHub Actions y Docker
    - Desarrollé APIs RESTful con Express y GraphQL
    - Mejoré el rendimiento de la aplicación en un 40%
    
    WebDev Company (2015-2018)
    Full Stack Developer
    - Desarrollé aplicaciones web con Angular y Laravel
    - Implementé bases de datos PostgreSQL y diseñé esquemas optimizados
    - Integré sistemas de pago y autenticación OAuth
    
    EDUCACIÓN
    
    Universidad Politécnica - Ingeniería Informática (2011-2015)
    
    CERTIFICACIONES
    - AWS Certified Developer
    - MongoDB Certified Developer
    
    HABILIDADES TÉCNICAS
    - Frontend: JavaScript, TypeScript, React, Angular, HTML5, CSS3, SASS
    - Backend: Node.js, Express, PHP, Laravel, Python, Django
    - Bases de datos: MongoDB, PostgreSQL, MySQL, Redis
    - DevOps: Docker, Kubernetes, AWS, CI/CD, Git
    
    PROYECTOS DESTACADOS
    
    Sistema de Gestión de Inventario (2020)
    - Aplicación full stack para gestión de inventario en tiempo real
    - Tecnologías: React, Node.js, Socket.io, MongoDB
    - Implementado en múltiples empresas con más de 200 usuarios activos
    
    Plataforma E-learning (2019)
    - LMS completo con sistema de videoconferencia integrado
    - Tecnologías: React, Express, PostgreSQL, WebRTC
    - Más de 1000 estudiantes activos
    
    IDIOMAS
    - Español (nativo)
    - Inglés (avanzado)
    """
    
    # CV de ejemplo para científico de datos
    cv_data_scientist = """
    LAURA GARCÍA
    Data Scientist
    laura.garcia@email.com | +34 698 765 432 | Barcelona, España
    
    EXPERIENCIA PROFESIONAL
    
    Data Intelligence (2019-Presente)
    Senior Data Scientist
    - Desarrollo de modelos predictivos para el sector financiero
    - Implementación de algoritmos de NLP para análisis de sentimiento
    - Creación de dashboards interactivos para visualización de datos
    - Optimización de modelos de machine learning que redujeron costes en un 30%
    
    Analytics Company (2017-2019)
    Data Analyst
    - Análisis de grandes volúmenes de datos con Python y SQL
    - Desarrollo de informes automatizados con Tableau
    - Implementación de modelos estadísticos para detección de anomalías
    
    EDUCACIÓN
    
    Universidad de Barcelona - Master en Data Science (2015-2017)
    Universidad de Valencia - Grado en Matemáticas (2011-2015)
    
    CERTIFICACIONES
    - TensorFlow Developer Certificate
    - Microsoft Certified: Azure Data Scientist Associate
    
    HABILIDADES TÉCNICAS
    - Lenguajes: Python, R, SQL
    - Machine Learning: Scikit-learn, TensorFlow, PyTorch, XGBoost
    - Big Data: Spark, Hadoop
    - Visualización: Tableau, PowerBI, Matplotlib, Seaborn
    - Cloud: AWS, Azure
    
    PROYECTOS DESTACADOS
    
    Sistema de Recomendación (2020)
    - Implementación de algoritmos de recomendación para e-commerce
    - Tecnologías: Python, TensorFlow, AWS
    - Incremento del 25% en conversión de ventas
    
    Detección de Fraude (2019)
    - Sistema de detección de transacciones fraudulentas en tiempo real
    - Tecnologías: Python, Spark, Kafka
    - Reducción del 60% en falsos positivos
    
    IDIOMAS
    - Español (nativo)
    - Inglés (avanzado)
    - Francés (intermedio)
    """
    
    # Seleccionar CV de ejemplo según el puesto
    if args.puesto == 'data':
        cv_content = cv_data_scientist
    else:
        cv_content = cv_desarrollador
    
    # Definir criterios del trabajo según el puesto
    criterios = crear_criterios_trabajo_avanzados(args.puesto)
    
    print(f"ANALIZANDO CV PARA PUESTO DE {criterios.job_title.upper()}")
    print("=" * 60)
    print(f"Utilizando esquema JSON personalizado para la industria tecnológica")
    print("-" * 60)
    
    # Analizar CV usando esquema avanzado
    resultado = client.analyze_cv(
        content=cv_content,
        criteria=criterios,
        schema_json_ob=ESQUEMA_INDUSTRIA_TECH
    )
    
    # Guardar el resultado en un archivo JSON
    nombre_archivo = f"analisis_{args.puesto}.json"
    with open(nombre_archivo, 'w', encoding='utf-8') as f:
        json.dump(resultado, f, indent=2, ensure_ascii=False)
    
    print(f"Análisis completado y guardado en '{nombre_archivo}'")
    
    # Mostrar resumen del resultado
    print("\nRESUMEN DEL ANÁLISIS:")
    print("-" * 60)
    
    try:
        if 'informacion_candidato' in resultado and 'nombre' in resultado['informacion_candidato']:
            print(f"Candidato: {resultado['informacion_candidato']['nombre']}")
        
        if 'adecuacion_puesto' in resultado:
            adecuacion = resultado['adecuacion_puesto']
            if 'puntuacion_global' in adecuacion:
                print(f"Puntuación global: {adecuacion['puntuacion_global']}/100")
            
            if 'recomendacion' in adecuacion:
                recomendacion = adecuacion['recomendacion']
                estado = {
                    'contratar': '✅ CONTRATAR',
                    'segunda_entrevista': '🔄 SEGUNDA ENTREVISTA',
                    'rechazar': '❌ RECHAZAR'
                }.get(recomendacion, recomendacion)
                print(f"Recomendación: {estado}")
            
            if 'fortalezas' in adecuacion and adecuacion['fortalezas']:
                print("\nFortalezas principales:")
                for fortaleza in adecuacion['fortalezas'][:3]:
                    print(f"  ✓ {fortaleza}")
            
            if 'areas_mejora' in adecuacion and adecuacion['areas_mejora']:
                print("\nÁreas de mejora:")
                for area in adecuacion['areas_mejora'][:3]:
                    print(f"  ✗ {area}")
        
        print("\nPara ver el análisis completo, consulte el archivo:", nombre_archivo)
        
    except Exception as e:
        print(f"Error al mostrar el resumen: {str(e)}")
        print("Consulte el archivo JSON para ver el análisis completo.")

if __name__ == "__main__":
    main() 