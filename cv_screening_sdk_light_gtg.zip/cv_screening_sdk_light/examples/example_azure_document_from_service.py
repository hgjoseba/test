"""
Example of loading CV content directly from an Azure service with authentication.

This example demonstrates:
1. Using Azure authentication via AzureAuthProvider
2. Fetching CV content directly from an Azure service using the enhanced load_cv_from_base64 function
3. Processing the CV with the screening client
"""

import os
import logging

from src.cv_screening import CVScreeningClient
from src.auth.azure import AzureAuthProvider
from src.utils.document import load_cv_from_base64
from src.models.criteria import JobCriteria

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Azure Service Principal credentials from environment variables
tenant_id = os.environ.get("AZURE_TENANT_ID")
client_id = os.environ.get("AZURE_CLIENT_ID")
client_secret = os.environ.get("AZURE_CLIENT_SECRET")
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")

# Azure resource URL - this should point to your specific Azure service endpoint
# that returns CV content (as plain text)
azure_resource_url = os.environ.get("AZURE_RESOURCE_URL")

# Additional parameters for the Azure request if needed
azure_params = {
    "documentId": os.environ.get("DOCUMENT_ID", "sample-cv"),
    # Add any additional parameters required by your Azure service
}

def main():
    """Main function to demonstrate loading CV from Azure service."""
    try:
        # Step 1: Initialize Azure Auth Provider
        logger.info("Initializing Azure authentication provider")
        azure_auth = AzureAuthProvider(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        
        # Step 2: Load CV content directly from Azure service
        logger.info(f"Loading CV content from Azure service: {azure_resource_url}")
        cv_content = load_cv_from_base64(
            azure_auth=azure_auth,
            azure_resource_url=azure_resource_url,
            azure_params=azure_params
        )
        
        logger.info(f"Successfully loaded CV content, length: {len(cv_content)} characters")
        
        # Optional - print a preview of the CV content
        if cv_content:
            preview_length = min(200, len(cv_content))
            logger.info(f"CV content preview: {cv_content[:preview_length]}...")
        
        # Step 3: Get authentication token for the CV Screening Client
        token = azure_auth.get_token()
        
        # Step 4: Initialize CV Screening Client
        logger.info("Initializing CV Screening Client")
        client = CVScreeningClient(
            api_key=token,  # Use token as API key
            endpoint=endpoint,
            model_name="gpt-4",  # or your specific deployment name
            temperature=0.1,
        )
        
        # Step 5: Define job criteria
        job_criteria = JobCriteria(
            title="Software Engineer",
            description="""
            We are looking for a skilled Software Engineer to join our development team.
            The ideal candidate has experience with Python, cloud services, and API development.
            Strong problem-solving skills and attention to detail are essential.
            """,
            required_skills=["Python", "REST APIs", "Git", "Cloud services"],
            preferred_skills=["Azure", "Docker", "Kubernetes", "CI/CD"],
            minimum_years_experience=3,
            education="Bachelor's degree in Computer Science or related field"
        )
        
        # Step 6: Analyze the CV with the client
        logger.info("Analyzing CV against job criteria")
        result = client.analyze_cv(
            cv_content=cv_content,
            job_criteria=job_criteria
        )
        
        # Step 7: Print analysis results
        logger.info("CV Analysis Results:")
        logger.info(f"Match score: {result.score}")
        logger.info(f"Decision: {result.decision}")
        logger.info(f"Summary:\n{result.summary}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error in CV analysis: {str(e)}", exc_info=True)
        raise

if __name__ == "__main__":
    main() 