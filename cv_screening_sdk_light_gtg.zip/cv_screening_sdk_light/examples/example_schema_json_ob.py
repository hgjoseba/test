#!/usr/bin/env python3
"""
Ejemplo de uso de CV Screening SDK con esquemas JSON personalizados.

Este ejemplo muestra cómo analizar CVs usando esquemas JSON personalizados 
que se pasan como argumentos al cliente de CV Screening.
"""

import os
import json
from typing import Dict, Any, List

# Importar el cliente principal de CV Screening
from src.cv_screening import CVScreeningClient
from src.core.types import ContentType
from src.models.criteria import JobCriteria

# Definir esquema JSON personalizado para análisis de CV individual
MI_ESQUEMA_PERSONALIZADO = {
    "type": "object",
    "properties": {
        "puntuacion_general": {"type": "number", "description": "Puntuación general del candidato (0-100)"},
        "habilidades": {
            "type": "object",
            "properties": {
                "habilidades_tecnicas": {"type": "array", "items": {"type": "string"}},
                "habilidades_blandas": {"type": "array", "items": {"type": "string"}},
                "nivel_experiencia": {"type": "string", "enum": ["junior", "mid", "senior"]}
            }
        },
        "adecuacion_al_puesto": {"type": "number", "description": "Adecuación al puesto (0-100)"},
        "comentarios": {"type": "string", "description": "Comentarios generales sobre el CV"}
    },
    "required": ["puntuacion_general", "habilidades", "adecuacion_al_puesto"]
}

def leer_cv_de_archivo(ruta_archivo: str) -> str:
    """
    Lee el contenido de un archivo de CV.
    
    Args:
        ruta_archivo: Ruta al archivo de CV.
        
    Returns:
        El contenido del CV como texto.
    """
    with open(ruta_archivo, 'r', encoding='utf-8') as f:
        return f.read()

def crear_criterios_trabajo() -> JobCriteria:
    """
    Define los criterios del trabajo para analizar los CVs.
    
    Returns:
        Un objeto JobCriteria con los criterios del trabajo.
    """
    return JobCriteria(
        job_title="Desarrollador Python Senior",
        required_skills=[
            "Python", 
            "Django", 
            "SQL",
            "Git"
        ],
        preferred_skills=[
            "Docker", 
            "AWS", 
            "FastAPI", 
            "Machine Learning"
        ],
        min_years_experience=5,
        education_level="Ingeniería o similar",
        job_description="Buscamos un desarrollador Python con experiencia en desarrollo web y APIs."
    )

def main():
    """Función principal del ejemplo."""
    # Configuración del cliente CV Screening
    azure_endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
    azure_api_key = os.environ.get("AZURE_OPENAI_API_KEY")
    
    if not azure_endpoint or not azure_api_key:
        print("Error: Se requieren las variables de entorno AZURE_OPENAI_ENDPOINT y AZURE_OPENAI_API_KEY.")
        return
        
    # Crear instancia del cliente
    client = CVScreeningClient(
        endpoint=azure_endpoint,
        api_key=azure_api_key,
        model_name="gpt-4",
        temperature=0.1
    )
    
    # Leer CV de ejemplo
    try:
        cv_content = leer_cv_de_archivo("examples/data/example_cv.txt")
    except FileNotFoundError:
        print("Error: No se encontró el archivo CV de ejemplo. Creando un CV de ejemplo.")
        # CV de ejemplo si no se encuentra el archivo
        cv_content = """
        JUAN PÉREZ
        Desarrollador de Software
        
        EXPERIENCIA PROFESIONAL
        
        ABC Technologies (2018-Presente)
        Desarrollador Senior
        - Desarrollo de APIs RESTful usando Python y Django
        - Gestión de bases de datos SQL y NoSQL
        - Implementación de Docker y Kubernetes para despliegues
        
        XYZ Solutions (2015-2018)
        Desarrollador Python
        - Desarrollo backend con Flask
        - Integración con APIs de terceros
        - Implementación de tests automatizados
        
        EDUCACIÓN
        
        Universidad Técnica - Ingeniería en Informática (2011-2015)
        
        HABILIDADES
        Python, Django, Flask, SQL, MongoDB, Git, Docker, AWS
        """
    
    # Definir criterios del trabajo
    criterios = crear_criterios_trabajo()
    
    print("1. ANALIZANDO CV CON ESQUEMA JSON PERSONALIZADO")
    print("------------------------------------------------")
    
    # Analizar CV usando esquema personalizado
    resultado = client.analyze_cv(
        content=cv_content,
        criteria=criterios,
        schema_json_ob=MI_ESQUEMA_PERSONALIZADO
    )
    
    # Imprimir resultado
    print(json.dumps(resultado, indent=2, ensure_ascii=False))
    print("\n")
    
    print("2. ANALIZANDO MÚLTIPLES CVs CON ESQUEMA JSON PERSONALIZADO")
    print("----------------------------------------------------------")
    
    # Crear lista de CVs de ejemplo
    cvs = [
        cv_content,
        # Añadir un segundo CV de ejemplo
        """
        ANA RODRÍGUEZ
        Data Scientist
        
        EXPERIENCIA PROFESIONAL
        
        Data Insights (2019-Presente)
        Data Scientist Senior
        - Desarrollo de modelos de machine learning con scikit-learn y TensorFlow
        - Análisis y visualización de datos con Python y PowerBI
        - Implementación de pipelines de datos
        
        Data Solutions (2017-2019)
        Data Analyst
        - Análisis de datos con Python y R
        - Desarrollo de dashboards
        
        EDUCACIÓN
        
        Universidad Central - Ingeniería en Estadística (2013-2017)
        
        HABILIDADES
        Python, R, SQL, Machine Learning, TensorFlow, PowerBI, Git
        """
    ]
    
    # Definir esquema JSON personalizado para análisis de múltiples CVs
    MI_ESQUEMA_MULTIPLE_PERSONALIZADO = {
        "type": "array",
        "items": {
            "type": "object",
            "properties": {
                "cv_index": {"type": "integer", "description": "Índice del CV"},
                "nombre_candidato": {"type": "string", "description": "Nombre del candidato extraído del CV"},
                "puntuacion": {"type": "number", "description": "Puntuación general (0-100)"},
                "fortalezas": {"type": "array", "items": {"type": "string"}},
                "debilidades": {"type": "array", "items": {"type": "string"}},
                "recomendacion": {"type": "string", "enum": ["contratar", "considerar", "rechazar"]}
            },
            "required": ["cv_index", "puntuacion", "recomendacion"]
        }
    }
    
    # Analizar múltiples CVs usando esquema personalizado
    resultados = client.analyze_multiple_cvs(
        contents=cvs,
        criteria=criterios,
        schema_json_ob=MI_ESQUEMA_MULTIPLE_PERSONALIZADO
    )
    
    # Imprimir resultados
    print(json.dumps(resultados, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main() 