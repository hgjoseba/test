"""
Example of CV screening using Azure token authentication with SSL verification disabled.

This example demonstrates how to use Azure token authentication while disabling
SSL verification, which is useful in corporate environments with SSL inspection,
proxies, or self-signed certificates.
"""

import os
import warnings
from src.cv_screening import CVScreeningClient
from src.core.types import ContentType
from src.models.criteria import JobCriteria
from src.auth.azure import AzureAuthProvider
from src.core.exceptions import AuthenticationError, OpenAIError

# Suppress SSL verification warnings - only use this in controlled environments
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# Azure Service Principal credentials
tenant_id = os.environ.get("AZURE_TENANT_ID", "your-tenant-id")
client_id = os.environ.get("AZURE_CLIENT_ID", "your-client-id")
client_secret = os.environ.get("AZURE_CLIENT_SECRET", "your-client-secret")
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "https://your-resource-name.openai.azure.com")

# Create Azure Auth Provider with SSL verification disabled
print("Initializing Azure Auth Provider with SSL verification disabled...")
azure_auth = AzureAuthProvider(
    tenant_id=tenant_id,
    client_id=client_id,
    client_secret=client_secret,
    connection_verify=False  # Disable SSL verification
)

try:
    # Get token from the authentication provider
    print("Obtaining authentication token from Azure...")
    token = azure_auth.get_token()
    print("Token obtained successfully")
    
    # Create the CV Screening client with token and SSL verification disabled
    print("Initializing CV Screening client with SSL verification disabled...")
    client = CVScreeningClient(
        api_key=token,  # Use token as API key
        endpoint=endpoint,
        model_name="gpt-4",  # or your specific deployment name
        connection_verify=False  # Disable SSL verification for the client too
    )
    
    # Define simple job criteria as a dictionary
    criteria = {
        "job_title": "Network Security Engineer",
        "job_description": "Looking for a network security professional with experience in corporate environments",
        "required_skills": ["Firewall Management", "VPN Configuration", "Network Security", "SSL/TLS"],
        "preferred_skills": ["Proxy Servers", "Certificate Management", "Enterprise Security"],
        "min_years_experience": 3
    }
    
    # Sample CV content
    cv_content = """
    SARAH PARKER
    Network Security Engineer
    sarah.parker@example.com | (555) 123-4567
    
    SKILLS
    - Network Security: Firewalls, VPNs, Proxies, IDS/IPS
    - Protocols: TCP/IP, HTTP/S, SSL/TLS
    - Products: Cisco ASA, Palo Alto, FortiGate, Juniper SRX
    - Tools: Wireshark, Nmap, Snort, Nagios
    - Certifications: CISSP, CCNP Security, CEH
    
    EXPERIENCE
    Senior Network Security Engineer | SecureNet Inc. | 2019 - Present
    - Managed enterprise firewall infrastructure for Fortune 500 clients
    - Implemented SSL inspection solution reducing security incidents by 40%
    - Designed and deployed corporate VPN solutions for 5,000+ remote users
    - Created and maintained security policies and procedures
    
    Network Engineer | TechDefense LLC | 2016 - 2019
    - Configured and maintained VPN tunnels and firewall rules
    - Performed regular security audits and vulnerability assessments
    - Implemented network monitoring solutions
    
    EDUCATION
    Master of Science in Cybersecurity | University of Technology | 2014-2016
    Bachelor of Science in Computer Networks | State University | 2010-2014
    """
    
    # Analyze CV
    print("Analyzing CV...")
    result = client.analyze_cv(
        content=cv_content,
        criteria=criteria,
        content_type=ContentType.TEXT
    )
    
    # Print results
    print("\nCV Analysis Results:")
    print(f"Overall Match: {result.get('overall_match', 'N/A')}%")
    
    # Print detailed skill matching
    if 'skills_match' in result:
        skills = result['skills_match']
        
        print("\nRequired Skills Match:")
        for skill, score in skills.get('required_skills', {}).items():
            recommendation = ""
            if score < 0.3:
                recommendation = "- Consider acquiring this skill"
            elif score < 0.7:
                recommendation = "- Has some experience, but could improve"
                
            print(f"  {skill}: {score:.2f} {recommendation}")
            
        print("\nPreferred Skills Match:")
        for skill, score in skills.get('preferred_skills', {}).items():
            print(f"  {skill}: {score:.2f}")
            
        if skills.get('missing_required'):
            print("\nMissing Critical Skills:")
            for skill in skills['missing_required']:
                print(f"  - {skill} (required but not found)")
    
    # Print overall recommendation
    if 'summary' in result:
        print(f"\nSummary: {result['summary']}")

except AuthenticationError as e:
    print(f"Authentication Error: {e}")
    print("Please check your Azure credentials and try again.")
    
except OpenAIError as e:
    print(f"OpenAI API Error: {e}")
    print("There was an issue with the CV analysis service.")
    
except Exception as e:
    print(f"Unexpected Error: {e}")
    print("Make sure your corporate network allows connections to Azure OpenAI Services.")
    print("If you're behind a proxy, you may need to configure additional proxy settings.")
    
finally:
    print("\nNote: Disabling SSL verification reduces security. Only use in controlled environments.")
    print("      For production, configure proper certificates instead of disabling verification.") 