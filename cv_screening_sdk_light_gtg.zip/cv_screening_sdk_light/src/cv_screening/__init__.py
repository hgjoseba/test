"""
CV Screening SDK - Main Package

This package provides functionality for analyzing curricula vitae (CVs) using
language models from OpenAI through Azure OpenAI Service.
"""

from .client import CVScreeningClient
from .utils.rate_limiting import (
    RateLimiter, DistributedRateLimiter, TokenCounter, 
    backoff_on_exception, backoff_on_predicate
)

__version__ = "0.1.0"
__all__ = [
    "CVScreeningClient",
    "RateLimiter",
    "DistributedRateLimiter",
    "TokenCounter",
    "backoff_on_exception",
    "backoff_on_predicate"
] 