#!/usr/bin/env python3

"""
Ejemplo simple del SDK que muestra el uso del parámetro base_model
"""

import os
import json
from src.cv_screening import CVScreeningClient
from src.cv_screening import ContentType

# Configura las credenciales desde variables de entorno (o configura aquí directamente)
endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT")
api_key = os.environ.get("AZURE_OPENAI_API_KEY")

# Ejemplo de CV
cv_python_senior = """
JUAN PÉREZ
Desarrollador Senior Python

EXPERIENCIA
- 7 años como desarrollador Python en Empresa ABC (2016-2023)
- 3 años como desarrollador web en XYZ Tech (2013-2016)

HABILIDADES
- Python, Django, Flask, FastAPI
- JavaScript, React
- Docker, Kubernetes
- AWS, Azure

EDUCACIÓN
- Ingeniería Informática, Universidad de Barcelona (2010-2014)
"""

# Criterios para el puesto
job_criteria = {
    "required_skills": ["Python", "Django", "API", "Docker"],
    "preferred_skills": ["AWS", "Kubernetes", "React"],
    "min_years_experience": 5,
    "education": "Ingeniería Informática o similar"
}

def test_base_model_inference():
    """Prueba la inferencia del modelo base a partir del nombre del despliegue"""
    print("\n===== EJEMPLO 1: Inferencia del modelo base =====")
    
    try:
        # Crear cliente con un nombre de despliegue que permita inferir el modelo base
        client = CVScreeningClient(
            endpoint=endpoint,
            api_key=api_key,
            deployment_name="mi-gpt4-deploy",  # Debería inferir "gpt-4"
            temperature=0.1
        )
        
        print(f"Base model inferido: {client.provider.base_model}")
        print(f"¿Es capaz de JSON schema?: {client.provider._is_model_schema_capable()}")
        print("Inferencia exitosa\n")
    except Exception as e:
        print(f"Error: {str(e)}")

def test_explicit_base_model():
    """Prueba especificar explícitamente el modelo base"""
    print("\n===== EJEMPLO 2: Modelo base explícito =====")
    
    try:
        # Crear cliente especificando el modelo base
        client = CVScreeningClient(
            endpoint=endpoint,
            api_key=api_key,
            deployment_name="deployment-personalizado",  # Nombre que no permitiría inferir el modelo
            base_model="gpt-4",  # Especificamos explícitamente el modelo base
            temperature=0.1
        )
        
        print(f"Base model explícito: {client.provider.base_model}")
        print(f"¿Es capaz de JSON schema?: {client.provider._is_model_schema_capable()}")
        print("Configuración exitosa con base_model explícito\n")
    except Exception as e:
        print(f"Error: {str(e)}")

def main():
    print("Ejemplos de uso del parámetro base_model")
    
    if not endpoint or not api_key:
        print("ERROR: Debes configurar AZURE_OPENAI_ENDPOINT y AZURE_OPENAI_API_KEY como variables de entorno")
        return
    
    test_base_model_inference()
    test_explicit_base_model()
    
    print("Ejemplos completados.")

if __name__ == "__main__":
    main() 