"""
Authentication modules for CV Screening SDK Light.

This package provides authentication capabilities for different services.
"""

from .azure import AzureCredentials, AzureAuthProvider

__all__ = ["AzureCredentials", "AzureAuthProvider"] 