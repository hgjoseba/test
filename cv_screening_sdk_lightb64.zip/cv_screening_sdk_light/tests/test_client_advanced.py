import unittest
import io
import base64
from unittest.mock import patch, MagicMock

from src.client import CVScreeningClient
from src.core.exceptions import ConfigurationError, OpenAIError, DocumentParsingError
from src.core.types import ContentType
from src.models.criteria import JobCriteria


class TestCVScreeningClientAdvanced(unittest.TestCase):
    """Pruebas avanzadas para el CVScreeningClient para mejorar la cobertura de pruebas."""

    @patch('src.client.AzureOpenAIProvider')
    def setUp(self, mock_provider_class):
        """Configurar el entorno de prueba."""
        self.mock_provider = MagicMock()
        mock_provider_class.return_value = self.mock_provider
        
        # Simular variables de entorno para pruebas
        with patch.dict('os.environ', {
            'AZURE_OPENAI_API_KEY': 'test-api-key',
            'AZURE_OPENAI_ENDPOINT': 'https://test-endpoint.com'
        }):
            self.client = CVScreeningClient()
    
    def test_analyze_multiple_cvs_text(self):
        """Probar analyze_multiple_cvs con contenido de texto."""
        # Configurar mock
        self.mock_provider.analyze_multiple_cvs.return_value = [{"match": 0.8}, {"match": 0.6}]
        
        # Ejecutar prueba
        result = self.client.analyze_multiple_cvs(
            ["CV content 1", "CV content 2"],
            {"required_skills": ["Python"]},
            ContentType.TEXT
        )
        
        # Verificar
        self.mock_provider.analyze_multiple_cvs.assert_called_once_with(
            contents=["CV content 1", "CV content 2"],
            criteria={"required_skills": ["Python"]},
            batch_size=None,
            schema_json_ob=None
        )
        self.assertEqual(result, [{"match": 0.8}, {"match": 0.6}])
    
    def test_analyze_multiple_cvs_base64(self):
        """Probar analyze_multiple_cvs con contenido base64."""
        # Crear contenido base64
        cv_text1 = "CV content 1"
        cv_text2 = "CV content 2"
        cv_base64_1 = base64.b64encode(cv_text1.encode('utf-8')).decode('utf-8')
        cv_base64_2 = base64.b64encode(cv_text2.encode('utf-8')).decode('utf-8')
        
        # Configurar mock
        self.mock_provider.analyze_multiple_cvs.return_value = [{"match": 0.9}, {"match": 0.7}]
        
        # Ejecutar prueba
        result = self.client.analyze_multiple_cvs(
            [cv_base64_1, cv_base64_2],
            {"required_skills": ["Python"]},
            ContentType.BASE64
        )
        
        # Verificar
        self.mock_provider.analyze_multiple_cvs.assert_called_once_with(
            contents=[cv_text1, cv_text2],
            criteria={"required_skills": ["Python"]},
            batch_size=None,
            schema_json_ob=None
        )
        self.assertEqual(result, [{"match": 0.9}, {"match": 0.7}])
    
    @patch('src.client.load_cv_content')
    def test_analyze_multiple_cvs_file_path(self, mock_load_cv_content):
        """Probar analyze_multiple_cvs con rutas de archivo."""
        # Configurar mock para simular la carga de archivos
        mock_load_cv_content.side_effect = ["CV content from file 1", "CV content from file 2"]
        self.mock_provider.analyze_multiple_cvs.return_value = [{"match": 0.7}, {"match": 0.5}]
        
        # Ejecutar prueba
        result = self.client.analyze_multiple_cvs(
            ["path/to/cv1.pdf", "path/to/cv2.pdf"],
            {"required_skills": ["Python"]},
            ContentType.FILE_PATH
        )
        
        # Verificar
        self.assertEqual(mock_load_cv_content.call_count, 2)
        mock_load_cv_content.assert_any_call("path/to/cv1.pdf")
        mock_load_cv_content.assert_any_call("path/to/cv2.pdf")
        
        self.mock_provider.analyze_multiple_cvs.assert_called_once_with(
            contents=["CV content from file 1", "CV content from file 2"],
            criteria={"required_skills": ["Python"]},
            batch_size=None,
            schema_json_ob=None
        )
        self.assertEqual(result, [{"match": 0.7}, {"match": 0.5}])
    
    def test_analyze_multiple_cvs_with_batch_size(self):
        """Probar analyze_multiple_cvs con tamaño de lote personalizado."""
        # Configurar mock
        self.mock_provider.analyze_multiple_cvs.return_value = [{"match": 0.8}, {"match": 0.7}, {"match": 0.6}]
        
        # Ejecutar prueba
        result = self.client.analyze_multiple_cvs(
            ["CV 1", "CV 2", "CV 3"],
            {"required_skills": ["Python"]},
            ContentType.TEXT,
            batch_size=2
        )
        
        # Verificar
        self.mock_provider.analyze_multiple_cvs.assert_called_once_with(
            contents=["CV 1", "CV 2", "CV 3"],
            criteria={"required_skills": ["Python"]},
            batch_size=2,
            schema_json_ob=None
        )
        self.assertEqual(result, [{"match": 0.8}, {"match": 0.7}, {"match": 0.6}])
    
    def test_analyze_multiple_cvs_with_schema(self):
        """Probar analyze_multiple_cvs con esquema JSON personalizado."""
        # Esquema personalizado
        custom_schema = {
            "type": "object",
            "properties": {
                "score": {"type": "number"},
                "skills": {"type": "array"}
            }
        }
        
        # Configurar mock
        self.mock_provider.analyze_multiple_cvs.return_value = [{"score": 85, "skills": ["Python"]}]
        
        # Ejecutar prueba
        result = self.client.analyze_multiple_cvs(
            ["CV content"],
            {"required_skills": ["Python"]},
            ContentType.TEXT,
            schema_json_ob=custom_schema
        )
        
        # Verificar
        self.mock_provider.analyze_multiple_cvs.assert_called_once_with(
            contents=["CV content"],
            criteria={"required_skills": ["Python"]},
            batch_size=None,
            schema_json_ob=custom_schema
        )
        self.assertEqual(result, [{"score": 85, "skills": ["Python"]}])
    
    def test_analyze_multiple_cvs_with_bytes_content(self):
        """Probar analyze_multiple_cvs con contenido en bytes."""
        # Contenido en bytes
        cv_bytes1 = b"CV content 1"
        cv_bytes2 = b"CV content 2"
        
        # Configurar mock
        self.mock_provider.analyze_multiple_cvs.return_value = [{"match": 0.8}, {"match": 0.7}]
        
        # Ejecutar prueba
        result = self.client.analyze_multiple_cvs(
            [cv_bytes1, cv_bytes2],
            {"required_skills": ["Python"]},
            ContentType.TEXT
        )
        
        # Verificar
        self.mock_provider.analyze_multiple_cvs.assert_called_once_with(
            contents=["CV content 1", "CV content 2"],
            criteria={"required_skills": ["Python"]},
            batch_size=None,
            schema_json_ob=None
        )
        self.assertEqual(result, [{"match": 0.8}, {"match": 0.7}])
    
    def test_analyze_multiple_cvs_provider_error(self):
        """Probar analyze_multiple_cvs cuando el proveedor lanza un error."""
        # Configurar mock para simular un error
        error_message = "API error during batch processing"
        self.mock_provider.analyze_multiple_cvs.side_effect = Exception(error_message)
        
        # Ejecutar prueba
        with self.assertRaises(OpenAIError) as context:
            self.client.analyze_multiple_cvs(
                ["CV 1", "CV 2"],
                {"required_skills": ["Python"]},
                ContentType.TEXT
            )
        
        # Verificar
        self.assertIn("Failed to analyze multiple CVs", str(context.exception))
        self.assertIn(error_message, str(context.exception))
    
    def test_analyze_multiple_cvs_invalid_file_path(self):
        """Probar analyze_multiple_cvs con ruta de archivo inválida."""
        # Configurar mock para simular error de archivo no encontrado
        with patch('src.client.load_cv_content', side_effect=FileNotFoundError("File not found")):
            # Ejecutar prueba
            with self.assertRaises(OpenAIError) as context:
                self.client.analyze_multiple_cvs(
                    ["invalid/path.pdf"],
                    {"required_skills": ["Python"]},
                    ContentType.FILE_PATH
                )
            
            # Verificar
            self.assertIn("Failed to load content from file", str(context.exception))
    
    def test_analyze_multiple_cvs_invalid_base64(self):
        """Probar analyze_multiple_cvs con base64 inválido."""
        # Ejecutar prueba
        with self.assertRaises(OpenAIError) as context:
            self.client.analyze_multiple_cvs(
                ["Invalid base64!"],
                {"required_skills": ["Python"]},
                ContentType.BASE64
            )
        
        # Verificar
        self.assertIn("Failed to decode base64 content", str(context.exception))
    
    @patch('src.client.load_cv_content')
    def test_load_cv_content_invalid_file_path(self, mock_load_cv_content):
        """Probar load_cv_content con ruta de archivo inválida."""
        # Configurar mock para simular error
        mock_load_cv_content.side_effect = FileNotFoundError("File not found")
        
        # Ejecutar prueba
        with self.assertRaises(FileNotFoundError) as context:
            self.client.load_cv_content("invalid/path.pdf", ContentType.FILE_PATH)
        
        # Verificar
        self.assertIn("File not found", str(context.exception))
    
    @patch('src.client.load_cv_from_base64')
    def test_load_cv_content_invalid_base64(self, mock_load_cv_from_base64):
        """Probar load_cv_content con base64 inválido."""
        # Configurar mock para simular error
        mock_load_cv_from_base64.side_effect = Exception("Invalid base64")
        
        # Ejecutar prueba
        with self.assertRaises(DocumentParsingError) as context:
            self.client.load_cv_content("InvalidBase64!", ContentType.BASE64)
        
        # Verificar
        self.assertIn("Failed to decode base64 content", str(context.exception))
    
    def test_load_cv_content_invalid_bytes(self):
        """Probar load_cv_content con bytes inválidos."""
        # Crear bytes con caracteres no decodificables como UTF-8
        invalid_bytes = b"\xff\xfe\xfd"
        
        # Ejecutar prueba
        with self.assertRaises(DocumentParsingError) as context:
            self.client.load_cv_content(invalid_bytes, ContentType.TEXT)
        
        # Verificar
        self.assertIn("Failed to decode content as UTF-8", str(context.exception))
    
    def test_init_with_custom_provider(self):
        """Probar inicialización con un proveedor personalizado."""
        # Crear un proveedor personalizado
        custom_provider = MagicMock()
        
        # Inicializar cliente con proveedor personalizado
        client = CVScreeningClient(custom_provider=custom_provider)
        
        # Verificar que se usó el proveedor personalizado
        self.assertEqual(client.provider, custom_provider) 